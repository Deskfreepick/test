package com.deep.infotech.atm_card_wallet.utils

import android.view.animation.Animation

open class BaseAnimationListener : Animation.AnimationListener {
    override fun onAnimationEnd(animation: Animation) {}
    override fun onAnimationRepeat(animation: Animation) {}
    override fun onAnimationStart(animation: Animation) {}
}