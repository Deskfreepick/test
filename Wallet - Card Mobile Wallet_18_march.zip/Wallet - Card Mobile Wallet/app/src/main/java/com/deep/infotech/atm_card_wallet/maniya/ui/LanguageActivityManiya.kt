package com.deep.infotech.atm_card_wallet.maniya.ui

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.adapter.AdapterLanguage
import com.deep.infotech.atm_card_wallet.databinding.ActivityLanguageManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.model.ModelLanguage
import com.deep.infotech.atm_card_wallet.utils.LocaleHelper

class LanguageActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityLanguageManiyaBinding

    private lateinit var adapter: AdapterLanguage
    private lateinit var languageList: List<ModelLanguage>

    private var currentLanguage: String = "en"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        init()
    }

    private fun changeLanguage() {

        val sharedPreferences = getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE)
        val selectedPosition = adapter.getLastSelectedItem()
        Log.d("TAG++++", "selectedPosition--->: " + selectedPosition)
        if (selectedPosition != -1) {
            val selectedLanguageCode = languageList[selectedPosition].subtitle
            Log.d("TAG++++", "selectedLanguageCode--->: " + selectedLanguageCode)

            val selectedLanguage = languageList[selectedPosition].title
            Log.d("TAG++++", "selectedLanguage--->: " + selectedLanguage)

            if (getSharedPreferences("language", 0).getBoolean("isFirstRun", true)) {
                setLocale(selectedLanguageCode, sharedPreferences, selectedLanguage)
            } else {
                if (selectedLanguageCode != currentLanguage) {
                    setLocale(selectedLanguageCode, sharedPreferences, selectedLanguage)
                }
            }

        }

    }

    private fun init() {
        val sharedPreferences = getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE)
        val selectedCountry = sharedPreferences.getString(SELECTED_COUNTRY_KEY, "en")
        currentLanguage = selectedCountry.toString()
        if (getSharedPreferences("language", 0).getBoolean("isFirstRun", true)) {
            binding.ivLanguageSet.visibility=View.VISIBLE

        }else{
            binding.ivLanguageSet.visibility=View.GONE
        }
        getAllLanguage()
        setAdapter(selectedCountry)
    }

    private fun setAdapter(selectedCountry: String?) {
        adapter = AdapterLanguage(this, languageList) { _, position ->
            adapter.setLastSelectedItem(position)
            if(binding.ivLanguageSet.visibility==View.GONE){
            changeLanguage()}
        }
        binding.rvLanguage.adapter = adapter

        languageList.forEachIndexed { index, languageModel ->
            if (languageModel.subtitle == selectedCountry) {
                adapter.setLastSelectedItem(index)
            }
        }
    }

    private fun getAllLanguage() {
        listOf(
            ModelLanguage(getString(R.string.english),"en", R.drawable.australia_language),
            ModelLanguage(getString(R.string.bengali),"bn", R.drawable.bangladesh_language),
            ModelLanguage(getString(R.string.hindi),"hi", R.drawable.india_language),
            ModelLanguage(title = getString(R.string.japanese), subtitle = "ja", icon = R.drawable.japan_language),
            ModelLanguage(getString(R.string.urdu),"ur", R.drawable.pakistan_language),
            ModelLanguage(getString(R.string.russian),"ru", R.drawable.russia_language),
            ModelLanguage(getString(R.string.arabic),"ar", R.drawable.saudi_arabia_language),
            ModelLanguage(getString(R.string.afrikaans),"af", R.drawable.south_africa_language),
            ModelLanguage(getString(R.string.lao),"lo", R.drawable.laos_language),
            ModelLanguage(getString(R.string.mongolian),"mn", R.drawable.mongolia_language),
            ModelLanguage(getString(R.string.spanish),"es", R.drawable.ecuador_language),
            ModelLanguage(getString(R.string.khmer),"km", R.drawable.cambodia_language),
            ModelLanguage(getString(R.string.burmese),"my", R.drawable.myanmar_language),
            ModelLanguage(getString(R.string.amharic),"am", R.drawable.ethiopia_language),
            ModelLanguage(getString(R.string.nepali),"ne", R.drawable.nepal_language),
            ModelLanguage(getString(R.string.malay),"ms", R.drawable.malaysia_language),
            ModelLanguage(getString(R.string.swahili),"sw", R.drawable.kenya_language),
            ModelLanguage(getString(R.string.vietnamese),"vi", R.drawable.vietnam_language),
            ModelLanguage(getString(R.string.thai),"th", R.drawable.thailand_language),
            ModelLanguage(getString(R.string.uzbek),"uz", R.drawable.uzbekistan_language),
            ModelLanguage(getString(R.string.romanian),"ro", R.drawable.romania_language),
            ModelLanguage(title = getString(R.string.german), subtitle = "de", icon = R.drawable.german_language),
            ModelLanguage(getString(R.string.indonesian),"in", R.drawable.indonesian_language),
            ModelLanguage(getString(R.string.italian),"it", R.drawable.italian_language),
            ModelLanguage(getString(R.string.korean),"ko", R.drawable.korean_language),
            ModelLanguage(getString(R.string.latvian),"lv", R.drawable.latvian_language),
            ModelLanguage(getString(R.string.lithuanian), "lt", R.drawable.klithuanian_language),
            ModelLanguage(getString(R.string.polish),"pl", R.drawable.polish_language),
            ModelLanguage(getString(R.string.portuguese),"pt", R.drawable.portuguese_language),
            ModelLanguage(getString(R.string.serbian), "sr", R.drawable.serbian_language),
            ModelLanguage(getString(R.string.slovak), "sk", R.drawable.slovak_language),
            ModelLanguage(getString(R.string.slovenian), "sl", R.drawable.slovenian_language),
            ModelLanguage(getString(R.string.swedish), "sv", R.drawable.swedish_language),
            ModelLanguage(getString(R.string.turkish), "tr", R.drawable.turkish_language),
            ModelLanguage(getString(R.string.ukrainian), "uk", R.drawable.ukrainian_language),
        ).also { languageList = it }
    }

    private fun setLocale(
        localeCode: String,
        sharedPreferences: SharedPreferences,
        selectedLanguage: String
    ) {
        sharedPreferences.edit().apply {
            putString(SELECTED_COUNTRY_KEY, localeCode)
            putString(SELECTED_LANGUAGE_NAME, selectedLanguage)
            apply()
        }

        LocaleHelper.setLocale(this, localeCode)
        recreate()
        LocaleHelper.updateLocaleAndRefreshUI(this, localeCode)

        val intent = Intent(this, TESTMainActivityManiya::class.java)
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
        getSharedPreferences("language", 0).edit().putBoolean("isFirstRun", false).apply()

    }

    override fun onBackPressed() {
        finish()
    }

    override fun onResume() {
        super.onResume()
        showNativeBannerAdsSecond()
    }

    fun onClickLanguageSet(view: View) {
        changeLanguage()
    }
}