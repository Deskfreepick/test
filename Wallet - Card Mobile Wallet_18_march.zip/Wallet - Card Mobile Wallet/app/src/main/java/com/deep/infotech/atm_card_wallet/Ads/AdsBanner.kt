package com.deep.infotech.atm_card_wallet.Ads

import android.app.Activity
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.ump.ConsentInformation
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.banner_ad_first_ad_network
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.banner_rotated_ad_network
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.fb_banner_show_ads
import com.deep.infotech.atm_card_wallet.Ads.AdsOpenApp.Companion.verifyForTest
import com.deep.infotech.atm_card_wallet.Ads.GDPRChecker.Companion.status
import com.deep.infotech.atm_card_wallet.utils.LogD
import com.deep.infotech.atm_card_wallet.utils.LogE

class AdsBanner {

    var admobBanner: AdView? = null
    var fbBanner1: com.facebook.ads.AdView? = null

    companion object {
        var adsBanner = AdsBanner()
        private const val LOG_TAG = "AdBanner++++"

    }


    fun bannerPreloadAds(activity: Activity, adBanner: RelativeLayout, fbBanner: LinearLayout, relativeLayout: RelativeLayout, ad_Banner: String, re_ad_Banner: String, fb_ad_Banner: String) {
        if (!banner_rotated_ad_network) {
            if (!fb_banner_show_ads) {
                showAdmobBannerAd(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
            } else {
                showFbBannerAds(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
            }
        } else {
            showAdmobBannerAd(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
            showFbBannerAds(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
        }
    }

    fun showAdmobBannerAd(activity: Activity, adBanner: RelativeLayout, fbBanner: LinearLayout, relativeLayout: RelativeLayout, ad_Banner: String, re_ad_Banner: String, fb_ad_Banner: String) {

    /*val adIds = listOf(ad_Banner, re_ad_Banner, fb_ad_Banner)*/


        val adIds: List<String>

        if(!verifyForTest(activity!!)){
            adIds = listOf("/6499/example/banner909", "/6499/example/banner909", fb_ad_Banner)
        } else {
            adIds = listOf(ad_Banner, re_ad_Banner, fb_ad_Banner)
        }
        var currentAdIndex = 0

        fun loadAd(){

            if (currentAdIndex >= adIds.size) {
                relativeLayout.visibility = View.GONE
                LogD(LOG_TAG, "All ads failed to load.")
                return
            }

            val adView = AdView(activity)
            adView.adUnitId = adIds[currentAdIndex]
            val adSize = getFullWidthAdaptiveSize(activity)
            adView.setAdSize(adSize)

            adView.adListener = object : AdListener() {

                override fun onAdClicked() {
                    showAdmobBannerAd(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
                    AdsIDS.when_click_ads = false
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {

                    LogD(LOG_TAG, "Ad failed to load for ID: ${adIds[currentAdIndex]} - ${adError.message}")
                    currentAdIndex++
                    if (fb_banner_show_ads){
                        if (currentAdIndex < adIds.size - 1) {
                            relativeLayout.visibility = View.VISIBLE
                            loadAd()
                        } else {
                            relativeLayout.visibility = View.GONE
                        }
                    }else {
                        if (currentAdIndex < adIds.size - 1) {
                            relativeLayout.visibility = View.VISIBLE
                            loadAd()
                        } else {
                            showFbBannerAds(activity, adBanner, fbBanner, relativeLayout, ad_Banner, re_ad_Banner, fb_ad_Banner)
                        }
                    }
                }

                override fun onAdLoaded() {
                    admobBanner = adView
                    showBanner(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
                    LogD(LOG_TAG, "Ad loaded successfully for ID: ${adIds[currentAdIndex]}")
                }
            }

            val adAdRequest: AdRequest.Builder = AdRequest.Builder()
            val request = status
            if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
                val extras = Bundle()
                extras.putString("npa", "1")
                adAdRequest.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
            }
            adView.loadAd(adAdRequest.build())
        }

        loadAd()
    }


    private fun showFbBannerAds(activity: Activity, ad_banner: RelativeLayout, fb_layout_Banner: LinearLayout, relativeLayout: RelativeLayout, ad_Banner: String, re_ad_Banner: String, fb_ad_Banner: String) {
        val adView = fb_ad_Banner.let {
            com.facebook.ads.AdView(activity, it, com.facebook.ads.AdSize.BANNER_HEIGHT_50)
        }

        val adListener: com.facebook.ads.AdListener = object : com.facebook.ads.AdListener {
            override fun onError(p0: Ad?, p1: AdError?) {
                LogE(LOG_TAG, "Error loading Facebook ad: ${p1!!.errorMessage}")

                if (fb_banner_show_ads){
                    showAdmobBannerAd(activity, ad_banner, fb_layout_Banner, relativeLayout, ad_Banner, re_ad_Banner, fb_ad_Banner)
                }else {
                    relativeLayout.visibility = View.GONE
                }
            }

            override fun onAdLoaded(p0: Ad?) {
                fbBanner1 = adView
                showBanner(activity, ad_banner, fb_layout_Banner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
                LogD(LOG_TAG, "Native ad is loaded and ready to be displayed!")

            }

            override fun onAdClicked(p0: Ad?) {
                LogD(LOG_TAG, "onAdClicked:    fb")
                showFbBannerAds(activity, ad_banner, fb_layout_Banner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
                AdsIDS.when_click_ads = false
            }

            override fun onLoggingImpression(p0: Ad?) {

            }
        }
        adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build())
    }


    private fun showBanner(activity: Activity, adBanner: RelativeLayout, fbBanner: LinearLayout, relativeLayout: RelativeLayout, ad_Banner: String, re_ad_Banner: String, fb_ad_Banner: String) {
        if (!banner_rotated_ad_network) {
            if (!fb_banner_show_ads) {
                showAdmobBanner(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
            } else {
                showFbBannerAd(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
            }
        } else {
            if (banner_ad_first_ad_network == "F") {
                showFbBannerAd(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
                banner_ad_first_ad_network = "G"
            } else {
                showAdmobBanner(activity, adBanner, fbBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
                banner_ad_first_ad_network = "F"
            }
        }
    }

    private fun showFbBannerAd(activity: Activity, adBanner: RelativeLayout, fb_layout_Banner: LinearLayout, relativeLayout: RelativeLayout, ad_Banner: String, re_ad_Banner: String, fb_ad_Banner: String) {
        if (fbBanner1 != null) {
            adBanner.visibility = View.GONE
            fb_layout_Banner.visibility = View.VISIBLE
            if (fbBanner1!!.parent != null) {
                (fbBanner1!!.parent as ViewGroup).removeView(
                    fbBanner1
                )
            }
            fb_layout_Banner.addView(fbBanner1)
        } else {
            showFbFailAdmobBanner(activity, adBanner, fb_layout_Banner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
        }
    }

    private fun showAdmobBanner(activity: Activity, adBanner: RelativeLayout, fbLayoutBanner: LinearLayout, relativeLayout: RelativeLayout, ad_Banner: String, re_ad_Banner: String, fb_ad_Banner: String) {
        if (admobBanner != null) {
            adBanner.visibility = View.VISIBLE
            fbLayoutBanner.visibility = View.GONE
            if (admobBanner!!.parent != null) {
                (admobBanner!!.parent as ViewGroup).removeView(admobBanner)
            }
            adBanner.addView(admobBanner)
        } else {
            showAdmobFbBannerAd(activity, adBanner, fbLayoutBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
        }
    }

    private fun showFbFailAdmobBanner(activity: Activity, adBanner: RelativeLayout, fbLayoutBanner: LinearLayout, relativeLayout: RelativeLayout, ad_Banner: String, re_ad_Banner: String, fb_ad_Banner: String) {
        if (admobBanner != null) {
            adBanner.visibility = View.VISIBLE
            fbLayoutBanner.visibility = View.GONE
            if (admobBanner!!.parent != null) {
                (admobBanner!!.parent as ViewGroup).removeView(
                    admobBanner
                )
            }
            adBanner.addView(admobBanner)
            if (fbBanner1 == null) {
                showFbBannerAds(activity, adBanner, fbLayoutBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
            }
        }
    }

    private fun showAdmobFbBannerAd(activity: Activity, adBanner: RelativeLayout, fbLayoutBanner: LinearLayout, relativeLayout: RelativeLayout, ad_Banner: String, re_ad_Banner: String, fb_ad_Banner: String) {
        if (fbBanner1 != null) {
            adBanner.visibility = View.GONE
            fbLayoutBanner.visibility = View.VISIBLE
            if (fbBanner1!!.parent != null) {
                (fbBanner1!!.parent as ViewGroup).removeView(
                    fbBanner1
                )
            }
            fbLayoutBanner.addView(fbBanner1)
            if (admobBanner == null) {
                showAdmobBannerAd(activity, adBanner, fbLayoutBanner, relativeLayout,ad_Banner, re_ad_Banner, fb_ad_Banner)
            }
        }
    }

    private fun getFullWidthAdaptiveSize(context: Activity): AdSize {
        val display = context.windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)

        val density = outMetrics.density
        val adWidthPixels = outMetrics.widthPixels
        val adWidth = (adWidthPixels / density).toInt()

        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(context, adWidth)
    }
}