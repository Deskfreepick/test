package com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData

import androidx.lifecycle.ViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EntityViewModel : ViewModel() {


    val detectedBlocks: MutableList<String> = ArrayList()

    var expDate: String = ""
    var issueDate: String = ""
    var d_o_b: String = ""

    var address: String = ""
    var dates: String = ""
    var email: String = ""
    var flightNo: String = ""
    var isbn: String = ""
    var iban: String = ""
    var ibanCountryCode: String = ""
    var money: String = ""
    var paymentCardNo: String = ""
    var paymentCardNetwork: String = ""
    var phoneNo: String = ""
    var trackingNo: String = ""
    var trackingCarrier: String = ""
    var url: String = ""
    var flightNO: String=""
    var airlineCode: String=""
    var amount: String=""

    val DATE_REGEX: String = """^(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$|^(0?[1-9]|[12][0-9]|3[01])([/-])(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$"""
    fun parseDate(dateString: String): Pair<Date?, String>? {
        val dateFormats = arrayOf(
            "MM/dd/yyyy",
            "dd/MM/yyyy",
            "yyyy/MM/dd",
            "MM/dd/yy",
            "yyyy-MM-dd",
            "MM-dd-yyyy",
            "dd-MM-yyyy",
            "M-dd-yyyy",
            "yyyy.MM.dd",
            "dd.MM.yyyy",
            "MM.dd.yyyy",
            "MM-yy",
            "MM/yyyy",
            "MM/yy"
        )
        for (format in dateFormats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.getDefault())
                val date = sdf.parse(dateString)
                if (date != null) {
                    return Pair(date, format)
                }
            } catch (e: Exception) {

            }
        }
        return null
    }

    fun findMinMaxDates() {
        var minDate: Date? = null
        var maxDate: Date? = null
        var minDateFormat: String? = null
        var maxDateFormat: String? = null

        for (dateString in detectedBlocks) {
            val result = parseDate(dateString)
            if (result != null) {
                val date = result.first
                val format = result.second


                if (minDate == null || date!!.before(minDate)) {
                    minDate = date
                    minDateFormat = format
                }


                if (maxDate == null || date!!.after(maxDate)) {
                    maxDate = date
                    maxDateFormat = format
                }
            }
        }

        val parts = minDate.toString().split("/")
        if(parts.size==2){

            var year = parts[1].trim()

            var mDate = year.replace("0", "")
            if (mDate.isNotEmpty()&& mDate.length>=2) {
                if (!isExpired(minDate)) {
                    expDate = formatDate(minDate, minDateFormat).toString()
                } else {
                    issueDate = formatDate(minDate, minDateFormat).toString()
                }
            }}

        val parts2 = maxDate.toString().split("/")
        if(parts2.size==2){
            val month = parts2[0].padStart(2, '0')
            var year = parts2[1].trim()

            var mxDate = year.replace("0", "")

            if (mxDate.isNotEmpty()&& mxDate.length>=2) {
                if (!isExpired(maxDate)) {
                    expDate = formatDate(maxDate, maxDateFormat).toString()
                } else {
                    issueDate = formatDate(maxDate, maxDateFormat).toString()
                }
            }}

        println("expDate Date:++++ $expDate")
        println("issueDate Date:++++ $issueDate ")

        val minDateString = formatDate(minDate, minDateFormat)
        val maxDateString = formatDate(maxDate, maxDateFormat)

        println("Min Date+++: $minDateString ")
        println("Max Date++++: $maxDateString")

    }

    fun formatDate(date: Date?, format: String?): String? {
        if (date == null || format == null) return null
        val sdf = SimpleDateFormat(format, Locale.getDefault())
        return sdf.format(date)
    }

    fun checkDateFormat(block: String) {
        if (Regex(DATE_REGEX).matches(block)) {
            detectedBlocks.add(block)}
    }

    fun isExpired(date: Date?): Boolean {
        val currentDate = Date()
        return date?.before(currentDate) ?: false
    }

}


