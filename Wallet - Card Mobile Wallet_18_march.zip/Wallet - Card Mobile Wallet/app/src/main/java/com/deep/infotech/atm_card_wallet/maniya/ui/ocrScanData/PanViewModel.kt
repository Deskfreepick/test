package com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData

import android.content.Context
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.CustomScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PANScanDataManiya
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PanViewModel : ViewModel() {

    val detectedBlocks: MutableList<String> = ArrayList()

    var fullName: String = ""
    var parentsName: String = ""
    var documentNumber: String = ""
    var dob: String = ""

    var phoneNumber: String = ""

    val restrictedKeywords = listOf(
        "platinu", "platinum", "gold", "black", "classic", "silver", "titanium",
        "bank", "credit", "debit", "atm", "transaction", "international", "card",
        "paypal", "money", "e-commerce", "charge", "visa", "mastercard", "american express",
        "discover", "jcb", "diners club", "unionpay", "maestro", "rupay", "laser",
        "china unionpay,payment", "valid", "from", "thru", "validity", "birthdate",
        "dob", "authorized", "signature", "licence", "idcard", "vehical",
        "name", "son","of","wife","daughter","father","mother",
        "blood","group",
        "licence","card","vehicales","state","drive","no","yes","n/a","ID",
        "health","hospital",
        "date","issuedate","birthdate","expiryDate",
    )

    fun parseDate(dateString: String): Pair<Date?, String>? {
        val dateFormats = arrayOf(
            "MM/dd/yyyy",
            "dd/MM/yyyy",
            "yyyy/MM/dd",
            "MM/dd/yy",
            "yyyy-MM-dd",
            "MM-dd-yyyy",
            "dd-MM-yyyy",
            "M-dd-yyyy",
            "yyyy.MM.dd",
            "dd.MM.yyyy",
            "MM.dd.yyyy",
            "MM-yy",
            "MM/yyyy",
            "MM/yy"
        )
        for (format in dateFormats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.getDefault())
                val date = sdf.parse(dateString)
                if (date != null) {
                    return Pair(date, format)
                }
            } catch (e: Exception) {

            }
        }
        return null
    }

    fun findMinMaxDates() {
        var minDate: Date? = null
        var maxDate: Date? = null
        var minDateFormat: String? = null
        var maxDateFormat: String? = null

        for (dateString in detectedBlocks) {
            val result = parseDate(dateString)
            if (result != null) {
                val date = result.first
                val format = result.second


                if (minDate == null || date!!.before(minDate)) {
                    minDate = date
                    minDateFormat = format
                }


                if (maxDate == null || date!!.after(maxDate)) {
                    maxDate = date
                    maxDateFormat = format
                }
            }
        }
        if (isExpired(minDate)) {
            dob = formatDate(minDate, minDateFormat).toString()}

        println("DOB Date:++++ $dob")

        val minDateString = formatDate(minDate, minDateFormat)
        val maxDateString = formatDate(maxDate, maxDateFormat)

        println("Min Date+++: $minDateString ")
        println("Max Date++++: $maxDateString")

    }

    fun formatDate(date: Date?, format: String?): String? {
        if (date == null || format == null) return null
        val sdf = SimpleDateFormat(format, Locale.getDefault())
        return sdf.format(date)
    }

    fun checkPANNo(str: String) {
        val panRegex = "^[A-Z]{5}[0-9]{4}[A-Z]$".toRegex()
            if( str.matches(panRegex)){
                documentNumber = str
                Log.d("PAN+++cardNumber++++", str)
            }
    }
    fun checkParentsName(cardholderName: String) {
        val cleanHolderName = cardholderName.trim()
        if (cleanHolderName.isNotEmpty() && cleanHolderName.length > 1) {
            val fullNamePattern = Regex("^[A-Za-z]+(?: [A-Za-z]+)*$")
            if (fullNamePattern.matches(cleanHolderName)) {
                parentsName = cardholderName
                Log.e("PAN+++parentsName---+++", "parentsName: $parentsName")
            }
        }
    }
    fun checkFullName(cardholderName: String) {
        if (restrictedKeywords.any { cardholderName.contains(it, ignoreCase = true) }) return
        val cleanHolderName = cardholderName.trim()
        if (cleanHolderName.isNotEmpty() && cleanHolderName.length > 3)
        {
            val fullNamePattern = Regex("\\b[A-Za-z][a-zA-Z]+(?: [A-Za-z][a-zA-Z]+)*\\b")
            if (fullNamePattern.matches(cleanHolderName)) {
                fullName = cardholderName
                Log.e("PAN+++FullName---+++", "Name: $fullName")
            }
        }
    }

    fun isExpired(date: Date?): Boolean {
        val currentDate = Date()
        return date?.before(currentDate) ?: false
    }
    fun checkDateFormat(block: String) {
        if (Regex("""^(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$|^(0?[1-9]|[12][0-9]|3[01])([/-])(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$""").matches(block)) {
            detectedBlocks.add(block)}
    }

    fun insertInDB(
        context: Context,
        stringFront: String,
        stringBack: String
    ) {

        val panCard = PANScanDataManiya(
            fullName = fullName.toString(),
            parentsName = parentsName.toString(),
            cardNumber = documentNumber.toString(),
            dob = dob.toString(),
            note = "",
            label = DatabaseHelperManiya(context).getLabelDao().queryForId(0),
            appearanceColor = ContextCompat.getColor(context, R.color.appreance),
            category = DatabaseHelperManiya(context).getCategoryDao().queryForId(19),
            frontCardImage = stringFront,
            backCardImage = stringBack,
            isLock = false,
            isFav = false,
            isDelete = true,
            isArchive = false
        )
        DatabaseHelperManiya(context).getPANCardDao().createOrUpdate(panCard)
    }
}


