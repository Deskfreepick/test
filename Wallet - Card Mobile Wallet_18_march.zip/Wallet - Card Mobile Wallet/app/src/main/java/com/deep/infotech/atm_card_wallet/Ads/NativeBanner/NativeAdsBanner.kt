package com.deep.infotech.atm_card_wallet.Ads.NativeBanner

import android.app.Activity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RelativeLayout
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.fb_native_show_ads
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.native_ad_first_ad_network
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.native_rotated_ad_network
import com.deep.infotech.atm_card_wallet.Ads.GDPRChecker.Companion.status
import com.deep.infotech.atm_card_wallet.R
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.AdOptionsView
import com.facebook.ads.NativeAdLayout
import com.facebook.ads.NativeAdListener
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.ump.ConsentInformation

class NativeAdsBanner {
    private var loadNativeAd: NativeAd? = null
    var fbNative: com.facebook.ads.NativeAd? = null

    fun nativeAdsLode(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (!native_rotated_ad_network) {
            if (!fb_native_show_ads) {
                admobNativeAdsLode(
                    activity,
                    frameLayout,
                    fbNativeAdLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
            } else {
                fbNativeAdsLode(
                    activity,
                    fbNativeAdLayout,
                    frameLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
            }
        } else {
            admobNativeAdsLode(
                activity,
                frameLayout,
                fbNativeAdLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
            fbNativeAdsLode(
                activity,
                fbNativeAdLayout,
                frameLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }

    private fun admobNativeAdsLode(
        activity: Activity?,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {

        val adIds = listOf(ad_native, re_ad_native, fb_ad_native)

        val videoOptions = VideoOptions.Builder().setStartMuted(true).build()
        val adOptions = NativeAdOptions.Builder().setVideoOptions(videoOptions).build()

        var currentAdIndex = 0

        fun loadAd() {
            if (currentAdIndex >= adIds.size) {
                relativeLayout.visibility = View.GONE
                Log.d("fatal", "All ads failed to load.")
                return
            }

            val adLoader = AdLoader.Builder(activity!!, adIds[currentAdIndex])
                .forNativeAd { ad: NativeAd ->
                    loadNativeAd = ad
                    showNativeAdView(
                        activity,
                        frameLayout,
                        fbNativeAdLayout,
                        shimmerFrameLayout,
                        relativeLayout,
                        ad_native,
                        re_ad_native,
                        fb_ad_native
                    )
                    Log.d("fatal", "Ad loaded successfully for ID: ${adIds[currentAdIndex]}")
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {

                        Log.d(
                            "fatal",
                            "Ad failed to load for ID: ${adIds[currentAdIndex]} - ${adError.message}"
                        )
                        currentAdIndex++

                        if (fb_native_show_ads) {
                            if (currentAdIndex < adIds.size - 1) {
                                relativeLayout.visibility = View.VISIBLE
                                loadAd()
                            } else {
                                relativeLayout.visibility = View.GONE
                            }
                        } else {
                            if (currentAdIndex < adIds.size - 1) {
                                relativeLayout.visibility = View.VISIBLE
                                loadAd()
                            } else {
                                fbNativeAdsLode(
                                    activity,
                                    fbNativeAdLayout,
                                    frameLayout,
                                    shimmerFrameLayout,
                                    relativeLayout,
                                    ad_native,
                                    re_ad_native,
                                    fb_ad_native
                                )
                            }
                        }
                    }
                })
                .withNativeAdOptions(adOptions)
                .build()

            val builder = AdRequest.Builder()
            val request = status
            if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
                val extras = Bundle()
                extras.putString("npa", "1")
                builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
            }
            adLoader.loadAd(builder.build())
        }

        loadAd()
    }

    private fun fbNativeAdsLode(
        activity: Activity,
        fb_nativeAdLayout: NativeAdLayout,
        frameLayout: FrameLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {

        val nativeAd = activity.let { com.facebook.ads.NativeAd(it, fb_ad_native) }
        val nativeAdListener = object : NativeAdListener {
            override fun onMediaDownloaded(ad: Ad) {
                Log.e("fatal", "Native ad finished downloading all assets.")
            }

            override fun onError(ad: Ad, adError: AdError) {
                Log.e("fatal", "Error loading Facebook ad: ${adError.errorMessage}")

                if (fb_native_show_ads) {
                    admobNativeAdsLode(
                        activity,
                        frameLayout,
                        fb_nativeAdLayout,
                        shimmerFrameLayout,
                        relativeLayout,
                        ad_native,
                        re_ad_native,
                        fb_ad_native
                    )
                } else {
                    relativeLayout.visibility = View.GONE
                }
            }

            override fun onAdLoaded(ad: Ad) {
                fbNative = nativeAd
                shimmerFrameLayout.stopShimmer()
                shimmerFrameLayout.visibility = View.GONE
                showNativeAdView(
                    activity,
                    frameLayout,
                    fb_nativeAdLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
                Log.d("fatal", "Native ad is loaded and ready to be displayed!")
            }

            override fun onAdClicked(ad: Ad) {
                Log.d("fatal", "Native ad clicked!")
            }

            override fun onLoggingImpression(ad: Ad) {
                Log.d("fatal", "Ad impression logged.")
            }
        }

        // Load the ad
        nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build())
    }

    private fun showFbNative(
        activity: Activity,
        fbNativeAdLayout: NativeAdLayout,
        frameLayout: FrameLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (fbNative != null) {
            frameLayout.visibility = View.GONE
            shimmerFrameLayout.visibility = View.GONE
            fbNativeAdLayout.visibility = View.VISIBLE

            val inflater = LayoutInflater.from(activity)
            val adView = inflater.inflate(
                R.layout.ad_native_fb_layout_banner, fbNativeAdLayout, false
            ) as RelativeLayout
            fbNativeAdLayout.addView(adView)
            val adChoicesContainer = adView.findViewById<LinearLayout>(R.id.ad_choices_container)
            val adOptionsView = AdOptionsView(activity, fbNative!!, fbNativeAdLayout)
            adChoicesContainer.removeAllViews()
            adChoicesContainer.addView(adOptionsView, 0)
            FbNativeLayoutBanner().inflateAd(fbNative!!, adView)
        } else {
            fbAfterShowAdmobNativeAd(
                activity,
                frameLayout,
                fbNativeAdLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }

    private fun fbAfterShowAdmobNativeAd(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (loadNativeAd != null) {
            val adView =
                activity.layoutInflater.inflate(R.layout.ad_unified_banner, null) as NativeAdView
            NativeInflateAdsBanner.instance?.Admob_Native_placement(
                activity, loadNativeAd!!, adView
            )
            frameLayout.visibility = View.VISIBLE
            shimmerFrameLayout.visibility = View.GONE
            fbNativeAdLayout.visibility = View.GONE
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
            fbNativeAdsLode(
                activity,
                fbNativeAdLayout,
                frameLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }

    private fun showAdmobNativeAd(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (loadNativeAd != null) {
            val adView =
                activity.layoutInflater.inflate(R.layout.ad_unified_banner, null) as NativeAdView
            NativeInflateAdsBanner.instance?.Admob_Native_placement(
                activity,
                loadNativeAd!!,
                adView
            )
            frameLayout.visibility = View.VISIBLE
            shimmerFrameLayout.visibility = View.GONE
            fbNativeAdLayout.visibility = View.GONE
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
        } else {
            admobAfterShowFbNative(
                activity,
                fbNativeAdLayout,
                frameLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }

    private fun admobAfterShowFbNative(
        activity: Activity,
        fbNativeAdLayout: NativeAdLayout,
        frameLayout: FrameLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (fbNative != null) {
            frameLayout.visibility = View.GONE
            shimmerFrameLayout.visibility = View.GONE
            fbNativeAdLayout.visibility = View.VISIBLE
            val inflater = LayoutInflater.from(activity)
            val adView = inflater.inflate(
                R.layout.ad_native_fb_layout_banner, fbNativeAdLayout, false
            ) as RelativeLayout
            fbNativeAdLayout.addView(adView)
            val adChoicesContainer = adView.findViewById<LinearLayout>(R.id.ad_choices_container)
            val adOptionsView = AdOptionsView(activity, fbNative!!, fbNativeAdLayout)
            adChoicesContainer.removeAllViews()
            adChoicesContainer.addView(adOptionsView, 0)
            FbNativeLayoutBanner().inflateAd(fbNative!!, adView)
            admobNativeAdsLode(
                activity,
                frameLayout,
                fbNativeAdLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }

    private fun showNativeAdView(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (native_rotated_ad_network) {
            if (native_ad_first_ad_network == "G") {
                showAdmobNativeAd(
                    activity,
                    frameLayout,
                    fbNativeAdLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
                native_ad_first_ad_network = "F"
            } else {
                showFbNative(
                    activity,
                    fbNativeAdLayout,
                    frameLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
                native_ad_first_ad_network = "G"
            }
        } else {
            if (!fb_native_show_ads) {
                showAdmobNativeAd(
                    activity,
                    frameLayout,
                    fbNativeAdLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
            } else {
                showFbNative(
                    activity,
                    fbNativeAdLayout,
                    frameLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
            }
        }
    }

    companion object {
        val nativeAdsBanner = NativeAdsBanner()
    }
}

