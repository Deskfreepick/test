package com.deep.infotech.atm_card_wallet.utils

import android.util.Log
import com.deep.infotech.atm_card_wallet.BuildConfig

fun LogE(tag: String, msg: String) {
    if (BuildConfig.DEBUG)
        Log.e(tag, msg)
}
fun LogW(tag: String, msg: String) {
    if (BuildConfig.DEBUG)
        Log.w(tag, msg)
}
fun LogD(tag: String, msg: String) {
    if (BuildConfig.DEBUG)
        Log.d(tag, msg)
}

