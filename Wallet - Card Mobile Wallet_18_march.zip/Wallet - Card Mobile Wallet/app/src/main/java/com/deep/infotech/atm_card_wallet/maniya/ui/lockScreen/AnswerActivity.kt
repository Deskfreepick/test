package com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen

import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.preference.PreferenceManager
import android.view.WindowManager
import android.view.animation.AnimationUtils
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityAnswerBinding
import com.deep.infotech.atm_card_wallet.maniya.ui.BaseActivity

class AnswerActivity : BaseActivity() {

    private lateinit var binding: ActivityAnswerBinding
    private var editor: SharedPreferences.Editor? = null
    private var sharedPreferences: SharedPreferences? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnswerBinding.inflate(layoutInflater)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        setContentView(binding.root)
        updateWindow()

        val defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(
            applicationContext
        )
        sharedPreferences = defaultSharedPreferences
        editor = defaultSharedPreferences.edit()

        binding.llSubmitAnswer.setOnClickListener {
            val obj = binding.etEnterNumber.text.toString()
            if (obj.isEmpty()) {
                binding.etEnterNumber.startAnimation(
                    AnimationUtils.loadAnimation(
                        this@AnswerActivity.applicationContext,
                        R.anim.shake
                    )
                )
            } else {
                Handler().postDelayed({
                    val intent: Intent = if (Build.VERSION.SDK_INT >= 23) {
                        Intent(this@AnswerActivity, EnterPinActivity::class.java)
                    } else {
                        Intent(this@AnswerActivity, ReEnterPinActivity::class.java)
                    }
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    intent.putExtra("pkgname", this@AnswerActivity.packageName)
                    startActivity(intent)

                    editor!!.putString("Q", obj)
                    editor!!.commit()
                    editor!!.putBoolean("first time", false)
                    editor!!.commit()
                    finish()
                }, 1500)

            }
        }
    }
}