package com.deep.infotech.atm_card_wallet.ui.ScanCard

import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ScanDataBottomDialogBinding
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.serialization.json.JsonObject
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScanDataViewModel : ViewModel() {

    var cPayCardNO: String? = ""
    var cPayCardType: String? = ""
    var cPayCardCVV: String? = ""
    var cPayCardHolderName: String? = ""
    var cPayCardTier: String? = ""
    var cPayCardBankNM: String? = ""
    var cIsValidPayCard: String? = ""

    var cDrivingLicenceNo: String? = ""
    var cParentsName: String? = ""
    var cOtherName: String? = ""
    var cDocumentNo: String? = ""
    var cIssueDate: String? = ""
    var cDOB: String? = ""
    var cGender: String? = ""
    var cBloodGroup: String? = ""
    var cBirthPlace: String? = ""
    var cIssueCountry: String? = ""
    var cAddress: String? = ""
    var cClasss: String? = ""
    var cBarcode: String? = ""
    var cURL: String? = ""
    var cEmail: String? = ""
    var cText: String? = ""
    var cType: String? = ""
    var cNationality: String? = ""
    var cBrand: String? = ""
    var cBank: String? = ""
    var cPaySystem: String? = ""
    var cCurrency: String? = ""
    var cBillingAddress: String? = ""
    var cLogin: String? = ""
    var cPassword: String? = ""
    var cPLV: String? = ""
    var cPUK: String? = ""
    var cCountry: String? = ""
    var cMobileOperator: String? = ""
    var cOwnerNM: String? = ""
    var cNumber: String? = ""
    var cAmount: String? = ""
    var cAccountNo: String? = ""
    var cCustomerServiceNo: String? = ""
    var cMemberSince: String? = ""
    var cBlankPages: String? = ""
    var cRestriction: String? = ""
    var cNotes: String? = ""
    var cCustom: String? = ""

    val parsedDates = mutableListOf<Date>()

    val detectedBlocks: MutableList<String> = ArrayList()

    val EXPIRY_DATE_REGEX: String = """^(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$|^(0?[1-9]|[12][0-9]|3[01])([/-])(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$"""
    val cardNumberPattern = Regex("\\b(?:\\d{4}[-\\s]?){3}\\d{4}|\\d{13,19}\\b")
    val cardholderNamePattern = Regex("\\b[A-Za-z][a-zA-Z]+(?: [A-Za-z][a-zA-Z]+)*\\b")
    val cardBankPattern = Regex("^[A-Za-z\\s]+\$")
    val cardTypePattern = Regex("\\b(?:VISA|MasterCard|AMEX|Discover|JCB|Diners Club)\\b")
    val bankNamePattern = Regex("\\b(?:Bank|Financial|Credit|Union|Institute)\\s?[A-Za-z]+(?: [A-Za-z]+)*\\b")
    val cardTierPattern = Regex("\\b(?:Platinum|Gold|Black|Classic|Silver|Titanium)\\b")
    val plvRegex = "(?i)\\bPLV\\b".toRegex()
    val pukRegex = "(?i)(PUK\\s?\\d{8}|\\d{8})".toRegex()

    //BACK side
    val cvvPattern = Regex("\\b\\d{3,4}\\b")
    val signaturePattern = Regex("\\bSIGNATURE\\b")
    val memberSince = Regex("(?i)\\bmember\\s*since\\b")
    val custmerService = Regex("(?i)^customer\\s*service\\s*no\\s*\\d+")
    val validName = Regex("^[A-Za-zÀ-ÿ'-. ]{2,50}\$")

     val paymentSystemRegex = "(?i)^(Visa|MasterCard|American\\sExpress|Discover|JCB|Diners\\sClub|UnionPay|Maestro|RuPay|Laser|PayPal|Apple\\sPay|Google\\sPay|Samsung\\sPay|Venmo|Alipay|WeChat\\sPay|Stripe|Square|Paytm|CashApp|Zelle|Bitcoin|Ethereum|Ripple|Litecoin|Monero|SWIFT|SEPA|Braintree|Skrill|Payoneer|Western\\sUnion|MoneyGram|Payza|Revolut|TransferWise|Worldpay|Adyen|Klarna|Afterpay|LemonPay|CitiPay|Fasapay|Yandex\\sMoney|Mercado\\sPago|Payza|Sofort|Paysafecard|Doku|PayU|iDEAL|Kakao\\sPay|GPay|Payeer|M-Pesa|NexPay|Twitch\\sPayments)$".toRegex()

    // Regex patterns for various flight ticket information
    val flightNumberPattern = Regex("\\b[A-Z]{2}\\d{1,4}\\b")
    val passengerNamePattern = Regex("\\b[A-Z][a-z]+(?: [A-Z][a-z]+)+\\b")
    val datePattern = Regex("\\b(?:\\d{1,2}[-/.\\s]?\\d{1,2}[-/.\\s]?\\d{4}|\\w{3,9} \\d{1,2}, \\d{4})\\b")
    val ticketTypePattern = Regex("\\b(Economy|Business|First|Premium|Class|Comfort|Economy\\+|Standard|Saver|Flex)\\b")
    val seatNumberPattern = Regex("\\b[1-9][0-9]{0,2}[A-Z]\\b")
    val ticketNumberPattern = Regex("\\b\\d{13}\\b")
    val pricePattern = Regex("\\b(?:\\$\\d{1,3}(?:,\\d{3})*(?:\\.\\d{2})?|€\\d{1,3}(?:,\\d{3})*(?:\\.\\d{2})?)\\b")
    val frequentFlyerPattern = Regex("\\b[A-Za-z0-9]{6,12}\\b")
    val drivinceLicencePattern= Regex("^(([A-Z]{2}[0-9]{2})( )|([A-Z]{2}-[0-9]{2}))((19|20)[0-9][0-9])[0-9]{7}$")
    val birthPlacePattern= Regex("(?i)^[A-Za-zÀ-ÖØ-öø-ÿ0-9\\s,'-]+(?:\\s(?:City|Town|Village|Province|State|Region|District|County|Country|Island|Mountain|Valley|Cove|Park|Bay|Lake|River|Hill|Harbor|Beach))?$")

    val nationalityPattern= Regex("(?i)^(American|Canadian|French|British|Brazilian|Japanese|Pakistani|English|Spanish|Italian|Chinese|German|Mexican|Russian|Indian|Australian|South African|Italian|Dutch|Finnish|Swedish|Norwegian|Swiss|Polish|Portuguese|Greek|Turkish|Irish|Egyptian|Israeli|Belgian|Danish|Austrian|Czech|Hungarian|Romanian|Ukrainian|Slovak|Bulgarian|Serbian|Croatian|Slovenian|Latvian|Estonian|Lithuanian|Latvian|New Zealander|Singaporean|Malaysian|Thai|Indonesian|Filipino|Vietnamese|South Korean|North Korean|Pakistani|Bangladeshi|Nepali|Sri Lankan|Bhutanese|Tanzanian|Kenyan|Ugandan|Nigerian|Ghanaian|Kenyan|Algerian|Moroccan|Libyan|Sudanese|Iraqi|Syrian|Jordanian|Lebanese|Afghan|Kazakh|Turkmen|Kyrgyz|Uzbek|Mongolian|Tajik|Armenian|Georgian|Kazakhstani|Kazakh|Belarusian|Kyrgyzstani|Turkmenistan|Maldivian|Mauritian|Malawian|Somali|Liberian|Congolese|Gabonese|Cameroonian|Chadian|Botswanan|Zambian|Zimbabwean|Namibian|Angolan|Mozambican|Eswatini|Lesotho)\$")

    val CountryPattern= Regex("(?i)^(Afghanistan|Albania|Algeria|Andorra|Angola|Antigua and Barbuda|Argentina|Armenia|Australia|Austria|Azerbaijan|Bahamas|Bahrain|Bangladesh|Barbados|Belarus|Belgium|Belize|Benin|Bhutan|Bolivia|Bosnia and Herzegovina|Botswana|Brazil|Brunei|Bulgaria|Burkina Faso|Burundi|Cabo Verde|Cambodia|Cameroon|Canada|Central African Republic|Chad|Chile|China|Colombia|Comoros|Congo (Congo-Brazzaville)|Costa Rica|Croatia|Cuba|Cyprus|Czechia (Czech Republic)|Democratic Republic of the Congo (Congo-Kinshasa)|Denmark|Djibouti|Dominica|Dominican Republic|Ecuador|Egypt|El Salvador|Equatorial Guinea|Eritrea|Estonia|Eswatini|Ethiopia|Fiji|Finland|France|Gabon|Gambia|Georgia|Germany|Ghana|Greece|Grenada|Guatemala|Guinea|Guinea-Bissau|Guyana|Haiti|Honduras|Hungary|Iceland|India|Indonesia|Iran|Iraq|Ireland|Israel|Italy|Jamaica|Japan|Jordan|Kazakhstan|Kenya|Kiribati|Korea, North|Korea, South|Kuwait|Kyrgyzstan|Laos|Latvia|Lebanon|Lesotho|Liberia|Libya|Liechtenstein|Lithuania|Luxembourg|Madagascar|Malawi|Malaysia|Maldives|Mali|Malta|Marshall Islands|Mauritania|Mauritius|Mexico|Micronesia|Moldova|Monaco|Mongolia|Montenegro|Morocco|Mozambique|Myanmar|Burma|Namibia|Nauru|Nepal|Netherlands|New Zealand|Nicaragua|Niger|Nigeria|North Macedonia|Norway|Oman|Pakistan|Palau|Panama|Papua New Guinea|Paraguay|Peru|Philippines|Poland|Portugal|Qatar|Romania|Russia|Rwanda|Saint Kitts and Nevis|Saint Lucia|Saint Vincent and the Grenadines|Samoa|San Marino|Sao Tome and Principe|Saudi Arabia|Senegal|Serbia|Seychelles|Sierra Leone|Singapore|Slovakia|Slovenia|Solomon Islands|Somalia|South Africa|South Sudan|Spain|Sri Lanka|Sudan|Suriname|Sweden|Switzerland|Syria|Taiwan|Tajikistan|Tanzania|Thailand|Timor-Leste|Togo|Tonga|Trinidad and Tobago|Tunisia|Turkey|Turkmenistan|Tuvalu|Uganda|Ukraine|United Arab Emirates|United Kingdom|United States|Uruguay|Uzbekistan|Vanuatu|Vatican City|Venezuela|Vietnam|Yemen|Zambia|Zimbabwe)\$")

    val restrictedKeywords = listOf(
        "platinu", "platinum", "gold", "black", "classic", "silver", "titanium",
        "bank", "credit", "debit", "atm", "transaction",
        "international", "card", "paypal", "money", "e-commerce", "charge",
        "visa", "mastercard", "american express", "discover", "jcb", "diners club",
        "unionpay", "maestro", "rupay", "laser", "china unionpay,payment",
        "valid", "from", "thru", "validity", "birthdate", "dob","authorized",
        "signature","customer","call","number","email","url","flight","brand","gift","pdf","ppt","software", "cloud", "server", "login",
        "api", "secure", "firewall", "encryption", "password", "security",
        "creditor", "debtor", "transaction", "atm", "cryptocurrency", "blockchain",
        "exchange", "web", "webmaster", "developer", "robot", "algorithm", "user",
        "chatbot", "widget", "platform", "online", "server", "host", "domain",
        "login", "subscription", "offer", "service", "subscription", "account",
        "net", "byte", "cookie", "data", "router", "interface", "platform",
        "portal", "app", "mobile", "payment", "gift", "voucher", "discount",
        "coupon", "store", "merchant", "discount", "redeem", "offer", "support",
        "helpdesk", "package", "subscriber", "license", "data", "analytics",
        "advertisement", "affiliate", "referral", "consultant", "specialist",
        "solutions", "expert", "service", "inbox", "callcenter", "support",
        "feedback", "team", "store", "cart", "checkout", "inventory", "sale"
    )

    fun invalidateData() {
        cPayCardNO = ""
        cPayCardType = ""
        cPayCardCVV = ""
        cPayCardHolderName = ""
        cPayCardTier = ""
        cPayCardBankNM = ""
        cIsValidPayCard = ""
        cDrivingLicenceNo = ""
        cParentsName = ""
        cOtherName = ""
        cDocumentNo = ""
        cIssueDate = ""
        cDOB = ""
        cGender = ""
        cBloodGroup = ""
        cBirthPlace = ""
        cIssueCountry = ""
        cAddress = ""
        cClasss = ""
        cBarcode = ""
        cURL = ""
        cEmail = ""
        cText = ""
        cType = ""
        cNationality = ""
        cBrand = ""
        cBank = ""
        cPaySystem = ""
        cCurrency = ""
        cBillingAddress = ""
        cLogin = ""
        cPassword = ""
        cPLV = ""
        cPUK = ""
        cCountry = ""
        cMobileOperator = ""
        cOwnerNM = ""
        cNumber = ""
        cAmount = ""
        cAccountNo = ""
        cCustomerServiceNo = ""
        cMemberSince = ""
        cBlankPages = ""
        cRestriction = ""
        cNotes = ""
        cCustom = ""
    }

}