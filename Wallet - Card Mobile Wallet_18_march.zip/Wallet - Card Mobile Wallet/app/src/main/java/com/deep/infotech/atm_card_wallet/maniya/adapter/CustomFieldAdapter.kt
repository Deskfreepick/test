package com.deep.infotech.atm_card_wallet.maniya.adapter

import android.app.DatePickerDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import androidx.recyclerview.widget.RecyclerView
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.FieldMoreBottomDialogBinding
import com.deep.infotech.atm_card_wallet.databinding.ItemDateCustomBinding
import com.deep.infotech.atm_card_wallet.databinding.ItemNameCustomBinding
import com.deep.infotech.atm_card_wallet.databinding.ItemPasswordCustomBinding
import com.deep.infotech.atm_card_wallet.maniya.model.Field
import com.deep.infotech.atm_card_wallet.maniya.model.FieldType
import com.deep.infotech.atm_card_wallet.maniya.ui.BaseActivity.Companion.SELECTED_COUNTRY_KEY
import com.deep.infotech.atm_card_wallet.maniya.ui.BaseActivity.Companion.SHARED_PREFS_NAME
import com.google.android.material.bottomsheet.BottomSheetDialog
import java.util.Calendar
import java.util.Collections
import java.util.Locale

interface FieldActionListener {
    fun onDelete(field: Field)
    fun onTogglePinned(field: Field)
}

class FieldAdapter(
    private val context: Context,
    private val fields: MutableList<Field>,
    private val onFieldClick: (Field) -> Unit,
    private val fieldActionListener: FieldActionListener
) : RecyclerView.Adapter<RecyclerView.ViewHolder>(), ItemTouchHelperAdapter {

    lateinit var bottomSheetDialog: BottomSheetDialog

    companion object {
        private const val VIEW_TYPE_NAME = 0
        private const val VIEW_TYPE_PASSWORD = 1
        private const val VIEW_TYPE_DATE = 2
    }

    inner class NameViewHolder(private val binding: ItemNameCustomBinding) :
        RecyclerView.ViewHolder(binding.root) {


        fun bind(field: Field, position: Int) {
            binding.apply {
                dividerVisibility(divider, position == fields.size - 1)
                fieldTitle(tvTitle, field.type.name)
                ivMore.setOnClickListener { showBottomSheetDialog(position, field.type.name) }
                root.setOnClickListener {}
            }

        }

        fun getViewValues(): Pair<String, String> {
            return Pair(binding.tvTitle.text.toString(), binding.edtText.text.toString())
        }

    }

    inner class PasswordViewHolder(private val binding: ItemPasswordCustomBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(field: Field, position: Int) {
            binding.apply {
                dividerVisibility(divider, position == fields.size - 1)
                fieldTitle(tvTitle, field.type.name)
                root.setOnClickListener {}
                ivMore.setOnClickListener { showBottomSheetDialog(position, field.type.name) }
            }
        }

        fun getViewValues(): Pair<String, String> {
            return Pair(binding.tvTitle.text.toString(), binding.edtText.text.toString())
        }
    }

    inner class DateViewHolder(private val binding: ItemDateCustomBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(field: Field, position: Int) {
            binding.apply {
                dividerVisibility(divider, position == fields.size - 1)
                fieldTitle(tvTitle, field.type.name)
                tvDate.setOnClickListener {
                    val calendar = Calendar.getInstance()

                    // Month and Year
                    val datePickerDialog = DatePickerDialog(
                        context,
                        { _, year, month, _ ->
                            tvDate.text = "${month + 1}/$year"
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                    )

                    // Remove the Day picker
                    datePickerDialog.datePicker.findViewById<View>(
                        context.resources.getIdentifier("day", "id", "android")
                    )?.visibility = View.GONE


                    /*// Day-Month-Year

                    val datePickerDialog = DatePickerDialog(
                        context,
                        { _, year, month, dayOfMonth ->
                            tvDate.text = String.format("%02d-%02d-%d", dayOfMonth, month + 1, year)
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                    )*/


                    datePickerDialog.show()
                }
                ivMore.setOnClickListener { showBottomSheetDialog(position, field.type.name) }
            }
        }

        fun getViewValues(): Pair<String, String> {
            return Pair(binding.tvTitle.text.toString(), binding.tvDate.text.toString())
        }
    }

    private fun fieldTitle(tvTitle: TextView, text: String) {
        tvTitle.text = text
            .replace("_", " ")
            .lowercase()
            .split(" ")
            .joinToString(" ") { it.capitalize(Locale.ROOT) }
    }

    private fun dividerVisibility(divider: View, isLastItem: Boolean) {
        divider.visibility = View.VISIBLE
        if (isLastItem)
            divider.visibility = View.GONE
    }

    private fun duplicateField(position: Int) {
        val field = fields[position]
        fields.add(position, field.copy())
        notifyItemInserted(position)
        if (bottomSheetDialog.isShowing) {
            bottomSheetDialog.dismiss()
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (fields[position].type) {
            FieldType.NUMBER, FieldType.CARD_NUMBER,
            FieldType.PHONE_NUMBER, FieldType.PERSONAL_NUMBER,
            FieldType.AMOUNT, FieldType.CVV,
            FieldType.ACCOUNT_NUMBER, FieldType.CUSTOMER_SERVICE_NO -> VIEW_TYPE_PASSWORD

            FieldType.DATE, FieldType.ISSUE_DATE,
            FieldType.EXPIRY_DATE, FieldType.DOB,
            FieldType.MEMBER_SINCE -> VIEW_TYPE_DATE

            else -> VIEW_TYPE_NAME
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_NAME -> {
                val binding =
                    ItemNameCustomBinding.inflate(LayoutInflater.from(context), parent, false)
                NameViewHolder(binding)
            }

            VIEW_TYPE_PASSWORD -> {
                val binding =
                    ItemPasswordCustomBinding.inflate(LayoutInflater.from(context), parent, false)
                PasswordViewHolder(binding)
            }

            VIEW_TYPE_DATE -> {
                val binding =
                    ItemDateCustomBinding.inflate(LayoutInflater.from(context), parent, false)
                DateViewHolder(binding)
            }

            else -> throw IllegalArgumentException("Unknown view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val field = fields[position]

        when (holder) {
            is NameViewHolder -> holder.bind(field, position)
            is PasswordViewHolder -> holder.bind(field, position)
            is DateViewHolder -> holder.bind(field, position)
        }

        holder.itemView.setOnClickListener {
            onFieldClick(field)
        }
    }

    override fun getItemCount(): Int = fields.size
    override fun onItemMove(fromPosition: Int, toPosition: Int): Boolean {
        Collections.swap(fields, fromPosition, toPosition)
        notifyItemMoved(fromPosition, toPosition)
        return true
    }

    override fun onItemDismiss(position: Int) {
        fields.removeAt(position)
        notifyItemRemoved(position)
    }

    fun addField(field: Field) {
        fields.add(field)
        notifyItemInserted(fields.size - 1)
        notifyDataSetChanged()

    }

    fun removeField(field: Field) {
        val index = fields.indexOf(field)
        if (index != -1) {
            fields.removeAt(index)
            notifyItemRemoved(index)
            notifyDataSetChanged()

        }
    }

    fun showBottomSheetDialog(position: Int, title: String) {
        bottomSheetDialog = BottomSheetDialog(context)

        val binding = FieldMoreBottomDialogBinding.inflate(bottomSheetDialog.layoutInflater)
        bottomSheetDialog.setContentView(binding.root)

        binding.root.setBackgroundResource(R.drawable.bottom_sheet_background)


        val layoutParams = binding.root.layoutParams as ViewGroup.MarginLayoutParams

        if (context.getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE).getString(SELECTED_COUNTRY_KEY, "en").toString() == "ar"
            || context.getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE).getString(SELECTED_COUNTRY_KEY, "en").toString() == "ur"){
            layoutParams.layoutDirection = View.LAYOUT_DIRECTION_RTL
        }else{
            layoutParams.layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        binding.root.layoutParams = layoutParams


        fieldTitle(binding.tvTitle, title)
        if (fields[position].isPinned) {
            binding.idPinUnpin.text = context.resources.getText(R.string.unpin)
        } else {
            binding.idPinUnpin.text = context.resources.getText(R.string.pin)
        }

        binding.llUnpin.setOnClickListener {
            bottomSheetDialog.dismiss()
            fieldActionListener.onTogglePinned(fields[position])
            bottomSheetDialog.dismiss()
        }

        binding.llSettings.setOnClickListener {
            bottomSheetDialog.dismiss()
            // Handle settings action
        }

        binding.llDuplicate.setOnClickListener {
            bottomSheetDialog.dismiss()
            duplicateField(position)
        }

        binding.llDelete.setOnClickListener {
            fieldActionListener.onDelete(fields[position])
            bottomSheetDialog.dismiss()
        }

        bottomSheetDialog.show()
    }

}
