package com.deep.infotech.atm_card_wallet.Ads.NativeBanner

import android.app.Activity
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.deep.infotech.atm_card_wallet.R
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

class NativeInflateAdsBanner {
    fun Admob_Native_placement(activity: Activity, nativeAd: NativeAd, adView: NativeAdView) {
        /*     val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
             mediaView.setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                 override fun onChildViewAdded(parent: View, child: View) {
                     if (child is ImageView) {
                         child.adjustViewBounds = true
                         child.scaleType = ImageView.ScaleType.FIT_CENTER
                     }
                 }

                 override fun onChildViewRemoved(parent: View, child: View) {}
             })
     */
//        mediaView.mediaContent = nativeAd.mediaContent
        val install = adView.findViewById<TextView>(R.id.ad_call_to_action)
        install.text = nativeAd.callToAction/*
        install.background.setColorFilter(
            activity.getColor(R.color.black),
            PorterDuff.Mode.SRC_ATOP
        )*/
        adView.callToActionView = install
//        adView.mediaView = mediaView
        adView.bodyView = adView.findViewById(R.id.ad_body)
        adView.iconView = adView.findViewById(R.id.ad_app_icon)
        adView.priceView = adView.findViewById(R.id.ad_price)
        adView.starRatingView = adView.findViewById(R.id.ad_stars)
        adView.storeView = adView.findViewById(R.id.ad_store)
        adView.advertiserView = adView.findViewById(R.id.ad_advertiser)

        if (nativeAd.body == null) {
            adView.bodyView!!.visibility = View.INVISIBLE
        } else {
            adView.bodyView!!.visibility = View.VISIBLE
            (adView.bodyView as TextView?)!!.text = nativeAd.body
        }
        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        headlineView.text = nativeAd.headline
        adView.headlineView = headlineView
        (adView.headlineView as TextView?)!!.text = nativeAd.headline
//        adView.mediaView!!.mediaContent = nativeAd.mediaContent
        if (nativeAd.callToAction == null) {
            adView.callToActionView!!.visibility = View.GONE
        } else {
            adView.callToActionView!!.visibility = View.VISIBLE
            (adView.callToActionView as TextView?)!!.text = nativeAd.callToAction
        }
        if (nativeAd.icon == null) {
            adView.findViewById<View>(R.id.llCard).visibility = View.GONE
        } else {
            (adView.iconView as ImageView?)!!.setImageDrawable(nativeAd.icon!!.drawable)
            adView.findViewById<View>(R.id.llCard).visibility = View.VISIBLE
        }
        if (nativeAd.price == null) {
            adView.priceView!!.visibility = View.GONE
        } else {
            adView.priceView!!.visibility = View.VISIBLE
            (adView.priceView as TextView?)!!.text = nativeAd.price
        }
        if (nativeAd.store == null) {
            adView.storeView!!.visibility = View.GONE
        } else {
            adView.storeView!!.visibility = View.VISIBLE
            (adView.storeView as TextView?)!!.text = nativeAd.store
        }
        /*  if (nativeAd.starRating == null) {
              adView.starRatingView!!.visibility = View.GONE
          } else {
              (adView.starRatingView as RatingBar?)!!.rating = nativeAd.starRating!!.toFloat()
              adView.starRatingView!!.visibility = View.VISIBLE
          }*/
        if (nativeAd.advertiser == null) {
            adView.advertiserView!!.visibility = View.GONE
        } else {
            (adView.advertiserView as TextView?)!!.text = nativeAd.advertiser
            adView.advertiserView!!.visibility = View.VISIBLE
        }
        adView.setNativeAd(nativeAd)

        /*      val vc = nativeAd.mediaContent!!.videoController
              if (nativeAd.mediaContent != null && nativeAd.mediaContent!!.hasVideoContent()) {
                  vc.videoLifecycleCallbacks = object : VideoController.VideoLifecycleCallbacks() {
                      override fun onVideoEnd() {
                          super.onVideoEnd()
                      }
                  }
              }*/
    }

    companion object {
        private var mInstance: NativeInflateAdsBanner? = null
        val instance: NativeInflateAdsBanner?
            get() {
                if (mInstance == null) {
                    mInstance = NativeInflateAdsBanner()
                }
                return mInstance
            }
    }
}