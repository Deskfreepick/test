package com.deep.infotech.atm_card_wallet.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.graphics.Shader.TileMode
import android.util.AttributeSet
import android.widget.FrameLayout

class CircleLayout : FrameLayout {
    private lateinit var mBitmap: Bitmap
    private var mBounds: RectF? = null
    private var mCanvas: Canvas? = null

    constructor(context: Context?) : super(context!!)
    constructor(context: Context?, attributeSet: AttributeSet?) : super(
        context!!, attributeSet
    )

    constructor(context: Context?, attributeSet: AttributeSet?, i: Int) : super(
        context!!, attributeSet, i
    )

    public override fun onSizeChanged(i: Int, i2: Int, i3: Int, i4: Int) {
        super.onSizeChanged(i, i2, i3, i4)
        if (i != i3 && i2 != i4) {
            val rectF = RectF(0.0f, 0.0f, i.toFloat(), i2.toFloat())
            mBounds = rectF
            mBitmap = Bitmap.createBitmap(
                rectF.width().toInt(),
                mBounds!!.height().toInt(),
                Bitmap.Config.ARGB_8888
            )
            mCanvas = Canvas(mBitmap)
        }
    }

    public override fun dispatchDraw(canvas: Canvas) {
        mCanvas!!.drawColor(0, PorterDuff.Mode.CLEAR)
        super.dispatchDraw(mCanvas!!)
        val bitmapShader = BitmapShader(mBitmap, TileMode.CLAMP, TileMode.CLAMP)
        val paint = Paint()
        paint.isAntiAlias = true
        paint.shader = bitmapShader
        canvas.drawCircle(mBounds!!.centerX(), mBounds!!.centerY(), mBounds!!.width() / 2.0f, paint)
    }
}