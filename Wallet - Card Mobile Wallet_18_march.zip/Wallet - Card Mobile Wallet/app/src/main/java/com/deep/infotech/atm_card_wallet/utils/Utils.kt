package com.deep.infotech.atm_card_wallet.utils

import android.content.Context
import android.content.SharedPreferences
import android.view.View
import android.widget.Toast

class Utils(var activity: Context) {

    private val sharedPreferences: SharedPreferences = activity.getSharedPreferences("AppSettings", Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = sharedPreferences.edit()

    fun getThemeMode(): String {
        return sharedPreferences.getString(THEME_MODE, "system") ?: "system"
    }

    fun setThemeMode(themeMode: String?) {
        editor.putString(THEME_MODE, themeMode)
        editor.apply()
    }
    fun getDateFormate(): String {
        return sharedPreferences.getString(DATE_FORMATE, "dd/MM/yyyy") ?: "dd/MM/yyyy"
    }

    fun setDateFormate(dateFormate: String?) {
        editor.putString(DATE_FORMATE, dateFormate)
        editor.apply()
    }


    companion object {
        const val THEME_MODE = "theme_mode"
        const val DATE_FORMATE = "date_formate"
    }
}