package com.deep.infotech.atm_card_wallet.utils

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver.OnGlobalLayoutListener
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.Interpolator
import android.view.animation.LinearInterpolator
import android.view.animation.ScaleAnimation
import android.widget.FrameLayout
import com.deep.infotech.bank_info_locker.LockOption.Utils.CustomAlphaAnimation
import com.deep.infotech.bank_info_locker.LockOption.Utils.CustomScaleAnimation
import com.deep.infotech.atm_card_wallet.R

@SuppressWarnings("all")
class CircleRippleLayout @JvmOverloads constructor(
    context: Context,
    attributeSet: AttributeSet? = null,
    i: Int = 0
) : FrameLayout(context, attributeSet, i) {
    private var mHasStopped = false
    private var mInterpolator: Interpolator? = null
    var mIsSlowAlphaAnimating = false
    var mIsSlowScaleAnimating = false
    private var mPadding = 0
    private var mRippleBgColor = 0
    var mRippleBgView: View? = null
    private var mRippleColor = 0
    var mRippleSize = 0
    var mRippleView: View? = null
    private var mRippleViewContainer: ViewGroup? = null
    private var mSlowAlphaAnimation: CustomAlphaAnimation? = null
    var mSlowScaleAnimation: CustomScaleAnimation? = null

    init {
        init(context, attributeSet)
    }

    private fun init(context: Context, attributeSet: AttributeSet?) {
        mInterpolator = LinearInterpolator()
        mRippleBgColor = DEFAULT_RIPPLE_COLOR
        mRippleColor = DEFAULT_RIPPLE_COLOR
        if (attributeSet != null) {
            val obtainStyledAttributes =
                context.obtainStyledAttributes(attributeSet, R.styleable.CircleRippleLayout)
            mRippleColor = obtainStyledAttributes.getColor(2, mRippleColor)
            mRippleBgColor = obtainStyledAttributes.getColor(1, mRippleBgColor)
            mPadding = obtainStyledAttributes.getDimensionPixelSize(0, 0)
            obtainStyledAttributes.recycle()
        }
        viewTreeObserver.addOnGlobalLayoutListener(object : OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                if (this@CircleRippleLayout.width != 0) {
                    this@CircleRippleLayout.viewTreeObserver.removeGlobalOnLayoutListener(this)
                    val circleRippleLayout = this@CircleRippleLayout
                    circleRippleLayout.mRippleSize = circleRippleLayout.width
                }
            }
        })
        initAnimations()
    }

    private fun initAnimations() {
        val customScaleAnimation = CustomScaleAnimation(
            0.0f,
            EXPANDED_SCALE,
            0.0f,
            EXPANDED_SCALE,
            1,
            CENTER_PIVOT,
            1,
            CENTER_PIVOT
        )
        mSlowScaleAnimation = customScaleAnimation
        customScaleAnimation.interpolator = mInterpolator
        mSlowScaleAnimation!!.duration = SLOW_SCALE_DURATION
        mSlowScaleAnimation!!.startOffset = SLOW_SCALE_OFFSET
        mSlowScaleAnimation!!.setAnimationListener(object : BaseAnimationListener() {
            override fun onAnimationStart(animation: Animation) {
                mRippleView!!.visibility = 0
                mIsSlowScaleAnimating = true
            }

            override fun onAnimationEnd(animation: Animation) {
                mIsSlowScaleAnimating = false
                if (!mSlowScaleAnimation!!.isCanceled) {
                    val layoutParams = mRippleView!!.layoutParams as LayoutParams
                    layoutParams.leftMargin = 0
                    layoutParams.topMargin = 0
                    mRippleView!!.requestLayout()
                }
            }
        })
        val customAlphaAnimation = CustomAlphaAnimation(0.0f, 1.0f)
        mSlowAlphaAnimation = customAlphaAnimation
        customAlphaAnimation.interpolator = mInterpolator
        mSlowAlphaAnimation!!.duration = 250
        mSlowAlphaAnimation!!.setAnimationListener(object : BaseAnimationListener() {
            override fun onAnimationStart(animation: Animation) {
                mRippleBgView!!.visibility = 0
                mIsSlowAlphaAnimating = true
            }

            override fun onAnimationEnd(animation: Animation) {
                mIsSlowAlphaAnimating = false
            }
        })
    }


    override fun onTouchEvent(motionEvent: MotionEvent): Boolean {
        if (isEnabled && isClickable) {
            when (motionEvent.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    mHasStopped = false
                    addRippleViews()
                    val layoutParams = mRippleView!!.layoutParams as LayoutParams
                    val rippleSize = mRippleSize
                    layoutParams.height = rippleSize
                    layoutParams.width = rippleSize
                    layoutParams.leftMargin = (motionEvent.x - (layoutParams.width / 2)).toInt()
                    layoutParams.topMargin = (motionEvent.y - (layoutParams.height / 2)).toInt()
                    mRippleView!!.requestLayout()
                    mRippleView!!.startAnimation(mSlowScaleAnimation)
                    mRippleBgView!!.startAnimation(mSlowAlphaAnimation)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!mHasStopped && (motionEvent.x < 0 || motionEvent.y < 0 || motionEvent.x > width || motionEvent.y > height)) {
                        stopAnimations()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!mHasStopped) {
                        stopAnimations()
                    }
                }
            }
        }
        return super.onTouchEvent(motionEvent)
    }



    private fun stopAnimations() {
        mHasStopped = true
        val view = mRippleView
        val viewGroup = mRippleViewContainer
        val view2 = mRippleBgView
        val createFastAlphaAnimation = createFastAlphaAnimation()
        createFastAlphaAnimation.setAnimationListener(object : BaseAnimationListener() {
            override fun onAnimationEnd(animation: Animation) {
                removeView(viewGroup)
            }
        })
        val createFastAlphaAnimation2 = createFastAlphaAnimation()
        createFastAlphaAnimation2.setAnimationListener(object : BaseAnimationListener() {
            override fun onAnimationEnd(animation: Animation) {
                removeView(view2)
            }
        })
        if (mIsSlowScaleAnimating) {
            mSlowScaleAnimation!!.cancel()
            mSlowScaleAnimation!!.reset()
            val lastInterpolatedTime = mSlowScaleAnimation!!.lastInterpolatedTime * EXPANDED_SCALE
            val scaleAnimation = ScaleAnimation(
                lastInterpolatedTime,
                EXPANDED_SCALE,
                lastInterpolatedTime,
                EXPANDED_SCALE,
                1,
                CENTER_PIVOT,
                1,
                CENTER_PIVOT
            )
            scaleAnimation.interpolator = mInterpolator
            scaleAnimation.duration = 250
            scaleAnimation.setAnimationListener(object : BaseAnimationListener() {
                override fun onAnimationEnd(animation: Animation) {
                    val layoutParams = view!!.layoutParams as LayoutParams
                    layoutParams.leftMargin = 0
                    layoutParams.topMargin = 0
                    view.requestLayout()
                    view.startAnimation(createFastAlphaAnimation)
                }
            })
            view!!.startAnimation(scaleAnimation)
            createFastAlphaAnimation2.duration = 250
            if (mIsSlowAlphaAnimating) {
                mSlowAlphaAnimation!!.cancel()
                mSlowAlphaAnimation!!.reset()
                val alphaAnimation =
                    AlphaAnimation(mSlowAlphaAnimation!!.lastInterpolatedTime, 1.0f)
                alphaAnimation.interpolator = mInterpolator
                alphaAnimation.duration = 150
                alphaAnimation.setAnimationListener(object : BaseAnimationListener() {
                    override fun onAnimationEnd(animation: Animation) {
                        view2!!.startAnimation(createFastAlphaAnimation2)
                    }
                })
                view2!!.startAnimation(alphaAnimation)
                return
            }
            view2!!.startAnimation(createFastAlphaAnimation2)
            return
        }
        view!!.startAnimation(createFastAlphaAnimation)
        view2!!.startAnimation(createFastAlphaAnimation2)
    }

    private fun createFastAlphaAnimation(): Animation {
        val alphaAnimation = AlphaAnimation(1.0f, 0.0f)
        alphaAnimation.interpolator = mInterpolator
        alphaAnimation.duration = 150
        return alphaAnimation
    }

    private fun addRippleViews() {
        mRippleView = initRippleView(mRippleColor)
        mRippleBgView = initRippleView(mRippleBgColor)
        val circleLayout = CircleLayout(context)
        mRippleViewContainer = circleLayout
        circleLayout.addView(mRippleView, LayoutParams(-1, -1))
        addRippleView(mRippleViewContainer)
        addRippleView(mRippleBgView)
    }

    private fun initRippleView(i: Int): View {
        val view = View(context)
        view.setBackgroundResource(R.drawable.colorcircle)
        (view.background as GradientDrawable).setColor(i)
        view.visibility = 4
        return view
    }

    private fun addRippleView(view: View?) {
        val layoutParams = LayoutParams(-1, -1)
        val i = mPadding
        layoutParams.setMargins(i, i, i, i)
        addView(view, 0, layoutParams)
    }

    companion object {
        private const val CENTER_PIVOT = 0.5f
        private const val DEFAULT_RIPPLE_COLOR = 1090519039
        private const val EXPANDED_SCALE = 3.0f
        private const val SLOW_SCALE_DURATION: Long = 700
        private const val SLOW_SCALE_OFFSET: Long = 300
    }
}