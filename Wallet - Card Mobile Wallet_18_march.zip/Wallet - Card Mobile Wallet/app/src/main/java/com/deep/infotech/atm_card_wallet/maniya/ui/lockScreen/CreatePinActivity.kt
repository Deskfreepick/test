package com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.preference.PreferenceManager
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.core.internal.view.SupportMenu
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityCreatePinBinding
import com.deep.infotech.atm_card_wallet.maniya.ui.BaseActivity
import java.lang.Boolean
import kotlin.Array
import kotlin.String
import kotlin.arrayOfNulls

class CreatePinActivity : BaseActivity() {

    var keyPadLockedFlag = false
    var pinBoxArray: Array<ImageView?>? = arrayOfNulls(4)
    private var sharedPreferences: SharedPreferences? = null
    var userEntered: String = ""
    private var vibrator: Vibrator? = null

    private var editor: SharedPreferences.Editor? = null
    private var pin: String? = ""
    private var shake: Animation? = null
    private var showAds = Boolean.TRUE

    private lateinit var binding: ActivityCreatePinBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreatePinBinding.inflate(layoutInflater)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE
        )
        setContentView(binding.root)
        updateWindow()
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        initData()
    }
    fun initData() {
        val defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        sharedPreferences = defaultSharedPreferences
        editor = defaultSharedPreferences.edit()
        shake = AnimationUtils.loadAnimation(this, R.anim.shake)
        vibrator = getSystemService("vibrator") as Vibrator
        binding.titleBox.setText(R.string.enter_password)
        pinBoxArray?.let {
            it[0]= binding.pinBox0
            it[1] = binding.pinBox1
            it[2] = binding.pinBox2
            it[3]= binding.pinBox3
        }
    }
    fun onClickSetPassword(view: View) {
        Log.d("++++=","SetPassword clicked")
        editor!!.putString("pin", pin)
        editor!!.commit()
        if (sharedPreferences!!.getBoolean("first time", true)) {
            Log.d("++++=","first time == true--->AnswerActivity")

            startActivity(
                Intent(
                    this@CreatePinActivity, AnswerActivity::class.java
                )
            )
        }
        else {
            Log.d("++++=","first time == false------>ChangePasswordDoneActivity")
            Handler().postDelayed({
                    /* if (getSharedPreferences("language", 0).getBoolean("isFirstRun", true)) {
                         startActivity(Intent(this, LanguageActivity::class.java))
                         finish()
                     } else*/ /*if (AdsIDS.start_screen_show) {
                    startActivity(Intent(this, StartActivity::class.java))
                    finish()
                } else {*/
                    dialogPasswordUpdated()
                   // startActivity(Intent(this, MainActivityManiya::class.java))
                  //  finish()
              /*  }*/
                }, 1000)
        }

    }

    fun onClickVerify(view: View) {
        Log.d("++++=","rlVerify clicked")
        binding.titleBox.setText(R.string.re_enter_password)
        binding.statusMessage.setText(R.string.tv_reenter)
        keyPadLockedFlag = true
        pin=userEntered
        resetKeypadUI()
    }
    fun onClickDeleteNumeric(view: View) {
        if (/*!keyPadLockedFlag && */userEntered.isNotEmpty()) {
            binding.rlVerify.visibility=View.GONE
            val createPinActivity = this@CreatePinActivity
            createPinActivity.userEntered =
                createPinActivity.userEntered.substring(0, userEntered.length - 1)
            pinBoxArray!![userEntered.length]!!.setImageResource(R.drawable.boder_round)
            if (sharedPreferences!!.getBoolean("vib", true)) {
                vibrator!!.vibrate(20)
            }
        }
    }
    @SuppressLint("RestrictedApi")
    fun onClickNumeric(view: View) {
        if (sharedPreferences!!.getBoolean("vib", true)) {
            vibrator!!.vibrate(20)
        }
        if (binding.statusMessage.text.toString().isNotEmpty()) {
            binding.statusMessage.setText(R.string.tv_createdata)
        }
        if (!keyPadLockedFlag) {
            if (userEntered.length < 4)
            {
                val str2 = userEntered + getViewNumericDigit(view)
                userEntered = str2
                pinBoxArray!![str2.length - 1]!!.setImageResource(R.drawable.bg_round)
                if (userEntered.length == 4)
                {
                    if (pin!!.length != 4)
                    {
                        Log.d("++++=","pin!!.length != 4")
                        handlePasswordButtonVisibility(false)

                    } else if (userEntered == pin)
                    {
                        Log.d("++++=","userEntered == pin")
                        handlePasswordButtonVisibility(true)

                    } else {
                        Log.d("++++=","userEntered == pin not matched")
                        binding.sk.startAnimation(shake)
                        binding.statusMessage.setTextColor(SupportMenu.CATEGORY_MASK)
                        binding.statusMessage.setText(R.string.password_not_match)
                        binding.titleBox.setText(R.string.re_enter_password)
                        resetKeypadUI()
                    }
                }
            }
            else
            {
                pinBoxArray!![0]!!.setImageResource(R.drawable.boder_round)
                pinBoxArray!![1]!!.setImageResource(R.drawable.boder_round)
                pinBoxArray!![2]!!.setImageResource(R.drawable.boder_round)
                pinBoxArray!![3]!!.setImageResource(R.drawable.boder_round)
                userEntered = ""
                binding.statusMessage.setText(R.string.tv_createdata)
                userEntered += getViewNumericDigit(view)
                Log.v("PinView", "User entered=$userEntered")
                pinBoxArray!![userEntered.length - 1]!!.setImageResource(R.drawable.bg_round)
            }
        }
    }
    fun handlePasswordButtonVisibility(isSet: kotlin.Boolean) {
        binding.rlVerify.visibility=View.VISIBLE
        binding.tvVerify.visibility=View.GONE
        binding.tvSetPassword.visibility=View.GONE
        if(isSet){
            binding.tvSetPassword.visibility=View.VISIBLE
        }else{
            binding.tvVerify.visibility=View.VISIBLE
        }
    }
    fun getViewNumericDigit(view: View): String? {
        if (view.id == R.id.button0) {
            return "0"
        }
        if (view.id == R.id.button1) {
            return "1"
        }
        if (view.id == R.id.button2) {
            return "2"
        }
        if (view.id == R.id.button3) {
            return "3"
        }
        if (view.id == R.id.button4) {
            return "4"
        }
        if (view.id == R.id.button5) {
            return "5"
        }
        if (view.id == R.id.button6) {
            return "6"
        }
        if (view.id == R.id.button7) {
            return "7"
        }
        if (view.id == R.id.button8) {
            return "8"
        }
        return if (view.id == R.id.button9) {
            "9"
        } else null
    }

    override fun onDestroy() {
        super.onDestroy()
        showAds = Boolean.FALSE
    }
    private fun resetKeypadUI() {
        Handler(Looper.getMainLooper()).postDelayed({
            pinBoxArray?.let {
                it[0]?.setImageResource(R.drawable.boder_round)
                it[1]?.setImageResource(R.drawable.boder_round)
                it[2]?.setImageResource(R.drawable.boder_round)
                it[3]?.setImageResource(R.drawable.boder_round)
            }
            userEntered = ""
            keyPadLockedFlag = false
            binding.rlVerify.visibility=View.GONE
        }, 200)

    }

}