package com.deep.infotech.atm_card_wallet.maniya.adapter

import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.deep.infotech.atm_card_wallet.databinding.ItemLabelViewBinding
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LabelDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya

class AdapterLabelView(
    private val context: Context,
    private val LabelList: MutableList<LabelDataManiya> = mutableListOf(),
    private val labelID: Long,
    private val onItemClick: (LabelDataManiya, Int) -> Unit,
    private val onItemLongClick: (LabelDataManiya, Int) -> Boolean,
) : RecyclerView.Adapter<AdapterLabelView.MyViewHolder>() {

    private var selectedItem = -1
    var isSelectionMode = false

    class MyViewHolder(val binding: ItemLabelViewBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding =
            ItemLabelViewBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = LabelList[position]
        with(holder.binding) {
            ivDelete.visibility = if (isSelectionMode) View.VISIBLE else View.GONE
            rlLabel.visibility = View.VISIBLE

            ivBlur.imageTintList = ColorStateList.valueOf(item.color)

            cvLabel.imageTintList = ColorStateList.valueOf(item.color)
            tvLabelName.text = item.name

            if (selectedItem == position) {
                ivLabelCheck.visibility = View.VISIBLE
            } else {
                ivLabelCheck.visibility = View.GONE
            }
            if (isSelectionMode) ivLabelCheck.visibility = View.GONE

            ivDelete.setOnClickListener {
                removeLabelAtPosition(position, item.id)
            }

            holder.itemView.setOnClickListener { v: View? ->
                if (!isSelectionMode) {
                    onItemClick(item, position)
                }
            }

            holder.itemView.setOnLongClickListener {
                if (!isSelectionMode) {
                    onItemLongClick(item, position)
                }
                true
            }

        }
    }

    fun removeLabelAtPosition(position: Int, id: Long) {
        DatabaseHelperManiya(context).labelDelete(id)
        if (position in LabelList.indices) {
            LabelList.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, LabelList.size)
        }
    }

    fun setLastSelectedItem(position: Int) {
        selectedItem = position
        notifyDataSetChanged()
    }

    fun sEnableSelection(): Boolean {
        return isSelectionMode
    }

    fun enableSelectionMode(enable: Boolean) {
        isSelectionMode = enable
        notifyItemRangeChanged(0, LabelList.size)
    }

    override fun getItemCount(): Int {
        return LabelList.size
    }
}
