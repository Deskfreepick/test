package com.deep.infotech.atm_card_wallet.maniya.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ItemLanguageManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.model.ModelLanguage

class AdapterLanguage(
    private val context: Context,
    private val modelLanguageList: List<ModelLanguage>,
    private val onItemClick: (ModelLanguage, Int) -> Unit
) : RecyclerView.Adapter<AdapterLanguage.MyViewHolder>() {

    private var selectedItem = -1

    class MyViewHolder(val binding: ItemLanguageManiyaBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemLanguageManiyaBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = modelLanguageList[position]
        with(holder.binding) {
            tvName.text = item.title
            ivImage.setImageResource(item.icon)

            if (selectedItem == position) {
                ivLanguageCheck.setImageResource(R.drawable.ic_checked)

            } else {
                ivLanguageCheck.setImageResource(R.drawable.ic_unchecked)
            }

            root.setOnClickListener {
                ivLanguageCheck.setImageResource(R.drawable.ic_checked)
                onItemClick(item, position)
            }
            ivLanguageCheck.setOnClickListener {
                ivLanguageCheck.setImageResource(R.drawable.ic_checked)
                onItemClick(item, position)
            }
        }
    }

    fun setLastSelectedItem(position: Int) {
        selectedItem = position
        notifyDataSetChanged()
    }

    fun getLastSelectedItem(): Int {
        return selectedItem
    }

    override fun getItemCount(): Int {
        return modelLanguageList.size
    }
}
