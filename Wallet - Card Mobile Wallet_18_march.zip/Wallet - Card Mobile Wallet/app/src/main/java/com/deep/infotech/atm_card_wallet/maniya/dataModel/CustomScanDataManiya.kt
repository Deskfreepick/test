package com.deep.infotech.atm_card_wallet.maniya.dataModel


import com.j256.ormlite.field.DatabaseField
import com.j256.ormlite.table.DatabaseTable

@DatabaseTable(tableName = "CustomCards")
data class CustomScanDataManiya(
    @DatabaseField(generatedId = true) // Auto-increment primary key
    var id: Long = 0,

    @DatabaseField(canBeNull = true)
    var title: String = "",

    @DatabaseField(canBeNull = true)
    var expDate: String = "",

    @DatabaseField(canBeNull = true)
    var note: String = "",

    @DatabaseField(canBeNull = true)
    var address: String = "",

    @DatabaseField(canBeNull = true)
    var barcode: String = "",

    @DatabaseField(canBeNull = true)
    var cardNumber: String = "",

    @DatabaseField(canBeNull = true)
    var date: String = "",

    @DatabaseField(canBeNull = true)
    var email: String = "",

    @DatabaseField(canBeNull = true)
    var fullName: String = "",

    @DatabaseField(canBeNull = true)
    var number: String = "",

    @DatabaseField(canBeNull = true)
    var phoneNumber: String = "",

    @DatabaseField(canBeNull = true)
    var text: String = "",

    @DatabaseField(canBeNull = true)
    var predefinedList: String = "",

    @DatabaseField(canBeNull = true)
    var url: String = "",

    @DatabaseField(foreign = true, foreignAutoRefresh = true, canBeNull = true, foreignColumnName = "id")
    var label: LabelDataManiya? = null,

    @DatabaseField(foreign = true, foreignAutoRefresh = true, canBeNull = true)
    var category: CategoryDataManiya? = null,

    @DatabaseField(canBeNull = true)
    var frontCardImage: String= "",

    @DatabaseField(canBeNull = true)
    var backCardImage: String= "",

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isLock: Boolean = false,

    @DatabaseField(canBeNull = true)
    var appearanceColor: Int = 0,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isSensitive: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isFav: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isDelete: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isArchive: Boolean = false
)
