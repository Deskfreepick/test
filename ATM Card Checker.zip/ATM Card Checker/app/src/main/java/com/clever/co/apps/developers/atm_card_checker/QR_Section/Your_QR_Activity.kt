package com.clever.co.apps.developers.atm_card_checker.QR_Section

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Base64
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R

class Your_QR_Activity : AppCompatActivity() {

    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null
    lateinit var idIVQrcode: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_your_qr)

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        tv_text_heading  = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Card History")


        idIVQrcode = findViewById(R.id.idIVQrcode)
        idIVQrcode.setImageBitmap(StringToBitMap(intent.getStringExtra("qr_img")))

    }

    fun StringToBitMap(str: String?): Bitmap? {
        return try {
            val decode = Base64.decode(str, 0)
            BitmapFactory.decodeByteArray(decode, 0, decode.size)
        } catch (e: Exception) {
            e.message
            null
        }
    }

    private fun Banner_Ad() {
        Banner_Ads_Here.mInstance!!.second_show_Banner(
            this,
            findViewById(R.id.AD_view),
            findViewById(R.id.B_Cont),
            findViewById(R.id.relative_ads_banner)
        )
    }

    override fun onResume() {
        super.onResume()
        Banner_Ad()
    }
}