package com.clever.co.apps.developers.atm_card_checker.Score_Show

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RelativeLayout
import android.widget.TextView
import com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R
import com.clever.co.apps.developers.atm_card_checker.Score.Data_Keepe_Credit

class Score_show_Activity : AppCompatActivity() {

    lateinit var your_score: TextView
    lateinit var tv_score_txt: TextView
    lateinit var ll_see_full_report: TextView

    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score_show)

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        tv_text_heading = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Credit Score")

        your_score = findViewById(R.id.your_score)
        tv_score_txt =  findViewById(R.id.tv_score_txt)
        ll_see_full_report =  findViewById(R.id.ll_see_full_report)

        your_score!!.text = java.lang.String.valueOf(Data_Keepe_Credit.getInstance().score)

        if (Data_Keepe_Credit.getInstance().getScore() >= 0 && Data_Keepe_Credit.getInstance()
                    .getScore() <= 350
            ) {
                tv_score_txt.setText("Poor Score")
                Savedprefrence_Score.setscore("Poor")
                your_score.setTextColor(getResources().getColor(R.color.poorcolor));

            } else if (Data_Keepe_Credit.getInstance().getScore() >= 350 && Data_Keepe_Credit.getInstance()
                    .getScore() <= 549
            ) {
                tv_score_txt.setText("Fair Score")
                Savedprefrence_Score.setscore("Fair")
                your_score.setTextColor(getResources().getColor(R.color.fircolor));

            } else if (Data_Keepe_Credit.getInstance().getScore() >= 550 && Data_Keepe_Credit.getInstance()
                    .getScore() <= 649
            ) {
                tv_score_txt.setText("Good Score")
                Savedprefrence_Score.setscore("Good")
                your_score.setTextColor(getResources().getColor(R.color.goodcolor));
            } else if (Data_Keepe_Credit.getInstance().getScore() >= 650 && Data_Keepe_Credit.getInstance()
                    .getScore() <= 749
            ) {
                tv_score_txt.setText("Very Good Score")
                Savedprefrence_Score.setscore("Very Good")
                your_score.setTextColor(getResources().getColor(R.color.exilentcolor));

            } else if (Data_Keepe_Credit.getInstance().getScore() >= 750 && Data_Keepe_Credit.getInstance()
                    .getScore() <= 900
            ) {
                tv_score_txt.setText("Excellent Score")
                Savedprefrence_Score.setscore("Excellent")
                your_score.setTextColor(getResources().getColor(R.color.exilentcolor));
            }


        ll_see_full_report.setOnClickListener {
            Interstitial_Ads_Here.instance!!.open_activity(
                this,
                Intent(
                    this@Score_show_Activity,
                    Score_Full_Result_Activity::class.java
                )
            )
        }

    }

    private fun Banner_Ad() {
        Banner_Ads_Here.mInstance!!.second_show_Banner(
            this,
            findViewById(R.id.AD_view),
            findViewById(R.id.B_Cont),
            findViewById(R.id.relative_ads_banner)
        )
    }

    override fun onResume() {
        super.onResume()
        Banner_Ad()
    }
}