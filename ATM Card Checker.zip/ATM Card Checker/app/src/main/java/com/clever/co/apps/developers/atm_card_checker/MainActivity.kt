package com.clever.co.apps.developers.atm_card_checker

import android.app.Dialog
import android.content.Intent
import android.content.IntentSender
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.clever.co.apps.developers.atm_card_checker.Ads.Ads_Google_ID
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.initialization.InitializationStatus
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.start_screen_show
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Native_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Network_Connected
import com.clever.co.apps.developers.atm_card_checker.History_Card.History_Card_Activity
import com.clever.co.apps.developers.atm_card_checker.Save_card_details.Save_Card_Details_Activity
import com.clever.co.apps.developers.atm_card_checker.Save_card_details.Save_Card_History_Activity
import com.clever.co.apps.developers.atm_card_checker.Score.Credit_Score_First_Checker_Activity

class MainActivity : AppCompatActivity() {

    var tv_card_checker: TextView? = null
    var img_near_bank: ImageView? = null
    var img_near_atm: ImageView? = null
    var linear_credit_score: LinearLayout? = null
    var li_save_card_details: LinearLayout? = null
    var li_card_history: LinearLayout? = null
    var li_save_card_history: LinearLayout? = null
    var tv_privacy: TextView? = null

    companion object {
        private const val IMMEDIATE_APP_UPDATE_REQ_CODE = 123
    }

    private var appUpdateManager: AppUpdateManager? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (Ads_Google_ID.get_show(this, "fb_show_banner") ||
            Ads_Google_ID.get_show(this, "fb_show_native") ||
            Ads_Google_ID.get_show(this, "fb_show_interstitial")
        ) {
            AudienceNetworkAds.initialize(this)
            MobileAds.initialize(this) { initializationStatus: InitializationStatus ->
                val statusMap =
                    initializationStatus.adapterStatusMap
                for (adapterClass in statusMap.keys) {
                    val status = statusMap[adapterClass]
                    Log.d(
                        "MyApp", String.format(
                            "Adapter name: %s, Description: %s, Latency: %d",
                            adapterClass, status!!.description, status.latency
                        )
                    )
                }
            }
        } else {
            MobileAds.initialize(this) { initializationStatus: InitializationStatus ->
                val statusMap =
                    initializationStatus.adapterStatusMap
                for (adapterClass in statusMap.keys) {
                    val status = statusMap[adapterClass]
                    Log.d(
                        "MyApp", String.format(
                            "Adapter name: %s, Description: %s, Latency: %d",
                            adapterClass, status!!.description, status.latency
                        )
                    )
                }
            }
        }

        if (Network_Connected.isConnected(this)) {
            Interstitial_Ads_Here.instance!!.pre_load_interstitial(this)
        }

        appUpdateManager = AppUpdateManagerFactory.create(this@MainActivity)
        checkUpdate()

        tv_card_checker = findViewById(R.id.tv_card_checker)
        tv_card_checker!!.setOnClickListener {
            Interstitial_Ads_Here.instance!!.open_activity(
                this, Intent(this, Credit_Card_Checker_Activity::class.java)
            )
        }

        img_near_bank = findViewById(R.id.img_near_bank)
        img_near_bank!!.setOnClickListener {
            try {
                val intent = Intent("android.intent.action.VIEW", Uri.parse("geo:0,0?q=BANK"))
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Any map app not found in your device",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        img_near_atm = findViewById(R.id.img_near_atm)
        img_near_atm!!.setOnClickListener {
            try {
                val intent = Intent("android.intent.action.VIEW", Uri.parse("geo:0,0?q=ATM"))
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Any map app not found in your device",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        linear_credit_score = findViewById(R.id.linear_credit_score)
        linear_credit_score!!.setOnClickListener {
            Interstitial_Ads_Here.instance!!.open_activity(
                this, Intent(this, Credit_Score_First_Checker_Activity::class.java)
            )
        }

        li_card_history = findViewById(R.id.li_card_history)
        li_card_history!!.setOnClickListener {
            Interstitial_Ads_Here.instance!!.open_activity(
                this, Intent(this, History_Card_Activity::class.java)
            )
        }

        li_save_card_details = findViewById(R.id.li_save_card_details)
        li_save_card_details!!.setOnClickListener {
            Interstitial_Ads_Here.instance!!.open_activity(
                this, Intent(this, Save_Card_Details_Activity::class.java)
            )
        }

        li_save_card_history = findViewById(R.id.li_save_card_history)
        li_save_card_history!!.setOnClickListener {
            Interstitial_Ads_Here.instance!!.open_activity(
                this, Intent(this, Save_Card_History_Activity::class.java)
            )
        }

        tv_privacy = findViewById(R.id.tv_privacy)
        tv_privacy!!.setOnClickListener {
            startActivity(Intent("android.intent.action.VIEW", Uri.parse(IDS_SEC.privacy_policy)))
        }


    }

    override fun onResume() {
        super.onResume()
        ShowNative()

        appUpdateManager!!.appUpdateInfo.addOnSuccessListener { appUpdateInfo: AppUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                try {
                    appUpdateManager!!.startUpdateFlowForResult(
                        appUpdateInfo,
                        AppUpdateType.IMMEDIATE,
                        this,
                        IMMEDIATE_APP_UPDATE_REQ_CODE
                    )
                } catch (e: IntentSender.SendIntentException) {
                    e.printStackTrace()
                }
            }
        }
    }

    override fun onBackPressed() {

        if (start_screen_show) {
            super.onBackPressed()
        } else {
            exit_dialog()
        }
    }

    private fun checkUpdate() {
        val appUpdateInfoTask = appUpdateManager!!.appUpdateInfo
        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo: AppUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
            ) {
                startUpdateFlow(appUpdateInfo)
            } else if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                startUpdateFlow(appUpdateInfo)
            }
        }
    }

    private fun startUpdateFlow(appUpdateInfo: AppUpdateInfo) {
        try {
            appUpdateManager!!.startUpdateFlowForResult(
                appUpdateInfo,
                AppUpdateType.IMMEDIATE,
                this,
                IMMEDIATE_APP_UPDATE_REQ_CODE
            )
        } catch (e: IntentSender.SendIntentException) {
            e.printStackTrace()
        }
    }

    fun ShowNative() {
        Native_Ads_Here.instance!!.second_show_native_ad_view(
            this,
            findViewById(R.id.Google_Na),
            findViewById(R.id.AD_Native_Con),
            findViewById(R.id.Sh_Layout),
            findViewById(R.id.native_ads_rl)
        )

    }

    fun exit_dialog() {
        val dialog =
            Dialog(this, androidx.appcompat.R.style.Base_Theme_AppCompat_Light_Dialog_MinWidth)
        dialog.requestWindowFeature(1)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(0))
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.exit_dialog)
        val lt_cancel = dialog.findViewById<LinearLayout>(R.id.lt_cancel)
        val lt_exit = dialog.findViewById<LinearLayout>(R.id.lt_exit)
        lt_exit.setOnClickListener {
//            Ads_Google_ID.Home_Screen(this, false)
            finishAffinity()
            dialog.dismiss()
        }
        lt_cancel.setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

}