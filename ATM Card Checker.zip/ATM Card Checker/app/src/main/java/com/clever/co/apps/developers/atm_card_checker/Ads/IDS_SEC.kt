package com.clever.co.apps.developers.atm_card_checker.Ads

object IDS_SEC {

    var when_click_ads = true

    var IDS_Activity_OPEN: Boolean? = null
    var app_open_show_ads = false
    var interstitial_first_time_show_ads = true

    var App_Open: String? = null
    var App_Open_1: String? = null
    var App_Open_id: String? = null
    var first_activity_ad_show_interstitial = false
    var fb_interstitial_show_ads = false
    var interstitial_rotated_ad_network = false
    var Count = 0
    var Default_Count = 0
    var interstitial_ad_first_ad_network: String? = null
    var interstitial: String? = null
    var interstitial_1: String? = null
    var interstitial_2: String? = null
    var re_interstitial: String? = null
    var re_interstitial_1: String? = null
    var re_interstitial_2: String? = null
    var fb_interstitial: String? = null
    var fb_interstitial_1: String? = null
    var fb_interstitial_2: String? = null
    var start_screen_show = false
    var splace_interstitial = false

    //native
    var first_activity_ad_show_native = false
    @JvmField
    var second_ad_show_native = false
    @JvmField
    var third_ad_show_native = false

    var fb_native_show_ads = false
    var native_rotated_ad_network = false
    var native_ad_first_ad_network: String? = null
    var ad_native: String? = null
    var ad_native_1: String? = null
    var ad_native_2: String? = null
    var re_ad_native: String? = null
    var re_ad_native_1: String? = null
    var re_ad_native_2: String? = null
    var fb_ad_native: String? = null
    var fb_ad_native_1: String? = null
    var fb_ad_native_2: String? = null

    var first_activity_ad_show_banner = false
    var second_ad_show_banner = false
    var third_ad_show_banner = false


    var fb_banner_show_ads = false
    var banner_rotated_ad_network = false
    var show_dialog = false
    var app_open_repeat_show = false
    var banner_ad_first_ad_network: String? = null
    var ad_banner: String? = null
    var ad_banner_1: String? = null
    var ad_banner_2: String? = null
    var re_ad_banner: String? = null
    var re_ad_banner_1: String? = null
    var re_ad_banner_2: String? = null
    var fb_ad_banner: String? = null
    var fb_ad_banner_1: String? = null
    var fb_ad_banner_2: String? = null


    var show_second_interstitial = false
    var show_third_interstitial = false
    var privacy_policy: String? = null

    var Admob_Native_Repeat_Failed = true
}