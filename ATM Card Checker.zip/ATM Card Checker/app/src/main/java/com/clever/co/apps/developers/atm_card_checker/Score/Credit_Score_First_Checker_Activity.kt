package com.clever.co.apps.developers.atm_card_checker.Score

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Native_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R

class Credit_Score_First_Checker_Activity : AppCompatActivity() , SeekBar.OnSeekBarChangeListener {

    var tv_text_heading: TextView? = null
    var rl_back_btn: RelativeLayout? = null
    lateinit var ll_first_next: TextView
    lateinit var sk_never: SeekBar
    lateinit var others_loan_sk: SeekBar
    lateinit var retail_finances_sk: SeekBar
    lateinit var student_loans_sb: SeekBar
    lateinit var credit_cards_sk: SeekBar
    lateinit var auto_loans_sk: SeekBar
    lateinit var mortgages_sk: SeekBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit_score_first_checker)

        tv_text_heading  = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Credit Score")

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        sk_never = findViewById(R.id.sk_never)
        sk_never.setOnSeekBarChangeListener(this)
        sk_never.max = 7
        sk_never.progress = Data_Keepe_Credit.getInstance().lastNegativeItem

        credit_cards_sk = findViewById(R.id.credit_cards_sk)
        credit_cards_sk.setOnSeekBarChangeListener(this)
        credit_cards_sk.max = 6
        credit_cards_sk.progress = Data_Keepe_Credit.getInstance().creditCards


        mortgages_sk = findViewById(R.id.mortgages_sk)
        mortgages_sk.setOnSeekBarChangeListener(this)
        mortgages_sk.max = 6
        mortgages_sk.progress = Data_Keepe_Credit.getInstance().mortgages


        ll_first_next = findViewById(R.id.ll_first_next)

        retail_finances_sk = findViewById(R.id.retail_finances_sk)
        retail_finances_sk.setOnSeekBarChangeListener(this)
        retail_finances_sk.max = 6
        retail_finances_sk.progress = Data_Keepe_Credit.getInstance().retailFinances


        auto_loans_sk = findViewById(R.id.auto_loans_sk)
        auto_loans_sk.setOnSeekBarChangeListener(this)
        auto_loans_sk.max = 6
        auto_loans_sk.progress = Data_Keepe_Credit.getInstance().autoLoans

        student_loans_sb = findViewById(R.id.student_loans_sb)
        student_loans_sb.setOnSeekBarChangeListener(this)
        student_loans_sb.max = 6
        student_loans_sb.progress = Data_Keepe_Credit.getInstance().studentLoans

        others_loan_sk = findViewById(R.id.others_loan_sk)
        others_loan_sk.setOnSeekBarChangeListener(this)
        others_loan_sk.max = 6
        others_loan_sk.progress = Data_Keepe_Credit.getInstance().otherLoans


        ll_first_next.setOnClickListener {
            Interstitial_Ads_Here.instance!!.third_activity(
                this,
                Intent(
                    this@Credit_Score_First_Checker_Activity,
                    Credit_Score_Second_Checker_Activity::class.java
                )
            )
        }
    }

    fun setText(i: Int, str: String?) {
        (findViewById<View>(i) as TextView).text = str
    }

    override fun onStartTrackingTouch(seekBar: SeekBar?) {}

    override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
        var valueOf = i.toString()
        if (seekBar.id == R.id.auto_loans_sk) {
            if (i == 6) {
                valueOf = "6+"
            }
            Credit_Score_Sec.st5 = valueOf
            setText(R.id.auto_loans_txt, valueOf)
        } else if (seekBar.id == R.id.credit_cards_sk) {
            if (i == 6) {
                valueOf = "6+"
            }
            Credit_Score_Sec.st2 = valueOf
            setText(R.id.credit_cards_txt, valueOf)
        } else if (seekBar.id == R.id.sk_never) {
            val sb: String
            sb = if (i == 0) {
                "Never"
            } else if (i == 7) {
                "7+ years"
            } else {
                val sb2 = StringBuilder()
                sb2.append(valueOf)
                sb2.append(if (i != 1) " years" else " year")
                sb2.toString()
            }
            Credit_Score_Sec.st1 = sb
            setText(R.id.text_never, sb)
        } else if (seekBar.id == R.id.mortgages_sk) {
            if (i == 6) {
                valueOf = "6+"
            }
            Credit_Score_Sec.st3 = valueOf
            setText(R.id.mortgages_txt, valueOf)
        } else if (seekBar.id == R.id.others_loan_sk) {
            if (i == 6) {
                valueOf = "6+"
            }
            Credit_Score_Sec.st7 = valueOf
            setText(R.id.other_loans_txt, valueOf)
        } else if (seekBar.id == R.id.retail_finances_sk) {
            if (i == 6) {
                valueOf = "6+"
            }
            Credit_Score_Sec.st4 = valueOf
            setText(R.id.retails_finance_txt, valueOf)
        } else if (seekBar.id == R.id.student_loans_sb) {
            if (i == 6) {
                valueOf = "6+"
            }
            Credit_Score_Sec.st6 = valueOf
            setText(R.id.student_loan_txt, valueOf)
        }
    }

    override fun onStopTrackingTouch(seekBar: SeekBar) {
        val progress = seekBar.progress
        if (seekBar.id == R.id.auto_loans_sk) {
            Data_Keepe_Credit.getInstance().autoLoans = progress
        } else if (seekBar.id == R.id.credit_cards_sk) {
            Data_Keepe_Credit.getInstance().creditCards = progress
        } else if (seekBar.id == R.id.sk_never) {
            Data_Keepe_Credit.getInstance().lastNegativeItem = progress
        } else if (seekBar.id == R.id.mortgages_sk) {
            Data_Keepe_Credit.getInstance().mortgages = progress
        } else if (seekBar.id == R.id.others_loan_sk) {
            Data_Keepe_Credit.getInstance().otherLoans = progress
        } else if (seekBar.id == R.id.retail_finances_sk) {
            Data_Keepe_Credit.getInstance().retailFinances = progress
        } else if (seekBar.id == R.id.student_loans_sb) {
            Data_Keepe_Credit.getInstance().studentLoans = progress
        }
    }

    fun ShowNative() {
        Native_Ads_Here.instance!!.third_show_native_ad_view(
            this,
            findViewById(R.id.Google_Na),
            findViewById(R.id.AD_Native_Con),
            findViewById(R.id.Sh_Layout),
            findViewById(R.id.native_ads_rl)
        )

    }

    override fun onResume() {
        super.onResume()
        ShowNative()
    }


}