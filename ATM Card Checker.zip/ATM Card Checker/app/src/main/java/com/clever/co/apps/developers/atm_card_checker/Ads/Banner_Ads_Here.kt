package com.clever.co.apps.developers.atm_card_checker.Ads

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.util.DisplayMetrics
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RelativeLayout
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError
import com.google.android.ump.ConsentInformation
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.Admob_Native_Repeat_Failed
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.banner_ad_first_ad_network
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.banner_rotated_ad_network
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.fb_banner_show_ads
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.first_activity_ad_show_banner
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.second_ad_show_banner
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.third_ad_show_banner

class Banner_Ads_Here {

    private var admob_banner_id: String? = null

    fun admob_banner_get_id() {
        if (admob_banner_id_rotation == 0) {
            if (Admob_banner_Repeat_Failed) {
                admob_banner_id =
                    IDS_SEC.ad_banner
                Admob_banner_Repeat_Failed = false
            } else {
                Log.v(
                    "Banner_____re_id",
                    "Native____re_id" + Admob_Native_Repeat_Failed + " " + IDS_SEC.re_ad_native
                )
                admob_banner_id =
                    IDS_SEC.re_ad_banner
                Admob_banner_Repeat_Failed = true
                admob_banner_fail_id_repeat()
            }
        } else if (admob_banner_id_rotation == 1) {
            if (Admob_banner_Repeat_Failed) {
                admob_banner_id =
                    IDS_SEC.ad_banner_1
                Admob_banner_Repeat_Failed = false
            } else {
                admob_banner_id =
                    IDS_SEC.re_ad_banner_1
                Admob_banner_Repeat_Failed = true
                admob_banner_fail_id_repeat()
            }
        } else if (admob_banner_id_rotation == 2) {
            if (Admob_Native_Repeat_Failed) {
                admob_banner_id =
                    IDS_SEC.ad_banner_2
                Admob_banner_Repeat_Failed = false
            } else {
                admob_banner_id =
                    IDS_SEC.re_ad_banner_2
                Admob_banner_Repeat_Failed = true
                admob_banner_fail_id_repeat()
            }
        }
    }

    fun admob_banner_fail_id_repeat() {
        Log.v("Native_____id", "Native_____id" + admob_banner_id_rotation)
        if (admob_banner_id_rotation == 0) {
            admob_banner_id_rotation = 1
        } else if (admob_banner_id_rotation == 1) {
            admob_banner_id_rotation = 2
        } else if (admob_banner_id_rotation == 2) {
            admob_banner_id_rotation = 0
        }
    }

    fun fb_native_get_id() {
        if (fb_banner_id_rotation == 0) {
            fb_banner_id =
                IDS_SEC.fb_ad_banner
        } else if (fb_banner_id_rotation == 1) {
            fb_banner_id =
                IDS_SEC.fb_ad_banner_1
        } else if (fb_banner_id_rotation == 2) {
            fb_banner_id =
                IDS_SEC.fb_ad_banner_2
        }
    }

    fun banner_preload_ads(activity: Activity) {
        if (!banner_rotated_ad_network) {
            if (!fb_banner_show_ads) {
                admob_banner_preload_ads(activity)
            } else {
                fb_pro_load_banner(activity)
            }
        } else {
            admob_banner_preload_ads(activity)
            fb_pro_load_banner(activity)
        }
    }

    fun admob_banner_preload_ads(activity: Activity) {
        admob_banner_get_id()
        Log.v("Banner_____Admob_id", "Native_____Admob_id$admob_banner_id")
        val adView = AdView(activity)
        adView.adUnitId = admob_banner_id!!
        val adSize =
            getFullWidthAdaptiveSize(
                activity
            )
        adView.setAdSize(adSize)
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() {
                super.onAdLoaded()
                admob_banner = adView
                admob_banner_fail_id_repeat()
                Admob_banner_Repeat_Failed = true
                Log.v("Banner_____Admob_show", "Native_____Admob_show" + admob_banner)
            }

            override fun onAdClicked() {
                super.onAdClicked()
                admob_banner_preload_ads(activity)
                IDS_SEC.when_click_ads = false
            }

            override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                super.onAdFailedToLoad(loadAdError)
                if (!Admob_banner_Repeat_Failed) {
                    admob_banner_preload_ads(activity)
                } else {
                    fb_pro_load_banner(activity)
                }
                Log.v(
                    "Banner_____Admob_onAdFailedToLoad",
                    "Native_____Admob_onAdFailedToLoad$loadAdError"
                )
            }

            override fun onAdImpression() {
                super.onAdImpression()
                Handler().postDelayed({
                    Log.v(
                        "Banner_____Admob_onAdFailedToLoad",
                        "Banner_____Admob_onAdFailedToLoad" + admob_banner_id + "-" + admob_banner_id_rotation + "-" /*+ isshow*/
                    )

                    admob_banner_preload_ads(activity);

                }, 15000)
            }
        }
        val adAdRequest: AdRequest.Builder
        adAdRequest = AdRequest.Builder()
        val request =
            GDPR_Checker_Here.Companion.status
        if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
            val extras = Bundle()
            extras.putString("npa", "1")
            adAdRequest.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        adView.loadAd(adAdRequest.build())
    }

    fun first_show_Banner(
        activity: Activity,
        adBanner: RelativeLayout,
        fbBanner: LinearLayout,
        relativeLayout: RelativeLayout
    ) {
        Log.v(
            "Banner_____show",
            "Native_____show $banner_ad_first_ad_network/$banner_rotated_ad_network"
        )
        if (first_activity_ad_show_banner) {
            if (!banner_rotated_ad_network) {
                if (!fb_banner_show_ads) {
                    show_admob_Banner(activity, adBanner, fbBanner)
                } else {
                    show_fb_banner_ad(activity, adBanner, fbBanner)
                }
            } else {
                if (banner_ad_first_ad_network.equals("F")) {
                    show_fb_banner_ad(activity, adBanner, fbBanner)
                    banner_ad_first_ad_network = "G"
                } else {
                    show_admob_Banner(activity, adBanner, fbBanner)
                    banner_ad_first_ad_network = "F"
                }
            }
        } else {
            relativeLayout.setVisibility(View.GONE);
        }
    }


    fun second_show_Banner(
        activity: Activity,
        adBanner: RelativeLayout,
        fbBanner: LinearLayout,
        relativeLayout: RelativeLayout
    ) {
        Log.v(
            "Banner_____show",
            "Native_____show $banner_ad_first_ad_network/$banner_rotated_ad_network"
        )
        if (second_ad_show_banner) {
            if (!banner_rotated_ad_network) {
                if (!fb_banner_show_ads) {
                    show_admob_Banner(activity, adBanner, fbBanner)
                } else {
                    show_fb_banner_ad(activity, adBanner, fbBanner)
                }
            } else {
                if (banner_ad_first_ad_network.equals("F")) {
                    show_fb_banner_ad(activity, adBanner, fbBanner)
                    banner_ad_first_ad_network = "G"
                } else {
                    show_admob_Banner(activity, adBanner, fbBanner)
                    banner_ad_first_ad_network = "F"
                }
            }
        } else {
            relativeLayout.setVisibility(View.GONE);
        }
    }

    fun third_show_Banner(
        activity: Activity,
        adBanner: RelativeLayout,
        fbBanner: LinearLayout,
        relativeLayout: RelativeLayout
    ) {
        Log.v(
            "Banner_____show",
            "Native_____show $banner_ad_first_ad_network/$banner_rotated_ad_network"
        )
        if (third_ad_show_banner) {
            if (!banner_rotated_ad_network) {
                if (!fb_banner_show_ads) {
                    show_admob_Banner(activity, adBanner, fbBanner)
                } else {
                    show_fb_banner_ad(activity, adBanner, fbBanner)
                }
            } else {
                if (banner_ad_first_ad_network.equals("F")) {
                    show_fb_banner_ad(activity, adBanner, fbBanner)
                    banner_ad_first_ad_network = "G"
                } else {
                    show_admob_Banner(activity, adBanner, fbBanner)
                    banner_ad_first_ad_network = "F"
                }
            }
        } else {
            relativeLayout.setVisibility(View.GONE);
        }
    }


    fun show_admob_Banner(
        activity: Activity,
        ad_banner: RelativeLayout,
        fb_layout_Banner: LinearLayout
    ) {
        if (admob_banner != null) {
            ad_banner.visibility = View.VISIBLE
            fb_layout_Banner.visibility = View.GONE
            if (admob_banner!!.parent != null) {
                (admob_banner!!.parent as ViewGroup).removeView(
                    admob_banner
                ) // <- fix
            }
            ad_banner.addView(admob_banner)
        } else {
            show_admob_fb_banner_ad(activity, ad_banner, fb_layout_Banner)
        }
    }

    fun fb_banner_fail_id_repeat() {
        Log.v("Native_____id", "Native_____id" + admob_banner_id_rotation)
        if (fb_banner_id_rotation == 0) {
            fb_banner_id_rotation = 1
        } else if (fb_banner_id_rotation == 1) {
            fb_banner_id_rotation = 2
        } else if (fb_banner_id_rotation == 2) {
            fb_banner_id_rotation = 0
        }
    }

    fun fb_pro_load_banner(activity: Activity) {
        Log.v("Banner_____fb_id", "Native_____fb_id" + fb_banner_id)
        fb_native_get_id()
        val adView = com.facebook.ads.AdView(
            activity,
            fb_banner_id,
            com.facebook.ads.AdSize.BANNER_HEIGHT_50
        )
        val adListener: com.facebook.ads.AdListener = object : com.facebook.ads.AdListener {
            override fun onError(ad: Ad, adError: AdError) {
                Log.v("Banner_____fb_onError", "Native_____fb_onError$adView")
                admob_banner_preload_ads(activity)
            }

            override fun onAdLoaded(ad: Ad) {
                Log.v("Banner_____fb_onAdLoaded", "Native_____fb_onAdLoaded$adView")
                fb_banner_fail_id_repeat()
                fb_banner = adView
            }

            override fun onAdClicked(ad: Ad) {
                fb_pro_load_banner(activity)
                IDS_SEC.when_click_ads = false
            }

            override fun onLoggingImpression(ad: Ad) {

                Handler().postDelayed({


                    fb_pro_load_banner(activity)


                }, 10000)

            }
        }
        adView.loadAd(adView.buildLoadAdConfig().withAdListener(adListener).build())
    }

    fun show_fb_banner_ad(
        activity: Activity,
        ad_banner: RelativeLayout,
        fb_layout_Banner: LinearLayout
    ) {
//        Log.v("Banner_____fb_show", "Native_____fb_show" + admob_banner);
        if (fb_banner != null) {
            ad_banner.visibility = View.GONE
            fb_layout_Banner.visibility = View.VISIBLE
            if (fb_banner!!.parent != null) {
                (fb_banner!!.parent as ViewGroup).removeView(
                    fb_banner
                )
            }
            fb_layout_Banner.addView(fb_banner)
        } else {
            show_fb_fail_admob_Banner(activity, ad_banner, fb_layout_Banner)
        }
    }

    fun show_fb_fail_admob_Banner(
        activity: Activity,
        ad_banner: RelativeLayout,
        fb_layout_Banner: LinearLayout
    ) {
        if (admob_banner != null) {
            ad_banner.visibility = View.VISIBLE
            fb_layout_Banner.visibility = View.GONE
            if (admob_banner!!.parent != null) {
                (admob_banner!!.parent as ViewGroup).removeView(
                    admob_banner
                ) // <- fix
            }
            ad_banner.addView(admob_banner)
            fb_banner_fail_id_repeat()
            if (fb_banner == null) {
                fb_pro_load_banner(activity)
            }
        }
    }

    fun show_admob_fb_banner_ad(
        activity: Activity,
        ad_banner: RelativeLayout,
        fb_layout_Banner: LinearLayout
    ) {
//        Log.v("Banner_____fb_show", "Native_____fb_show" + admob_banner);
        if (fb_banner != null) {
            ad_banner.visibility = View.GONE
            fb_layout_Banner.visibility = View.VISIBLE
            if (fb_banner!!.parent != null) {
                (fb_banner!!.parent as ViewGroup).removeView(
                    fb_banner
                )
            }
            fb_layout_Banner.addView(fb_banner)
            if (admob_banner == null) {
                admob_banner_preload_ads(activity)
            }
        }
    }

    companion object {
        var admob_banner: AdView? = null
        var fb_banner: com.facebook.ads.AdView? = null

        @JvmField
        var mInstance: Banner_Ads_Here? = null
        private var admob_banner_id_rotation = 0
        private var fb_banner_id_rotation = 0
        private var fb_banner_id: String? = null
        private var Admob_banner_Repeat_Failed = true
        val instance: Banner_Ads_Here?
            get() {
                if (mInstance == null) {
                    mInstance =
                        Banner_Ads_Here()
                }
                return mInstance
            }

        fun getFullWidthAdaptiveSize(activity: Activity): AdSize {
            val display = activity.windowManager.defaultDisplay
            val outMetrics = DisplayMetrics()
            display.getMetrics(outMetrics)
            val widthPixels = outMetrics.widthPixels.toFloat()
            val density = outMetrics.density
            val adWidth = (widthPixels / density).toInt()
            return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity, adWidth)
        }
    }
}