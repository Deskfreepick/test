package com.clever.co.apps.developers.atm_card_checker.Score_Show

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RelativeLayout
import android.widget.TextView
import com.clever.co.apps.developers.atm_card_checker.Ads.Native_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R
import com.clever.co.apps.developers.atm_card_checker.Score.Credit_Score_Sec
import com.clever.co.apps.developers.atm_card_checker.Score.Data_Keepe_Credit

class Score_Full_Result_Activity : AppCompatActivity() {

    lateinit var latest_txt_score: TextView
    lateinit var txt_share_score: TextView
    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null
    lateinit var first_ans_txt: TextView
    lateinit var third_ans_txt: TextView
    lateinit var four_ans_txt: TextView
    lateinit var five_ans_txt: TextView
    lateinit var six_ans_txt: TextView

    lateinit var ans_sec_1_txt: TextView
    lateinit var ans_sec_2_txt: TextView
    lateinit var ans_sec_3_txt: TextView
    lateinit var ans_sec_4_txt: TextView
    lateinit var ans_sec_5_txt: TextView
    lateinit var ans_sec_6_txt: TextView

    lateinit var show_score_name: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_score_full_result)

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        tv_text_heading = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Credit Score")

        latest_txt_score = findViewById(R.id.latest_txt_score)
        show_score_name = findViewById(R.id.show_score_name)
        txt_share_score = findViewById(R.id.txt_share_score)

        first_ans_txt = findViewById(R.id.first_ans_txt)
        ans_sec_1_txt = findViewById(R.id.ans_sec_1_txt)
        ans_sec_2_txt = findViewById(R.id.ans_sec_2_txt)
        ans_sec_3_txt = findViewById(R.id.ans_sec_3_txt)
        ans_sec_4_txt = findViewById(R.id.ans_sec_4_txt)
        ans_sec_5_txt = findViewById(R.id.ans_sec_5_txt)
        ans_sec_6_txt = findViewById(R.id.ans_sec_6_txt)

        third_ans_txt = findViewById(R.id.third_ans_txt)
        four_ans_txt = findViewById(R.id.four_ans_txt)
        five_ans_txt = findViewById(R.id.five_ans_txt)
        six_ans_txt = findViewById(R.id.six_ans_txt)

        ans_sec_1_txt.text = Credit_Score_Sec.st2
        ans_sec_2_txt.text = Credit_Score_Sec.st3
        ans_sec_3_txt.text = Credit_Score_Sec.st4
        ans_sec_4_txt.text = Credit_Score_Sec.st5
        ans_sec_5_txt.text = Credit_Score_Sec.st6
        ans_sec_6_txt.text = Credit_Score_Sec.st7

        first_ans_txt.text = Credit_Score_Sec.st1
        third_ans_txt.text = Credit_Score_Sec.st8
        four_ans_txt.text = Credit_Score_Sec.st9
        five_ans_txt.text = Credit_Score_Sec.f10
        six_ans_txt.text = Credit_Score_Sec.f11

        latest_txt_score.text = Data_Keepe_Credit.getInstance().score.toString()


        if (Data_Keepe_Credit.getInstance().getScore() >= 0 && Data_Keepe_Credit.getInstance()
                .getScore() <= 350
        ) {
            show_score_name.setText("Poor Score")
            Savedprefrence_Score.setscore("Poor")
            latest_txt_score.setTextColor(getResources().getColor(R.color.white));

        } else if (Data_Keepe_Credit.getInstance().getScore() >= 350 && Data_Keepe_Credit.getInstance()
                .getScore() <= 549
        ) {
            show_score_name.setText("Fair Score")
            Savedprefrence_Score.setscore("Fair")
            latest_txt_score.setTextColor(getResources().getColor(R.color.white));

        } else if (Data_Keepe_Credit.getInstance().getScore() >= 550 && Data_Keepe_Credit.getInstance()
                .getScore() <= 649
        ) {
            show_score_name.setText("Good Score")
            Savedprefrence_Score.setscore("Good")
            latest_txt_score.setTextColor(getResources().getColor(R.color.white));
        } else if (Data_Keepe_Credit.getInstance().getScore() >= 650 && Data_Keepe_Credit.getInstance()
                .getScore() <= 749
        ) {
            show_score_name.setText("Very Good Score")
            Savedprefrence_Score.setscore("Very Good")
            latest_txt_score.setTextColor(getResources().getColor(R.color.white));

        } else if (Data_Keepe_Credit.getInstance().getScore() >= 750 && Data_Keepe_Credit.getInstance()
                .getScore() <= 900
        ) {
            show_score_name.setText("Excellent Score")
            Savedprefrence_Score.setscore("Excellent")
            latest_txt_score.setTextColor(getResources().getColor(R.color.white));
        }

        txt_share_score.setOnClickListener {
            val intent = Intent()
            intent.action = "android.intent.action.SEND"
            intent.putExtra(
                "android.intent.extra.TEXT",
                """1.${resources.getString(R.string.last_negative_item)}  :-  ${Credit_Score_Sec.st1}
                 2.""" + resources.getString(
                    R.string.count_following_accounts
                ) + "\n\t\t1." + resources.getString(R.string.credit_cards) + " :- " + Credit_Score_Sec.st2 + "\n\t\t2." + resources.getString(
                    R.string.mortgages
                ) + " :- " + Credit_Score_Sec.st3 + "\n\t\t3." + resources.getString(
                    R.string.retail_finances
                ) + " :- " + Credit_Score_Sec.st4 + "\n\t\t4." + resources.getString(
                    R.string.auto_loans
                ) + " :- " + Credit_Score_Sec.st5 + "\n\t\t5." + resources.getString(
                    R.string.student_loans
                ) + " :- " + Credit_Score_Sec.st6 + "\n\t\t6." + resources.getString(
                    R.string.other_loans
                ) + " :- " + Credit_Score_Sec.st7 + "\n\n3." + resources.getString(
                    R.string.all_credit_limits
                ) + "  :-  " + Credit_Score_Sec.st8 + "\n\n4." + resources.getString(
                    R.string.recent_balances
                ) + "  :-  " + Credit_Score_Sec.st9 + "\n\n5." + resources.getString(
                    R.string.apply_credit
                ) + "  :-  " + Credit_Score_Sec.f10 + "\n\n6." + resources.getString(
                    R.string.first_open_oldest_active
                ) + "  :-  " + Credit_Score_Sec.f11 + "\n\n\n\t\t\t\t\t" + resources.getString(
                    R.string.your_score
                ) + "  :-  " + Data_Keepe_Credit.getInstance().score + "\n\n"
            )
            intent.type = "text/plain"
            startActivity(Intent.createChooser(intent, null))
        }

    }

    fun ShowNative() {
        Native_Ads_Here.instance!!.second_show_native_ad_view(
            this,
            findViewById(R.id.Google_Na),
            findViewById(R.id.AD_Native_Con),
            findViewById(R.id.Sh_Layout),
            findViewById(R.id.native_ads_rl)
        )

    }


    override fun onResume() {
        super.onResume()
        ShowNative()
    }
}