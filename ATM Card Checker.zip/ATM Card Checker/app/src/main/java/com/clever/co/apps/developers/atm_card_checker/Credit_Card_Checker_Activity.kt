package com.clever.co.apps.developers.atm_card_checker

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here

class Credit_Card_Checker_Activity : AppCompatActivity() {

    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null
    var tx_card_valid: TextView? = null
    var credit_card_number_edit: EditText? = null
    var card_name_edit: EditText? = null
    var card_date_edit: EditText? = null
    var ll_is_valid: LinearLayout? = null
    var ll_is_notvalid: LinearLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit_card_checker)

        tv_text_heading = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Credit Card Checker")

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }
        card_name_edit = findViewById(R.id.card_name_edit)

        credit_card_number_edit = findViewById(R.id.credit_card_number_edit)
        credit_card_number_edit!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(editable: Editable) {
                var i = 0
                while (i < editable.length) {
                    if (' ' == editable[i]) {
                        val i2 = i + 1
                        if (i2 % 5 != 0 || i2 == editable.length) {
                            editable.delete(i, i2)
                        }
                    }
                    i++
                }
                var i3 = 4
                while (i3 < editable.length) {
                    if ("0123456789".indexOf(editable[i3]) >= 0) {
                        editable.insert(i3, " ")
                    }
                    i3 += 5
                }
            }

            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i2: Int, i3: Int) {}
            override fun onTextChanged(charSequence: CharSequence, i: Int, i2: Int, i3: Int) {}
        })

        card_date_edit = findViewById(R.id.card_date_edit)
        card_date_edit!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(editable: Editable) {
                if (editable.length > 0 && editable.length % 3 == 0 && '/' == editable[editable.length - 1]) {
                    editable.delete(editable.length - 1, editable.length)
                }
                if (editable.length <= 0 || editable.length % 3 != 0 || !Character.isDigit(
                        editable[editable.length - 1]
                    ) || TextUtils.split(editable.toString(), "/").size > 2
                ) {
                    return
                }
                editable.insert(editable.length - 1, "/")
            }
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i2: Int, i3: Int) {}
            override fun onTextChanged(charSequence: CharSequence, i: Int, i2: Int, i3: Int) {}
        })

        ll_is_valid = findViewById(R.id.ll_is_valid)
        ll_is_notvalid = findViewById(R.id.ll_is_notvalid)

        tx_card_valid = findViewById(R.id.tx_card_valid)
        tx_card_valid!!.setOnClickListener(View.OnClickListener {
            val obj = credit_card_number_edit!!.text.toString()
            val obj2 = card_name_edit!!.text.toString()
            val obj3 = card_date_edit!!.text.toString()
            if (!obj.startsWith("5") && !obj.startsWith("4") && !obj.startsWith("40") && !obj.startsWith(
                    "41"
                ) && !obj.startsWith("42") && !obj.startsWith("43")
            ) {
                if (obj2.isEmpty()) {
                    Toast.makeText(this@Credit_Card_Checker_Activity, "Enter person name", Toast.LENGTH_SHORT)
                        .show()
                    return@OnClickListener
                } else if (obj3.isEmpty()) {
                    Toast.makeText(this@Credit_Card_Checker_Activity, "Enter expiry Date", Toast.LENGTH_SHORT)
                        .show()
                    return@OnClickListener
                } else {
                    // not
                    ll_is_notvalid!!.visibility = View.VISIBLE
                    ll_is_valid!!.visibility = View.GONE
                    credit_card_number_edit!!.setText("")
                    return@OnClickListener
                }
            }
            //show
            ll_is_valid!!.visibility = View.VISIBLE
            ll_is_notvalid!!.visibility = View.GONE
            credit_card_number_edit!!.setText("")

            val gdgdb =
                gdgDB(this@Credit_Card_Checker_Activity)
            if (intent.extras != null) {

                return@OnClickListener
            }
            gdgdb.insertData(obj, obj2, obj3)
        })

    }

    private fun Banner_Ad() {
        Banner_Ads_Here.mInstance!!.first_show_Banner(
            this,
            findViewById(R.id.AD_view),
            findViewById(R.id.B_Cont),
            findViewById(R.id.relative_ads_banner)
        )
    }

    override fun onResume() {
        super.onResume()
        Banner_Ad()
    }
}