package com.clever.co.apps.developers.atm_card_checker.Save_card_details;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

@SuppressWarnings("all")
public class DBHandler extends SQLiteOpenHelper {
    private static final String CARD_CVV = "card_cvv";
    private static final String CARD_NAME = "card_name";
    private static final String CARD_QR_CODE = "card_qr_code";
    private static final String CARD_TYPE = "card_type";
    private static final String DB_NAME = "coursedb";
    private static final int DB_VERSION = 1;
    private static final String ID_COL = "id";
    private static final String TABLE_NAME = "mycourses";

    public DBHandler(Context context) {
        super(context, DB_NAME, (SQLiteDatabase.CursorFactory) null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE mycourses (id INTEGER PRIMARY KEY AUTOINCREMENT, card_type INTEGER,card_qr_code TEXT,card_name TEXT,card_cvv TEXT)");
    }

    public void addNewCourse(int i, String str, String str2, String str3) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(CARD_TYPE, Integer.valueOf(i));
        contentValues.put(CARD_QR_CODE, str);
        contentValues.put(CARD_NAME, str2);
        contentValues.put(CARD_CVV, str3);
        writableDatabase.insert(TABLE_NAME, null, contentValues);
        writableDatabase.close();
    }

    public ArrayList<card_h_model> readCourses() {
        Cursor rawQuery = getReadableDatabase().rawQuery("SELECT * FROM mycourses", null);
        ArrayList<card_h_model> arrayList = new ArrayList<>();
        if (rawQuery.moveToFirst()) {
            do {
                arrayList.add(new card_h_model(rawQuery.getInt(1), rawQuery.getString(2), rawQuery.getString(3), rawQuery.getString(4)));
            } while (rawQuery.moveToNext());
            rawQuery.close();
            return arrayList;
        }
        rawQuery.close();
        return arrayList;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        sQLiteDatabase.execSQL("DROP TABLE IF EXISTS mycourses");
        onCreate(sQLiteDatabase);
    }
}
