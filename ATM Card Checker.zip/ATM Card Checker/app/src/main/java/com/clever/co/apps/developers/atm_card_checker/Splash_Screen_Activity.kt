package com.clever.co.apps.developers.atm_card_checker

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Base64
import android.util.Log
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import com.clever.co.apps.developers.atm_card_checker.Ads.Ads_Google_ID.Count
import com.clever.co.apps.developers.atm_card_checker.Ads.Ads_Google_ID.Default_Count
import com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.initialization.InitializationStatus
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Native_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Network_Connected
import com.clever.co.apps.developers.atm_card_checker.Ads.Manager_Ads_Here_Open
import com.facebook.FacebookSdk
import com.facebook.FacebookSdk.setAdvertiserIDCollectionEnabled
import com.facebook.FacebookSdk.setAutoLogAppEventsEnabled
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings


class Splash_Screen_Activity : AppCompatActivity() {

    var pg_bar: ProgressBar? = null
    var openManager: Manager_Ads_Here_Open? = null
    var ll_ads: LinearLayout? = null
    var firebaseConfig: FirebaseRemoteConfig? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash_screen)

        pg_bar = findViewById(R.id.loading_bar)
        ll_ads = findViewById(R.id.ll_ads)

        MobileAds.initialize(this) { initializationStatus: InitializationStatus ->
            val statusMap = initializationStatus.adapterStatusMap
            for (adapterClass in statusMap.keys) {
                val status = statusMap[adapterClass]
                Log.d(
                    "MyApp", String.format(
                        "Adapter name: %s, Description: %s, Latency: %d",
                        adapterClass,
                        status!!.description,
                        status.latency
                    )
                )
            }
        }

        AudienceNetworkAds.initialize(this)
        setAutoLogAppEventsEnabled(true);
        FacebookSdk.fullyInitialize()
        setAdvertiserIDCollectionEnabled(true);



//        IDS_SEC.App_Open = "ca-app-pub-3940256099942544/3419835294"
//        IDS_SEC.App_Open_1 = "ca-app-pub-3940256099942544/3419835293"
//        IDS_SEC.app_open_show_ads = true
//
//        IDS_SEC.first_activity_ad_show_interstitial = true
//        IDS_SEC.fb_interstitial_show_ads = true
//        IDS_SEC.interstitial_rotated_ad_network = false
//        IDS_SEC.show_dialog = true
//        IDS_SEC.start_screen_show = true
//        IDS_SEC.show_second_interstitial = true
//        IDS_SEC.show_third_interstitial = true
//        IDS_SEC.app_open_repeat_show = true
//        IDS_SEC.interstitial_ad_first_ad_network = "F"
//        IDS_SEC.Default_Count = 2
//        Count(this, 3)
//        Default_Count(this, 2)
//
//        IDS_SEC.interstitial = "ca-app-pub-3940256099942544/1033173712"
//        IDS_SEC.interstitial_1 = "ca-app-pub-3940256099942544/1033173712"
//        IDS_SEC.interstitial_2 = "ca-app-pub-3940256099942544/1033173712"
//        IDS_SEC.re_interstitial = "ca-app-pub-3940256099942544/1033173712"
//        IDS_SEC.re_interstitial_1 = "ca-app-pub-3940256099942544/1033173712"
//        IDS_SEC.re_interstitial_2 = "ca-app-pub-3940256099942544/1033173712"
//        IDS_SEC.fb_interstitial = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//        IDS_SEC.fb_interstitial_1 = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//        IDS_SEC.fb_interstitial_2 = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//        IDS_SEC.Count = 3
//
//        IDS_SEC.native_rotated_ad_network = false
//        IDS_SEC.first_activity_ad_show_native = true
//        IDS_SEC.second_ad_show_native = true
//        IDS_SEC.third_ad_show_native = true
//
//        IDS_SEC.native_ad_first_ad_network = "F"
//
//        IDS_SEC.fb_native_show_ads = true
//        IDS_SEC.ad_native = "ca-app-pub-3940256099942544/2247696110"
//        IDS_SEC.ad_native_1 = "ca-app-pub-3940256099942544/2247696110"
//        IDS_SEC.ad_native_2 = "ca-app-pub-3940256099942544/2247696110"
//        IDS_SEC.re_ad_native = "ca-app-pub-3940256099942544/2247696110"
//        IDS_SEC.re_ad_native_1 = "ca-app-pub-3940256099942544/2247696110"
//        IDS_SEC.re_ad_native_2 = "ca-app-pub-3940256099942544/2247696110"
//        IDS_SEC.fb_ad_native = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//        IDS_SEC.fb_ad_native_1 = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//        IDS_SEC.fb_ad_native_2 = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//
//        IDS_SEC.banner_rotated_ad_network = false
//        IDS_SEC.first_activity_ad_show_banner = true
//        IDS_SEC.second_ad_show_banner = true
//        IDS_SEC.third_ad_show_banner = true
//        IDS_SEC.banner_ad_first_ad_network = "F"
//
//        IDS_SEC.fb_banner_show_ads = true
//        IDS_SEC.ad_banner = "ca-app-pub-3940256099942544/6300978111"
//        IDS_SEC.ad_banner_1 = "ca-app-pub-3940256099942544/6300978111"
//        IDS_SEC.ad_banner_2 = "ca-app-pub-3940256099942544/6300978111"
//        IDS_SEC.re_ad_banner = "ca-app-pub-3940256099942544/6300978111"
//        IDS_SEC.re_ad_banner_1 = "ca-app-pub-3940256099942544/6300978111"
//        IDS_SEC.re_ad_banner_2 = "ca-app-pub-3940256099942544/6300978111"
//        IDS_SEC.fb_ad_banner = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//        IDS_SEC.fb_ad_banner_1 = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//        IDS_SEC.fb_ad_banner_2 = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID"
//        IDS_SEC.privacy_policy =
//            "https://amazingappscollection.blogspot.com/2023/05/privacy-policy.html"
//
//        Native_Ads_Here.instance!!.native_pre_load(this@Splash_Screen_Activity)
//        com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here.instance!!.banner_preload_ads(this)
//        Interstitial_Ads_Here.instance!!.pre_load_interstitial(this)
//
//        IDS_SEC.App_Open_id = IDS_SEC.App_Open
//        IDS_SEC.IDS_Activity_OPEN = true
//
//        if (Network_Connected.isConnected(this)) {
//            if (IDS_SEC.app_open_show_ads) {
//                Handler().postDelayed({
//                    openManager = Manager_Ads_Here_Open(this@Splash_Screen_Activity, ll_ads!!)
//                }, 2000)
//            } else {
//                Open_Activity()
//            }
//        } else {
//            Open_Activity()
//        }


        if (Network_Connected.isConnected(this)) {
            firebaseConfig = FirebaseRemoteConfig.getInstance()
            val configSettings =
                FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(0).build()
            firebaseConfig!!.setConfigSettingsAsync(configSettings)
            firebaseConfig!!.fetchAndActivate().addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    displayWelcomeMessage()
                } else {
                    Toast.makeText(
                        this@Splash_Screen_Activity, "Fetch failed", Toast.LENGTH_SHORT
                    ).show()
                }
            }
        } else {
            Open_Activity()
        }
    }

    private fun Open_Activity() {
        Handler().postDelayed({
            if (IDS_SEC.start_screen_show) {
//                if (Ads_Google_ID.get_Home_Screen(this)) {
                startActivity(Intent(this, Start_Screen_Activity::class.java))
                finish()
//                } else {
//                    startActivity(Intent(this, MainActivity::class.java))
//                    finish()
//                }
            } else {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            }


        }, 4000)
    }

    private fun Interstitial_Open_Activity() {
        Handler().postDelayed({
            if (IDS_SEC.start_screen_show) {
//                if (Ads_Google_ID.get_Home_Screen(this)) {
                Interstitial_Ads_Here.instance!!.splace_open_activity(
                    this,
                    Intent(this, Start_Screen_Activity::class.java)

                )


//                } else {
//                    startActivity(Intent(this, MainActivity::class.java))
//                    finish()
//                }
            } else {
                Interstitial_Ads_Here.instance!!.splace_open_activity(
                    this,
                    Intent(this, MainActivity::class.java)

                )

            }


        }, 4000)
    }


    private fun displayWelcomeMessage() {

        IDS_SEC.first_activity_ad_show_interstitial =
            firebaseConfig!!.getBoolean("first_interstitial_show")
        IDS_SEC.fb_interstitial_show_ads =
            firebaseConfig!!.getBoolean("fb_show_interstitial")
        IDS_SEC.interstitial_rotated_ad_network =
            firebaseConfig!!.getBoolean("interstitial_rotated_ad_network")
        IDS_SEC.show_dialog = firebaseConfig!!.getBoolean("show_dialog")
        IDS_SEC.show_dialog = firebaseConfig!!.getBoolean("splash_interstitial")
        IDS_SEC.start_screen_show = firebaseConfig!!.getBoolean("start_screen_show")
        IDS_SEC.show_second_interstitial =
            firebaseConfig!!.getBoolean("show_second_interstitial")
        IDS_SEC.show_third_interstitial =
            firebaseConfig!!.getBoolean("show_third_interstitial")
        IDS_SEC.app_open_repeat_show = firebaseConfig!!.getBoolean("app_open_repeat_show")
        IDS_SEC.interstitial_ad_first_ad_network =
            firebaseConfig!!.getString("interstitial_first_choice_network")
        IDS_SEC.Default_Count = firebaseConfig!!.getLong("default_count").toInt()
        Count(this, firebaseConfig!!.getLong("count").toInt())
        Default_Count(
            this,
            firebaseConfig!!.getLong("default_count").toInt()
        )

        IDS_SEC.App_Open = firebaseConfig!!.getString("app_open")
        IDS_SEC.App_Open_1 = firebaseConfig!!.getString("app_open_1")
        IDS_SEC.app_open_show_ads = firebaseConfig!!.getBoolean("app_open_show_ads_1")
        IDS_SEC.interstitial = firebaseConfig!!.getString("interstitial")
        IDS_SEC.interstitial_1 = firebaseConfig!!.getString("interstitial1")
        IDS_SEC.interstitial_2 = firebaseConfig!!.getString("interstitial2")
        IDS_SEC.re_interstitial = firebaseConfig!!.getString("re_interstitial")
        IDS_SEC.re_interstitial_1 = firebaseConfig!!.getString("re_interstitial1")
        IDS_SEC.re_interstitial_2 = firebaseConfig!!.getString("re_interstitial2")
        IDS_SEC.fb_interstitial = firebaseConfig!!.getString("fb_interstitial")
        IDS_SEC.fb_interstitial_1 = firebaseConfig!!.getString("fb_interstitial1")
        IDS_SEC.fb_interstitial_2 = firebaseConfig!!.getString("fb_interstitial2")
        IDS_SEC.Count = firebaseConfig!!.getLong("count").toInt()

        //
        IDS_SEC.native_rotated_ad_network =
            firebaseConfig!!.getBoolean("native_rotated_ad_network")
        IDS_SEC.first_activity_ad_show_native =
            firebaseConfig!!.getBoolean("start_show_native")
        IDS_SEC.second_ad_show_native =
            firebaseConfig!!.getBoolean("second_ad_show_native")
        IDS_SEC.third_ad_show_native = firebaseConfig!!.getBoolean("third_ad_show_native")
        IDS_SEC.native_ad_first_ad_network =
            firebaseConfig!!.getString("native_ad_first_choice_network")


        IDS_SEC.fb_native_show_ads = firebaseConfig!!.getBoolean("fb_show_native")
        IDS_SEC.ad_native = firebaseConfig!!.getString("native")
        IDS_SEC.ad_native_1 = firebaseConfig!!.getString("native1")
        IDS_SEC.ad_native_2 = firebaseConfig!!.getString("native2")
        IDS_SEC.re_ad_native = firebaseConfig!!.getString("re_native")
        IDS_SEC.re_ad_native_1 = firebaseConfig!!.getString("re_native1")
        IDS_SEC.re_ad_native_2 = firebaseConfig!!.getString("re_native2")
        IDS_SEC.fb_ad_native = firebaseConfig!!.getString("fb_native")
        IDS_SEC.fb_ad_native_1 = firebaseConfig!!.getString("fb_native1")
        IDS_SEC.fb_ad_native_2 = firebaseConfig!!.getString("fb_native2")

//
        IDS_SEC.banner_rotated_ad_network =
            firebaseConfig!!.getBoolean("banner_rotated_ad_network")
        IDS_SEC.first_activity_ad_show_banner =
            firebaseConfig!!.getBoolean("start_show_banner")
        IDS_SEC.second_ad_show_banner =
            firebaseConfig!!.getBoolean("second_ad_show_banner")
        IDS_SEC.third_ad_show_banner = firebaseConfig!!.getBoolean("third_ad_show_banner")

        IDS_SEC.banner_ad_first_ad_network =
            firebaseConfig!!.getString("banner_ad_first_choice_network")
        IDS_SEC.fb_banner_show_ads = firebaseConfig!!.getBoolean("fb_show_banner")
        IDS_SEC.ad_banner = firebaseConfig!!.getString("banner")
        IDS_SEC.ad_banner_1 = firebaseConfig!!.getString("banner1")
        IDS_SEC.ad_banner_2 = firebaseConfig!!.getString("banner2")
        IDS_SEC.re_ad_banner = firebaseConfig!!.getString("re_banner")
        IDS_SEC.re_ad_banner_1 = firebaseConfig!!.getString("re_banner1")
        IDS_SEC.re_ad_banner_2 = firebaseConfig!!.getString("re_banner2")
        IDS_SEC.fb_ad_banner = firebaseConfig!!.getString("fb_banner")
        IDS_SEC.fb_ad_banner_1 = firebaseConfig!!.getString("fb_banner1")
        IDS_SEC.fb_ad_banner_2 = firebaseConfig!!.getString("fb_banner2")
        IDS_SEC.privacy_policy = firebaseConfig!!.getString("privacy_policy")

        Interstitial_Ads_Here.instance!!.pre_load_interstitial(this)
        Native_Ads_Here.instance!!.native_pre_load(this@Splash_Screen_Activity)
        Banner_Ads_Here.instance!!.banner_preload_ads(this)


        IDS_SEC.App_Open_id = IDS_SEC.App_Open
        IDS_SEC.IDS_Activity_OPEN = true
        if (IDS_SEC.app_open_show_ads) {
            Handler().postDelayed({
                openManager =
                    Manager_Ads_Here_Open(this@Splash_Screen_Activity, ll_ads!!)
            }, 2500)
        } else if (IDS_SEC.splace_interstitial) {
            Handler().postDelayed({
                Interstitial_Open_Activity()
            }, 2500)

        } else {
            Open_Activity()
        }
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        finishAffinity()
    }

}