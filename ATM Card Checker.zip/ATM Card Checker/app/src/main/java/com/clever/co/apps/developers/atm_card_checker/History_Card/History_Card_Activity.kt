package com.clever.co.apps.developers.atm_card_checker.History_Card

import android.database.Cursor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R
import com.clever.co.apps.developers.atm_card_checker.gdgDB

class History_Card_Activity : AppCompatActivity() {

    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null
    private val model_list: ArrayList<History_Model> = ArrayList()
    lateinit var card_history_recycle: RecyclerView
    lateinit var li_empty_section: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_card)

        card_history_recycle = findViewById(R.id.card_history_recycle)
        li_empty_section = findViewById(R.id.li_empty_section)
        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }
        tv_text_heading = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Card History")


        val data: Cursor = gdgDB(
            this
        ).data
        while (data.moveToNext()) {
            model_list.add(
                History_Model(
                    data.getInt(0),
                    data.getString(1),
                    data.getString(2),
                    data.getString(3)
                )
            )
        }
        card_history_recycle.adapter =
            Card_History_Adapter(
                this@History_Card_Activity,
                model_list
            )

    }

    override fun onResume() {
        if (model_list.size <= 0) {
            li_empty_section.visibility = View.VISIBLE
        } else {
            li_empty_section.visibility = View.GONE
        }
        super.onResume()
        Banner_Ad()

    }


    private fun Banner_Ad() {
        Banner_Ads_Here.mInstance!!.third_show_Banner(
            this,
            findViewById(R.id.AD_view),
            findViewById(R.id.B_Cont),
            findViewById(R.id.relative_ads_banner)
        )
    }


}