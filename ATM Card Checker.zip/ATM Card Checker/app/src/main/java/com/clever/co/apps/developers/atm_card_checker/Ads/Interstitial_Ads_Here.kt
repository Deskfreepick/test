package com.clever.co.apps.developers.atm_card_checker.Ads

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import com.facebook.ads.Ad
import com.facebook.ads.InterstitialAdListener
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.fb_interstitial_show_ads
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.first_activity_ad_show_interstitial
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.interstitial_ad_first_ad_network
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.interstitial_first_time_show_ads
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.interstitial_rotated_ad_network
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.show_dialog
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.show_second_interstitial
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.show_third_interstitial
import com.clever.co.apps.developers.atm_card_checker.Ads.Ads_Google_ID.get_Count
import com.clever.co.apps.developers.atm_card_checker.R

class Interstitial_Ads_Here {
    var clickCount = 0
    var isInterstitialRequest = false
    var isInterstitialfbRequest = false
    var dialog_ad: ProgressDialog? = null

    fun pre_load_interstitial(activity: Activity) {
        if (interstitial_rotated_ad_network) {
            if (interstitial_ad_first_ad_network.equals("G")) {
                if (mInterstitialAdMob == null) {
                    instance!!.Load_Admob_Interstitial(activity)
                }
            } else {
                if (mInterstitialfb == null) {
                    Load_Fb_interstitial_Ad(activity)
                }
            }
        } else {
            if (!fb_interstitial_show_ads) {
                if (mInterstitialAdMob == null) {
                    instance!!.Load_Admob_Interstitial(activity)
                }
            } else {
                if (mInterstitialfb == null) {
                    Load_Fb_interstitial_Ad(activity)
                }
            }
        }
    }


    fun admob_interstitial_get_id() {
        Log.v(
            "onAdFailedToLoad_____",
            "onAdFailedToLoad_____" + Admob_interstitial_Repeat_failed + "/" + " " + admob_interstitial_id_rotation
        )
        if (admob_interstitial_id_rotation == 0) {
            if (Admob_interstitial_Repeat_failed) {
                admob_interstitial_id = IDS_SEC.interstitial
                Admob_interstitial_Repeat_failed = false
            } else {
                admob_interstitial_id = IDS_SEC.re_interstitial
                Admob_interstitial_Repeat_failed = true
                admob_interstitial_fail_id_repeat()
            }
        } else if (admob_interstitial_id_rotation == 1) {
            if (Admob_interstitial_Repeat_failed) {
                admob_interstitial_id = IDS_SEC.interstitial_1
                Admob_interstitial_Repeat_failed = false
            } else {
                admob_interstitial_id = IDS_SEC.re_interstitial_1
                Admob_interstitial_Repeat_failed = true
                admob_interstitial_fail_id_repeat()
            }
        } else if (admob_interstitial_id_rotation == 2) {
            if (Admob_interstitial_Repeat_failed) {
                admob_interstitial_id = IDS_SEC.interstitial_2
                Admob_interstitial_Repeat_failed = false
            } else {
                admob_interstitial_id = IDS_SEC.re_interstitial_2
                Admob_interstitial_Repeat_failed = true
                admob_interstitial_fail_id_repeat()
            }
        }
    }

    fun Load_Admob_Interstitial(activity: Activity?) {
        isInterstitialRequest = true
        val builder = AdRequest.Builder()
        val request = GDPR_Checker_Here.status
        if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
            // load non Personalized ads
            val extras = Bundle()
            extras.putString("npa", "1")
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        admob_interstitial_get_id()
        Log.v(
            "admob_interstitial_id____",
            "admob_interstitial_id____" + admob_interstitial_id + "/" + admob_interstitial_id_rotation
        )
        InterstitialAd.load(
            activity!!,
            admob_interstitial_id!!,
            builder.build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    Log.v(
                        "admob_interstitial_id____onAdLoaded",
                        "admob_interstitial_id____onAdLoaded" + admob_interstitial_id + "/" + admob_interstitial_id_rotation + "/" + 1
                    )
                    isInterstitialRequest = false
                    mInterstitialAdMob = interstitialAd
                    interstitialAd.fullScreenContentCallback =
                        object : FullScreenContentCallback() {
                            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                                super.onAdFailedToShowFullScreenContent(adError)
                            }

                            override fun onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent()
                            }

                            override fun onAdClicked() {
                                super.onAdClicked()
                                Log.v("onAdClicked___", "onAdClicked___" + IDS_SEC.when_click_ads)
                                IDS_SEC.when_click_ads = false;
                            }

                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                                IDS_SEC.when_click_ads = true
                                Admob_interstitial_Repeat_failed = true
                                admob_interstitial_onAdDismissed(activity)
                            }

                            override fun onAdImpression() {
                                super.onAdImpression()
                            }
                        }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    mInterstitialAdMob = null
                    isInterstitialRequest = false
                    admob_interstitial_onAdFailedToLoad(activity)
                }
            })
    }

    fun showInterstitial(activity: Activity?) {
        if (mInterstitialAdMob != null) {
            mInterstitialAdMob!!.show(activity!!)
        }
    }

    fun admob_interstitial_fail_id_repeat() {
        if (admob_interstitial_id_rotation == 0) {
            admob_interstitial_id_rotation = 1
        } else if (admob_interstitial_id_rotation == 1) {
            admob_interstitial_id_rotation = 2
        } else if (admob_interstitial_id_rotation == 2) {
            admob_interstitial_id_rotation = 0
        }
    }

    fun admob_interstitial_onAdFailedToLoad(activity: Activity?) {
        Log.v(
            "admob_interstitial_id____onAdFailedToLoad",
            "admob_interstitial_id____onAdFailedToLoad" + admob_interstitial_id + "/" + Admob_interstitial_Repeat_failed
        )
        if (!Admob_interstitial_Repeat_failed) {
            Load_Admob_Interstitial(activity)
        }
    }

    fun admob_interstitial_onAdDismissed(activity: Activity?) {
        mInterstitialAdMob = null
        admob_interstitial_fail_id_repeat()
        if (interstitial_rotated_ad_network) {
            Load_Fb_interstitial_Ad(activity)
        } else {
            if (!fb_interstitial_show_ads) {
                if (!isInterstitialRequest) {
                    Load_Admob_Interstitial(activity)
                }
            } else {
                Load_Fb_interstitial_Ad(activity)
            }
        }
    }

    fun first_open_activity(activity: Activity, intent: Intent?) {
        clickCount = getClick(activity)
        if (first_activity_ad_show_interstitial) {
            activity(activity, intent)
        } else {
            activity.startActivity(intent)
        }
    }

    fun splace_open_activity(activity: Activity, intent: Intent?) {
        splace_activity(activity, intent)

    }

    fun open_activity(activity: Activity, intent: Intent?) {
        clickCount = getClick(activity)
        if (show_second_interstitial) {
            activity(activity, intent)
        } else {
            activity.startActivity(intent)
        }
    }

    fun third_activity(activity: Activity, intent: Intent?) {
        clickCount = getClick(activity)
        if (show_third_interstitial) {
            activity(activity, intent)
        } else {
            activity.startActivity(intent)
        }
    }


    fun splace_activity(activity: Activity, intent: Intent?) {
        activity.startActivity(intent)
        show_ad(activity)
        activity.finish()
    }


    fun activity(activity: Activity, intent: Intent?) {
        if (interstitial_first_time_show_ads) {
            if (clickCount % get_Count(activity) == 0) {
                showDialog(activity)
                interstitial_first_time_show_ads = false
                Handler().postDelayed({
                    activity.startActivity(intent)
                    show_ad(activity)
                    hideDialog()
                }, 1000)
                clickCount++
                Click(activity, clickCount)
            } else {
                if (show_dialog) {
                    showDialog(activity)
                    interstitial_first_time_show_ads = false
                    Handler().postDelayed({
                        activity.startActivity(intent)
                        show_ad(activity)
                        hideDialog()
                    }, 1000)
                } else {
                    interstitial_first_time_show_ads = false
                    activity.startActivity(intent)
                    show_ad(activity)
                }
            }


        } else {
            if (clickCount % get_Count(activity) == 0) {
                if (show_dialog) {
                    showDialog(activity)
                    Handler().postDelayed({
                        activity.startActivity(intent)
                        show_ad(activity)
                        hideDialog()
                    }, 1000)
                } else {
                    activity.startActivity(intent)
                    show_ad(activity)
                }
            } else {
                activity.startActivity(intent)
            }
            clickCount++
            Click(activity, clickCount)
        }

    }

    fun showDialog(activity: Activity) {
        dialog_ad = ProgressDialog(activity, R.style.MyDialog)
        dialog_ad!!.setCancelable(false)
        dialog_ad!!.setCanceledOnTouchOutside(false)
        dialog_ad!!.setTitle(activity.getString(R.string.please_wait))
        dialog_ad!!.setMessage(activity.getString(R.string.load_ad))
        dialog_ad!!.show()
    }

    fun hideDialog() {
        if (dialog_ad!!.isShowing) {
            dialog_ad!!.dismiss()
        }
    }

    private fun show_ad(activity: Activity) {
        if (interstitial_rotated_ad_network) {
            if (interstitial_ad_first_ad_network.equals("G")) {
                interstitial_ad_first_ad_network = "F"
                showInterstitial(activity)
            } else {
                interstitial_ad_first_ad_network = "G"
                show_fb_interstitial(activity)
            }
        } else {
            if (!fb_interstitial_show_ads) {
                showInterstitial(activity)
            } else {
                show_fb_interstitial(activity)
            }
        }
    }


    fun fb_interstitial_get_id() {
        if (fb_interstitial_id_rotation == 0) {
            fb_interstitial_id = IDS_SEC.fb_interstitial
        } else if (fb_interstitial_id_rotation == 1) {
            fb_interstitial_id = IDS_SEC.fb_interstitial_1
        } else if (fb_interstitial_id_rotation == 2) {
            fb_interstitial_id = IDS_SEC.fb_interstitial_2
        }
    }

    fun fb_interstitial_id_repeat() {
        if (fb_interstitial_id_rotation == 0) {
            fb_interstitial_id_rotation = 1
        } else if (fb_interstitial_id_rotation == 1) {
            fb_interstitial_id_rotation = 2
        } else {
            fb_interstitial_id_rotation = 0
        }
    }

    fun Load_Fb_interstitial_Ad(activity: Activity?) {
        isInterstitialfbRequest = true
        fb_interstitial_get_id()
        Log.v("Load_Network_____", "Load_Network_____" + fb_interstitial_id)
        mInterstitialfb = com.facebook.ads.InterstitialAd(activity, fb_interstitial_id)
        val interstitialAdListener: InterstitialAdListener = object : InterstitialAdListener {
            override fun onInterstitialDisplayed(ad: Ad) {}
            override fun onInterstitialDismissed(ad: Ad) {
                fb_onInterstitialDismissed(activity)
                IDS_SEC.when_click_ads = true
            }

            override fun onError(ad: Ad, adError: com.facebook.ads.AdError) {
                Log.v(
                    "Load_Network_____onError",
                    "Load_Network_____onError$fb_interstitial_show_ads"
                )
                isInterstitialfbRequest = false
                fb_interstitial_id_repeat()
                if (interstitial_rotated_ad_network) {
                    Load_Admob_Interstitial(activity)
                } else {
                    Load_Admob_Interstitial(activity)
                }
            }

            override fun onAdLoaded(ad: Ad) {
                isInterstitialfbRequest = true
            }

            override fun onAdClicked(ad: Ad) {
                Log.v("onAdClicked___", "onAdClicked___" + IDS_SEC.when_click_ads)
                IDS_SEC.when_click_ads = false;
            }

            override fun onLoggingImpression(ad: Ad) {}
        }
        mInterstitialfb!!.loadAd(
            mInterstitialfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener).build()
        )
    }

    private fun show_fb_interstitial(activity: Activity) {
        if (mInterstitialfb!!.isAdLoaded && mInterstitialfb != null) {
            mInterstitialfb!!.show()
        } else {
            showInterstitial(activity)
        }
    }

    private fun fb_onInterstitialDismissed(activity: Activity?) {
        Log.v("Load_Network_____Dismissed", "Load_Network_____Dismissed$fb_interstitial_show_ads")
        isInterstitialfbRequest = false
        fb_interstitial_id_repeat()
        if (interstitial_rotated_ad_network) {
            Load_Admob_Interstitial(activity)
        } else {
            Load_Fb_interstitial_Ad(activity)
            Log.v(
                "Load_Ad_Network_____",
                "facebook" + fb_interstitial_id_rotation + "/" + Admob_interstitial_Repeat_failed
            )
        }
    }

    companion object {
        private const val Count_No = "click"
        private var admob_interstitial_id: String? = null
        private var fb_interstitial_id: String? = null
        private var admob_interstitial_id_rotation = 0
        private var fb_interstitial_id_rotation = 0
        private var mInterstitialfb: com.facebook.ads.InterstitialAd? = null
        var mInstance: Interstitial_Ads_Here? = null
        var Admob_interstitial_Repeat_failed = true

        //    public static boolean interstitial_admob_ad_failed = false;
        var mInterstitialAdMob: InterstitialAd? = null
        val instance: Interstitial_Ads_Here?
            get() {
                if (mInstance == null) {
                    mInstance = Interstitial_Ads_Here()
                }
                return mInstance
            }

        fun Click(context: Activity, str2: Int) {
            val edit = context.getSharedPreferences(Count_No, 0).edit()
            edit.putInt(Count_No, str2)
            edit.apply()
        }

        fun getClick(context: Context): Int {
            return context.getSharedPreferences(Count_No, 0).getInt(Count_No, IDS_SEC.Default_Count)
        }
    }
}