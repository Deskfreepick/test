package com.clever.co.apps.developers.atm_card_checker.Ads

import android.view.View
import android.widget.Button
import android.widget.RelativeLayout
import android.widget.TextView
import com.facebook.ads.MediaView
import com.facebook.ads.NativeAd
import com.clever.co.apps.developers.atm_card_checker.R

class Native_Fb_LayOut {
    fun inflateAd(nativeAd: NativeAd, adView: RelativeLayout) {

        nativeAd.unregisterView()
        val nativeAdIcon = adView.findViewById<MediaView>(R.id.native_ad_icon)
        val nativeAdTitle = adView.findViewById<TextView>(R.id.native_ad_title)
        val nativeAdMedia = adView.findViewById<MediaView>(R.id.native_ad_media)
        val nativeAdSocialContext = adView.findViewById<TextView>(R.id.native_ad_social_context)
        val nativeAdBody = adView.findViewById<TextView>(R.id.native_ad_body)
        val sponsoredLabel = adView.findViewById<TextView>(R.id.native_ad_sponsored_label)
        val nativeAdCallToAction = adView.findViewById<Button>(R.id.native_ad_call_to_action)

        nativeAdTitle.text = nativeAd.advertiserName
        nativeAdBody.text = nativeAd.adBodyText
        nativeAdSocialContext.text = nativeAd.adSocialContext
        nativeAdCallToAction.visibility =
            if (nativeAd.hasCallToAction()) View.VISIBLE else View.INVISIBLE
        nativeAdCallToAction.text = nativeAd.adCallToAction
        sponsoredLabel.text = nativeAd.sponsoredTranslation

        val clickableViews: MutableList<View> = ArrayList()
        clickableViews.add(nativeAdTitle)
        clickableViews.add(nativeAdCallToAction)

        nativeAd.registerViewForInteraction(
            adView, nativeAdMedia, nativeAdIcon, clickableViews
        )
    }

    companion object {
        var mInstance: Native_Fb_LayOut? = null
        val instance: Native_Fb_LayOut?
            get() {
                if (mInstance == null) {
                    mInstance = Native_Fb_LayOut()
                }
                return mInstance
            }
    }
}