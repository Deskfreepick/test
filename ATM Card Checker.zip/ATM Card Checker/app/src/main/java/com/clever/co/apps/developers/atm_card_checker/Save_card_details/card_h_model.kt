package com.clever.co.apps.developers.atm_card_checker.Save_card_details

class card_h_model(
    var card_type: Int,
    var card_qr_code: String,
    var card_name: String,
    var card_cvv: String
) {
    var id = 0

}