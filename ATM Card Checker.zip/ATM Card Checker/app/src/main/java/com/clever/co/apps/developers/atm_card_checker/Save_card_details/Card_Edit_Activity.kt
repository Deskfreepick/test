package com.clever.co.apps.developers.atm_card_checker.Save_card_details

import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix
import com.google.zxing.WriterException
import com.journeyapps.barcodescanner.BarcodeEncoder
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R
import java.io.ByteArrayOutputStream

class Card_Edit_Activity : AppCompatActivity() {

    var edit_Bitmap: Bitmap? = null
    private var dbHandler: DBHandler? = null

    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null

    lateinit var save_details_txt: TextView

    lateinit var card_holder_name_edit: EditText
    lateinit var card_through_edit: EditText
    lateinit var card_number_edit: EditText
    lateinit var card_cvv_edit: EditText




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_card_edit)

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        tv_text_heading  = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Save Credit Card Details")

        card_holder_name_edit = findViewById(R.id.card_holder_name_edit)
        card_through_edit = findViewById(R.id.card_through_edit)
        card_number_edit = findViewById(R.id.card_number_edit)
        card_cvv_edit = findViewById(R.id.card_cvv_edit)


        save_details_txt = findViewById(R.id.save_details_txt)

        dbHandler =
            DBHandler(
                this
            )
        val intExtra = intent.getIntExtra("c_type", 0)

        save_details_txt.setOnClickListener(View.OnClickListener {
            if (card_holder_name_edit.text.toString().isEmpty() || card_number_edit.text.toString()
                    .isEmpty() || card_cvv_edit.text.toString().isEmpty() || card_through_edit.text
                    .toString().isEmpty()
            ) {
                Toast.makeText(
                    this@Card_Edit_Activity.applicationContext,
                    "Please enter detail",
                    Toast.LENGTH_SHORT
                ).show()
                return@OnClickListener
            }
            val trim = card_holder_name_edit.text.toString().trim { it <= ' ' }
            val trim2 = card_number_edit.text.toString().trim { it <= ' ' }
            val trim3 = card_cvv_edit.text.toString().trim { it <= ' ' }
            val trim4: String = card_through_edit.text.toString().trim { it <= ' ' }
            try {
                val encode: BitMatrix = MultiFormatWriter().encode(
                    """
                                $trim
                                $trim2
                                $trim3
                                $trim4
                                """.trimIndent(), BarcodeFormat.QR_CODE, 400, 400
                )
                val barcodeEncoder = BarcodeEncoder()
                edit_Bitmap = barcodeEncoder.createBitmap(encode)
                val inputMethodManager = getSystemService("input_method") as InputMethodManager
                inputMethodManager.hideSoftInputFromWindow(
                    card_holder_name_edit.applicationWindowToken,
                    0
                )
                inputMethodManager.hideSoftInputFromWindow(card_number_edit.applicationWindowToken, 0)
                inputMethodManager.hideSoftInputFromWindow(card_cvv_edit.applicationWindowToken, 0)
                inputMethodManager.hideSoftInputFromWindow(
                    card_through_edit.applicationWindowToken,
                    0
                )
            } catch (e: WriterException) {
                e.printStackTrace()
            }
            dbHandler!!.addNewCourse(
                intExtra,
                BitMapToString(edit_Bitmap!!),
                trim,
                trim3
            )
            Interstitial_Ads_Here.instance!!.open_activity(
                this,
                Intent(
                    this@Card_Edit_Activity.applicationContext,
                    Save_Card_History_Activity::class.java
                )
            )
        })


    }


    fun BitMapToString(bitmap: Bitmap): String? {
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0)
    }

    private fun Banner_Ad() {
        Banner_Ads_Here.mInstance!!.third_show_Banner(
            this,
            findViewById(R.id.AD_view),
            findViewById(R.id.B_Cont),
            findViewById(R.id.relative_ads_banner)
        )
    }

    override fun onResume() {
        super.onResume()
        Banner_Ad()
    }

}