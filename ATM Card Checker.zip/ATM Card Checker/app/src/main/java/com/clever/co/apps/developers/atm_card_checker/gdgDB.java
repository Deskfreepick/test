package com.clever.co.apps.developers.atm_card_checker;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

@SuppressWarnings("all")
public class gdgDB extends SQLiteOpenHelper {
    public gdgDB(@Nullable Context context) {
        super(context, "CARD", (SQLiteDatabase.CursorFactory) null, 2);
    }

    public void deleteData(int i) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("delete from contactbook where id = '" + i + "'");
    }

    public Cursor getData() {
        return getReadableDatabase().rawQuery("select * from contactbook", null);
    }

    public void insertData(String str, String str2, String str3) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.execSQL("insert into contactbook (name,contact,card_Date) values('" + str + "','" + str2 + "','" + str3 + "')");
    }

    @Override
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("create table contactbook (id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,contact TEXT,card_Date TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
    }
}
