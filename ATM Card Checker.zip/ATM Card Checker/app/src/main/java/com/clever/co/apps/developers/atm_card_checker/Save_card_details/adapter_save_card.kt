package com.clever.co.apps.developers.atm_card_checker.Save_card_details

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R


class adapter_save_card(var activity: Activity, var list: ArrayList<Model_Save>) :
    RecyclerView.Adapter<adapter_save_card.ViewHolder>() {
    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        return ViewHolder(
            LayoutInflater.from(
                activity
            ).inflate(R.layout.card_save_item, viewGroup, false)
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, i: Int) {
        val card_modelVar = list[i]
        holder.card_img.setImageResource(card_modelVar.image)
        holder.card_name_txt.text = card_modelVar.name
        holder.itemView.setOnClickListener {
            val intent = Intent(activity, Card_Edit_Activity::class.java)
            intent.putExtra("c_type", card_modelVar.image)
            Interstitial_Ads_Here.instance!!.third_activity(activity, intent)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var card_img: ImageView
        var card_name_txt: TextView

        init {
            card_img = view.findViewById(R.id.card_img)
            card_name_txt = view.findViewById(R.id.card_name_txt)
        }
    }
}