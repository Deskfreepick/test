package com.clever.co.apps.developers.atm_card_checker.Save_card_details

class Model_Save(var image: Int, var name: String)