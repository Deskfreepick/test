package com.clever.co.apps.developers.atm_card_checker

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.clever.co.apps.developers.atm_card_checker.Ads.Ads_Google_ID
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Native_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Network_Connected
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.initialization.InitializationStatus
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException


class Start_Screen_Activity : AppCompatActivity() {

    lateinit var iv_start_btn: ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start_screen)

        if (Ads_Google_ID.get_show(this, "fb_show_banner") ||
            Ads_Google_ID.get_show(this, "fb_show_native") ||
            Ads_Google_ID.get_show(this, "fb_show_interstitial")
        ) {
            AudienceNetworkAds.initialize(this)
            MobileAds.initialize(this) { initializationStatus: InitializationStatus ->
                val statusMap =
                    initializationStatus.adapterStatusMap
                for (adapterClass in statusMap.keys) {
                    val status = statusMap[adapterClass]
                    Log.d(
                        "MyApp", String.format(
                            "Adapter name: %s, Description: %s, Latency: %d",
                            adapterClass, status!!.description, status.latency
                        )
                    )
                }
            }
        } else {
            MobileAds.initialize(this) { initializationStatus: InitializationStatus ->
                val statusMap =
                    initializationStatus.adapterStatusMap
                for (adapterClass in statusMap.keys) {
                    val status = statusMap[adapterClass]
                    Log.d(
                        "MyApp", String.format(
                            "Adapter name: %s, Description: %s, Latency: %d",
                            adapterClass, status!!.description, status.latency
                        )
                    )
                }
            }
        }



        if (Network_Connected.isConnected(this)) {
            Interstitial_Ads_Here.instance!!.pre_load_interstitial(this)
        }

        iv_start_btn = findViewById(R.id.iv_start_btn)
        iv_start_btn.setOnClickListener {
            Interstitial_Ads_Here.instance!!.first_open_activity(
                this,
                Intent(this, MainActivity::class.java)
            )
        }

    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        val dialog =
            Dialog(this, androidx.appcompat.R.style.Base_Theme_AppCompat_Light_Dialog_MinWidth)
        dialog.requestWindowFeature(1)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(0))
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.exit_dialog)
        val lt_cancel = dialog.findViewById<LinearLayout>(R.id.lt_cancel)
        val lt_exit = dialog.findViewById<LinearLayout>(R.id.lt_exit)
        lt_exit.setOnClickListener {
//            Ads_Google_ID.Home_Screen(this, false)
            finishAffinity()
            dialog.dismiss()
        }
        lt_cancel.setOnClickListener {
            dialog.dismiss()
        }
        dialog.show()
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onResume() {
        super.onResume()
        showNative()
    }

    fun showNative() {
        Native_Ads_Here.instance!!.show_first_activity_native_ad_view(
            this,
            findViewById(R.id.Google_Na),
            findViewById(R.id.AD_Native_Con),
            findViewById(R.id.Sh_Layout),
            findViewById(R.id.native_ads_rl)
        )
    }
}