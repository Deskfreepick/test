package com.clever.co.apps.developers.atm_card_checker.Score

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Native_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R

class Credit_Score_Second_Checker_Activity : AppCompatActivity(), SeekBar.OnSeekBarChangeListener {

    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null
    lateinit var ll_second_next: TextView
    lateinit var credit_balances_sk: SeekBar
    lateinit var credit_limits_sk: SeekBar


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit_score_second_checker)

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        tv_text_heading = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Credit Score")

        credit_balances_sk = findViewById(R.id.credit_balances_sk)
        credit_balances_sk.max = 100000
        credit_balances_sk.progress = Data_Keepe_Credit.getInstance().recentBalances

        ll_second_next = findViewById(R.id.ll_second_next)
        ll_second_next.setOnClickListener {
            Interstitial_Ads_Here.instance!!.open_activity(
                this,
                Intent(
                    this@Credit_Score_Second_Checker_Activity,
                    Credit_Score_third_Checker_Activity::class.java
                )
            )
        }

        credit_limits_sk = findViewById(R.id.credit_limits_sk)
        credit_limits_sk.max = 100000
        credit_limits_sk.progress = Data_Keepe_Credit.getInstance().creditLimit

        credit_limits_sk.setOnSeekBarChangeListener(this)
        credit_balances_sk.setOnSeekBarChangeListener(this)

    }

    override fun onStartTrackingTouch(seekBar: SeekBar?) {}

    override fun onProgressChanged(seekBar: SeekBar, i: Int, z: Boolean) {
        var valueOf = i.toString()
        val id = seekBar.id
        if (id != R.id.credit_limits_sk) {
            if (id == R.id.credit_balances_sk) {
                if (i == 0) {
                    valueOf = "₹0".substring(1)
                } else if (i == 100000) {
                    valueOf = "₹100000+".substring(1)
                }
                Credit_Score_Sec.st7 = valueOf
                setText(R.id.credit_balances_txt, "₹$valueOf")
                return
            }
            return
        }
        if (i == 0) {
            valueOf = "₹0".substring(1)
        } else if (i == 100000) {
            valueOf = "₹100000+".substring(1)
        }
        Credit_Score_Sec.st6 = valueOf
        setText(R.id.credit_limits_txt, "₹$valueOf")
        setText(R.id.credit_limits_txt, "₹$valueOf")
    }

    fun setText(i: Int, str: String?) {
        (findViewById<View>(i) as TextView).text = str
    }

    override fun onStopTrackingTouch(seekBar: SeekBar) {
        val id = seekBar.id
        if (id == R.id.credit_limits_sk) {
            Data_Keepe_Credit.getInstance().creditLimit = seekBar.progress
        } else if (id == R.id.credit_balances_sk) {
            Data_Keepe_Credit.getInstance().recentBalances = seekBar.progress
        }
    }


    fun ShowNative() {
        Native_Ads_Here.instance!!.second_show_native_ad_view(
            this,
            findViewById(R.id.Google_Na),
            findViewById(R.id.AD_Native_Con),
            findViewById(R.id.Sh_Layout),
            findViewById(R.id.native_ads_rl)
        )

    }


    override fun onResume() {
        super.onResume()
        ShowNative()
    }
}