package com.clever.co.apps.developers.atm_card_checker.Ads

import android.app.Activity
import android.content.Context
import android.util.Log

object Ads_Google_ID {

    @JvmField
    var IDS_Activity_OPEN: Boolean? = null
    var show = "Show"
    var Count = "Count"
    var Default = "Default"
    var Home_Screen = "Home_Screen"
    var IDS_GOOGLE_AD_ID = "google_ad_id"
    private const val CONTACT_ID = "ID"

    fun IDS_GOOGLE_AD_ID(context: Context, str: String, str2: String) {
        Log.d("Utils", "Saving:$str:$str2")
        val edit = context.getSharedPreferences(IDS_GOOGLE_AD_ID, 0).edit()
        edit.putString(str, str2)
        edit.commit()
    }

    @JvmStatic
    fun get_IDS_GOOGLE_AD_ID(context: Context, str: String): Regex {
        Log.d("Utils", "Get:$str")
        return context.getSharedPreferences(IDS_GOOGLE_AD_ID, 0).getString(str, "1") as Regex
    }

    @JvmStatic
    fun Count(context: Context, str2: Int) {
        Log.d("Utils", "Saving:" + Count + ":" + str2)
        val edit = context.getSharedPreferences(Count, Context.MODE_PRIVATE).edit()
        edit.putInt(Count, str2)
        edit.commit()
    }

    @JvmStatic
    fun get_Count(context: Context): Int {
        Log.v("Utils____", "Get:" + Count)
        return context.getSharedPreferences(Count, 0).getInt(
            Count, 1)
    }

    fun show(context: Context, str: String, str2: Boolean) {
        Log.d("Utils", "Saving:$str:$str2")
        val edit = context.getSharedPreferences(show, 0).edit()
        edit.putBoolean(str, str2)
        edit.commit()
    }

    fun get_show(context: Context, str: String): Boolean {
        Log.d("Utils", "Get:$str")
        return context.getSharedPreferences(show, 0).getBoolean(str, false)
    }

    fun set_ID(context: Context, str: String?, str2: String?) {
        val edit = context.getSharedPreferences(IDS_GOOGLE_AD_ID, 0).edit()
        edit.putString(str, str2)
        edit.apply()
    }

    fun get_ID(context: Context, str: String?): String? {
        return context.getSharedPreferences(IDS_GOOGLE_AD_ID, 0).getString(str, "1")
    }

    fun Default_Count(context: Context, str2: Int) {
        val edit = context.getSharedPreferences(Default, Context.MODE_PRIVATE).edit()
        edit.putInt(Default, str2)
        edit.commit()
    }

    fun get_Default_Count(context: Context): Int {
        Log.d("Utils", "Get:" + Default)
        return context.getSharedPreferences(Default, 0).getInt(
            Default, 0)
    }

    //Start_Activity
    fun Home_Screen(context: Context, str2: Boolean) {
        val edit = context.getSharedPreferences(Home_Screen, 0).edit()
        edit.putBoolean("Screen", str2)
        edit.commit()
    }

    fun get_Home_Screen(context: Context): Boolean {
        Log.d("Utils", "Get:Screen")
        return context.getSharedPreferences(Home_Screen, 0).getBoolean("Screen", true)
    }

    //Permission_Activity
    fun Permission(context: Context, str2: Boolean) {
        val edit = context.getSharedPreferences("Permission", 0).edit()
        edit.putBoolean("First_Time", str2)
        edit.commit()
    }

    fun get_Permission(context: Context): Boolean {
        return context.getSharedPreferences("Permission", 0).getBoolean("First_Time", true)
    }

    //phone_contacts_Activity
    fun ID(context: Activity, str2: Int) {
        val edit = context.getSharedPreferences(
            CONTACT_ID,
            0
        ).edit()
        edit.putInt(CONTACT_ID, str2)
        edit.apply()
    }

    fun getID(context: Context): Int {
        return context.getSharedPreferences(
            CONTACT_ID,
            0
        ).getInt(CONTACT_ID, 1)
    }

}