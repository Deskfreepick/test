package com.clever.co.apps.developers.atm_card_checker.Score;

public class Credit_Score_Sec {

    public static String f10;
    public static String f11;
    public static String st1;
    public static String st2;
    public static String st3;
    public static String st4;
    public static String st5;
    public static String st6;
    public static String st7;
    public static String st8;
    public static String st9;

}
