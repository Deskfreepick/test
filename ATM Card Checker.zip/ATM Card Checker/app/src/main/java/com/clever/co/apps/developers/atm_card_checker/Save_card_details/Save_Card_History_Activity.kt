package com.clever.co.apps.developers.atm_card_checker.Save_card_details

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R

class Save_Card_History_Activity : AppCompatActivity() {

    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null
    private var adapter: adapter_save_card_history? = null
    lateinit var recy_save_card: RecyclerView
    lateinit var linear_empty_sec: LinearLayout
    lateinit var card_list: ArrayList<card_h_model>
    private var card_dbHandler: DBHandler? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_save_card_history)

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        tv_text_heading  = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Save Card History")

        card_list = java.util.ArrayList()
        card_dbHandler =
            DBHandler(
                this
            )
        card_list = card_dbHandler!!.readCourses()
        adapter = adapter_save_card_history(card_list, this)

        recy_save_card = findViewById(R.id.recy_save_card)
        recy_save_card.layoutManager = LinearLayoutManager(this)
        recy_save_card.adapter = adapter
        linear_empty_sec = findViewById(R.id.linear_empty_sec)

    }


    override fun onResume() {
        if (card_list.size <= 0) {
            linear_empty_sec.visibility = View.VISIBLE
        } else {
            linear_empty_sec.visibility = View.GONE
        }
        super.onResume()
        Banner_Ad()

    }


    private fun Banner_Ad() {
        Banner_Ads_Here.mInstance!!.third_show_Banner(
            this,
            findViewById(R.id.AD_view),
            findViewById(R.id.B_Cont),
            findViewById(R.id.relative_ads_banner)
        )
    }

}