package com.clever.co.apps.developers.atm_card_checker.Save_card_details

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RelativeLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.clever.co.apps.developers.atm_card_checker.Ads.Banner_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R

class Save_Card_Details_Activity : AppCompatActivity() {

    lateinit var relative_card_details: RecyclerView

    var rl_back_btn: RelativeLayout? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_save_card_details)

        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        relative_card_details = findViewById(R.id.relative_card_details)


        relative_card_details.layoutManager = LinearLayoutManager(this)

        relative_card_details.setHasFixedSize(true)

        val arrayList = ArrayList<Model_Save>()
        arrayList.add(Model_Save(R.drawable.iv_visa_card, "Visa Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_nba_visa_card, "NBA Visa Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_master_card, "Master Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_america_card, "American Express Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_jcb_debit_card, "JCB Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_dk_card, "DK Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_discover_debit_card, "Discover Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_banrisual, "Banrisul Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_interac_card, "Interac Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_union_pay_card, "UnionPay Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_verve_debit_card, "Verve Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_rupay_card, "RuPay Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_csld_maha_card, "CSLD Mada Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_master_card, "Bankaxept Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_visa_card, "Bradesco Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_visa_card, "Midland Debit Card"))
        arrayList.add(Model_Save(R.drawable.iv_visa_card, "PBS Debit Card"))
        relative_card_details.adapter = adapter_save_card(this, arrayList)
    }



    private fun Banner_Ad() {
       Banner_Ads_Here.mInstance!!.second_show_Banner(
            this,
            findViewById(R.id.AD_view),
            findViewById(R.id.B_Cont),
            findViewById(R.id.relative_ads_banner)
        )
    }

    override fun onResume() {
        super.onResume()
        Banner_Ad()

    }

}