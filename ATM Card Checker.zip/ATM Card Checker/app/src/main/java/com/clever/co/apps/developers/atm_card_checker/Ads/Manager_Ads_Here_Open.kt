package com.clever.co.apps.developers.atm_card_checker.Ads

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.ump.ConsentInformation
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.App_Open
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.App_Open_1
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.App_Open_id
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.when_click_ads
import com.clever.co.apps.developers.atm_card_checker.MainActivity
import com.clever.co.apps.developers.atm_card_checker.Start_Screen_Activity
import java.util.Date

class Manager_Ads_Here_Open(myApplication: Activity?, progressBar: LinearLayout) :
    Application.ActivityLifecycleCallbacks, LifecycleObserver {

    private var appOpenAd: AppOpenAd? = null
    private var activity: Activity? = null
    private var boolean_showAd = false
    private var ad_loadTime: Long = 0
    private var fb_adShow = true
    var linearLayout: LinearLayout

    init {
        activity = myApplication
        this.linearLayout = progressBar
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onStart() {
        activity?.let {
            Log.v("when_click_ads____", "" + when_click_ads)
            if (when_click_ads) {
                showAdIfAvailable(activity!!)
            } else {
                when_click_ads = true
            }
        }

        Log.d(LOG_TAG, "onStart")
    }


    fun fetchAd() {
        Log.d("c", "" + isAdAvailable())
        if (isAdAvailable()) {
            return
        }
        Log.d("isAdAvailable_____fetchAd", "" + isAdAvailable())
        val builder = AdRequest.Builder()
        val request = GDPR_Checker_Here.status
        if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
            val extras = Bundle()
            extras.putString("npa", "1")
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        AppOpenAd.load(
            activity!!, App_Open_id!!, builder.build(),
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            object : AppOpenAd.AppOpenAdLoadCallback() {

                override fun onAdLoaded(ad: AppOpenAd) {
                    Log.d(LOG_TAG, "Ad was loaded.")
                    appOpenAd = ad

                    ad_loadTime = Date().time
                    if (fb_adShow) {
                        showAdIfAvailable(activity!!)
                        linearLayout.visibility = View.GONE
                        fb_adShow = false
                    }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    if (App_Open_id == App_Open) {
                        App_Open_id = App_Open_1
                        Manager_Ads_Here_Open(activity!!, linearLayout)
                    } else {

                        if (IDS_SEC.IDS_Activity_OPEN!!) {
                            IDS_SEC.IDS_Activity_OPEN = false
                            if (IDS_SEC.start_screen_show) {
//                                if (Ads_Google_ID.get_Home_Screen(activity!!)) {
                                    activity!!.startActivity(
                                        Intent(
                                            activity,
                                            Start_Screen_Activity::class.java
                                        )
                                    )
                                    activity!!.finish()
//                                } else {
//                                    activity!!.startActivity(
//                                        Intent(
//                                            activity,
//                                            com.easy.light.apps.credit_and_debit_card_checker.Activity.MainActivity::class.java
//                                        )
//                                    )
//                                    activity!!.finish()
//                                }
                            } else {
                                activity!!.startActivity(Intent(activity, MainActivity::class.java))
                                activity!!.finish()
                            }
                        }
                    }
                    Log.d(LOG_TAG, loadAdError.message)
                }
            })
    }

    fun showAdIfAvailable(activity: Activity) {
        if (boolean_showAd) {
            Log.d(LOG_TAG, "The app open ad is already showing.")
            return
        }

        if (!isAdAvailable()) {
            Log.d(LOG_TAG, "The app open ad is not ready yet.")

            fetchAd()
            return
        }

        appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {

            override fun onAdDismissedFullScreenContent() {
                Log.d(LOG_TAG, "Ad dismissed fullscreen content.")
                appOpenAd = null
                boolean_showAd = IDS_SEC.app_open_repeat_show
                linearLayout.visibility = View.GONE
                Log.v("fetchAd________", "fetchAd________" + " " + IDS_SEC.app_open_repeat_show)
                if (!IDS_SEC.app_open_repeat_show) {
                    fetchAd()
                }
                if (IDS_SEC.IDS_Activity_OPEN!!) {
                    IDS_SEC.IDS_Activity_OPEN = false

                    if (IDS_SEC.start_screen_show) {
//                        if (Ads_Google_ID.get_Home_Screen(activity)) {
                            activity.startActivity(
                                Intent(
                                    activity,
                                    Start_Screen_Activity::class.java
                                )
                            )
                            activity.finish()
//                        } else {
//                            activity.startActivity(Intent(activity, com.easy.light.apps.credit_and_debit_card_checker.Activity.MainActivity::class.java))
//                            activity.finish()
//                        }
                    } else {
                        activity.startActivity(Intent(activity, MainActivity::class.java))
                        activity.finish()
                    }
                }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {

                Log.d(LOG_TAG, adError.message)
                appOpenAd = null
                boolean_showAd = false
                fetchAd()
            }

            override fun onAdShowedFullScreenContent() {
                // Called when fullscreen content is shown.
                Log.d(LOG_TAG, "Ad showed fullscreen content.")
            }
        }
        boolean_showAd = true
        appOpenAd?.show(activity)
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {
        this.activity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        this.activity = activity

        Log.v("App_Resume____", "App_Resume____$activity")
    }

    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {
        this.activity = null
    }

    private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
        val dateDifference = Date().time - ad_loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour * numHours
    }

    private fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
    }

    companion object {
        private const val LOG_TAG = "Open_Manager"
    }
}