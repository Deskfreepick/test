package com.clever.co.apps.developers.atm_card_checker.Ads

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RelativeLayout
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.AdOptionsView
import com.facebook.ads.NativeAdLayout
import com.facebook.ads.NativeAdListener
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.ump.ConsentInformation
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.Admob_Native_Repeat_Failed
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.fb_native_show_ads
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.first_activity_ad_show_native
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.native_ad_first_ad_network
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.native_rotated_ad_network
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.second_ad_show_native
import com.clever.co.apps.developers.atm_card_checker.Ads.IDS_SEC.third_ad_show_native
import com.clever.co.apps.developers.atm_card_checker.Ads.GDPR_Checker_Here.Companion.status
import com.clever.co.apps.developers.atm_card_checker.R


class Native_Ads_Here {

    private var admob_native_id: String? = null
    private var fb_native_id: String? = null
    private var isshow: Boolean = true

    fun admob_native_get_id() {
        if (admob_native_id_rotation == 0) {
            if (Admob_Native_Repeat_Failed) {
                admob_native_id = IDS_SEC.ad_native
                Admob_Native_Repeat_Failed = false
            } else {
                Log.v(
                    "Native_____re_id",
                    "Native____re_id" + Admob_Native_Repeat_Failed + " " + IDS_SEC.re_ad_native
                )
                admob_native_id = IDS_SEC.re_ad_native
                Admob_Native_Repeat_Failed = true
                admob_native_fail_id_repeat()
            }
        } else if (admob_native_id_rotation == 1) {
            if (Admob_Native_Repeat_Failed) {
                admob_native_id = IDS_SEC.ad_native_1
                Admob_Native_Repeat_Failed = false
            } else {
                admob_native_id = IDS_SEC.re_ad_native_1
                Admob_Native_Repeat_Failed = true
                admob_native_fail_id_repeat()
            }
        } else if (admob_native_id_rotation == 2) {
            if (Admob_Native_Repeat_Failed) {
                admob_native_id = IDS_SEC.ad_native_2
                Admob_Native_Repeat_Failed = false
            } else {
                admob_native_id = IDS_SEC.re_ad_native_2
                Admob_Native_Repeat_Failed = true
                admob_native_fail_id_repeat()
            }
        }
    }


    fun fb_native_get_id() {
        if (fb_native_id_rotation == 0) {
            fb_native_id = IDS_SEC.fb_ad_native
        } else if (fb_native_id_rotation == 1) {
            fb_native_id = IDS_SEC.fb_ad_native_1
        } else if (fb_native_id_rotation == 2) {
            fb_native_id = IDS_SEC.fb_ad_native_2
        }
    }

    fun admob_native_fail_id_repeat() {
        Log.v("Native_____id", "Native_____id" + admob_native_id_rotation)
        if (admob_native_id_rotation == 0) {
            admob_native_id_rotation = 1
        } else if (admob_native_id_rotation == 1) {
            admob_native_id_rotation = 2
        } else if (admob_native_id_rotation == 2) {
            admob_native_id_rotation = 0
        }
    }

    fun fb_native_fail_id_repeat() {
        Log.v("Native_____id", "Native_____id" + admob_native_id_rotation)
        if (fb_native_id_rotation == 0) {
            fb_native_id_rotation = 1
        } else if (fb_native_id_rotation == 1) {
            fb_native_id_rotation = 2
        } else if (fb_native_id_rotation == 2) {
            fb_native_id_rotation = 0
        }
    }

    fun native_pre_load(activity: Activity?) {
        if (!native_rotated_ad_network) {
            if (!fb_native_show_ads) {
                admob_pre_load_Native(activity)
            } else {
                fb_pre_load_native_ad(activity)
            }
        } else {
            admob_pre_load_Native(activity)
            fb_pre_load_native_ad(activity)
        }
    }

    fun admob_pre_load_Native(activity: Activity?) {
        val videoOptions = VideoOptions.Builder().setStartMuted(true).build()
        val adOptions = NativeAdOptions.Builder().setVideoOptions(videoOptions).build()
        admob_native_get_id()
        Log.v(
            "Native_____Load",
            "Native_____Load" + "---" + admob_native_id + "-" + admob_native_id_rotation + "-" + Admob_Native_Repeat_Failed
        )
        //        Native_Ad_Service.getInstance().admob_native_get_id();
        val adLoader = AdLoader.Builder(activity!!, admob_native_id!!)
            .forNativeAd { nativeAd: NativeAd? -> load_nativeAd = nativeAd }
            .withAdListener(object : AdListener() {
                override fun onAdClicked() {
                    super.onAdClicked()
                    instance!!.admob_pre_load_Native(activity)
                    IDS_SEC.when_click_ads = false
                }

                override fun onAdClosed() {
                    super.onAdClosed()
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    super.onAdFailedToLoad(loadAdError)
                    Log.v(
                        "Native_____Fail",
                        "Native_____Fail" + admob_native_id + "-" + admob_native_id_rotation + "-" + Admob_Native_Repeat_Failed
                    )
                    if (!Admob_Native_Repeat_Failed) {
                        admob_pre_load_Native(activity)
                    } else {
                        fb_pre_load_native_ad(activity)
                    }
                }

                override fun onAdImpression() {
                    super.onAdImpression()
                    Handler().postDelayed({
                        Log.v(
                            "Native_____onAdImpression",
                            "Native_____onAdImpression" + admob_native_id + "-" + admob_native_id_rotation + "-" /*+ isshow*/
                        )

                        admob_pre_load_Native(activity);

                    }, 15000)
                }

                override fun onAdLoaded() {
                    super.onAdLoaded()
                    admob_native_fail_id_repeat()
                    Admob_Native_Repeat_Failed = true
                }

                override fun onAdOpened() {
                    super.onAdOpened()
                }
            }).withNativeAdOptions(adOptions).build()
        val builder = AdRequest.Builder()
        val request = status
        if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
            val extras = Bundle()
            extras.putString("npa", "1")
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        adLoader.loadAd(builder.build())
    }

    fun show_first_activity_native_ad_view(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout
    ) {
        if (first_activity_ad_show_native) {
            if (native_rotated_ad_network) {
                if (native_ad_first_ad_network.equals("G")) {
                    show_admob_native_ad(
                        activity,
                        frameLayout,
                        fbNativeAdLayout,
                        shimmerFrameLayout
                    )
                    native_ad_first_ad_network = "F"
                } else {
                    show_fb_native(activity, fbNativeAdLayout, frameLayout, shimmerFrameLayout)
                    native_ad_first_ad_network = "G"
                }
            } else {
                if (!fb_native_show_ads) {
                    show_admob_native_ad(
                        activity,
                        frameLayout,
                        fbNativeAdLayout,
                        shimmerFrameLayout
                    )
                } else {
                    show_fb_native(activity, fbNativeAdLayout, frameLayout, shimmerFrameLayout)
                }
            }
        } else {
            relativeLayout.setVisibility(View.GONE);
        }

    }

    fun second_show_native_ad_view(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout
    ) {
        Log.v("Native_____ad_view", "Native_ad_view - true")
        if (second_ad_show_native) {
            if (native_rotated_ad_network) {
                if (native_ad_first_ad_network == "G") {
                    show_admob_native_ad(
                        activity,
                        frameLayout,
                        fbNativeAdLayout,
                        shimmerFrameLayout
                    )
                    native_ad_first_ad_network = "F"
                } else {
                    show_fb_native(activity, fbNativeAdLayout, frameLayout, shimmerFrameLayout)
                    native_ad_first_ad_network = "G"
                }
            } else {
                if (!fb_native_show_ads) {
                    show_admob_native_ad(
                        activity,
                        frameLayout,
                        fbNativeAdLayout,
                        shimmerFrameLayout
                    )
                } else {
                    show_fb_native(activity, fbNativeAdLayout, frameLayout, shimmerFrameLayout)
                }
            }
        } else {
            relativeLayout.setVisibility(View.GONE);
        }
    }

    fun third_show_native_ad_view(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout
    ) {
        Log.v("Native_____ad_view", "Native_ad_view - true")
        if (third_ad_show_native) {
            if (native_rotated_ad_network) {
                if (native_ad_first_ad_network == "G") {
                    show_admob_native_ad(
                        activity,
                        frameLayout,
                        fbNativeAdLayout,
                        shimmerFrameLayout
                    )
                    native_ad_first_ad_network = "F"
                } else {
                    show_fb_native(activity, fbNativeAdLayout, frameLayout, shimmerFrameLayout)
                    native_ad_first_ad_network = "G"
                }
            } else {
                if (!fb_native_show_ads) {
                    show_admob_native_ad(
                        activity,
                        frameLayout,
                        fbNativeAdLayout,
                        shimmerFrameLayout
                    )
                } else {
                    show_fb_native(activity, fbNativeAdLayout, frameLayout, shimmerFrameLayout)
                }
            }
        } else {
            relativeLayout.setVisibility(View.GONE);
        }
    }

    fun show_admob_native_ad(
        activity: Activity,
        frameLayout: FrameLayout,
        fb_nativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout
    ) {
        isshow = true
        if (load_nativeAd != null) {
            val adView = activity.layoutInflater.inflate(R.layout.ad_unified, null) as NativeAdView
            Native_Inflate_Ads.instance?.Admob_Native_placement(
                activity,
                load_nativeAd!!,
                adView
            )
            Log.v("Native_____", "Native_Show" + "-" + true)
            frameLayout.visibility = View.VISIBLE
            shimmerFrameLayout.visibility = View.GONE
            fb_nativeAdLayout.visibility = View.GONE
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
        } else {
            admob_native_fail_id_repeat()
            admob_after_show_fb_native(activity, fb_nativeAdLayout, frameLayout, shimmerFrameLayout)
        }
    }

    private fun fb_pre_load_native_ad(activity: Activity?) {
        fb_native_get_id()
        Log.v("fb_native______id", "fb_native____id-$fb_native_id")
        val nativeAd = com.facebook.ads.NativeAd(activity, fb_native_id)
        val adListener: NativeAdListener = object : NativeAdListener {
            override fun onMediaDownloaded(ad: Ad) {}
            override fun onError(ad: Ad, adError: AdError) {
                if (adError != null) {
                    admob_pre_load_Native(activity)
                }
            }

            override fun onAdLoaded(ad: Ad) {
                fb_native = nativeAd
                fb_native_fail_id_repeat()
                Log.v("fb_native______", "fb_native____-$nativeAd")
            }

            override fun onAdClicked(ad: Ad) {
                Log.v("fb_native______", "fb_native____-$nativeAd")
                fb_pre_load_native_ad(activity)
                IDS_SEC.when_click_ads = false
            }

            override fun onLoggingImpression(ad: Ad) {
                Log.v(
                    "fb_native_onLoggingImpression______",
                    "fb_native_onLoggingImpression______-$nativeAd"
                )
                Handler().postDelayed({
                    Log.v(
                        "Native_____onAdImpression",
                        "Native_____onAdImpression" + admob_native_id + "-" + admob_native_id_rotation + "-" + isshow
                    )

                    fb_pre_load_native_ad(activity);


                }, 10000)
            }
        }
        //        fb_native.buildLoadAdConfig().withAdListener(adListener).build();
        nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(adListener).build())
    }

    private fun show_fb_native(
        activity: Activity,
        fb_nativeAdLayout: NativeAdLayout,
        frameLayout: FrameLayout,
        shimmerFrameLayout: ShimmerFrameLayout
    ) {
        Log.v("fb_native______show", "fb_native____show" + "-" + fb_native)
        if (fb_native != null) {
            frameLayout.visibility = View.GONE
            shimmerFrameLayout.visibility = View.GONE
            fb_nativeAdLayout.visibility = View.VISIBLE
            val inflater = LayoutInflater.from(activity)
            val adView = inflater.inflate(
                R.layout.ad_native_fb_layout,
                fb_nativeAdLayout,
                false
            ) as RelativeLayout
            fb_nativeAdLayout.addView(adView)
            val adChoicesContainer = adView.findViewById<LinearLayout>(R.id.ad_choices_container)
            val adOptionsView = AdOptionsView(activity, fb_native, fb_nativeAdLayout)
            adChoicesContainer.removeAllViews()
            adChoicesContainer.addView(adOptionsView, 0)
            Native_Fb_LayOut().inflateAd(fb_native!!, adView)
        } else {
            fb_native_fail_id_repeat()
            fb_after_show_admob_native_ad(
                activity,
                frameLayout,
                fb_nativeAdLayout,
                shimmerFrameLayout
            )
        }
    }

    fun fb_after_show_admob_native_ad(
        activity: Activity,
        frameLayout: FrameLayout,
        fb_nativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout
    ) {
        if (load_nativeAd != null) {
            val adView = activity.layoutInflater.inflate(R.layout.ad_unified, null) as NativeAdView
            Native_Inflate_Ads.instance?.Admob_Native_placement(
                activity, load_nativeAd!!, adView
            )
            Log.v("Native_____", "Native_Show" + "-" + true)
            frameLayout.visibility = View.VISIBLE
            shimmerFrameLayout.visibility = View.GONE
            fb_nativeAdLayout.visibility = View.GONE
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
            fb_pre_load_native_ad(activity)
        }
    }

    private fun admob_after_show_fb_native(
        activity: Activity,
        fb_nativeAdLayout: NativeAdLayout,
        frameLayout: FrameLayout,
        shimmerFrameLayout: ShimmerFrameLayout
    ) {
        Log.v("fb_native______show", "fb_native____show" + "-" + fb_native)
        if (fb_native != null) {
            frameLayout.visibility = View.GONE
            shimmerFrameLayout.visibility = View.GONE
            fb_nativeAdLayout.visibility = View.VISIBLE
            val inflater = LayoutInflater.from(activity)
            val adView = inflater.inflate(
                R.layout.ad_native_fb_layout,
                fb_nativeAdLayout,
                false
            ) as RelativeLayout
            fb_nativeAdLayout.addView(adView)
            val adChoicesContainer = adView.findViewById<LinearLayout>(R.id.ad_choices_container)
            val adOptionsView = AdOptionsView(activity, fb_native, fb_nativeAdLayout)
            adChoicesContainer.removeAllViews()
            adChoicesContainer.addView(adOptionsView, 0)
            Native_Fb_LayOut().inflateAd(fb_native!!, adView)
            admob_pre_load_Native(activity)
        }
    }

    companion object {
        var load_nativeAd: NativeAd? = null
        var fb_native: com.facebook.ads.NativeAd? = null
        private var admob_native_id_rotation = 0
        private var fb_native_id_rotation = 0
        var mInstance: Native_Ads_Here? = null
        val instance: Native_Ads_Here?
            get() {
                if (mInstance == null) {
                    mInstance = Native_Ads_Here()
                }
                return mInstance
            }
    }
}