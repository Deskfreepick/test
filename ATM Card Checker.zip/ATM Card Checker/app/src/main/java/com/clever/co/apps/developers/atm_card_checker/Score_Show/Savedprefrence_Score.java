package com.clever.co.apps.developers.atm_card_checker.Score_Show;

import android.app.Application;
import android.content.SharedPreferences;

public class Savedprefrence_Score extends Application {
    public static SharedPreferences sharedpreference;
    static SharedPreferences.Editor editor;
    private static Savedprefrence_Score instance;

    public static Savedprefrence_Score getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sharedpreference = getSharedPreferences("bank", MODE_PRIVATE);
        editor = sharedpreference.edit();
        instance = this;
    }

    public static void setscore(String score){
        editor.putString("score",score).commit();
    }

    public static String getscore(){
        return   sharedpreference.getString("score","");
    }

}