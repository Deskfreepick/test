package com.clever.co.apps.developers.atm_card_checker.Save_card_details

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.QR_Section.Your_QR_Activity
import com.clever.co.apps.developers.atm_card_checker.R

class adapter_save_card_history(private val list: ArrayList<card_h_model>, private val activity: Activity) :
    RecyclerView.Adapter<adapter_save_card_history.history_holder>() {
    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): history_holder {
        return history_holder(
            LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.save_card_item, viewGroup, false)
        )
    }

    override fun onBindViewHolder(holder: history_holder, i: Int) {
        val history_modelVar = list[i]
        holder.save_img_card.setImageResource(history_modelVar.card_type)
        holder.save_card_txt.text = history_modelVar.card_name
        holder.txt_save_card_cvv.text = history_modelVar.card_cvv

        holder.iv_cc_qr_code.setImageBitmap(StringToBitMap(history_modelVar.card_qr_code))
        holder.itemView.setOnClickListener {
            val intent = Intent(activity, Your_QR_Activity::class.java)
            intent.putExtra("qr_img", history_modelVar.card_qr_code)
            Interstitial_Ads_Here.instance!!.third_activity(activity,intent)
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class history_holder(view: View) : RecyclerView.ViewHolder(view) {
        var iv_cc_qr_code: ImageView
        var save_img_card: ImageView
        var save_card_txt: TextView
        var txt_save_card_cvv: TextView

        init {
            save_img_card = view.findViewById(R.id.save_img_card)
            iv_cc_qr_code = view.findViewById(R.id.iv_cc_qr_code)
            save_card_txt = view.findViewById(R.id.save_card_txt)
            txt_save_card_cvv = view.findViewById(R.id.txt_save_card_cvv)
        }
    }

    fun StringToBitMap(str: String?): Bitmap? {
        return try {
            val decode = Base64.decode(str, 0)
            BitmapFactory.decodeByteArray(decode, 0, decode.size)
        } catch (e: Exception) {
            e.message
            null
        }
    }
}