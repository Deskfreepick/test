package com.clever.co.apps.developers.atm_card_checker.Score

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import com.clever.co.apps.developers.atm_card_checker.Ads.Interstitial_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.Ads.Native_Ads_Here
import com.clever.co.apps.developers.atm_card_checker.R
import com.clever.co.apps.developers.atm_card_checker.Score_Show.Score_show_Activity

class Credit_Score_third_Checker_Activity : AppCompatActivity() {

    var rl_back_btn: RelativeLayout? = null
    var tv_text_heading: TextView? = null
    lateinit var many_times_txt: TextView
    lateinit var many_time_sb: SeekBar
    lateinit var most_recent_sb: SeekBar
    lateinit var ll_third_next: TextView
    lateinit var most_recent_txt: TextView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_credit_score_third_checker)
        rl_back_btn = findViewById(R.id.rl_back_btn)
        rl_back_btn!!.setOnClickListener {
            onBackPressed()
        }

        tv_text_heading = findViewById(R.id.tv_text_heading)
        tv_text_heading!!.setText("Credit Score")

        many_times_txt = findViewById(R.id.many_times_txt)
        many_time_sb = findViewById(R.id.many_time_sb)
        most_recent_sb = findViewById(R.id.most_recent_sb)
        most_recent_txt = findViewById(R.id.most_recent_txt)
        ll_third_next = findViewById(R.id.ll_third_next)
        many_time_sb.max = 10
        many_time_sb.progress = Data_Keepe_Credit.getInstance().appliedCredit
        most_recent_sb.max = 10
        most_recent_sb.progress =
            Data_Keepe_Credit.getInstance().firstOpenCredit

        many_time_sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, i: Int, b: Boolean) {
                var sb: String
                var valueOf = i.toString()
                if (i == 10) {
                    valueOf = "10+"
                }
                Credit_Score_Sec.f10 = valueOf
                many_times_txt.text = valueOf

            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                Data_Keepe_Credit.getInstance().appliedCredit = seekBar.progress
            }
        })

        most_recent_sb.setOnSeekBarChangeListener(object :
            SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, i: Int, b: Boolean) {
                val sb: String
                val valueOf = i.toString()
                if (i == 0) {
                    sb = "No accounts open"
                } else if (i == 10) {
                    sb = "10+ years"
                } else {
                    val sb2 = StringBuilder()
                    sb2.append(valueOf)
                    sb2.append(if (i != 1) " years" else " year")
                    sb = sb2.toString()
                }
                Credit_Score_Sec.f11 = sb
                most_recent_txt.text = sb
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {
                Data_Keepe_Credit.getInstance().firstOpenCredit = seekBar.progress
            }
        })

        ll_third_next.setOnClickListener {
            Interstitial_Ads_Here.instance!!.third_activity(
                    this,
                    Intent(
                        this@Credit_Score_third_Checker_Activity,
                        Score_show_Activity::class.java
                    )
                )
        }



//        ll_third_next.setOnClickListener {
//            val dialog = Dialog(this,androidx.appcompat.R.style.Base_Theme_AppCompat_Light_Dialog_MinWidth)
//            dialog.setContentView(R.layout.see_full_report)
//            dialog.window!!.setBackgroundDrawableResource(android.R.color.transparent)
//            dialog.setCancelable(true)
//
//            val tv_score_txt = dialog.findViewById<TextView>(R.id.tv_score_txt)
//
//            val your_score = dialog.findViewById<TextView>(R.id.your_score)
//            your_score!!.text = java.lang.String.valueOf(Data_Keepe_Credit.getInstance().score)
//
//            if (Data_Keepe_Credit.getInstance().getScore() >= 0 && Data_Keepe_Credit.getInstance()
//                    .getScore() <= 350
//            ) {
//                tv_score_txt.setText("Poor Score")
//                Savedprefrencebank.setscore("Poor")
//                your_score.setTextColor(getResources().getColor(R.color.poorcolor));
//
//            } else if (Data_Keepe_Credit.getInstance().getScore() >= 350 && Data_Keepe_Credit.getInstance()
//                    .getScore() <= 549
//            ) {
//                tv_score_txt.setText("Fair Score")
//                Savedprefrencebank.setscore("Fair")
//                your_score.setTextColor(getResources().getColor(R.color.fircolor));
//
//            } else if (Data_Keepe_Credit.getInstance().getScore() >= 550 && Data_Keepe_Credit.getInstance()
//                    .getScore() <= 649
//            ) {
//                tv_score_txt.setText("Good Score")
//                Savedprefrencebank.setscore("Good")
//                your_score.setTextColor(getResources().getColor(R.color.goodcolor));
//            } else if (Data_Keepe_Credit.getInstance().getScore() >= 650 && Data_Keepe_Credit.getInstance()
//                    .getScore() <= 749
//            ) {
//                tv_score_txt.setText("Very Good Score")
//                Savedprefrencebank.setscore("Very Good")
//                your_score.setTextColor(getResources().getColor(R.color.exilentcolor));
//
//            } else if (Data_Keepe_Credit.getInstance().getScore() >= 750 && Data_Keepe_Credit.getInstance()
//                    .getScore() <= 900
//            ) {
//                tv_score_txt.setText("Excellent Score")
//                Savedprefrencebank.setscore("Excellent")
//                your_score.setTextColor(getResources().getColor(R.color.exilentcolor));
//            }
//
//
//            val ll_full_result_score = dialog.findViewById<LinearLayout>(R.id.ll_full_result_score)
//            dialog.findViewById<View>(R.id.ll_full_result_score).setOnClickListener { view: View? ->
//                Interstitial_Ads_Services.instance!!.third_activity(
//                    this,
//                    Intent(
//                        this@Third_Credit_Score_Activity,
//                        Full_Score_Result_Activity::class.java
//                    )
//                )
//
//                dialog.dismiss()
//            }
//
//            dialog.show()
//
//
//        }

    }

    fun ShowNative() {
        Native_Ads_Here.instance!!.third_show_native_ad_view(
            this,
            findViewById(R.id.Google_Na),
            findViewById(R.id.AD_Native_Con),
            findViewById(R.id.Sh_Layout),
            findViewById(R.id.native_ads_rl)
        )

    }
    

    override fun onResume() {
        super.onResume()
        ShowNative()
    }

    
}