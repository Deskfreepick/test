package com.clever.co.apps.developers.atm_card_checker.History_Card;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.clever.co.apps.developers.atm_card_checker.R;
import com.clever.co.apps.developers.atm_card_checker.gdgDB;
import com.clever.co.apps.developers.atm_card_checker.gdgDB;

import java.util.ArrayList;

@SuppressWarnings("all")
public class Card_History_Adapter extends RecyclerView.Adapter<Card_History_Adapter.ViewHolder> {
    private Context context;

    private ArrayList<History_Model> historyModels;

    public Card_History_Adapter(Context historyActvity, ArrayList<History_Model> arrayList) {
        this.context = historyActvity;
        this.historyModels = arrayList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(this.context).inflate(R.layout.card_history, viewGroup, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, final int i) {
        History_Model binmodel = this.historyModels.get(i);

        final int id = binmodel.getId();
        String name = binmodel.getName();
        String contact = binmodel.getContact();
        String card_Date = binmodel.getCardDate();
        viewHolder.card_number_txt.setText(name);
        viewHolder.holder_name_txt.setText(contact);
        viewHolder.card_date_txt.setText(card_Date);

        viewHolder.card_delete_txt.setOnClickListener(view -> {
            Dialog dialog = new Dialog(context, androidx.appcompat.R.style.Base_Theme_AppCompat_Light_Dialog_MinWidth);
            dialog.requestWindowFeature(1);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            dialog.setCancelable(true);
            dialog.setContentView(R.layout.delete_dialog);
            LinearLayout lt_cancel = dialog.findViewById(R.id.lt_cancel);
            LinearLayout lt_delete = dialog.findViewById(R.id.lt_delete);

            lt_delete.setOnClickListener(view1 -> {
                new gdgDB(context).deleteData(id);
                historyModels.remove(i);
                notifyDataSetChanged();
                dialog.dismiss();
            });

            lt_cancel.setOnClickListener(view1 -> dialog.dismiss());
            dialog.show();
        });
    }

    @Override
    public int getItemCount() {
        return historyModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView card_number_txt;
        public TextView holder_name_txt;
        public TextView card_date_txt;
        public TextView card_delete_txt;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            card_number_txt = itemView.findViewById(R.id.card_number_txt);
            holder_name_txt = itemView.findViewById(R.id.holder_name_txt);
            card_date_txt = itemView.findViewById(R.id.card_date_txt);
            card_delete_txt = itemView.findViewById(R.id.card_delete_txt);
        }
    }
}
