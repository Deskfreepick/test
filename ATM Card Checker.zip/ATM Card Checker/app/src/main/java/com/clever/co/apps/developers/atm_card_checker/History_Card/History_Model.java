package com.clever.co.apps.developers.atm_card_checker.History_Card;

@SuppressWarnings("all")
public class History_Model {
    private int id;
    private String name;
    private String contact;
    private String cardDate;

    public History_Model(int id, String name, String contact, String cardDate) {
        this.id = id;
        this.name = name;
        this.contact = contact;
        this.cardDate = cardDate;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getContact() {
        return contact;
    }

    public String getCardDate() {
        return cardDate;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public void setCardDate(String cardDate) {
        this.cardDate = cardDate;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", contact='" + contact + '\'' +
                ", cardDate='" + cardDate + '\'' +
                '}';
    }

}
