plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id ("com.google.gms.google-services")
}

android {
    namespace = "com.clever.co.apps.developers.atm_card_checker"
    compileSdk = 35


    defaultConfig {
        applicationId = "com.clever.co.apps.developers.atm_card_checker"
        minSdk = 24
        targetSdk = 35
        versionCode = 9
        versionName = "1.8"
        multiDexEnabled = true
        vectorDrawables.useSupportLibrary = true
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.2.0")
    implementation("com.google.android.play:app-update-ktx:2.1.0")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    //ads
    implementation(platform("com.google.firebase:firebase-bom:32.2.2"))
    implementation("com.google.firebase:firebase-analytics-ktx")
    implementation("com.google.firebase:firebase-config:22.1.0")
    //sdp
    implementation("com.intuit.sdp:sdp-android:1.1.0")
    implementation("com.google.android.gms:play-services-ads:23.6.0")
    implementation("com.facebook.android:audience-network-sdk:6.18.0")
    implementation("com.facebook.shimmer:shimmer:0.5.0")
    implementation("androidx.lifecycle:lifecycle-process:2.8.7")
    implementation ("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation ("com.airbnb.android:lottie:6.2.0")
    implementation  ("com.google.ads.mediation:adcolony:4.8.0.2")
    implementation  ("com.google.ads.mediation:applovin:13.0.1.1")
    implementation ("com.google.ads.mediation:imobile:2.3.2.0")
    implementation  ("com.google.ads.mediation:inmobi:10.8.0.0")
    implementation  ("com.google.ads.mediation:ironsource:8.6.1.0")
    implementation  ("com.google.ads.mediation:vungle:7.4.3.0")
    implementation  ("com.google.ads.mediation:mintegral:16.8.61.0")
    implementation  ("com.google.ads.mediation:mytarget:5.27.1.0")
    implementation  ("com.unity3d.ads:unity-ads:4.9.2")
    implementation  ("com.google.ads.mediation:unity:4.13.0.0")
    implementation  ("com.google.ads.mediation:facebook:6.18.0.0")
    implementation  ("com.facebook.android:facebook-android-sdk:latest.release")

}