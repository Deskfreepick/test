pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()

        maven {
            url  = uri("https://imobile.github.io/adnw-sdk-android")
        }
        maven {
            url  = uri("https://jitpack.io")
        }
        maven {
            url = uri("https://android-sdk.is.com/")
        }
        maven {
            url = uri ("https://dl-maven-android.mintegral.com/repository/mbridge_android_sdk_oversea")
        }
        maven {
            url = uri("https://sdk.tapjoy.com/")
        }

        jcenter()
    }
}

rootProject.name = "ATM Card Checker"
include(":app")
