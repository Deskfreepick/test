package com.deep.infotech.atm_card_wallet.maniya.ui

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityAppreanceCardManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.adapter.LabelColorAdapter
import java.io.File
import java.io.FileOutputStream
import java.util.Arrays

class AppreanceCardActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityAppreanceCardManiyaBinding
    private lateinit var labelColorAdapter: LabelColorAdapter
    private var selectedColor: Int = 0
    private var selectedIndex: Int = -1
    private var categoryID = 15L
    var isFrontSelected = false
    var mMyDialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppreanceCardManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        init()
    }
    private fun init(){
        setCategoryCard()
        setAppreanceColorsList()
    }

    private fun setCategoryCard() {
        categoryID = intent.getLongExtra("categoryID", 15L)
        when (categoryID) {
            1L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_licence)
            }

            2L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_passport)
            }

            3L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_idcard)
            }

            4L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_residence)
            }

            5L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_payment)
            }

            6L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_gift)
            }

            7L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_loyalty)
            }

            8L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_membership)
            }

            9L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_medical)
            }

            10L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_health)
            }

            11L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_birth)
            }

            12L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_mrg)
            }

            13L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_sim)
            }

            14L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_password)
            }

            15L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_custom)
            }
            16L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_vehical)
            }
            17L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_adhar)
            }
            18L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_voter)
            }
            19L -> {
                binding.ivAppreance.setImageResource(R.drawable.appreance_adhar)
            }
        }
    }

    private fun returnResult() {
        val resultIntent = Intent()
        resultIntent.putExtra("appreanceColor", selectedColor)
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    fun setAppreanceColorsList() {
        selectedColor = intent.getIntExtra("appreanceColor", ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.appreance))
        binding.tvAppreanceColor.setBackgroundColor(selectedColor)

        val colorList = Arrays.asList(
            ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.label_color1),
            ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.label_color2),
            ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.label_color3),
            ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.label_color4),
            ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.label_color5),
            ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.label_color6),
            ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.label_color7),
            ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.label_color8)
        )
        val index = colorList.indexOf(selectedColor)
        if (index != -1) {
            selectedIndex=index
        }
        labelColorAdapter = LabelColorAdapter(this, colorList,selectedIndex) { color, position ->
            selectedColor = color
            binding.tvAppreanceColor.setBackgroundColor(selectedColor)
        }
        binding.rvLabelColors.apply {
            layoutManager = LinearLayoutManager(this@AppreanceCardActivityManiya, LinearLayoutManager.HORIZONTAL, false)
            adapter = labelColorAdapter
        }
    }

    fun onBackClick(view: View) {
        AdsInterstitial.instance?.showInterstitialAd(
            this@AppreanceCardActivityManiya,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    onBackPressed()
                }
            })
    }
    fun onSaveClick(view: View) {
        returnResult()
    }
    fun onResetDefaultClick(view: View) {
        selectedColor = ContextCompat.getColor(this@AppreanceCardActivityManiya, R.color.appreance)
        binding.tvAppreanceColor.setBackgroundColor(selectedColor)
        selectedIndex=-1
        labelColorAdapter?.setLastSelectedItem(selectedIndex)
    }
    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }


    companion object {
        fun getImage(bArr: ByteArray): Bitmap {
            return BitmapFactory.decodeByteArray(bArr, 0, bArr.size)
        }
    }

}




