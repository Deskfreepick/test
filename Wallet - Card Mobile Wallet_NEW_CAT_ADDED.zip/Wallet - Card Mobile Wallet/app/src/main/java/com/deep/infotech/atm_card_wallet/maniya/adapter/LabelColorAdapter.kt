package com.deep.infotech.atm_card_wallet.maniya.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.deep.infotech.atm_card_wallet.databinding.ItemLabelManiyaBinding
import com.deep.infotech.atm_card_wallet.R

class LabelColorAdapter(
    private val context: Context,
    private val colorList: List<Int>,
    private var selectedIndex:Int,
    private val onItemClick: (Int, Int) -> Unit
) : RecyclerView.Adapter<LabelColorAdapter.MyViewHolder>() {

    class MyViewHolder(val binding: ItemLabelManiyaBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val binding = ItemLabelManiyaBinding.inflate(LayoutInflater.from(context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val color = colorList[position]
        with(holder.binding) {
            cvItemLabelColor.setCardBackgroundColor(color)
            if (selectedIndex == position) {
                cvLabelSelection.setCardBackgroundColor(context.getColor(R.color.colorPrimary))
            } else {
                cvLabelSelection.setCardBackgroundColor(context.getColor(android.R.color.transparent))
            }
            root.setOnClickListener {
                handleSelection(position)
                onItemClick(color, position)
            }
        }
    }
    private fun handleSelection(position: Int) {
        val oldPosition = selectedIndex
        selectedIndex = position
        notifyItemChanged(oldPosition)
        notifyItemChanged(selectedIndex)
    }
    fun setLastSelectedItem(position: Int) {
        selectedIndex = position
        notifyDataSetChanged()
    }
    fun getLastSelectedItem(): Int {
        return selectedIndex
    }
    override fun getItemCount(): Int {
        return colorList.size
    }
}