package com.deep.infotech.atm_card_wallet.maniya.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.deep.infotech.atm_card_wallet.databinding.ItemNavCatlabManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.dataModel.CategoryDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya

class CategoriesNavigationAdapter(
     val context: Context,
     val items: List<CategoryDataManiya>,
     val onItemClick: (CategoryDataManiya, Int) -> Unit
) : RecyclerView.Adapter<CategoriesNavigationAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemNavCatlabManiyaBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemNavCatlabManiyaBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        with(holder.binding) {
            ivNavItem.visibility = View.VISIBLE
            rlLabel.visibility = View.GONE
            tvNavItem.text = item.name
            ivNavItem.setImageResource(
                context.resources.getIdentifier(
                    item.icon,
                    "drawable",
                    context.packageName
                )
            )

            val dataFetchMap = mapOf(
                1L to { DatabaseHelperManiya(context).fetchLicenceData().size },
                2L to { DatabaseHelperManiya(context).fetchPassportData().size },
                3L to { DatabaseHelperManiya(context).fetchIDCardData().size },
                4L to { DatabaseHelperManiya(context).fetchResidenceCardData().size },
                5L to { DatabaseHelperManiya(context).fetchPaymentData().size },
                6L to { DatabaseHelperManiya(context).fetchGiftData().size },
                7L to { DatabaseHelperManiya(context).fetchLoyaltyData().size },
                8L to { DatabaseHelperManiya(context).fetchMemberShipData().size },
                9L to { DatabaseHelperManiya(context).fetchMedicalData().size },
                10L to { DatabaseHelperManiya(context).fetchHealthData().size },
                11L to { DatabaseHelperManiya(context).fetchBirthData().size },
                12L to { DatabaseHelperManiya(context).fetchMrgData().size },
                13L to { DatabaseHelperManiya(context).fetchSIMData().size },
                14L to { DatabaseHelperManiya(context).fetchPasswordData().size },
                15L to { DatabaseHelperManiya(context).fetchCustomData().size },
                16L to { DatabaseHelperManiya(context).fetchVehicleData().size },
                17L to { DatabaseHelperManiya(context).fetchAdharData().size },
                18L to { DatabaseHelperManiya(context).fetchVoterData().size },
                19L to { DatabaseHelperManiya(context).fetchPANData().size },
            )

            tvNavCount.text = dataFetchMap[item.id]?.invoke()?.toString() ?: "0"



        }
        holder.itemView.setOnClickListener {
            onItemClick(item, position)
        }

    }

    override fun getItemCount(): Int {
        return items.size
    }

}