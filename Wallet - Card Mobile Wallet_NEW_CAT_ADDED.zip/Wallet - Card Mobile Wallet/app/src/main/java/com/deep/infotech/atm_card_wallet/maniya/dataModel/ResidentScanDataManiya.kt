package com.deep.infotech.atm_card_wallet.maniya.dataModel


import com.j256.ormlite.field.DatabaseField
import com.j256.ormlite.table.DatabaseTable

@DatabaseTable(tableName = "ResidentCards")
data class ResidentScanDataManiya(
    @DatabaseField(generatedId = true) // Auto-increment primary key
    var id: Long = 0,
    @DatabaseField(canBeNull = true)
    var title: String = "",

    @DatabaseField(canBeNull = true)
    var documentNumber: String = "",

    @DatabaseField(canBeNull = true)
    var issueDate: String = "",

    @DatabaseField(canBeNull = true)
    var expiryDate: String = "",

    @DatabaseField(canBeNull = true)
    var dob: String = "",

    @DatabaseField(canBeNull = true)
    var fullName: String = "",

    @DatabaseField(canBeNull = true)
    var personalNumber: String = "",


    @DatabaseField(canBeNull = true)
    var placeOfBirth: String = "",

    @DatabaseField(canBeNull = true)
    var issueCountry: String = "",

    @DatabaseField(canBeNull = true)
    var issueAuthority: String = "",

    @DatabaseField(canBeNull = true)
    var nationality: String = "",

    @DatabaseField(canBeNull = true)
    var regAddress: String = "",

    @DatabaseField(canBeNull = true)
    var Notes: String = "",

    @DatabaseField(canBeNull = true)
    var custom: String = "",

    @DatabaseField(foreign = true, foreignAutoRefresh = true, canBeNull = true, foreignColumnName = "id")
    var label: LabelDataManiya? = null,

    @DatabaseField(foreign = true, foreignAutoRefresh = true, canBeNull = true)
    var category: CategoryDataManiya? = null,

    @DatabaseField(canBeNull = true)
    var frontCardImage: String= "",

    @DatabaseField(canBeNull = true)
    var backCardImage: String= "",


    @DatabaseField(canBeNull = true)
    var appearanceColor: Int = 0,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isSensitive: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isLock: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isFav: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isDelete: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isArchive: Boolean = false
)
