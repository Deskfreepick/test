package com.deep.infotech.atm_card_wallet.maniya.ui

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.ItemTouchHelper
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityCustomManiyaBinding
import com.deep.infotech.atm_card_wallet.databinding.DialogFieldTypeBinding
import com.deep.infotech.atm_card_wallet.maniya.adapter.FieldActionListener
import com.deep.infotech.atm_card_wallet.maniya.adapter.FieldAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.ItemTouchHelperCallback
import com.deep.infotech.atm_card_wallet.maniya.dataModel.AdharScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PANScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.VehicleScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.VoterScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.CategoryFieldManager
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.maniya.model.Field
import com.deep.infotech.atm_card_wallet.maniya.model.FieldType


class CustomActivityManiya : BaseActivity(), FieldActionListener {

    private var sTAG = "CustomActivityManiya+++++"

    private lateinit var binding: ActivityCustomManiyaBinding

    private lateinit var itemTouchHelper: ItemTouchHelper
    private lateinit var pinnedAdapter: FieldAdapter
    private lateinit var unpinnedAdapter: FieldAdapter

    private var pinnedFieldList = mutableListOf<Field>()
    private var unpinnedFieldList = mutableListOf<Field>()
    private var filteredFieldList = mutableListOf<Field>()

    private var fieldTypePairs: List<Pair<FieldType, String>>? = null
    private var displayFieldTypes: List<String>? = mutableListOf()
    private val addedFieldViews = mutableListOf<Pair<String, String>>()

    private var frontImage = ""
    private var backImage = ""
    private var currentCategory = "Custom"
    private var currentCategoryResID = 0
    private var currentCategoryID = 15L

    private var viewCount = 0
    private var appreanceColor: Int = 0
    private var isSensitive = false
  //  private var category: com.deep.infotech.atm_card_wallet.maniya.dataModel.CategoryDataManiya? = null

    private lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCustomManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()

        activityResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                appreanceColor = result.data?.getIntExtra(
                    "appreanceColor",
                    ContextCompat.getColor(this@CustomActivityManiya, R.color.appreance)
                ) ?: ContextCompat.getColor(this@CustomActivityManiya, R.color.appreance)
                Log.d(sTAG, "AppreanceColor--->: $appreanceColor")

                frontImage = result.data?.getStringExtra("frontImage") ?: ""
                backImage = result.data?.getStringExtra("backImage") ?: ""
                Log.d(sTAG, "frontImage--->: $frontImage")
                Log.d(sTAG, "backImage--->: $backImage")
                setImageLayout()
            }
        }
        getIntentData()
        init()
    }

    fun getIntentData() {
        currentCategory = intent.getStringExtra("categoryName") ?: resources.getString(R.string.custom_cat_maniya)
        currentCategoryID = intent.getLongExtra("categoryID", 15)
/*      category = DatabaseHelperManiya(this@CustomActivityManiya).getSingleCategoryByID(currentCategoryID)?.get(0)
        currentCategory = category?.name.toString()
        Log.w("+++currentCategory++=", category.toString())*/
        binding.tvType.text = currentCategory
        appreanceColor = ContextCompat.getColor(this@CustomActivityManiya, R.color.appreance)
    }

    fun init() {
        getCategoryResId()
        setImageLayout()
        binding.switchSensitive.setOnCheckedChangeListener { _, isChecked ->
            isSensitive = isChecked
        }
        setPinnedItems()
        setUnPinnedItems()
        loadDefaultFields()
    }

    private fun setImageLayout(){
        if (frontImage.isNotEmpty())
        {
            Glide.with(this@CustomActivityManiya)
                .load(frontImage)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(binding.ivCard)
            viewCount = 1
        }
        if (backImage.isNotEmpty())
        {
            if (frontImage.isEmpty())
            {
                Glide.with(this@CustomActivityManiya)
                    .load(backImage)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(binding.ivCard)}
            viewCount++
        }

        binding.tvPhotoCount.text = "$viewCount"
        if (frontImage.isNotEmpty() || backImage.isNotEmpty())
        {
            binding.tvAutoFill.alpha = 1f
            binding.tvAutoFill.isClickable = true
        }
        else
        {
            binding.tvAutoFill.alpha = 0.5f
            binding.tvAutoFill.isClickable = false
        }
        if(frontImage.isNotEmpty() || backImage.isNotEmpty()){
            binding.llPhotos.visible()
            binding.llAddPhoto.gone()

        }else{
            binding.llPhotos.gone()
            binding.llAddPhoto.visible()
        }
    }
    private fun saveCarddData()
    {

        val title = binding.edtTitle.text.toString()

        var address = ""
        var barcode = ""
        var cardNumber = ""
        var date = ""
        var email = ""
        var fullName = ""
        var number = ""
        var expDate = ""
        var note = ""
        var phoneNumber = ""
        var text = ""
        var url = ""
        var name = ""
        var spouseName = ""
        var parentsName = ""
        var documentNumber = ""
        var issuingCountry = ""
        var issuingAuthority = ""
        var restrictions = ""
        var registrationAddress = ""
        var classs = ""
        var type = ""
        var placeOfBirth = ""
        var nationality = ""
        var blankPagesRemaining = ""
        var cardHolderName = ""
        var cardHolderNumber = ""
        var brand = ""
        var bank = ""
        var paySystem = ""
        var currency = ""
        var mobileOperator = ""
        var ownerName = ""
        var personalNumber = ""
        var amount = ""
        var cvv = ""
        var accountNumber = ""
        var customerServiceNo = ""
        var issueDate = ""
        var dob = ""
        var mrgDate = ""
        var gender = ""
        var bloodGroup = ""
        var memberSince = ""
        var custom = ""
        var pin = ""
        var puk = ""
        var login = ""
        var password = ""

        for (i in 0 until pinnedAdapter.itemCount)
        {
            val nameViewHolder = binding.rvPinned.findViewHolderForAdapterPosition(i) as? FieldAdapter.NameViewHolder
            nameViewHolder?.let { holder ->
                addedFieldViews.add(holder.getViewValues())
            }

            val paswordViewHolder =
                binding.rvPinned.findViewHolderForAdapterPosition(i) as? FieldAdapter.PasswordViewHolder
            paswordViewHolder?.let { holder ->
                addedFieldViews.add(holder.getViewValues())
            }

            val dateViewHolder =
                binding.rvPinned.findViewHolderForAdapterPosition(i) as? FieldAdapter.DateViewHolder
            dateViewHolder?.let { holder ->
                addedFieldViews.add(holder.getViewValues())
            }
        }

        for (i in 0 until unpinnedAdapter.itemCount) {
            val nameViewHolder =
                binding.rvUnPinned.findViewHolderForAdapterPosition(i) as? FieldAdapter.NameViewHolder
            nameViewHolder?.let { holder ->
                addedFieldViews.add(holder.getViewValues())
            }

            val paswordViewHolder =
                binding.rvUnPinned.findViewHolderForAdapterPosition(i) as? FieldAdapter.PasswordViewHolder
            paswordViewHolder?.let { holder ->
                addedFieldViews.add(holder.getViewValues())
            }

            val dateViewHolder =
                binding.rvUnPinned.findViewHolderForAdapterPosition(i) as? FieldAdapter.DateViewHolder
            dateViewHolder?.let { holder ->
                addedFieldViews.add(holder.getViewValues())
            }
        }

        for (i in 0 until addedFieldViews.size) {

            if (addedFieldViews[i].first.equals("Address")) { address = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Barcode")) { barcode = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Card Number")) { cardNumber = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Date")) { date = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Email")) { email = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Full Name")) { fullName = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Number")) { number = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Expiry Date")) { expDate = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Notes")) { note = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Phone Number")) { phoneNumber = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Text")) { text = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Url")) { url = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Name")) { name = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Spouse Name")) { spouseName = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Parents Name")) { parentsName = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Document Number")) { documentNumber = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Issuing Country")) { issuingCountry = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Issuing Authority")) { issuingAuthority = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Restrictions")) { restrictions = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Registration Address")) { address = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Class")) { classs = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Type")) { type = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Place of Birth")) { placeOfBirth = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Nationality")) { nationality = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Blank Pages Remaining")) { blankPagesRemaining = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Card Holder Name")) { cardHolderName = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Card Holder Number")) { cardHolderNumber = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Brand")) { brand = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Bank")) { bank = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Pay System")) { paySystem = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Currency")) { currency = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Mobile Operator")) { mobileOperator = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Owner Name")) { ownerName = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Mrg Date")) { mrgDate = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Spouse Name")) { spouseName = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Phone Number")) { phoneNumber = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Personal Number")) { personalNumber = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Amount")) { amount = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Cvv")) { cvv = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Account Number")) { accountNumber = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Customer Service No")) { customerServiceNo = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Issue Date")) { issueDate = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Dob")) { dob = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Mrg Date")) { mrgDate = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Member Since")) { memberSince = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Gender")) { gender = addedFieldViews[i].second }
            if (addedFieldViews[i].first.equals("Blood Group")) { bloodGroup = addedFieldViews[i].second }
        }

        when (currentCategoryID)
        {
            1L -> {
                val licenseCard =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya(
                        title = title,
                        gender = gender,
                        bloodGroup = bloodGroup,
                        documentNumber = documentNumber,
                        issueDate = issueDate,
                        expiryDate = expDate,
                        dob = dob,
                        fullName = fullName,
                        parentsName = parentsName,
                        personamNumber = personalNumber,
                        issueCountry = issuingCountry,
                        issueAuthority = issuingAuthority,
                        regAddress = registrationAddress,
                        restrictions = restrictions,
                        notes = note,
                        classs = classs,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(1),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertLicenceCard(licenseCard)
            }

            2L -> {
                val passportData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.PassportScanDataManiya(
                        title = title,
                        documentNumber = documentNumber,
                        issueDate = issueDate,
                        expiryDate = expDate,
                        dob = dob,
                        fullName = fullName,
                        personalNumber = personalNumber,
                        type = type,
                        placeOfBirth = placeOfBirth,
                        issueCountry = issuingCountry,
                        issueAuthority = issuingAuthority,
                        nationality = nationality,
                        regAddress = registrationAddress,
                        blankpageRemain = blankPagesRemaining,
                        Notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(2),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertPassportCard(passportData)

            }

            3L -> {

                val identityData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya(
                        title = title,
                        documentNumber = documentNumber,
                        issueDate = issueDate,
                        expiryDate = expDate,
                        dob = dob,
                        fullName = fullName,
                        personalNumber = personalNumber,
                        placeOfBirth = placeOfBirth,
                        issueCountry = issuingCountry,
                        issueAuthority = issuingAuthority,
                        nationality = nationality,
                        regAddress = registrationAddress,
                        Notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(3),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertIDCard(identityData)
            }

            4L -> {

                val residenceData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.ResidentScanDataManiya(
                        title = title,
                        documentNumber = documentNumber,
                        issueDate = issueDate,
                        expiryDate = expDate,
                        dob = dob,
                        fullName = fullName,
                        personalNumber = personalNumber,
                        placeOfBirth = placeOfBirth,
                        issueCountry = issuingCountry,
                        issueAuthority = issuingAuthority,
                        nationality = nationality,
                        regAddress = registrationAddress,
                        Notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(4),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertResidenceCard(residenceData)
            }
            5L -> {
                val paymentData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya(
                        title = title,
                        holderName = cardHolderName,
                        cardNumber = cardHolderNumber,
                        cvv = cvv,
                        expDate = expDate,
                        cardType = type,
                        bankName = bank,
                        cardPIN = pin,
                        address = address,
                        email = email,
                        barcode = barcode,
                        phoneNumber = phoneNumber,
                        url = url,
                        text = text,
                        number = number,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(5),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertPaymentCard(paymentData)
            }

            6L -> {

                val giftData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.GiftCardScanDataManiya(
                        title = title,
                        cardNumber = cardNumber,
                        pin = pin,
                        amount = amount,
                        barcode = barcode,
                        brand = brand,
                        issueDate = issueDate,
                        expDate = expDate,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(6),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertGiftCard(giftData)

            }

            7L -> {

                val loyaltyData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.LoyaltyCardScanDataManiya(
                        title = title,
                        barcode = barcode,
                        brand = brand,
                        cardNumber = cardNumber,
                        url = url,
                        login = login,
                        password = password,
                        cardHolderName = cardHolderName,
                        cardHolderNumber = cardHolderNumber,
                        expDate = expDate,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(7),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertLoyaltyCard(loyaltyData)

            }

            8L -> {
                val memberShipData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.MemberShipCardScanDataManiya(
                        title = title,
                        cardHolderName = cardHolderName,
                        cardHolderNumber = cardHolderNumber,
                        url = url,
                        login = login,
                        password = password,
                        barcode = barcode,
                        brand = brand,
                        expDate = expDate,
                        memberSince = memberSince,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(8),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertMembershipCard(memberShipData)
            }

            9L -> {
                val medicalData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.MedicalCardScanDataManiya(
                        title = title,
                        documentNumber = documentNumber,
                        expiryDate = expDate,
                        issueDate = issueDate,
                        dob = dob,
                        phoneNumber = phoneNumber,
                        email = email,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(9),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertMedicalCard(medicalData)
            }

            10L -> {

                val healthData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya(
                        title = title,
                        fullName = fullName,
                        documentNumber = documentNumber,
                        expiryDate = expDate,
                        phoneNumber = phoneNumber,
                        email = email,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(10),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertHealthCard(healthData)

            }

            11L -> {

                val birthData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.BirthCardScanDataManiya(
                        title = title,
                        fullName = fullName,
                        documentNumber = documentNumber,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(11),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertBirthCard(birthData)

            }

            12L -> {

                val mrgData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.MrgCardScanDataManiya(
                        title = title,
                        mrgDate = mrgDate,
                        spouseName = spouseName,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(12),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertMrgCard(mrgData)
            }

            13L -> {

                val simData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.SIMCardScanDataManiya(
                        title = title,
                        phoneNumber = phoneNumber,
                        pin = pin,
                        puk = puk,
                        country = issuingCountry,
                        operator = mobileOperator,
                        ownerName = ownerName,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(13),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertSIMCard(simData)

            }

            14L -> {

                val passwordData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.PasswordCardScanDataManiya(
                        title = title,
                        url = url,
                        password = password,
                        login = login,
                        Name = name,
                        notes = note,
                        custom = custom,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(14),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertPasswordCard(passwordData)

            }

            15L -> {
                val customData =
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.CustomScanDataManiya(
                        title = title,
                        address = address,
                        barcode = barcode,
                        cardNumber = cardNumber,
                        date = date,
                        email = email,
                        fullName = fullName,
                        number = number,
                        expDate = expDate,
                        note = note,
                        phoneNumber = phoneNumber,
                        text = text,
                        url = url,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(15),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertCustomCard(customData)
            }

            16L -> {
                val vehicleData =
                    VehicleScanDataManiya(
                        title = title,
                        address = address,
                        barcode = barcode,
                        cardNumber = cardNumber,
                        date = date,
                        email = email,
                        fullName = fullName,
                        number = number,
                        expDate = expDate,
                        note = note,
                        phoneNumber = phoneNumber,
                        text = text,
                        url = url,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(16),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertVehicleCard(vehicleData)
            }
            17L -> {
                val adharData =
                    AdharScanDataManiya(
                        title = title,
                        address = address,
                        adharNo = cardNumber,
                        dob = date,
                        email = email,
                        fullName = fullName,
                        phoneNumber = number,
                        note = note,
                        text = text,
                        url = url,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(17),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertAdharCard(adharData)
            }
            18L -> {
                val voterData =
                    VoterScanDataManiya(
                        address = address,
                        barcode = barcode,
                        cardNumber = cardNumber,
                        date = date,
                        email = email,
                        fullName = fullName,
                        number = number,
                        dob = expDate,
                        note = note,
                        phoneNumber = phoneNumber,
                        text = text,
                        url = url,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(18),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertVoterCard(voterData)
            }
            18L -> {
                val panData =
                    PANScanDataManiya(
                        address = address,
                        barcode = barcode,
                        cardNumber = cardNumber,
                        date = date,
                        email = email,
                        fullName = fullName,
                        number = number,
                        expDate = expDate,
                        note = note,
                        phoneNumber = phoneNumber,
                        text = text,
                        url = url,
                        category = DatabaseHelperManiya(this).getCategoryDao().queryForId(18),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive
                    )
                DatabaseHelperManiya(this).insertPANCard(panData)
            }
        }
        returnResult()
    }

    private fun getCategoryResId() {

        when (currentCategoryID)
        {
            1L -> {
                currentCategoryResID = R.string.driver_cat_maniya
            }

            2L -> {
                currentCategoryResID = R.string.passport_cat_maniya
            }

            3L -> {
                currentCategoryResID = R.string.identity_cat_maniya
            }

            4L -> {
                currentCategoryResID = R.string.residence_cat_maniya
            }
            5L -> {
                currentCategoryResID = R.string.pay_cat_maniya
            }

            6L -> {
                currentCategoryResID = R.string.gift_cat_maniya
            }

            7L -> {
                currentCategoryResID = R.string.loyal_cat_maniya
            }

            8L -> {
                currentCategoryResID = R.string.member_cat_maniya
            }

            9L -> {
                currentCategoryResID = R.string.medical_cat_maniya
            }

            10L -> {
                currentCategoryResID = R.string.health_cat_maniya
            }

            11L -> {
                currentCategoryResID = R.string.birth_cat_maniya
            }

            12L -> {
                currentCategoryResID = R.string.mrg_cat_maniya
            }

            13L -> {
                currentCategoryResID = R.string.sim_cat_maniya
            }

            14L -> {
                currentCategoryResID = R.string.password_cat_maniya
            }

            15L -> {
                currentCategoryResID = R.string.custom_cat_maniya
            }
            16L -> {
                currentCategoryResID = R.string.driver_cat_maniya
            }
            17L -> {
                currentCategoryResID = R.string.adhar_cat_maniya
            }
            18L -> {
                currentCategoryResID = R.string.voter_cat_maniya
            }
            19L -> {
                currentCategoryResID = R.string.pan_cat_maniya
            }
        }

    }
    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    private fun setPinnedItems() {
        pinnedAdapter =
            FieldAdapter(this@CustomActivityManiya, pinnedFieldList, onFieldClick = { field ->
           /*     Toast.makeText(
                    this@CustomActivityManiya,
                    "Pinned Item Clicked!!!",
                    Toast.LENGTH_SHORT
                ).show()*/
            }, fieldActionListener = this)
        binding.rvPinned.adapter = pinnedAdapter

        val itemTouchHelperCallback = ItemTouchHelperCallback(pinnedAdapter)

        itemTouchHelper = ItemTouchHelper(itemTouchHelperCallback)
        itemTouchHelper.attachToRecyclerView(binding.rvPinned)
    }

    private fun setUnPinnedItems() {
        unpinnedAdapter = FieldAdapter(this@CustomActivityManiya, unpinnedFieldList, onFieldClick = { field ->
               /* Toast.makeText(
                    this@CustomActivityManiya,
                    "UnPinned Item Clicked!!!",
                    Toast.LENGTH_SHORT
                ).show()*/
            }, fieldActionListener = this)
        binding.rvUnPinned.adapter = unpinnedAdapter
        val itemTouchHelperCallback = ItemTouchHelperCallback(unpinnedAdapter)
        itemTouchHelper = ItemTouchHelper(itemTouchHelperCallback)
        itemTouchHelper.attachToRecyclerView(binding.rvUnPinned)

    }

    private fun loadDefaultFields() {
        binding.rlPinned.visible()
        binding.rlUnPinned.visible()

        val categoryFields = CategoryFieldManager.getCategoryFields(currentCategoryResID)
        pinnedFieldList.clear()
        unpinnedFieldList.clear()
        filteredFieldList.clear()

        categoryFields.pinned.forEach { pinnedFieldList.add(Field(type = it, isPinned = true)) }
        categoryFields.unpinned.forEach { unpinnedFieldList.add(Field(type = it)) }
        getPairedFieldData()

        pinnedAdapter.notifyDataSetChanged()
        unpinnedAdapter.notifyDataSetChanged()

        if (unpinnedFieldList.size == 0) {
            binding.rlUnPinned.gone()
        }
        if (pinnedFieldList.size == 0) {
            binding.rlPinned.gone()
        }
    }

    private fun openPhotoViewAdd() {
        activityResultLauncher.launch(
            Intent(this@CustomActivityManiya, PhotoAddViewActivityManiya::class.java)
                .putExtra("frontImage", frontImage)
                .putExtra("backIMage", backImage)
                .putExtra("title", currentCategory)
        )
    }

    private fun showFieldTypeDialog() {
        val dialogBinding = DialogFieldTypeBinding.inflate(layoutInflater)
        val dialog = Dialog(this).apply {
            setContentView(dialogBinding.root)

            window!!.setBackgroundDrawable(ColorDrawable(0))
        }

        val displayMetrics = resources.displayMetrics
        val bottomMarginInPixels = (100 * displayMetrics.density).toInt()

        dialog.window?.let { window ->
            val params = window.attributes
            params.gravity = Gravity.BOTTOM
            params.y = bottomMarginInPixels
            window.attributes = params
        }

        getPairedFieldData()
        dialogBinding.topField.visible()
        dialogBinding.bottomField.gone()
        setFieldListData(dialogBinding.lvFieldTypes)
        dialogBinding.lvFieldTypes.setOnItemClickListener { _, _, position, _ ->
            val selectedType = fieldTypePairs!![position].first
            Log.w("+++selectedType++=", selectedType.toString())
            unpinnedAdapter.addField(Field(type = selectedType))
            CategoryFieldManager.addToUnpinned(category = currentCategoryResID, selectedType)
            dialog.dismiss()
        }
        dialogBinding.topField.setOnClickListener {
            Log.w("+++selectedType++=", "Back Field")
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun setFieldListData(lvFieldTypes: ListView) {
        lvFieldTypes.adapter =
            ArrayAdapter(this@CustomActivityManiya, R.layout.item_field_dialog, displayFieldTypes!!)
        lvFieldTypes.divider = null
        setListViewHeightBasedOnChildren(lvFieldTypes)
    }

    private fun getPairedFieldData() {
        filteredFieldList.clear()
        displayFieldTypes = mutableListOf()
        CategoryFieldManager.getFilteredList(currentCategoryResID)
            .forEach { filteredFieldList.add(Field(type = it)) }
        fieldTypePairs = filteredFieldList.map { field ->
            val formattedName = field.type.name.replace("_", " ")
                .lowercase()
                .split(" ")
                .joinToString(" ") { word -> word.replaceFirstChar { it.uppercase() } }

            field.type to formattedName
        }
        displayFieldTypes = fieldTypePairs?.map { it.second }

        if (filteredFieldList.size > 0) {
            binding.tvAddField.alpha = 1f
            binding.tvAddField.isClickable = true
        } else {
            binding.tvAddField.alpha = 0.5f
            binding.tvAddField.isClickable = false
        }

    }

    private fun setListViewHeightBasedOnChildren(listView: ListView) {
        val listAdapter = listView.adapter ?: return
        var totalHeight = 0
        for (i in 0 until listAdapter.count) {
            val listItem = listAdapter.getView(i, null, listView)
            listItem.measure(0, 0)
            totalHeight += listItem.measuredHeight
        }
        val params = listView.layoutParams
        params.height = totalHeight + (listView.dividerHeight * (listAdapter.count - 1))
        listView.layoutParams = params
        listView.requestLayout()
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }

    override fun onDelete(field: Field) {
        if (field.isPinned) {
            pinnedAdapter.removeField(field)
            CategoryFieldManager.removeFromPinned(category = currentCategoryResID, field.type)

        } else {
            unpinnedAdapter.removeField(field)
            CategoryFieldManager.removeFromUnpinned(category = currentCategoryResID, field.type)
        }
    }

    override fun onTogglePinned(field: Field) {
        field.togglePinned()
        if (field.isPinned) {
            unpinnedAdapter.removeField(field)
            pinnedAdapter.addField(field)
            CategoryFieldManager.addToPinned(category = currentCategoryResID, field.type)

        } else {
            pinnedAdapter.removeField(field)
            unpinnedAdapter.addField(field)
            CategoryFieldManager.addToUnpinned(category = currentCategoryResID, field.type)

        }
    }

    fun onBackClick(view: View) {
        onBackPressed()
    }
    fun onSaveClick(view: View) {
        if(frontImage.isNotEmpty() || backImage.isNotEmpty())
        {
        saveCarddData()
        }
        else
        {
            Toast.makeText(this@CustomActivityManiya,
                getString(R.string.please_enter_card_photo),Toast.LENGTH_SHORT).show()
        }
    }
    fun onClickAppearance(view: View) {
        activityResultLauncher.launch(
            Intent(this@CustomActivityManiya, AppreanceCardActivityManiya::class.java)
                .putExtra("appreanceColor", appreanceColor)
                .putExtra("categoryID", currentCategoryID)
        )
    }
    fun onClickAddPhoto(view: View) { openPhotoViewAdd() }
    fun onClickPhotos(view: View) { openPhotoViewAdd() }
    fun onClickAutoFill(view: View) {}
    fun onClickAddField(view: View) {

        if (filteredFieldList.size > 0) {
            binding.tvAddField.alpha = 1f
            binding.tvAddField.isClickable = true
        } else {
            binding.tvAddField.alpha = 0.5f
            binding.tvAddField.isClickable = false
        }

        if (binding.tvAddField.alpha == 1f) {
            showFieldTypeDialog()
        }
    }

}




