package com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData

import android.content.Context
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PassportScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.ResidentScanDataManiya
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PassportViewModel : ViewModel() {

    val detectedBlocks: MutableList<String> = ArrayList()
    var expDate: String? = ""
    var issueDate: String? = ""
    var d_o_b: String? = ""
    var fullName: String? = ""
    var personalNumber: String? = ""
    var documentNumber: String? = ""
    var placeOfBirth: String? = ""
    var issueCountry: String? = ""
    var issueAuthority: String? = ""
    var nationality: String? = ""
    var regAddress: String? = ""

    val DATE_REGEX: String = """^(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$|^(0?[1-9]|[12][0-9]|3[01])([/-])(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$"""
    val restrictedKeywords = listOf(
        "platinu", "platinum", "gold", "black", "classic", "silver", "titanium",
        "bank", "credit", "debit", "atm", "transaction", "international", "card",
        "paypal", "money", "e-commerce", "charge", "visa", "mastercard", "american express",
        "discover", "jcb", "diners club", "unionpay", "maestro", "rupay", "laser",
        "china unionpay,payment", "valid", "from", "thru", "validity", "birthdate",
        "dob", "authorized", "signature", "licence", "idcard", "vehical",
        "name", "son","of","wife","daughter",
        "blood","group",
        "licence","card","vehicales","state","drive","no","yes","n/a","ID",
        "health","hospital",
        "date","issuedate","birthdate","expiryDate",
    )
    val countryPattern= Regex("(?i)^(Afghanistan|Albania|Algeria|Andorra|Angola|Antigua and Barbuda|Argentina|Armenia|Australia|Austria|Azerbaijan|Bahamas|Bahrain|Bangladesh|Barbados|Belarus|Belgium|Belize|Benin|Bhutan|Bolivia|Bosnia and Herzegovina|Botswana|Brazil|Brunei|Bulgaria|Burkina Faso|Burundi|Cabo Verde|Cambodia|Cameroon|Canada|Central African Republic|Chad|Chile|China|Colombia|Comoros|Congo (Congo-Brazzaville)|Costa Rica|Croatia|Cuba|Cyprus|Czechia (Czech Republic)|Democratic Republic of the Congo (Congo-Kinshasa)|Denmark|Djibouti|Dominica|Dominican Republic|Ecuador|Egypt|El Salvador|Equatorial Guinea|Eritrea|Estonia|Eswatini|Ethiopia|Fiji|Finland|France|Gabon|Gambia|Georgia|Germany|Ghana|Greece|Grenada|Guatemala|Guinea|Guinea-Bissau|Guyana|Haiti|Honduras|Hungary|Iceland|India|Indonesia|Iran|Iraq|Ireland|Israel|Italy|Jamaica|Japan|Jordan|Kazakhstan|Kenya|Kiribati|Korea, North|Korea, South|Kuwait|Kyrgyzstan|Laos|Latvia|Lebanon|Lesotho|Liberia|Libya|Liechtenstein|Lithuania|Luxembourg|Madagascar|Malawi|Malaysia|Maldives|Mali|Malta|Marshall Islands|Mauritania|Mauritius|Mexico|Micronesia|Moldova|Monaco|Mongolia|Montenegro|Morocco|Mozambique|Myanmar|Burma|Namibia|Nauru|Nepal|Netherlands|New Zealand|Nicaragua|Niger|Nigeria|North Macedonia|Norway|Oman|Pakistan|Palau|Panama|Papua New Guinea|Paraguay|Peru|Philippines|Poland|Portugal|Qatar|Romania|Russia|Rwanda|Saint Kitts and Nevis|Saint Lucia|Saint Vincent and the Grenadines|Samoa|San Marino|Sao Tome and Principe|Saudi Arabia|Senegal|Serbia|Seychelles|Sierra Leone|Singapore|Slovakia|Slovenia|Solomon Islands|Somalia|South Africa|South Sudan|Spain|Sri Lanka|Sudan|Suriname|Sweden|Switzerland|Syria|Taiwan|Tajikistan|Tanzania|Thailand|Timor-Leste|Togo|Tonga|Trinidad and Tobago|Tunisia|Turkey|Turkmenistan|Tuvalu|Uganda|Ukraine|United Arab Emirates|United Kingdom|United States|Uruguay|Uzbekistan|Vanuatu|Vatican City|Venezuela|Vietnam|Yemen|Zambia|Zimbabwe)$")
    val nationalityPattern= Regex("(?i)^(American|Canadian|French|British|Brazilian|Japanese|Pakistani|English|Spanish|Italian|Chinese|German|Mexican|Russian|Indian|Australian|South African|Italian|Dutch|Finnish|Swedish|Norwegian|Swiss|Polish|Portuguese|Greek|Turkish|Irish|Egyptian|Israeli|Belgian|Danish|Austrian|Czech|Hungarian|Romanian|Ukrainian|Slovak|Bulgarian|Serbian|Croatian|Slovenian|Latvian|Estonian|Lithuanian|Latvian|New Zealander|Singaporean|Malaysian|Thai|Indonesian|Filipino|Vietnamese|South Korean|North Korean|Pakistani|Bangladeshi|Nepali|Sri Lankan|Bhutanese|Tanzanian|Kenyan|Ugandan|Nigerian|Ghanaian|Kenyan|Algerian|Moroccan|Libyan|Sudanese|Iraqi|Syrian|Jordanian|Lebanese|Afghan|Kazakh|Turkmen|Kyrgyz|Uzbek|Mongolian|Tajik|Armenian|Georgian|Kazakhstani|Kazakh|Belarusian|Kyrgyzstani|Turkmenistan|Maldivian|Mauritian|Malawian|Somali|Liberian|Congolese|Gabonese|Cameroonian|Chadian|Botswanan|Zambian|Zimbabwean|Namibian|Angolan|Mozambican|Eswatini|Lesotho)\$")

    fun parseDate(dateString: String): Pair<Date?, String>? {
        val dateFormats = arrayOf(
            "MM/dd/yyyy",
            "dd/MM/yyyy",
            "yyyy/MM/dd",
            "MM/dd/yy",
            "yyyy-MM-dd",
            "MM-dd-yyyy",
            "dd-MM-yyyy",
            "M-dd-yyyy",
            "yyyy.MM.dd",
            "dd.MM.yyyy",
            "MM.dd.yyyy",
            "MM-yy",
            "MM/yyyy",
            "MM/yy"
        )
        for (format in dateFormats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.getDefault())
                val date = sdf.parse(dateString)
                if (date != null) {
                    return Pair(date, format)
                }
            } catch (e: Exception) {

            }
        }
        return null
    }
    fun findMinMaxDates() {
        var minDate: Date? = null
        var maxDate: Date? = null
        var minDateFormat: String? = null
        var maxDateFormat: String? = null

        for (dateString in detectedBlocks) {
            val result = parseDate(dateString)
            if (result != null) {
                val date = result.first
                val format = result.second


                if (minDate == null || date!!.before(minDate)) {
                    minDate = date
                    minDateFormat = format
                }


                if (maxDate == null || date!!.after(maxDate)) {
                    maxDate = date
                    maxDateFormat = format
                }
            }
        }

        val parts = minDate.toString().split("/")
        if(parts.size==2){

        var year = parts[1].trim()

        var mDate = year.replace("0", "")
        if (mDate.isNotEmpty()&& mDate.length>=2) {
            if (!isExpired(minDate)) {
                expDate = formatDate(minDate, minDateFormat)
            } else {
                issueDate = formatDate(minDate, minDateFormat)
            }
        }}

        val parts2 = maxDate.toString().split("/")
        if(parts2.size==2){
            val month = parts2[0].padStart(2, '0')
            var year = parts2[1].trim()

            var mxDate = year.replace("0", "")

        if (mxDate.isNotEmpty()&& mxDate.length>=2) {
            if (!isExpired(maxDate)) {
                expDate = formatDate(maxDate, maxDateFormat)
            } else {
                issueDate = formatDate(maxDate, maxDateFormat)
            }
        }}

        println("expDate Date:++++ $expDate")
        println("issueDate Date:++++ $issueDate ")

        val minDateString = formatDate(minDate, minDateFormat)
        val maxDateString = formatDate(maxDate, maxDateFormat)

        println("Min Date+++: $minDateString ")
        println("Max Date++++: $maxDateString")

    }
    fun formatDate(date: Date?, format: String?): String? {
        if (date == null || format == null) return null
        val sdf = SimpleDateFormat(format, Locale.getDefault())
        return sdf.format(date)
    }
    fun checkFullName(cardholderName: String) {
        if (restrictedKeywords.any { cardholderName.contains(it, ignoreCase = true) }) return
        val cleanHolderName = cardholderName.trim()
        if (cleanHolderName.isNotEmpty() && cleanHolderName.length > 1)
        {
            val fullNamePattern = Regex("\\b[A-Za-z][a-zA-Z]+(?: [A-Za-z][a-zA-Z]+)*\\b")
            if (fullNamePattern.matches(cleanHolderName)) {
                fullName = cardholderName
                Log.e("Passport+++FullName---+++", "cardholderName: $fullName")
            }
        }
    }
    fun checkCountry(str: String) {
        if (countryPattern.matches(str)) {
            issueCountry = str
            Log.d("Passport+++Country++++", str)
        }
    }
    fun checkAuthority(str: String) {
        if (nationalityPattern.matches(str)) {
            issueAuthority = str
            Log.d("Passport+++Authority++++", str)
        }
    }

    fun nationality(str: String) {
        if (nationalityPattern.matches(str)) {
            nationality = str
            Log.d("Passport+++Authority++++", str)
        }
    }

    fun checkDocumentNumber(str: String) {
        val documentNoPattern = Regex("^[A-Z]{2}[0-9]{2}( |-|)[0-9]{4}((19|20)[0-9]{2})[0-9]{7}$")
        if (documentNoPattern.matches(str)) {
            documentNumber = str
            Log.d("Passport+++documentNumber++++", str)
        }
    }
    fun isExpired(date: Date?): Boolean {
        val currentDate = Date()
        return date?.before(currentDate) ?: false
    }
    fun checkDateFormat(block: String) {
        if (Regex(DATE_REGEX).matches(block)) {
            detectedBlocks.add(block)}
    }

    fun insertInDB(
        context: Context,
        stringFront: String,
        stringBack: String,
        categoryID: Long
    ) {

        if(categoryID==2L){

        val passportCard =
            PassportScanDataManiya(
                documentNumber = documentNumber.toString(),
                issueDate = issueDate.toString(),
                expiryDate = expDate.toString(),
                personalNumber = personalNumber.toString(),
                dob = d_o_b.toString(),
                fullName = fullName.toString(),
                issueCountry = issueCountry.toString(),
                issueAuthority = issueAuthority.toString(),
                placeOfBirth = placeOfBirth.toString(),
                regAddress = regAddress.toString(),
                nationality = nationality.toString(),
                label = DatabaseHelperManiya(context).getLabelDao().queryForId(0),
                appearanceColor = ContextCompat.getColor(context, R.color.appreance),
                category = DatabaseHelperManiya(context).getCategoryDao().queryForId(2),
                frontCardImage = stringFront,
                backCardImage = stringBack,
                isLock = false,
                isFav = false,
                isDelete = true,
                isArchive = false
            )
        DatabaseHelperManiya(context).getPassportDao().createOrUpdate(passportCard)}

        if(categoryID==3L){

            val identityCard =
                IdentityScanDataManiya(
                    documentNumber = documentNumber.toString(),
                    issueDate = issueDate.toString(),
                    expiryDate = expDate.toString(),
                    personalNumber = personalNumber.toString(),
                    dob = d_o_b.toString(),
                    fullName = fullName.toString(),
                    issueCountry = issueCountry.toString(),
                    issueAuthority = issueAuthority.toString(),
                    placeOfBirth = placeOfBirth.toString(),
                    regAddress = regAddress.toString(),
                    nationality = nationality.toString(),
                    label = DatabaseHelperManiya(context).getLabelDao().queryForId(0),
                    appearanceColor = ContextCompat.getColor(context, R.color.appreance),
                    category = DatabaseHelperManiya(context).getCategoryDao().queryForId(3),
                    frontCardImage = stringFront,
                    backCardImage = stringBack,
                    isLock = false,
                    isFav = false,
                    isDelete = true,
                    isArchive = false
                )
            DatabaseHelperManiya(context).getIDCardDao().createOrUpdate(identityCard)}

        if(categoryID==4L){

            val residenceCard =
                ResidentScanDataManiya(
                    documentNumber = documentNumber.toString(),
                    issueDate = issueDate.toString(),
                    expiryDate = expDate.toString(),
                    personalNumber = personalNumber.toString(),
                    dob = d_o_b.toString(),
                    fullName = fullName.toString(),
                    issueCountry = issueCountry.toString(),
                    issueAuthority = issueAuthority.toString(),
                    placeOfBirth = placeOfBirth.toString(),
                    regAddress = regAddress.toString(),
                    nationality = nationality.toString(),
                    label = DatabaseHelperManiya(context).getLabelDao().queryForId(0),
                    appearanceColor = ContextCompat.getColor(context, R.color.appreance),
                    category = DatabaseHelperManiya(context).getCategoryDao().queryForId(4),
                    frontCardImage = stringFront,
                    backCardImage = stringBack,
                    isLock = false,
                    isFav = false,
                    isDelete = true,
                    isArchive = false
                )
            DatabaseHelperManiya(context).getResidenceCardDao().createOrUpdate(residenceCard)}
    }
}


