package com.deep.infotech.atm_card_wallet.maniya.dataModel


import com.j256.ormlite.field.DatabaseField
import com.j256.ormlite.table.DatabaseTable

@DatabaseTable(tableName = "PayScanCards")
data class PaymentCardScanDataManiya(

    @DatabaseField(generatedId = true) // Auto-increment primary key
     var id: Long = 0,

    @DatabaseField(canBeNull = true)
    var title: String = "",

    @DatabaseField(canBeNull = true)
     var holderName: String = "",

    @DatabaseField(canBeNull = true)
      var cardNumber: String = "",

    @DatabaseField(canBeNull = true)
    var cvv: String = "",

    @DatabaseField(canBeNull = true)
    var expDate: String = "",

    @DatabaseField(canBeNull = true)
      var cardType: String = "",

    @DatabaseField(canBeNull = true)
     var bankName: String = "",

    @DatabaseField(canBeNull = true)
    var cardPIN: String = "",

    @DatabaseField(canBeNull = true)
    var address: String = "",

    @DatabaseField(canBeNull = true)
    var email: String = "",

    @DatabaseField(canBeNull = true)
    var barcode: String = "",

    @DatabaseField(canBeNull = true)
    var fullName: String = "",

    @DatabaseField(canBeNull = true)
    var phoneNumber: String = "",

    @DatabaseField(canBeNull = true)
    var url: String = "",

    @DatabaseField(canBeNull = true)
    var predefinedList: String = "",

    @DatabaseField(canBeNull = true)
    var text: String = "",

    @DatabaseField(canBeNull = true)
    var number: String = "",

    @DatabaseField(foreign = true, foreignAutoRefresh = true, canBeNull = true, foreignColumnName = "id")
    var label: com.deep.infotech.atm_card_wallet.maniya.dataModel.LabelDataManiya? = null,

    @DatabaseField(foreign = true, foreignAutoRefresh = true, canBeNull = true)
    var category: com.deep.infotech.atm_card_wallet.maniya.dataModel.CategoryDataManiya? = null,

    @DatabaseField(canBeNull = true)
     var frontCardImage: String= "",

    @DatabaseField(canBeNull = true)
    var backCardImage: String= "",

    @DatabaseField(canBeNull = true)
    var appearanceColor: Int = 0,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isSensitive: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isLock: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isFav: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isDelete: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isArchive: Boolean = false
)
