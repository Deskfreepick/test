package com.deep.infotech.atm_card_wallet.maniya.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.model.CardData
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class SearchAdapter(
    private val context: Context,
    private val items: MutableList<CardData>,
    private var useTwoColumns: Boolean,
    private val onItemClick: (CardData, Int) -> Unit,
    private val onItemLongClick: (CardData, Int) -> Boolean,
    private val onSelectionChange: (List<CardData>) -> Unit
) : RecyclerView.Adapter<SearchAdapter.MyViewHolder>() {

    private var filteredItems: List<CardData> = items
    private val selectedItems = mutableSetOf<CardData>()

    var isSelectionMode = false

    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
         val tvDataNM: TextView = itemView.findViewById(R.id.tvDataNM)
         val tvDataText: TextView = itemView.findViewById(R.id.tvDataText)
         val selectionIcon: ImageView = itemView.findViewById(R.id.ivSelection)
         val ivData: ImageView = itemView.findViewById(R.id.ivData)

        @OptIn(DelicateCoroutinesApi::class)
        fun bind(item: CardData, position: Int, isSelected: Boolean, isSelectionMode: Boolean, context:Context) {
            tvDataNM.text = item.title
            tvDataText.text = item.text
            selectionIcon.visibility = if (isSelectionMode) View.VISIBLE else View.GONE
            Log.d("++++frontCardImage++++", "------${item.frontCardImage}---")

            GlobalScope.launch(Dispatchers.Main) {
                   if (!item.frontCardImage.isNullOrEmpty()){
                   Glide.with(context)
                       .load(item.frontCardImage.toString())
                       .thumbnail(0.1f)
                       .diskCacheStrategy(DiskCacheStrategy.ALL)
                       .into(ivData)
               }
               }
            selectionIcon.setImageResource(if (isSelected) R.drawable.select_all else R.drawable.deselect_all)

            itemView.setOnClickListener { v: View? ->
                if (isSelectionMode) {
                    toggleSelection(item,position)
                } else {
                    onItemClick(item, position)
                }
            }
            itemView.setOnLongClickListener {
                if (!isSelectionMode) {
                    onItemLongClick(item, position)
                }
                true
            }
            itemView.isSelected = selectedItems.contains(item)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutId = if (useTwoColumns) R.layout.item_search_grid_two else R.layout.item_search_grid_one
        val view = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = filteredItems[position]
        val isSelected = selectedItems.contains(item)
        Log.e("Glide+++", "File does not exist at: $item.frontCardImage")
        holder.bind(item, position, isSelected, isSelectionMode,context)
    }

    override fun getItemCount(): Int {
        return filteredItems.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun filter(query: String) {
        filteredItems = if (query.isEmpty()) {
            items
        } else {
            items.filter { it.categoryName?.contains(query, ignoreCase = true)!!
                    || it.label?.contains(query, ignoreCase = true)!!
                    || it.title?.contains(query, ignoreCase = true)!!
                    || it.text?.contains(query, ignoreCase = true)!!
            }
        }
        notifyDataSetChanged()
    }

    private fun toggleSelection(item: CardData, position:Int) {
        if (selectedItems.contains(item)) {
            selectedItems.remove(item)
        } else {
            selectedItems.add(item)
        }
        onSelectionChange(selectedItems.toList())
        notifyItemChanged(position)
    }

    fun selectAll() {
        isSelectionMode = true
        selectedItems.clear()
        selectedItems.addAll(filteredItems)
        onSelectionChange(selectedItems.toList())
        notifyItemRangeChanged(0,filteredItems.size)
    }

    fun deSelectAll() {
        isSelectionMode = true
        selectedItems.clear()
        onSelectionChange(selectedItems.toList())
        notifyItemRangeChanged(0,filteredItems.size)
    }

    fun getSelectedData(): List<CardData> {
        return selectedItems.toList()
    }


    fun enableSelectionMode(enable: Boolean) {
        isSelectionMode = enable
        if (!enable) selectedItems.clear()
        onSelectionChange(selectedItems.toList())
        notifyItemRangeChanged(0,filteredItems.size)

    }

    fun updateView(isTwoColumns: Boolean) {
        useTwoColumns = isTwoColumns
        notifyDataSetChanged()
    }

}