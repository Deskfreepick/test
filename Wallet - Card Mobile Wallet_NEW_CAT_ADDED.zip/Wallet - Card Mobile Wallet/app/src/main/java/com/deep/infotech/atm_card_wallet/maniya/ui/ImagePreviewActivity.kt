package com.deep.infotech.atm_card_wallet.maniya.ui

import android.os.Bundle
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.maniya.adapter.ImageRecyclerAdapter
import com.deep.infotech.atm_card_wallet.databinding.ActivityImagePreviewBinding

class ImagePreviewActivity : BaseActivity() {

    private lateinit var binding: ActivityImagePreviewBinding

    private val imagesList = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImagePreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        if(intent.getStringExtra("FrontImage").toString().isNotEmpty())
        {
            imagesList.add(intent.getStringExtra("FrontImage").toString())
        }
        if(intent.getStringExtra("BackImage").toString().isNotEmpty())
        {
          imagesList.add(intent.getStringExtra("BackImage").toString())
        }

        setupViewPager()
    }

    private fun setupViewPager() {
        binding.viewPager.adapter = ImageRecyclerAdapter(imagesList)
        binding.dotIndicator.setViewPager2(binding.viewPager)
    }

    override fun onBackPressed() {
        AdsInterstitial.instance?.showInterstitialAd(
            this@ImagePreviewActivity,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    finish()
                }
            })

    }

    override fun onResume() {
        super.onResume()
//      showBannerAdsSecond()
    }
}
