package com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.widget.Toast
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS
import com.deep.infotech.atm_card_wallet.Ads.NetworkConnectedCheck.isConnected
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityChangePasswordDoneBinding
import com.deep.infotech.atm_card_wallet.maniya.ui.TESTMainActivityManiya
import com.deep.infotech.atm_card_wallet.maniya.ui.BaseActivity

class ChangePasswordDoneActivity : BaseActivity() {

    private lateinit var binding: ActivityChangePasswordDoneBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChangePasswordDoneBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()

        binding.ivDone.setOnClickListener {
            if (isConnected(this@ChangePasswordDoneActivity))
            {
                Handler().postDelayed({
                   /* if (getSharedPreferences("language", 0).getBoolean("isFirstRun", true)) {
                        startActivity(Intent(this, LanguageActivity::class.java))
                        finish()
                    } else*//* if (AdsIDS.start_screen_show) {
                        startActivity(Intent(this, StartActivity::class.java))
                        finish()
                    } else {*/
                        startActivity(Intent(this, TESTMainActivityManiya::class.java))
                        finish()
                   /* }*/
                }, 1000)
            } else {
                Toast.makeText(
                    this@ChangePasswordDoneActivity,
                    getString(R.string.please_check_your_internet_connection),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}