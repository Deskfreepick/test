package com.deep.infotech.atm_card_wallet.maniya.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.deep.infotech.atm_card_wallet.databinding.ItemNavCatlabManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LabelDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya

class LabelsNavigationAdapter(
     val context: Context,
     val items: List<LabelDataManiya>,
     val onItemClick: (LabelDataManiya, Int) -> Unit
) :
    RecyclerView.Adapter<LabelsNavigationAdapter.ViewHolder>() {
    class ViewHolder(val binding: ItemNavCatlabManiyaBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemNavCatlabManiyaBinding.inflate(LayoutInflater.from(context), parent, false)
        return ViewHolder(binding)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]

        with(holder.binding) {
            ivNavItem.visibility = View.GONE
            rlLabel.visibility = View.VISIBLE

            ivBlur.imageTintList = ColorStateList.valueOf(item.color)
            ivBlur.alpha = 0.1f

            cvLabel.imageTintList = ColorStateList.valueOf(item.color)
            tvNavItem.text = item.name

            val dbHelper = DatabaseHelperManiya(context)
            val dataFetchFunctions = listOf(
                { dbHelper.fetchLicensesByLabelID(item.id).size },
                { dbHelper.fetchPassportData().size },
                { dbHelper.fetchIDCardData().size },
                { dbHelper.fetchResidenceCardData().size },
                { dbHelper.fetchPaymentData().size },
                { dbHelper.fetchGiftData().size },
                { dbHelper.fetchLoyaltyData().size },
                { dbHelper.fetchMemberShipData().size },
                { dbHelper.fetchMedicalData().size },
                { dbHelper.fetchHealthData().size },
                { dbHelper.fetchBirthData().size },
                { dbHelper.fetchMrgData().size },
                { dbHelper.fetchSIMData().size },
                { dbHelper.fetchPasswordData().size },
                { dbHelper.fetchCustomData().size },
                { dbHelper.fetchVehicleData().size },
                { dbHelper.fetchAdharData().size },
                { dbHelper.fetchVoterData().size },
                { dbHelper.fetchPANData().size }
            )
            Log.d("++++++LABEL++++++",item.name+"--->"+dataFetchFunctions.sumOf { it() });
            tvNavCount.text = dataFetchFunctions.sumOf { it() }.toString()

        }


        holder.itemView.setOnClickListener { v: View? ->
            onItemClick(item, position)
        }

    }

    override fun getItemCount(): Int {
        return items.size
    }

}