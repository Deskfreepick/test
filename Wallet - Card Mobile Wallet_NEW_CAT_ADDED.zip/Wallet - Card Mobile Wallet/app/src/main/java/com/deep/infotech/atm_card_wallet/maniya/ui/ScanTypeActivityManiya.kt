package com.deep.infotech.atm_card_wallet.maniya.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityScantypeManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya


class ScanTypeActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityScantypeManiyaBinding

    private var categoryName: String = "Custom"
    private var categoryId: Long = 15

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScantypeManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        getIntentData()
    }

    @SuppressLint("SetTextI18n")
    fun getIntentData() {
        categoryName = intent.getStringExtra("category_name") ?: resources.getString(R.string.custom_cat_maniya)
        categoryId = intent.getLongExtra("category_id", 15)

        binding.tvScanCategory.text = categoryName // Toolbar Title
        binding.tvScanText.text = binding.tvScanText.text.toString()+" "+categoryName
       /* binding.tvScanTypeText.text = categoryName*/
        binding.tvScan.text = getString(R.string.scan) + " " + categoryName

        // Fetch category data safely
        val databaseHelper = DatabaseHelperManiya(this@ScanTypeActivityManiya)
        val categoriesData = databaseHelper.getSingleCategoryByID(categoryId)

        // Check if categoriesData is null or empty
        if (!categoriesData.isNullOrEmpty()) {
            val iconName = categoriesData[0].icon
            val resourceId = resources.getIdentifier(iconName, "drawable", packageName)

            if (resourceId != 0) {
                binding.ivScanType.setImageResource(resourceId)
            }
        }
    }

    fun onBackClick(view: View) {

        AdsInterstitial.instance?.showInterstitialAd(
            this@ScanTypeActivityManiya,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    onBackPressed()
                }
            })
    }

    fun onCameraScanClick(view: View) {
              val intent = Intent(this@ScanTypeActivityManiya, ScanCardActivity::class.java)
               intent.putExtra("category_name", categoryName)
               intent.putExtra("category_id", categoryId)
               intent.putExtra("isCamera", true)
               startActivity(intent)
            finish()
    }
    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.v("+++++", "onActivityResult($requestCode, $resultCode, $data)")
    }

    fun onPhotoScanClick(view: View) {
        val intent = Intent(this@ScanTypeActivityManiya, ScanCardActivity::class.java)
        intent.putExtra("category_name", categoryName)
        intent.putExtra("category_id", categoryId)
        intent.putExtra("isCamera", false)
        startActivity(intent)
        finish()
    }

    fun onSkipScanClick(view: View) {
        startActivity(Intent(this@ScanTypeActivityManiya, CustomActivityManiya::class.java)
            .putExtra("categoryName",categoryName)
            .putExtra("categoryID",categoryId)
        )
        finish()
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }
}




