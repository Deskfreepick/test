package com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData

import android.content.Context
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LicenseViewModel : ViewModel() {

    val detectedBlocks: MutableList<String> = ArrayList()
    val expiryBlocks: MutableList<String> = ArrayList()
    val futureBlocks: MutableList<String> = ArrayList()

    var expDate: String = ""
    var issueDate: String = ""
    var d_o_b: String = ""
    var fullName: String = ""
    var contactNumber: String = ""
    var parentsName: String = ""
    var gender: String = ""
    var bloodGroup: String = ""
    var licenceNo: String = ""
    var issueCountry: String = ""
    var issueAuthority: String = ""
    var regAddress: String = ""
    var classs: String = ""

    val DATE_REGEX: String = """^(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$|^(0?[1-9]|[12][0-9]|3[01])([/-])(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$"""

    val restrictedKeywords = listOf(
        "platinu", "platinum", "gold", "black", "classic", "silver", "titanium",
        "bank", "credit", "debit", "atm", "transaction", "international", "card",
        "paypal", "money", "e-commerce", "charge", "visa", "mastercard", "american express",
        "discover", "jcb", "diners club", "unionpay", "maestro", "rupay", "laser",
        "china unionpay,payment", "valid", "from", "thru", "validity", "birthdate",
        "dob", "authorized", "signature", "licence", "idcard", "vehical",
        "name", "son","of","wife","daughter",
        "blood","group",
        "licence","card","vehicales","state","drive","no","yes","n/a","ID",
        "health","hospital",
        "date","issuedate","birthdate","expiryDate",
    )


    val countryPattern= Regex("(?i)^(Afghanistan|Albania|Algeria|Andorra|Angola|Antigua and Barbuda|Argentina|Armenia|Australia|Austria|Azerbaijan|Bahamas|Bahrain|Bangladesh|Barbados|Belarus|Belgium|Belize|Benin|Bhutan|Bolivia|Bosnia and Herzegovina|Botswana|Brazil|Brunei|Bulgaria|Burkina Faso|Burundi|Cabo Verde|Cambodia|Cameroon|Canada|Central African Republic|Chad|Chile|China|Colombia|Comoros|Congo (Congo-Brazzaville)|Costa Rica|Croatia|Cuba|Cyprus|Czechia (Czech Republic)|Democratic Republic of the Congo (Congo-Kinshasa)|Denmark|Djibouti|Dominica|Dominican Republic|Ecuador|Egypt|El Salvador|Equatorial Guinea|Eritrea|Estonia|Eswatini|Ethiopia|Fiji|Finland|France|Gabon|Gambia|Georgia|Germany|Ghana|Greece|Grenada|Guatemala|Guinea|Guinea-Bissau|Guyana|Haiti|Honduras|Hungary|Iceland|India|Indonesia|Iran|Iraq|Ireland|Israel|Italy|Jamaica|Japan|Jordan|Kazakhstan|Kenya|Kiribati|Korea, North|Korea, South|Kuwait|Kyrgyzstan|Laos|Latvia|Lebanon|Lesotho|Liberia|Libya|Liechtenstein|Lithuania|Luxembourg|Madagascar|Malawi|Malaysia|Maldives|Mali|Malta|Marshall Islands|Mauritania|Mauritius|Mexico|Micronesia|Moldova|Monaco|Mongolia|Montenegro|Morocco|Mozambique|Myanmar|Burma|Namibia|Nauru|Nepal|Netherlands|New Zealand|Nicaragua|Niger|Nigeria|North Macedonia|Norway|Oman|Pakistan|Palau|Panama|Papua New Guinea|Paraguay|Peru|Philippines|Poland|Portugal|Qatar|Romania|Russia|Rwanda|Saint Kitts and Nevis|Saint Lucia|Saint Vincent and the Grenadines|Samoa|San Marino|Sao Tome and Principe|Saudi Arabia|Senegal|Serbia|Seychelles|Sierra Leone|Singapore|Slovakia|Slovenia|Solomon Islands|Somalia|South Africa|South Sudan|Spain|Sri Lanka|Sudan|Suriname|Sweden|Switzerland|Syria|Taiwan|Tajikistan|Tanzania|Thailand|Timor-Leste|Togo|Tonga|Trinidad and Tobago|Tunisia|Turkey|Turkmenistan|Tuvalu|Uganda|Ukraine|United Arab Emirates|United Kingdom|United States|Uruguay|Uzbekistan|Vanuatu|Vatican City|Venezuela|Vietnam|Yemen|Zambia|Zimbabwe)$")

    val nationalityPattern= Regex("(?i)^(American|Canadian|French|British|Brazilian|Japanese|Pakistani|English|Spanish|Italian|Chinese|German|Mexican|Russian|Indian|Australian|South African|Italian|Dutch|Finnish|Swedish|Norwegian|Swiss|Polish|Portuguese|Greek|Turkish|Irish|Egyptian|Israeli|Belgian|Danish|Austrian|Czech|Hungarian|Romanian|Ukrainian|Slovak|Bulgarian|Serbian|Croatian|Slovenian|Latvian|Estonian|Lithuanian|Latvian|New Zealander|Singaporean|Malaysian|Thai|Indonesian|Filipino|Vietnamese|South Korean|North Korean|Pakistani|Bangladeshi|Nepali|Sri Lankan|Bhutanese|Tanzanian|Kenyan|Ugandan|Nigerian|Ghanaian|Kenyan|Algerian|Moroccan|Libyan|Sudanese|Iraqi|Syrian|Jordanian|Lebanese|Afghan|Kazakh|Turkmen|Kyrgyz|Uzbek|Mongolian|Tajik|Armenian|Georgian|Kazakhstani|Kazakh|Belarusian|Kyrgyzstani|Turkmenistan|Maldivian|Mauritian|Malawian|Somali|Liberian|Congolese|Gabonese|Cameroonian|Chadian|Botswanan|Zambian|Zimbabwean|Namibian|Angolan|Mozambican|Eswatini|Lesotho)\$")
    fun parseDate(dateString: String): Pair<Date?, String>? {
        val dateFormats = arrayOf(
            "MM/dd/yyyy",
            "dd/MM/yyyy",
            "yyyy/MM/dd",
            "MM/dd/yy",
            "yyyy-MM-dd",
            "MM-dd-yyyy",
            "dd-MM-yyyy",
            "M-dd-yyyy",
            "yyyy.MM.dd",
            "dd.MM.yyyy",
            "MM.dd.yyyy",
            "MM-yy",
            "MM/yyyy",
            "MM/yy"
        )
        for (format in dateFormats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.getDefault())
                val date = sdf.parse(dateString)
                if (date != null) {
                    return Pair(date, format)
                }
            } catch (e: Exception) {

            }
        }
        return null
    }

    fun findMinMaxDates() {
        var minDate: Date? = null
        var maxDate: Date? = null
        var minDateFormat: String? = null
        var maxDateFormat: String? = null

        for (dateString in detectedBlocks) {
            val result = parseDate(dateString)
            if (result != null) {
                val date = result.first
                val format = result.second


                if (minDate == null || date!!.before(minDate)) {
                    minDate = date
                    minDateFormat = format
                }


                if (maxDate == null || date!!.after(maxDate)) {
                    maxDate = date
                    maxDateFormat = format
                }
            }
        }

        val parts = minDate.toString().split("/")
        if(parts.size==2){

        var year = parts[1].trim()

        var mDate = year.replace("0", "")
        if (mDate.isNotEmpty()&& mDate.length>=2) {
            if (!isExpired(minDate)) {
                expDate = formatDate(minDate, minDateFormat).toString()
            } else {
                issueDate = formatDate(minDate, minDateFormat).toString()
            }
        }}

        val parts2 = maxDate.toString().split("/")
        if(parts2.size==2){
            val month = parts2[0].padStart(2, '0')
            var year = parts2[1].trim()

            var mxDate = year.replace("0", "")

        if (mxDate.isNotEmpty()&& mxDate.length>=2) {
            if (!isExpired(maxDate)) {
                expDate = formatDate(maxDate, maxDateFormat).toString()
            } else {
                issueDate = formatDate(maxDate, maxDateFormat).toString()
            }
        }}

        println("expDate Date:++++ $expDate")
        println("issueDate Date:++++ $issueDate ")

        val minDateString = formatDate(minDate, minDateFormat)
        val maxDateString = formatDate(maxDate, maxDateFormat)

        println("Min Date+++: $minDateString ")
        println("Max Date++++: $maxDateString")

    }

    fun formatDate(date: Date?, format: String?): String? {
        if (date == null || format == null) return null
        val sdf = SimpleDateFormat(format, Locale.getDefault())
        return sdf.format(date)
    }

    fun checkFullName(cardholderName: String) {
        if (restrictedKeywords.any { cardholderName.contains(it, ignoreCase = true) }) return
        val cleanHolderName = cardholderName.trim()
        if (cleanHolderName.isNotEmpty() && cleanHolderName.length > 3)
        {
            val fullNamePattern = Regex("\\b[A-Za-z][a-zA-Z]+(?: [A-Za-z][a-zA-Z]+)*\\b")
            if (fullNamePattern.matches(cleanHolderName)) {
                fullName = cardholderName
                Log.e("Licence+++FullName---+++", "cardholderName: $fullName")
            }
        }
    }

    fun checkGender(text: String) {
        val genderPattern = Regex("^(?:m|M|male|Male|f|F|female|Female|FEMALE|MALE|Not prefer to say)$")
        if (genderPattern.matches(text)) {
            gender = text
        }
    }

    fun checkCountry(str: String) {
        if (countryPattern.matches(str)) {
            issueCountry = str
            Log.d("Licence+++Country++++", str)
        }
    }
    fun checkAuthority(str: String) {
        if (nationalityPattern.matches(str)) {
            issueAuthority = str
            Log.d("Licence+++Authority++++", str)
        }
    }

    fun checkDrivingLicenceNumber(str: String) {
        val drivinceLicencePattern = Regex("^[A-Z]{2}[0-9]{2}[0-9]{4}((19|20)[0-9]{2})[0-9]{7}\$")
            val trimmedStr = str.trim()
        if (drivinceLicencePattern.matches(trimmedStr)) {
            licenceNo = str
            Log.d("Licence+++drivingLicenceNo++++", str)
        }
    }
    fun checkBloodGroup(str: String) {
        val bloodGroupPattern = Regex("^(A|B|AB|O)[+-]$")
        if (bloodGroupPattern.matches(str)) {
            bloodGroup = str
            Log.d("Licence+++BloodGroup++++", str)
        }
    }

    fun isExpired(date: Date?): Boolean {
        val currentDate = Date()
        return date?.before(currentDate) ?: false
    }

    fun isFutureDate(dateString: String) {
        if( !isExpired(dateString)){
            futureBlocks.add(dateString)
        }
    }

    fun isExpired(dateString: String): Boolean {
        val dateFormats = listOf(
            "MM-yy",
            "MM/yyyy",
            "MM-dd-yyyy",
            "M-dd-yyyy",
            "M-dd-yy",
            "MM/dd/yy",
            "dd/MM/yyyy"
        )

        val currentDate = Date()

        for (format in dateFormats) {
            try {
                val dateFormat = SimpleDateFormat(format, Locale.getDefault())
                dateFormat.isLenient = false
                val parsedDate = dateFormat.parse(dateString)

                if (parsedDate != null) {
                    return parsedDate.before(currentDate)
                }
            } catch (e: Exception) {
                continue
            }
        }
        return false

    }

    fun checkDateFormat(block: String) {
      /*  if (Regex(DATE_REGEX).matches(block)) {
            detectedBlocks.add(block)}*/

        if (Regex(DATE_REGEX).matches(block)) {
            detectedBlocks.add(block)
            isFutureDate(block)
            if( isExpired(block)){
                expiryBlocks.add(block)
            }
        }
    }
    fun checkBirthDateFormat(block: String) {
        if (Regex(DATE_REGEX).matches(block)) {
            d_o_b= block
            Log.d("Licence+++DOBDate++++", d_o_b.toString())
        }
    }


     fun checkIssueTrimDate(blockTextLowerCase: String) {
        val substring = blockTextLowerCase.substringAfter(blockTextLowerCase, "").trim()
        issueDate = Regex(DATE_REGEX).find(substring)?.value.toString()

    }
     fun checkDOBTrimDate(blockTextLowerCase: String) {
        val substring = blockTextLowerCase.substringAfter(blockTextLowerCase, "").trim()
        d_o_b = Regex(DATE_REGEX).find(substring)?.value.toString()

    }
    fun checkExpiryTrimDate(blockTextLowerCase: String) {
        val substring = blockTextLowerCase.substringAfter(blockTextLowerCase, "").trim()
        expDate = Regex(DATE_REGEX).find(substring)?.value.toString()

    }
    fun checkClassFormate(block: String) {
        if (Regex("^[A-Za-z]$").matches(block)) {
            classs= block
        }
    }
    fun checkExpiryDateFormat(block: String) {
        if (Regex(DATE_REGEX).matches(block)) {
            expDate= block
            Log.d("Licence+++ExpiryDate++++", expDate.toString())
        }
    }
    fun checkIssueDateFormat(block: String) {
        if (Regex(DATE_REGEX).matches(block)) {
            issueDate= block
            Log.d("Licence+++IssueDate++++", issueDate.toString())
        }
    }
    fun checkParentsName(cardholderName: String) {
        if (restrictedKeywords.any { cardholderName.contains(it, ignoreCase = true) }) return
        val cleanHolderName = cardholderName.trim()
        if (cleanHolderName.isNotEmpty() && cleanHolderName.length > 1) {
            val fullNamePattern = Regex("^[A-Za-z]+(?: [A-Za-z]+)*$")
            if (fullNamePattern.matches(cleanHolderName)) {
                parentsName = cardholderName
                Log.e("Licence+++parentsName---+++", "parentsName: $parentsName")
            }
        }
    }


    fun insertInDB(
        context: Context,
        stringFront: String,
        stringBack: String
    ) {
        val licenseCard = LicenseScanDataManiya(
            documentNumber = licenceNo.toString(),
            issueDate = issueDate.toString(),
            expiryDate = expDate.toString(),
            dob = d_o_b.toString(),
            fullName = fullName.toString(),
            personamNumber = contactNumber.toString(),
            issueCountry = issueCountry.toString(),
            issueAuthority = issueAuthority.toString(),
            regAddress = regAddress.toString(),
            label = DatabaseHelperManiya(context).getLabelDao().queryForId(0),
            appearanceColor = ContextCompat.getColor(context, R.color.appreance),
            category = DatabaseHelperManiya(context).getCategoryDao().queryForId(1),
            frontCardImage = stringFront,
            backCardImage = stringBack,
            isLock = false,
            isFav = false,
            isDelete = true,
            isArchive = false
        )
        DatabaseHelperManiya(context).getLicenceCardDao().createOrUpdate(licenseCard)
    }
}


