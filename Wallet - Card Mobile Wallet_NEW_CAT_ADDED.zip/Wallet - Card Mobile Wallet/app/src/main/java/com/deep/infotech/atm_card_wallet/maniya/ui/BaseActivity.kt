package com.deep.infotech.atm_card_wallet.maniya.ui

import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS
import com.deep.infotech.atm_card_wallet.Ads.NativeAds
import com.deep.infotech.atm_card_wallet.Ads.NativeBanner.NativeAdsBanner
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.DialogExitBinding
import com.deep.infotech.atm_card_wallet.databinding.DialogSuccessBinding
import com.deep.infotech.atm_card_wallet.utils.LocaleHelper
import com.deep.infotech.atm_card_wallet.utils.LogD
import com.deep.infotech.atm_card_wallet.utils.LogE
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.UpdateAvailability
import java.io.File
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

open class BaseActivity : AppCompatActivity() {

    private var appUpdateManager: AppUpdateManager? = null
    private var sTAG = "BaseActivity++++"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        appUpdateManager = AppUpdateManagerFactory.create(this@BaseActivity)

        if (getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE).getString(SELECTED_COUNTRY_KEY, "en").toString() == "ar"
            || getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE).getString(SELECTED_COUNTRY_KEY, "en").toString() == "ur"){
            window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        }else{
            window.decorView.layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

    }

    fun restartApp() {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        intent?.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)
    }
    fun updateWindow() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }


    fun shareIdea()
    {

        val subject = "Idea for Your App "+getString(R.string.app_name)
        val feedbackTemplate = "Dear developers,\n\nI would like to provide the following feedback:\n\n"

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, arrayOf(AdsIDS.share_idea_mail))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, feedbackTemplate)
        }

        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Log.d("shareIdea++++", "No email client found.")

        }
    }

    fun contactAppSupport()
    {
        val subject = getString(R.string.app_name)

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, arrayOf(AdsIDS.contact_support_mail))
            putExtra(Intent.EXTRA_SUBJECT, subject)
        }

        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        } else {
            Log.d("contactAppSupport+++++", "No email client found.")
        }
    }


    fun shareAppToFrnd() {

        val intent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "text/plain"
        }

        val shareText = StringBuilder(resources.getString(R.string.share_app_text1))
        shareText.append(resources.getString(R.string.share_app_text2))
        shareText.append(resources.getString(R.string.share_app_text3))
        val appLink = "https://play.google.com/store/apps/details?id=$packageName"
        intent.putExtra(Intent.EXTRA_TEXT, shareText.toString() + appLink)
        intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))

        startActivity(Intent.createChooser(intent, null))
    }


    fun showShareIntentAll(image1Path: String?, image2Path: String?, stripe: String) {
        val intent = Intent().apply {
            action = Intent.ACTION_SEND_MULTIPLE
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val uris = arrayListOf<Uri>()

        image1Path?.let {
            val file = File(it)
            val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            uris.add(imageUri)
        }

        image2Path?.let {
            val file = File(it)
            val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            uris.add(imageUri)
        }

        if (uris.isNotEmpty()) {
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }

        val shareText = StringBuilder(stripe)
        shareText.append("\n\nDownload our app: https://play.google.com/store/apps/details?id=$packageName")

        intent.putExtra(Intent.EXTRA_TEXT, shareText.toString())
        intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))

        startActivity(Intent.createChooser(intent, "Share Card Details and Images"))
    }
    fun multiShare(imagesPath: List<String>) {
        val intent = Intent().apply {
            action = Intent.ACTION_SEND_MULTIPLE
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        val uris = arrayListOf<Uri>()

        imagesPath?.forEach { item ->
            val file = File(item.toString())
            val imageUri = FileProvider.getUriForFile(this, "$packageName.provider", file)
            uris.add(imageUri)
        }

        if (uris.isNotEmpty()) {
            intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        }

        val shareText = StringBuilder("Hey..")
        shareText.append("\n\nDownload app: https://play.google.com/store/apps/details?id=$packageName")

        intent.putExtra(Intent.EXTRA_TEXT, shareText.toString())
        intent.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.app_name))

        startActivity(Intent.createChooser(intent, "Share Card Details and Images"))
    }

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(LocaleHelper.onAttach(base!!))
    }

    companion object {
        const val SHARED_PREFS_NAME = "MyPrefs"
        const val SELECTED_COUNTRY_KEY = "selected_language"
        const val SELECTED_LANGUAGE_NAME = "selected_language_name"
        private const val IMMEDIATE_APP_UPDATE_REQ_CODE = 123

    }

    fun checkUpdate() {
        appUpdateManager?.appUpdateInfo?.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE &&
                appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)
            ) {
                startUpdateFlow(appUpdateInfo)
            }
        }
    }

    fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onResume() {
        super.onResume()
        appUpdateManager?.appUpdateInfo?.addOnSuccessListener { appUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                startUpdateFlow(appUpdateInfo)
            }
        }
    }

    private fun startUpdateFlow(appUpdateInfo: AppUpdateInfo) {
        try {
            appUpdateManager?.startUpdateFlowForResult(
                appUpdateInfo, AppUpdateType.IMMEDIATE, this, IMMEDIATE_APP_UPDATE_REQ_CODE
            )
        } catch (e: IntentSender.SendIntentException) {
            e.printStackTrace()
        }
    }

    fun moveFile(sourceFileUri:String,isFromCroop:Boolean):String {
        var sourceFile:File
        if(!isFromCroop){
            sourceFile= File(URI(sourceFileUri.toString()))

        }else{
            sourceFile= File(sourceFileUri.toString())

        }
        val fileName = "/wallet_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())+".png"
        val destinationFilePath = getFilesDir().absolutePath+fileName
        val destinationFile = File(destinationFilePath)
        if (sourceFile.exists()) {
            destinationFile.parentFile?.mkdirs()
            if (sourceFile.renameTo(destinationFile)) {
                LogD(sTAG, "File moved successfully!")
                if(sourceFile.exists()){
                    sourceFile.delete()
                }
                return destinationFile.absolutePath
            } else {
                LogD(sTAG, "Failed to move the file.")
                return sourceFile.absolutePath
            }
        } else {
            LogD(sTAG, "Source file does not exist.")
            return sourceFile.absolutePath
        }
    }

    override fun onBackPressed() {
        finish()
    }

    fun rateUS() {
        try {
            startActivity(
                Intent(
                    "android.intent.action.VIEW", Uri.parse("market://details?id=$packageName")
                )
            )
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(
                    "android.intent.action.VIEW",
                    Uri.parse("http://play.google.com/store/apps/details?id=$packageName")
                )
            )
        }
    }

/*    fun showNativeAdsThird() {
        if (AdsIDS.third_ad_show_native) {
            NativeAds.nativeAds.nativeAdsLode(
                this,
                findViewById(R.id.AdsGoogleNative),
                findViewById(R.id.AdsFBNative),
                findViewById(R.id.ShimmerNativeLayout),
                findViewById(R.id.adsRlNative),
                AdsIDS.ad_native_2!!,
                AdsIDS.re_ad_native_2!!,
                AdsIDS.fb_ad_native_2!!
            )
            findViewById<View>(R.id.adsRlNative).visible()
        } else {
            findViewById<View>(R.id.adsRlNative).gone()
        }
    }*/

    fun showNativeAdsSecond() {
        if (AdsIDS.second_ad_show_native) {
            NativeAds.nativeAds.nativeAdsLode(
                this,
                findViewById(R.id.AdsGoogleNative),
                findViewById(R.id.AdsFBNative),
                findViewById(R.id.ShimmerNativeLayout),
                findViewById(R.id.adsRlNative),
                AdsIDS.ad_native_1!!,
                AdsIDS.re_ad_native_1!!,
                AdsIDS.fb_ad_native_1!!
            )
            findViewById<View>(R.id.adsRlNative).visible()
        } else {
            findViewById<View>(R.id.adsRlNative).gone()
        }
    }

/*    fun showNativeAdsFirst() {
        if (AdsIDS.first_activity_ad_show_native) {
            NativeAds.nativeAds.nativeAdsLode(
                this,
                findViewById(R.id.AdsGoogleNative),
                findViewById(R.id.AdsFBNative),
                findViewById(R.id.ShimmerNativeLayout),
                findViewById(R.id.adsRlNative),
                AdsIDS.ad_native!!,
                AdsIDS.re_ad_native!!,
                AdsIDS.fb_ad_native!!
            )
            findViewById<View>(R.id.adsRlNative).visible()
        } else {
            findViewById<View>(R.id.adsRlNative).gone()
        }
    }*/

    fun showNativeBannerAdsSecond() {
        if (AdsIDS.second_ad_show_native) {
            NativeAdsBanner.nativeAdsBanner.nativeAdsLode(
                this,
                findViewById(R.id.AdsGoogleNative),
                findViewById(R.id.AdsFBNative),
                findViewById(R.id.ShimmerNativeLayout),
                findViewById(R.id.adsRlNative),
                AdsIDS.ad_native_1!!,
                AdsIDS.re_ad_native_1!!,
                AdsIDS.fb_ad_native_1!!
            )
            findViewById<View>(R.id.adsRlNative).visible()
        } else {
            findViewById<View>(R.id.adsRlNative).gone()
        }
    }

  /*  fun showNativeBannerAdsFirst() {
        if (AdsIDS.first_activity_ad_show_native) {
            NativeAdsBanner.nativeAdsBanner.nativeAdsLode(
                this,
                findViewById(R.id.AdsGoogleNative),
                findViewById(R.id.AdsFBNative),
                findViewById(R.id.ShimmerNativeLayout),
                findViewById(R.id.adsRlNative),
                AdsIDS.ad_native!!,
                AdsIDS.re_ad_native!!,
                AdsIDS.fb_ad_native!!
            )
            findViewById<View>(R.id.adsRlNative).visible()
        } else {
            findViewById<View>(R.id.adsRlNative).gone()
        }
    }*/

   /* fun showNativeBannerAdsThird() {
        if (AdsIDS.third_ad_show_native) {
            NativeAdsBanner.nativeAdsBanner.nativeAdsLode(
                this,
                findViewById(R.id.AdsGoogleNative),
                findViewById(R.id.AdsFBNative),
                findViewById(R.id.ShimmerNativeLayout),
                findViewById(R.id.adsRlNative),
                AdsIDS.ad_native_2!!,
                AdsIDS.re_ad_native_2!!,
                AdsIDS.fb_ad_native_2!!
            )
            findViewById<View>(R.id.adsRlNative).visible()
        } else {
            findViewById<View>(R.id.adsRlNative).gone()
        }
    }*/

    fun dialogExit() {
        val binding = DialogExitBinding.inflate(LayoutInflater.from(this))
        val dialog = Dialog(this)
        dialog.setContentView(binding.root)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(0))

        binding.llCancel.setOnClickListener {
            dialog.dismiss()
        }

        binding.llExit.setOnClickListener {
            finishAffinity()
            dialog.dismiss()
        }
        dialog.show()
    }

    fun dialogPasswordUpdated() {
        val binding = DialogSuccessBinding.inflate(LayoutInflater.from(this))
        val dialog = Dialog(this)
        dialog.setContentView(binding.root)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(0))

        Handler(Looper.getMainLooper()).postDelayed({
            dialog.dismiss()
            restartApp()
        }, 1000)
        dialog.show()
    }
    fun shareCardManiya() {
        val shareText = ""
     /*   val shareText = """
            1. ${getString(R.string.last_negative_item)}  :-  ${Credit_Score_Sec.st1}
            2. ${getString(R.string.count_following_accounts)}:
                1. ${getString(R.string.credit_cards)} :- ${Credit_Score_Sec.st2}
                2. ${getString(R.string.mortgages)} :- ${Credit_Score_Sec.st3}
                3. ${getString(R.string.retail_finances)} :- ${Credit_Score_Sec.st4}
                4. ${getString(R.string.auto_loans)} :- ${Credit_Score_Sec.st5}
                5. ${getString(R.string.student_loans)} :- ${Credit_Score_Sec.st6}
                6. ${getString(R.string.other_loans)} :- ${Credit_Score_Sec.st7}
            3. ${getString(R.string.all_credit_limits)}  :-  ${Credit_Score_Sec.st8}
            4. ${getString(R.string.recent_balances)}  :-  ${Credit_Score_Sec.st9}
            5. ${getString(R.string.apply_credit)}  :-  ${Credit_Score_Sec.f10}
            6. ${getString(R.string.first_open_oldest_active)}  :-  ${Credit_Score_Sec.f11}
            7. ${getString(R.string.your_score)}  :-  ${Data_Keepe_Credit.getInstance().score}
        """.trimIndent()*/

        Intent(Intent.ACTION_SEND).apply {
            putExtra(Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
            startActivity(Intent.createChooser(this, null))
        }
    }



    fun getCategoryTitle(categoryID:Long):String {
    var currentCategory:String
        when (categoryID)
        {
            1L -> currentCategory = resources.getString(R.string.driver_cat_maniya)
            2L -> currentCategory = resources.getString(R.string.passport_cat_maniya)
            3L -> currentCategory = resources.getString(R.string.identity_cat_maniya)
            4L -> currentCategory = resources.getString(R.string.residence_cat_maniya)
            5L -> currentCategory = resources.getString(R.string.pay_cat_maniya)
            6L -> currentCategory = resources.getString(R.string.gift_cat_maniya)
            7L ->currentCategory = resources.getString(R.string.loyal_cat_maniya)
            8L ->currentCategory = resources.getString(R.string.member_cat_maniya)
            9L ->currentCategory = resources.getString(R.string.medical_cat_maniya)
            10L ->currentCategory = resources.getString(R.string.health_cat_maniya)
            11L ->currentCategory = resources.getString(R.string.birth_cat_maniya)
            12L ->currentCategory = resources.getString(R.string.mrg_cat_maniya)
            13L -> currentCategory = resources.getString(R.string.sim_cat_maniya)
            14L -> currentCategory = resources.getString(R.string.password_cat_maniya)
            15L ->  currentCategory = resources.getString(R.string.custom_cat_maniya)
            16L ->  currentCategory = resources.getString(R.string.vehicle_cat_maniya)
            17L ->  currentCategory = resources.getString(R.string.adhar_cat_maniya)
            18L ->  currentCategory = resources.getString(R.string.voter_cat_maniya)
            19L ->  currentCategory = resources.getString(R.string.pan_cat_maniya)
            else -> currentCategory=resources.getString(R.string.custom_cat_maniya)
        }

        return  currentCategory

    }


    fun visible() = View.VISIBLE
    fun invisible() = View.INVISIBLE
    fun gone() = View.GONE

    fun View.gone() {
        this.visibility = View.GONE
    }

    fun View.visible() {
        this.visibility = View.VISIBLE
    }

    fun View.inVisible() {
        this.visibility = View.INVISIBLE
    }


    fun Context.toastMsg(message: CharSequence) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()


}