package com.deep.infotech.atm_card_wallet


import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.view.WindowManager
import com.deep.infotech.atm_card_wallet.Ads.ConfigManager
import com.deep.infotech.atm_card_wallet.Ads.NetworkConnectedCheck
import com.deep.infotech.atm_card_wallet.utils.LogD
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.MobileAds
import com.izooto.iZooto


class MyApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Set FLAG_SECURE for prevent SS
  /*      setSecureFlag()*/

       iZooto.initialize(this).build()

        // Initialize Google Mobile Ads
        MobileAds.initialize(this) { initializationStatus ->
            val statusMap = initializationStatus.adapterStatusMap
            statusMap.forEach { (adapterClass, status) ->
                LogD(
                    "MyApplication++++",
                    String.format(
                        "Adapter name: %s, Description: %s, Latency: %d",
                        adapterClass, status.description, status.latency
                    )
                )
            }
        }

        // Initialize Facebook Audience Network
        AudienceNetworkAds.initialize(this)

        // Fetch and store configuration if connected to the network
        val configManager = ConfigManager(this)
        if (NetworkConnectedCheck.isConnected(this)) {
            configManager.fetchAndStoreData()
        }
    }

   /* override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(LocaleHelper.onAttach(base,"en"))
    }*/

    private fun setSecureFlag() {
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
                // Prevent screenshots for each activity
                activity.window.setFlags(
                    WindowManager.LayoutParams.FLAG_SECURE,
                    WindowManager.LayoutParams.FLAG_SECURE
                )
            }

            override fun onActivityStarted(activity: Activity) {}

            override fun onActivityResumed(activity: Activity) {}

            override fun onActivityPaused(activity: Activity) {}

            override fun onActivityStopped(activity: Activity) {}

            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}