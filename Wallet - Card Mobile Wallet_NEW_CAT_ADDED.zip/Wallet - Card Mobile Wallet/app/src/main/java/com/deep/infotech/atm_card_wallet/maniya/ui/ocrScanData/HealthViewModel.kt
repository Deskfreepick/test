package com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData

import android.content.Context
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HealthViewModel : ViewModel() {

    val detectedBlocks: MutableList<String> = ArrayList()

    var fullName: String? = ""
    var documentNumber: String? = ""
    var expiryDate: String? = ""
    var phoneNumber: String? = ""
    var email: String? = ""

    val DATE_REGEX: String = """^(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$|^(0?[1-9]|[12][0-9]|3[01])([/-])(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$"""

    fun parseDate(dateString: String): Pair<Date?, String>? {
        val dateFormats = arrayOf(
            "MM/dd/yyyy",
            "dd/MM/yyyy",
            "yyyy/MM/dd",
            "MM/dd/yy",
            "yyyy-MM-dd",
            "MM-dd-yyyy",
            "dd-MM-yyyy",
            "M-dd-yyyy",
            "yyyy.MM.dd",
            "dd.MM.yyyy",
            "MM.dd.yyyy",
            "MM-yy",
            "MM/yyyy",
            "MM/yy"
        )
        for (format in dateFormats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.getDefault())
                val date = sdf.parse(dateString)
                if (date != null) {
                    return Pair(date, format)
                }
            } catch (e: Exception) {

            }
        }
        return null
    }

    fun findMinMaxDates() {
        var minDate: Date? = null
        var maxDate: Date? = null
        var minDateFormat: String? = null
        var maxDateFormat: String? = null

        for (dateString in detectedBlocks) {
            val result = parseDate(dateString)
            if (result != null) {
                val date = result.first
                val format = result.second


                if (minDate == null || date!!.before(minDate)) {
                    minDate = date
                    minDateFormat = format
                }


                if (maxDate == null || date!!.after(maxDate)) {
                    maxDate = date
                    maxDateFormat = format
                }
            }
        }

        val parts = minDate.toString().split("/")
        if(parts.size==2){

        var year = parts[1].trim()

        var mDate = year.replace("0", "")
        if (mDate.isNotEmpty()&& mDate.length>=2) {
            if (!isExpired(minDate)) {
                expiryDate = formatDate(minDate, minDateFormat)
            } else {
                /*issueDate = formatDate(minDate, minDateFormat)*/
            }
        }}

        val parts2 = maxDate.toString().split("/")
        if(parts2.size==2){
            val month = parts2[0].padStart(2, '0')
            var year = parts2[1].trim()

            var mxDate = year.replace("0", "")

        if (mxDate.isNotEmpty()&& mxDate.length>=2) {
            if (!isExpired(maxDate)) {
                expiryDate = formatDate(maxDate, maxDateFormat)
            } else {
               /* issueDate = formatDate(maxDate, maxDateFormat)*/
            }
        }}

        println("expDate Date:++++ $expiryDate")
/*        println("issueDate Date:++++ $issueDate ")*/

        val minDateString = formatDate(minDate, minDateFormat)
        val maxDateString = formatDate(maxDate, maxDateFormat)

        println("Min Date+++: $minDateString ")
        println("Max Date++++: $maxDateString")

    }

    fun formatDate(date: Date?, format: String?): String? {
        if (date == null || format == null) return null
        val sdf = SimpleDateFormat(format, Locale.getDefault())
        return sdf.format(date)
    }

    fun checkDocumentNumber(str: String) {
        val documentNoPattern = Regex("^[A-Z]{2}[0-9]{2}( |-|)[0-9]{4}((19|20)[0-9]{2})[0-9]{7}$")
        if (documentNoPattern.matches(str)) {
            documentNumber = str
            Log.d("Health+++cardNumber++++", str)
        }
    }

    fun isExpired(date: Date?): Boolean {
        val currentDate = Date()
        return date?.before(currentDate) ?: false
    }
    fun checkDateFormat(block: String) {
        if (Regex(DATE_REGEX).matches(block)) {
            detectedBlocks.add(block)}
    }

    fun insertInDB(
        context: Context,
        stringFront: String,
        stringBack: String
    ) {

        val healthCard =
            com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya(
                fullName = fullName.toString(),
                documentNumber = documentNumber.toString(),
                expiryDate = expiryDate.toString(),
                phoneNumber = phoneNumber.toString(),
                email = email.toString(),
                label = DatabaseHelperManiya(context).getLabelDao().queryForId(0),
                appearanceColor = ContextCompat.getColor(context, R.color.appreance),
                category = DatabaseHelperManiya(context).getCategoryDao().queryForId(9),
                frontCardImage = stringFront,
                backCardImage = stringBack,
                isLock = false,
                isFav = false,
                isDelete = true,
                isArchive = false
            )
        DatabaseHelperManiya(context).getHealthCardDao().createOrUpdate(healthCard)
    }
}


