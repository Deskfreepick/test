package com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen

import android.os.Bundle
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.ui.BaseActivity

class HomeFingerprintActivity : BaseActivity() {

    private var promptInfo: BiometricPrompt.PromptInfo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home_fingerprint)
        updateWindow()
        val biometricManager = BiometricManager.from(this)
        if (biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE) {
            Toast.makeText(
                applicationContext,
                getString(R.string.your_device_does_t_support_fingerprint_scanner),
                Toast.LENGTH_LONG
            ).show()
            finish()
            setResult(0)
            Toast.makeText(applicationContext, getString(R.string.not_working), Toast.LENGTH_LONG).show()
            finish()
            setResult(0)
            Toast.makeText(applicationContext,
                getString(R.string.not_fingerprint_assigned), Toast.LENGTH_LONG)
                .show()
            finish()
        }
        else if (biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE) {
            Toast.makeText(applicationContext, getString(R.string.not_working), Toast.LENGTH_LONG).show()
            finish()
            setResult(0)
            Toast.makeText(applicationContext, getString(R.string.not_fingerprint_assigned), Toast.LENGTH_LONG)
                .show()
            finish()
        }
        else if (biometricManager.canAuthenticate() == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED) {
            Toast.makeText(applicationContext, getString(R.string.not_fingerprint_assigned), Toast.LENGTH_LONG)
                .show()
            finish()
        }
        val biometricPrompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    finish()
                }

                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    Toast.makeText(applicationContext,
                        getString(R.string.login_success), Toast.LENGTH_LONG).show()
                    setResult(-1)
                    finish()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    setResult(0)
                }
            })
        promptInfo = BiometricPrompt.PromptInfo.Builder().setTitle(getString(R.string.app_name))
            .setDescription("Use your Fingerprint to Login")
            .setDeviceCredentialAllowed(true).build()
        biometricPrompt.authenticate(promptInfo!!)
    }
}