package com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya
import jp.wasabeef.blurry.Blurry

class LicenseCardAdapter(
    private val context: Context,
    private var items: MutableList<LicenseScanDataManiya>,
    private var useTwoColumns: Boolean,
    private val onItemClick: (LicenseScanDataManiya, Int) -> Unit,
    private val onItemLongClick: (LicenseScanDataManiya, Int) -> Boolean
) : RecyclerView.Adapter<LicenseCardAdapter.MyViewHolder>() {

    private var filteredItems: List<LicenseScanDataManiya> = items

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvDataNM: TextView = itemView.findViewById(R.id.tvDataNM)
        private val tvDataText: TextView = itemView.findViewById(R.id.tvDataText)
        private val ivData: ImageView = itemView.findViewById(R.id.ivData)

        fun bind(item: LicenseScanDataManiya, position: Int) {

            if(item.fullName.isNotEmpty())
            {
                tvDataNM.text = item.fullName
                tvDataNM.visibility=View.VISIBLE
            }
            else
            {
                tvDataNM.visibility=View.GONE
            }


            if(item.documentNumber.isNotEmpty())
            {
                tvDataText.text = item.documentNumber
                tvDataText.visibility=View.VISIBLE
            }
            else
            {
                tvDataText.visibility=View.GONE
            }


            if (!item.frontCardImage.isNullOrEmpty())
            { if(item.isSensitive){
                Glide.with(ivData.context)
                    .asBitmap()
                    .load(item.frontCardImage)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(/* target = */ object : SimpleTarget<Bitmap>() {
                        override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                            Blurry.with(ivData.context)
                                .from(resource)
                                .into(ivData)
                        }
                    })
            }else{ Glide.with(ivData.context)
                .load(item.frontCardImage)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(ivData) }
            }

        /*    selectionIcon.setImageResource(if (isSelectionMode) R.drawable.round_item_selected else R.drawable.round_item_deselected)*/
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutId = if (useTwoColumns) R.layout.test_item_grid_two else R.layout.test_item_categories_maniya2
        val view = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val item = filteredItems[position]
        holder.bind(item, position)

        holder.itemView.setOnClickListener {
            onItemClick(item, position)
        }

        holder.itemView.setOnLongClickListener {
            onItemLongClick(item, position)
        }
    }

    override fun getItemCount(): Int {
        return if (filteredItems.size > 4) 4 else filteredItems.size
    }

    fun filter(query: String) {
        filteredItems = if (query.isEmpty()) {
            items
        } else {
            items.filter { it.fullName.contains(query, ignoreCase = true) || it.documentNumber.contains(query, ignoreCase = true) }
        }
        updateData(filteredItems)
    }

    @SuppressLint("NotifyDataSetChanged")
    fun updateView(isTwoColumns: Boolean) {
        useTwoColumns = isTwoColumns
        notifyDataSetChanged()
    }

    // Update data in real-time
    fun updateData(newItems: List<LicenseScanDataManiya>) {
        items = newItems.toMutableList()
        Log.e("++++","size---"+items.size)
        filteredItems = items
        notifyDataSetChanged()
    }

    fun toggleProperty(cardId: Long, property: String) {
        val item = filteredItems.find { it.id == cardId }
        item?.let {
            when (property) {
                "fav" -> it.isFav = !it.isFav
                "lock" -> it.isLock = !it.isLock
                "delete" -> it.isDelete = !it.isDelete
                "archive" -> it.isArchive = !it.isArchive
            }
            notifyDataSetChanged() // Refresh the view after toggling the property
        }
    }
}
