package com.deep.infotech.atm_card_wallet.maniya.ui

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.hardware.fingerprint.FingerprintManager
import android.os.Build
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.View
import android.widget.Toast
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityPrivacySecurityManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.CreatePinActivity
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.HomeFingerprintActivity
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.OldPinLockActivity
import java.io.File


class PrivacySecurityActivityManiya : BaseActivity() {
    private lateinit var binding: ActivityPrivacySecurityManiyaBinding
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor


    @SuppressLint("UsableSpace")
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityPrivacySecurityManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        editor = sharedPreferences.edit()
        init()

        val formattedSize = formatSize(getTotalStorageUsed())

        println("Total Storage Used:+++ $formattedSize")

    }


    private fun getTotalStorageUsed(): Long {
        val appDataDir = filesDir
        val dataDir = dataDir
        val cacheDir = cacheDir
        val databasesDir = File(filesDir.parent, "databases")
        val sharedPrefsDir = File(filesDir.parent, "shared_prefs")


        println("appDataDir Storage Used:+++"+formatSize(getDirectorySize(appDataDir)))
        println("cacheDir Storage Used:+++"+formatSize(getDirectorySize(cacheDir)))
        println("DataDir Storage Used:+++"+formatSize(getDirectorySize(dataDir)))
        println("DatabaseDir Storage Used:+++"+formatSize(getDirectorySize(databasesDir)))
        println("sharedPrefsDir Storage Used:+++"+formatSize(getDirectorySize(sharedPrefsDir)))


        val totalStorageUsed = getDirectorySize(filesDir) +
                getDirectorySize(appDataDir) +
                getDirectorySize(dataDir) +
                getDirectorySize(cacheDir)+
                getDirectorySize(databasesDir) +
                getDirectorySize(sharedPrefsDir)


        return totalStorageUsed
    }

    private fun getDirectorySize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var size: Long = 0
        val files = dir.listFiles()
        if (files != null) {
            for (file in files) {
                size += if (file.isDirectory) {
                    getDirectorySize(file)
                } else {
                    file.length()
                }
            }
        }
        return size
    }

    private fun formatSize(sizeInBytes: Long): String {
        if (sizeInBytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(sizeInBytes.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format("%.1f %s", sizeInBytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }


    @SuppressLint("DefaultLocale")
    fun formatSize(size: Int): String {
        if (size <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
        val digitGroups = (Math.log10(size.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format("%.1f %s", (size / 1024) / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }


    private fun init() {
        checkFingureLockDeviceStatus()
        setLockStatus()
        binding.switchFingureLock.setOnCheckedChangeListener { _, isChecked ->
            binding.switchFingureLock.isChecked = isChecked
            if (isChecked) {
                startActivityForResult(Intent(this, HomeFingerprintActivity::class.java), 4)
            } else {
                editor.putBoolean("fp", false).commit()
            }
        }
        binding.switchScreenLock.setOnCheckedChangeListener { _, isChecked ->
            binding.switchScreenLock.isChecked = isChecked
            editor.putBoolean("appLockIsCheck", isChecked).commit()
        }
    }
    private fun checkFingureLockDeviceStatus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val fingerprintManager = getSystemService(Context.FINGERPRINT_SERVICE) as? FingerprintManager
            if (fingerprintManager != null && fingerprintManager.isHardwareDetected && fingerprintManager.hasEnrolledFingerprints()) {
                binding.llFingureLock.visible()
            } else {
                binding.llFingureLock.gone()
            }
        } else {
            binding.llFingureLock.gone()
        }
    }

    private fun setLockStatus(){
        binding.switchScreenLock.isChecked = sharedPreferences.getBoolean("appLockIsCheck", false)
        binding.switchFingureLock.isChecked = sharedPreferences.getBoolean("fp", false)
    }

    fun onBackClick(view: View) {
        AdsInterstitial.instance?.showInterstitialAd(
            this@PrivacySecurityActivityManiya,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    onBackPressed()
                }
            })
    }

    fun onClickNewLock(view: View) {

        if (sharedPreferences.getBoolean("appLockIsCheck", false)) {

            if (!sharedPreferences.getBoolean("first time", true)) {
                val intent: Intent?
                intent = Intent(this@PrivacySecurityActivityManiya, com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.OldPinLockActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                intent.putExtra("pkgname", this@PrivacySecurityActivityManiya.packageName)
                startActivity(intent)
            } else {
                this@PrivacySecurityActivityManiya.startActivity(
                    Intent(
                        this@PrivacySecurityActivityManiya, CreatePinActivity::class.java
                    )
                )
            }
        } else {
            Toast.makeText(
                this,
                getString(R.string.please_turn_on_app_lock), Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 4 && resultCode == -1) {
            editor.putBoolean("fp", true).commit()
             Toast.makeText(
                this@PrivacySecurityActivityManiya,
                getString(R.string.fingerprint_lock_set_successfully),
                Toast.LENGTH_SHORT
            ).show()
        } else if (requestCode == 4 && resultCode == 0)
        {
            editor.putBoolean("fp", false).commit()
            Toast.makeText(
                this@PrivacySecurityActivityManiya,
                getString(R.string.failed_to_set_fingerprint_lock),
                Toast.LENGTH_SHORT
            ).show()
        }
        setLockStatus()
    }
}
