package com.deep.infotech.atm_card_wallet.maniya.ui

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.GravityCompat
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.deep.infotech.atm_card_wallet.Ads.AdsIDGoogle
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.BuildConfig
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.adapter.ImagePagerAdapter
import com.deep.infotech.atm_card_wallet.databinding.ActivityMainManiyaBinding
import com.deep.infotech.atm_card_wallet.databinding.DialogRestoreBinding
import com.deep.infotech.atm_card_wallet.databinding.ItemLongclickBottomDialogBinding
import com.deep.infotech.atm_card_wallet.databinding.MainMenuBinding
import com.deep.infotech.atm_card_wallet.databinding.NavHeaderManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.model.CardData
import com.deep.infotech.atm_card_wallet.maniya.adapter.CategoriesNavigationAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.LabelsNavigationAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.SearchWalletAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.AdharAdapter
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.BirthAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.CustomAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.GiftAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.HealthAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.IDCardAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.LicenseCardAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.LoyaltyAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.MedicalAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.MembershipAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.MrgAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.PANAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.PassportCardAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.PasswordAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.PaymentAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.ResidenceCardAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.SIMAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.VehicleAdapter
import com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter.VoterAdapter
import com.facebook.ads.AudienceNetworkAds
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.initialization.InitializationStatus
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.takusemba.spotlight.OnSpotlightListener
import com.takusemba.spotlight.OnTargetListener
import com.takusemba.spotlight.Spotlight
import com.takusemba.spotlight.Target
import com.takusemba.spotlight.shape.Circle

class TESTMainActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityMainManiyaBinding
    private lateinit var navHeaderBinding: NavHeaderManiyaBinding
    private lateinit var viewCoordinates: MutableMap<View, Pair<Float, Float>>
    private lateinit var touchBlocker: View
    private lateinit var spotlight: Spotlight
    private lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    private var popupWindow: PopupWindow? = null
    private var llMenuSelect: View? = null
    private var llMenuSelectAll: View? = null
    private var llMenuDeselectAll: View? = null
    private var llMenuDelete: View? = null
    private var llMenuCategory: View? = null
    private var menuCategory: View? = null
    private var ivCategoryCheck: View? = null
    private var menuType: View? = null
    private var ivTypeCheck: View? = null
    private var menuLabel: View? = null
    private var ivLabelCheck: View? = null
    private var menuNoGroup: View? = null
    private var ivNoGroupCheck: View? = null

    private var licenseAdapter: LicenseCardAdapter? = null
    private var passportAdapter: PassportCardAdapter? = null
    private var identityAdapter: IDCardAdapter? = null
    private var residenceAdapter: ResidenceCardAdapter? = null
    private var paymentAdapter: PaymentAdapter? = null
    private var giftAdapter: GiftAdapter? = null
    private var loyaltyAdapter: LoyaltyAdapter? = null
    private var membershipAdapter: MembershipAdapter? = null
    private var medicalAdapter: MedicalAdapter? = null
    private var healthAdapter: HealthAdapter? = null
    private var birthAdapter: BirthAdapter? = null
    private var mrgAdapter: MrgAdapter? = null
    private var simAdapter: SIMAdapter? = null
    private var passwordAdapter: PasswordAdapter? = null
    private var customAdapter: CustomAdapter? = null
    private var navLabelAdapter: LabelsNavigationAdapter? = null
    private var navCategoriesAdapter: CategoriesNavigationAdapter? = null
    private var searchAdapter: SearchWalletAdapter? = null
    private var vehicleAdapter: VehicleAdapter? = null
    private var adharAdapter: AdharAdapter? = null
    private var voterAdapter: VoterAdapter? = null
    private var panAdapter: PANAdapter? = null

    private var licenseRecyclerView: RecyclerView? = null
    private var passportRecyclerView: RecyclerView? = null
    private var identityRecyclerView: RecyclerView? = null
    private var residenceRecyclerView: RecyclerView? = null
    private var paymentRecyclerView: RecyclerView? = null
    private var giftRecyclerView: RecyclerView? = null
    private var loyaltyRecyclerView: RecyclerView? = null
    private var membershipRecyclerView: RecyclerView? = null
    private var medicalRecyclerView: RecyclerView? = null
    private var healthRecyclerView: RecyclerView? = null
    private var birthRecyclerView: RecyclerView? = null
    private var mrgRecyclerView: RecyclerView? = null
    private var simRecyclerView: RecyclerView? = null
    private var passwordRecyclerView: RecyclerView? = null
    private var customRecyclerView: RecyclerView? = null
    private var vehicleRecyclerView: RecyclerView? = null
    private var adharRecyclerView: RecyclerView? = null
    private var voterRecyclerView: RecyclerView? = null
    private var panRecyclerView: RecyclerView? = null

    private val dFilteredCategoriesData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.CategoryDataManiya> =
        mutableListOf()
    private var licenceDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya> =
        mutableListOf()
    private var passportDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PassportScanDataManiya> =
        mutableListOf()
    private var identityDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya> =
        mutableListOf()
    private var residenceDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.ResidentScanDataManiya> =
        mutableListOf()
    private var paymentDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya> =
        mutableListOf()
    private var giftDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.GiftCardScanDataManiya> =
        mutableListOf()
    private var loyaltyDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.LoyaltyCardScanDataManiya> =
        mutableListOf()
    private var membershipDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MemberShipCardScanDataManiya> =
        mutableListOf()
    private var medicalDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MedicalCardScanDataManiya> =
        mutableListOf()
    private var healthDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya> =
        mutableListOf()
    private var birthDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.BirthCardScanDataManiya> =
        mutableListOf()
    private var mrgDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MrgCardScanDataManiya> =
        mutableListOf()
    private var simDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.SIMCardScanDataManiya> =
        mutableListOf()
    private var passwordDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PasswordCardScanDataManiya> =
        mutableListOf()
    private var customDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.CustomScanDataManiya> =
        mutableListOf()
    private var vehicleDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.VehicleScanDataManiya> =
        mutableListOf()
    private var adharDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.AdharScanDataManiya> =
        mutableListOf()
    private var voterDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.VoterScanDataManiya> =
        mutableListOf()
    private var panDataList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PANScanDataManiya> =
        mutableListOf()

    private var walletCount = 0
    private var deletedCount = 0
    private var favouritedCount = 0
    private var lockedCount = 0
    private var archivedCount = 0
    private var currentPosition = 0

    private var sharedPreferences: SharedPreferences? = null
    private var preferences: SharedPreferences? = null

    private var isSpotlightActive = false
    private var isFromNavMenu = false
    private var useTwoColumns = false
    private var isNoDataView = false
    private var isUnlockDone = false

    private var combineList: MutableList<CardData> = mutableListOf()
    private val targets = ArrayList<Target>()
    private val pagerImagesList = mutableListOf<Drawable>()
    private val loopedList = mutableListOf<Drawable>()
    private var handler = Handler(Looper.getMainLooper())

    private var title: String = ""
    private var currentType: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainManiyaBinding.inflate(layoutInflater)
        val navigationView = binding.navigationView
        val headerView = navigationView.getHeaderView(0)
        navHeaderBinding = NavHeaderManiyaBinding.bind(headerView)
        setContentView(binding.root)
        updateWindow()
        getSharedPreferencesValue()
        currentType = "none"

        activityResultLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                Log.d("ActivityResultContracts+++++", "------")
                /*   isUnlockDone = result.data?.getBooleanExtra("isUnlockDone", false)!!*/
                initView(true)
            }
        }
        //   showSpotLightsOnViews()
        adsInit()
        checkUpdate()
        setupViewPager()
        initView(false)
    }

    private fun getSharedPreferencesValue() {
        sharedPreferences = getSharedPreferences("isFirst", Context.MODE_PRIVATE)
        preferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        getSharedPreferences("openApp", 0).edit().putBoolean("isFirstRun", false).apply()
    }


    override fun onPause() {
        super.onPause()
        handler.removeCallbacksAndMessages(null)
    }

    private fun setupViewPager() {
        pagerImagesList.add(resources.getDrawable(R.drawable.pager1))
        pagerImagesList.add(resources.getDrawable(R.drawable.pager2))
        pagerImagesList.add(resources.getDrawable(R.drawable.pager3))
        pagerImagesList.add(resources.getDrawable(R.drawable.pager4))
        pagerImagesList.add(resources.getDrawable(R.drawable.pager5))

        loopedList.addAll(pagerImagesList)
        loopedList.addAll(pagerImagesList)
        loopedList.addAll(pagerImagesList)
        loopedList.addAll(pagerImagesList)
        loopedList.addAll(pagerImagesList)

        binding.slideViewPager.adapter = ImagePagerAdapter(loopedList)

        startAutoSlide()
    }

    private fun startAutoSlide() {
        val autoSlideRunnable = object : Runnable {
            override fun run() {
                if (currentPosition == loopedList.size - 1) {
                    currentPosition = 0
                } else {
                    currentPosition++
                }
                binding.slideViewPager.setCurrentItem(currentPosition, true)

                handler.postDelayed(this, 2000)
            }
        }
        handler.postDelayed(autoSlideRunnable, 500)
    }

    private fun showSpotLightsOnViews() {
        if (getSharedPreferences("showCase", 0).getBoolean("isShowCaseMode", true)) {

            viewCoordinates = mutableMapOf()

            binding.ivSearch.viewTreeObserver.addOnGlobalLayoutListener(object :
                ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    val location = IntArray(2)
                    binding.ivSearch.getLocationOnScreen(location)
                    val layoutParams = binding.ivSearch.layoutParams as ViewGroup.MarginLayoutParams
                    val centerX =
                        location[0].toFloat() + layoutParams.marginStart + binding.ivSearch.width / 2f
                    val centerY =
                        location[1].toFloat() + layoutParams.topMargin + binding.ivSearch.height / 2f
                    viewCoordinates[binding.ivSearch] = centerX to centerY
                    Log.d("ViewPosition", "ivSearch - X: ${location[0]}, Y: ${location[1]}")
                    binding.ivSearch.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    if (viewCoordinates.size == 4) {
                        setupShowcaseTargets()
                    }
                }
            })

            binding.ivMenu.viewTreeObserver.addOnGlobalLayoutListener(object :
                ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    val location = IntArray(2)
                    binding.ivMenu.getLocationOnScreen(location)
                    val layoutParams = binding.ivMenu.layoutParams as ViewGroup.MarginLayoutParams
                    val centerX =
                        location[0].toFloat() + layoutParams.marginEnd + binding.ivMenu.width / 2f
                    val centerY =
                        location[1].toFloat() + layoutParams.topMargin + binding.ivMenu.height / 2f
                    viewCoordinates[binding.ivMenu] = centerX to centerY
                    Log.d("ViewPosition", "ivMenu - X: ${location[0]}, Y: ${location[1]}")
                    binding.ivMenu.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    if (viewCoordinates.size == 4) setupShowcaseTargets()
                }
            })

            binding.ivDrawerIcon.viewTreeObserver.addOnGlobalLayoutListener(object :
                ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    val location = IntArray(2)
                    binding.ivDrawerIcon.getLocationOnScreen(location)
                    val layoutParams =
                        binding.ivDrawerIcon.layoutParams as ViewGroup.MarginLayoutParams
                    val centerX =
                        location[0].toFloat() + layoutParams.marginStart + binding.ivDrawerIcon.width / 2f
                    val centerY =
                        location[1].toFloat() + layoutParams.topMargin + binding.ivDrawerIcon.height / 2f
                    viewCoordinates[binding.ivDrawerIcon] = centerX to centerY
                    Log.d("ViewPosition", "ivDrawerIcon - X: ${location[0]}, Y: ${location[1]}")
                    binding.ivMenu.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    if (viewCoordinates.size == 4) setupShowcaseTargets()
                }
            })

            binding.fabCategories.viewTreeObserver.addOnGlobalLayoutListener(object :
                ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    val location = IntArray(2)
                    binding.fabCategories.getLocationOnScreen(location)
                    val layoutParams =
                        binding.fabCategories.layoutParams as ViewGroup.MarginLayoutParams
                    val centerX =
                        location[0].toFloat() + layoutParams.marginEnd + binding.fabCategories.width / 2f
                    val centerY =
                        location[1].toFloat() + layoutParams.topMargin + binding.fabCategories.height / 2f
                    viewCoordinates[binding.fabCategories] = centerX to centerY
                    Log.d("ViewPosition", "fabCategories - X: ${location[0]}, Y: ${location[1]}")
                    binding.ivMenu.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    if (viewCoordinates.size == 4) setupShowcaseTargets()
                }
            })
        }

    }

    private fun setupShowcaseTargets() {

        val firstRoot = FrameLayout(this)
        val first = layoutInflater.inflate(R.layout.target_main_maniya, firstRoot)
        val firstTarget = Target.Builder()
            .setAnchor(
                viewCoordinates[binding.ivDrawerIcon]?.first ?: 0f,
                (viewCoordinates[binding.ivDrawerIcon]?.second) ?: 0f
            )
            .setShape(Circle(100f))
            .setOverlay(first)
            .setOnTargetListener(object : OnTargetListener {
                override fun onStarted() {
                    first.findViewById<TextView>(R.id.tvTargetTitle).text = "Drawer"
                    first.findViewById<TextView>(R.id.tvTargetDesc).text = "on Click Drawer"
                    first.findViewById<RelativeLayout>(R.id.rlMenuTarget).visible()
                    first.findViewById<RelativeLayout>(R.id.rlMenuTarget).visible()
                    first.findViewById<RelativeLayout>(R.id.rlFabTarget).gone()
                    first.findViewById<LinearLayout>(R.id.llTargetSpaces).inVisible()
                    moveToNextTarget(1500)
                }

                override fun onEnded() {
                }
            })
            .build()
        targets.add(firstTarget)

        val secondTarget = Target.Builder()
            .setAnchor(
                viewCoordinates[binding.ivSearch]?.first ?: 0f,
                viewCoordinates[binding.ivSearch]?.second ?: 0f
            )
            .setShape(Circle(100f))
            .setOverlay(first)
            .setOnTargetListener(object : OnTargetListener {
                override fun onStarted() {
                    first.findViewById<TextView>(R.id.tvTargetTitle).apply {
                        text = "Search"
                        textAlignment = View.TEXT_ALIGNMENT_VIEW_END
                    }
                    first.findViewById<TextView>(R.id.tvTargetDesc).apply {
                        text = "on Click Search"
                        textAlignment = View.TEXT_ALIGNMENT_VIEW_END
                    }

                    first.findViewById<ImageView>(R.id.ivSpaceSearch).visible()
                    first.findViewById<ImageView>(R.id.ivSpaceMenu).inVisible()
                    first.findViewById<LinearLayout>(R.id.llTargetViews).visible()
                    moveToNextTarget(1500)
                }

                override fun onEnded() {
                }
            })
            .build()
        targets.add(secondTarget)

        val thirdTarget = Target.Builder()
            .setAnchor(
                viewCoordinates[binding.ivMenu]?.first ?: 0f,
                viewCoordinates[binding.ivMenu]?.second ?: 0f
            )
            .setShape(Circle(100f))
            .setOverlay(first)
            .setOnTargetListener(object : OnTargetListener {
                override fun onStarted() {
                    first.findViewById<TextView>(R.id.tvTargetTitle).apply {
                        text = "Menu"
                        textAlignment = View.TEXT_ALIGNMENT_VIEW_END
                    }
                    first.findViewById<TextView>(R.id.tvTargetDesc).apply {
                        text = "on Click Menu"
                        textAlignment = View.TEXT_ALIGNMENT_VIEW_END
                    }
                    first.findViewById<ImageView>(R.id.ivSpaceSearch).gone()
                    first.findViewById<ImageView>(R.id.ivSpaceMenu).visible()
                    first.findViewById<LinearLayout>(R.id.llTargetViews).inVisible()
                    moveToNextTarget(1500)
                }

                override fun onEnded() {
                }
            })
            .build()
        targets.add(thirdTarget)

        val fourthTarget = Target.Builder()
            .setAnchor(
                viewCoordinates[binding.fabCategories]?.first ?: 0f,
                viewCoordinates[binding.fabCategories]?.second ?: 0f
            )
            .setShape(Circle(200f))
            .setOverlay(firstRoot)
            .setOnTargetListener(object : OnTargetListener {
                override fun onStarted() {
                    first.findViewById<TextView>(R.id.tvTargetTitle).text = "fabCategories"
                    first.findViewById<TextView>(R.id.tvTargetDesc).text = "on Click fabCategories"
                    first.findViewById<RelativeLayout>(R.id.rlMenuTarget).visibility =
                        View.INVISIBLE
                    first.findViewById<RelativeLayout>(R.id.rlFabTarget).visible()
                    Handler(Looper.getMainLooper()).postDelayed({
                        spotlight.finish()
                        (window.decorView as ViewGroup).removeView(touchBlocker)
                        isSpotlightActive = false
                        getSharedPreferences("showCase", 0).edit()
                            .putBoolean("isShowCaseMode", false).apply()

                    }, 1500)
                }

                override fun onEnded() {
                    spotlight.finish()
                }
            })
            .build()
        targets.add(fourthTarget)

        touchBlocker = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
        }
        (window.decorView as ViewGroup).addView(touchBlocker)

        isSpotlightActive = true

        spotlight = Spotlight.Builder(this@TESTMainActivityManiya)
            .setTargets(targets)
            .setBackgroundColorRes(R.color.spotlightBackground)
            .setDuration(3000L)
            .setAnimation(DecelerateInterpolator(3f))
            .setOnSpotlightListener(object : OnSpotlightListener {
                override fun onStarted() {
                }

                override fun onEnded() {
                }
            })
            .build()

        spotlight.start()
    }

    private fun moveToNextTarget(delayMillis: Long) {
        Handler(Looper.getMainLooper()).postDelayed({
            spotlight.next()  // Transition to the next target
        }, delayMillis)
    }

    private fun adsInit() {
        if (AdsIDGoogle.get_show(this, "fb_show_banner") || AdsIDGoogle.get_show(
                this, "fb_show_native"
            ) || AdsIDGoogle.get_show(this, "fb_show_interstitial")
        ) {
            AudienceNetworkAds.initialize(this)
        } else {
            MobileAds.initialize(this) { initializationStatus: InitializationStatus ->
                initializationStatus.adapterStatusMap.forEach { (adapterClass, status) ->
                    Log.d("AdsInit", "Adapter: $adapterClass, Desc: ${status?.description}")
                }
            }
        }
    }

    private fun initView(isFromResult: Boolean) {

        navHeaderBinding.navVersion.text = BuildConfig.VERSION_NAME
        createMenuPopupWindow()
        setCategoriesDBData()
        // setTESTWalletDataRecyclerView(false, "", false)
        if (currentType.equals("none")) {
            setTESTWalletDataRecyclerView(false, "", false)
        }
        if (currentType.equals("delete")) {
            setTESTWalletDataRecyclerView(
                true,
                resources.getString(R.string.nav_recently_deleted_menu),
                true
            )
        }
        if (currentType.equals("Archive")) {

            setTESTWalletDataRecyclerView(
                true,
                resources.getString(R.string.nav_archived_menu),
                true
            )
        }
        if (currentType.equals("favourite")) {
            setTESTWalletDataRecyclerView(
                true,
                resources.getString(R.string.nav_favourite_menu),
                true
            )
        }
        if (currentType.equals("locked")) {
            setTESTWalletDataRecyclerView(true, resources.getString(R.string.nav_locked_menu), true)
        }

        if (currentType.equals("wallet")) {
            setTESTWalletDataRecyclerView(
                true,
                resources.getString(R.string.nav_wallet_menu),
                false
            )
        }

        setSearchRecyclerView()
        binding.edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(query: CharSequence?, start: Int, before: Int, count: Int) {
                if (query.toString().trim().isNotEmpty()) {
                    binding.scrollview.gone()
                    binding.rvSearchRecyclerView.visible()
                    searchAdapter!!.filter(query.toString())
                } else {
                    binding.scrollview.visible()
                    binding.rvSearchRecyclerView.gone()
                }
            }

            override fun afterTextChanged(s: Editable?) {}
        })
        updateDrawerData()
    }

    fun onNavWalletClick(view: View?) {
        currentType = "wallet"
        setTESTWalletDataRecyclerView(true, resources.getString(R.string.nav_wallet_menu), false)
    }

    fun onNavLockedClick(view: View?) {
        currentType = "locked"
        setTESTWalletDataRecyclerView(true, resources.getString(R.string.nav_locked_menu), true)
    }

    fun onNavFavouriteClick(view: View?) {
        currentType = "favourite"
        setTESTWalletDataRecyclerView(true, resources.getString(R.string.nav_favourite_menu), true)
    }

    fun onNavArchiveClick(view: View?) {
        currentType = "Archive"
        setTESTWalletDataRecyclerView(true, resources.getString(R.string.nav_archived_menu), true)
    }

    fun onNavRDeleteClick(view: View?) {
        currentType = "delete"
        setTESTWalletDataRecyclerView(
            true,
            resources.getString(R.string.nav_recently_deleted_menu),
            true
        )
    }

    private fun setTESTWalletDataRecyclerView(
        isFromNavMenuClick: Boolean,
        title: String,
        isFromADFL: Boolean
    ) {
        combineList.clear()
        useTwoColumns = false
        closeDrawer()
        if (!isFromADFL) {
            dFilteredCategoriesData.clear()
            walletCount = 0
        }

        binding.dynamicContainer.removeAllViews()

        if (isFromNavMenuClick) {
            binding.tvType.visible()
            binding.tvType.text = title
            binding.llTitle.gone()
            binding.dynamicContainer.removeAllViews()
        } else {
            binding.tvType.gone()
            binding.llTitle.visible()
        }

        if (!isFromADFL) {

            val fetchLicenceData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya> =
                DatabaseHelperManiya(this).fetchLicenceData()

            val fetchPassportData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PassportScanDataManiya> =
                DatabaseHelperManiya(this).fetchPassportData()
            val fetchIDCardData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya> =
                DatabaseHelperManiya(this).fetchIDCardData()
            val fetchResidenceCardData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.ResidentScanDataManiya> =
                DatabaseHelperManiya(this).fetchResidenceCardData()
            val fetchPaymentData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchPaymentData()
            val fetchGiftData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.GiftCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchGiftData()
            val fetchLoyaltyData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.LoyaltyCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchLoyaltyData()
            val fetchMemberShipData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MemberShipCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchMemberShipData()
            val fetchMedicalData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MedicalCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchMedicalData()
            val fetchHealthData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchHealthData()
            val fetchBirthData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.BirthCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchBirthData()
            val fetchMrgData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MrgCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchMrgData()
            val fetchSIMData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.SIMCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchSIMData()
            val fetchPasswordData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PasswordCardScanDataManiya> =
                DatabaseHelperManiya(this).fetchPasswordData()
            val fetchCustomData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.CustomScanDataManiya> =
                DatabaseHelperManiya(this).fetchCustomData()

            val fetchVehicleData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.VehicleScanDataManiya> =
                DatabaseHelperManiya(this).fetchVehicleData()


            val fetchAdharData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.AdharScanDataManiya> =
                DatabaseHelperManiya(this).fetchAdharData()

            val fetchVoterData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.VoterScanDataManiya> =
                DatabaseHelperManiya(this).fetchVoterData()


            val fetchPANData: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PANScanDataManiya> =
                DatabaseHelperManiya(this).fetchPANData()


            if (fetchLicenceData.isNotEmpty() ||
                fetchPassportData.isNotEmpty() ||
                fetchIDCardData.isNotEmpty() ||
                fetchResidenceCardData.isNotEmpty() ||
                fetchPaymentData.isNotEmpty() ||
                fetchGiftData.isNotEmpty() ||
                fetchLoyaltyData.isNotEmpty() ||
                fetchMemberShipData.isNotEmpty() ||
                fetchMedicalData.isNotEmpty() ||
                fetchHealthData.isNotEmpty() ||
                fetchBirthData.isNotEmpty() ||
                fetchMrgData.isNotEmpty() ||
                fetchSIMData.isNotEmpty() ||
                fetchPasswordData.isNotEmpty() ||
                fetchCustomData.isNotEmpty()||
                fetchVehicleData.isNotEmpty()||
                fetchAdharData.isNotEmpty()||
                fetchVoterData.isNotEmpty()||
                fetchPANData.isNotEmpty()
            ) {
                isNoDataView = false
                if (fetchLicenceData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(1)

                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData[0])
                    walletCount += fetchLicenceData.size

                    addLicenceRecyclerView(false, "", title, 0L)
                    for (item in fetchLicenceData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.documentNumber ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }
                }

                if (fetchPassportData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(2)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchPassportData.size
                    addPassportRecyclerView(false, "", title, 0L)
                    for (item in fetchPassportData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.documentNumber ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )

                    }
                }

                if (fetchIDCardData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(3)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchIDCardData.size
                    addIDCardRecyclerView(false, "", title, 0L)
                    for (item in fetchIDCardData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.documentNumber ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchResidenceCardData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(4)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchResidenceCardData.size
                    addResidencetRecyclerView(false, "", title, 0L)
                    for (item in fetchResidenceCardData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.documentNumber ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchPaymentData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(5)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchPaymentData.size
                    addPaymentRecyclerView(false, "", title, 0L)
                    for (item in fetchPaymentData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.cardNumber ?: "",
                                item.holderName ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchGiftData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(6)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchGiftData.size
                    addGiftRecyclerView(false, "", title, 0L)
                    for (item in fetchGiftData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.cardNumber ?: "",
                                item.brand ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchLoyaltyData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(7)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchLoyaltyData.size
                    addLoyaltyRecyclerView(false, "", title, 0L)
                    for (item in fetchLoyaltyData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.cardNumber ?: "",
                                item.cardHolderName ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchMemberShipData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(8)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchMemberShipData.size
                    addMembershipRecyclerView(false, "", title, 0L)
                    for (item in fetchMemberShipData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.cardHolderNumber ?: "",
                                item.cardHolderNumber ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchMedicalData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(9)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchMedicalData.size
                    addMedicalRecyclerView(false, "", title, 0L)
                    for (item in fetchMedicalData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.documentNumber ?: "",
                                item.email ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchHealthData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(10)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchHealthData.size
                    addHealthRecyclerView(false, "", title, 0L)
                    for (item in fetchHealthData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.documentNumber ?: "",
                                item.email ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchBirthData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(11)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchBirthData.size
                    addBirthRecyclerView(false, "", title, 0L)
                    for (item in fetchBirthData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.documentNumber ?: "",
                                item.fullName ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchMrgData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(12)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchMrgData.size
                    addMrgRecyclerView(false, "", title, 0L)
                    for (item in fetchMrgData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.custom ?: "",
                                item.notes ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchSIMData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(13)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchSIMData.size
                    addSIMRecyclerView(false, "", title, 0L)
                    for (item in fetchSIMData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.phoneNumber ?: "",
                                item.ownerName ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchPasswordData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(14)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchPasswordData.size
                    addPasswordRecyclerView(false, "", title, 0L)
                    for (item in fetchPasswordData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.password ?: "",
                                item.login ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchCustomData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(15)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchCustomData.size
                    addCustomRecyclerView(false, "", title, 0L)
                    for (item in fetchCustomData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchVehicleData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(16)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchVehicleData.size
                    addVehicleRecyclerView(false, "", title, 0L)
                    for (item in fetchVehicleData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }


                if (fetchAdharData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(17)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchAdharData.size
                    addAdharRecyclerView(false, "", title, 0L)
                    for (item in fetchAdharData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }


                if (fetchVoterData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(18)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchVoterData.size
                    addVoterRecyclerView(false, "", title, 0L)
                    for (item in fetchVoterData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }

                if (fetchPANData.isNotEmpty()) {
                    val categoriesData = DatabaseHelperManiya(this).getSingleCategoryByID(19)
                    if (!categoriesData.isNullOrEmpty()) dFilteredCategoriesData.add(categoriesData!![0])
                    walletCount += fetchPANData.size
                    addPANRecyclerView(false, "", title, 0L)
                    for (item in fetchPANData) {
                        combineList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                item.category?.id ?: -1,
                                item.label?.name ?: "",
                                item.label?.id ?: -1
                            )
                        )
                    }

                }


                walletCount.toString().also { navHeaderBinding.navWalletCount.text = it }

            } else {
                showNoDataView()
                walletCount = 0
            }
        } else {
            Log.d("ADFL++++", "True-----Type--->$title")
            when (title) {
                resources.getString(R.string.nav_recently_deleted_menu) -> setDeletedWalletData(
                    title
                )

                resources.getString(R.string.nav_favourite_menu) -> setFavouritedWalletData(title)
                resources.getString(R.string.nav_archived_menu) -> setArchivedWalletData(title)
                resources.getString(R.string.nav_locked_menu) -> setLockedWalletData(title)
                else -> ""
            }

        }

    }

    private fun setLabelWalletDataRecyclerView(title: String, labelID: Long) {

        closeDrawer()
        binding.dynamicContainer.removeAllViews()
        binding.tvType.visible()
        binding.tvType.text = title
        binding.llTitle.gone()
        binding.dynamicContainer.removeAllViews()

        setLabelBasedWalletData(title, labelID)

    }

    private fun setLabelBasedWalletData(labelName: String, labelID: Long) {
        setWalletData(
            labelName,
            labelID,
            { DatabaseHelperManiya(this).fetchLicensesByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchPassportByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchIDCardByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchResidenceCardByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchPaymentByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchGiftByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchLoyaltyByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchMemberShipByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchMedicalByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchHealthByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchBirthByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchMrgByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchSIMByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchPasswordByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchCustomByLabelID(labelID) },
            { DatabaseHelperManiya(this).fetchVehicleByLabelID(labelID)},
            { DatabaseHelperManiya(this).fetchAdharByLabelID(labelID)},
            { DatabaseHelperManiya(this).fetchVoterByLabelID(labelID)},
            { DatabaseHelperManiya(this).fetchPANByLabelID(labelID)}
        )
    }

    private fun setDeletedWalletData(titleText: String) {
        setWalletData(
            titleText,
            0L,
            { DatabaseHelperManiya(this).fetchDeletedLicenceData() },
            { DatabaseHelperManiya(this).fetchDeletedPassportData() },
            { DatabaseHelperManiya(this).fetchDeletedIDCardData() },
            { DatabaseHelperManiya(this).fetchDeletedResidenceCardData() },
            { DatabaseHelperManiya(this).fetchDeletedPaymentData() },
            { DatabaseHelperManiya(this).fetchDeletedGiftData() },
            { DatabaseHelperManiya(this).fetchDeletedLoyaltyData() },
            { DatabaseHelperManiya(this).fetchDeletedMemberShipData() },
            { DatabaseHelperManiya(this).fetchDeletedMedicalData() },
            { DatabaseHelperManiya(this).fetchDeletedHealthData() },
            { DatabaseHelperManiya(this).fetchDeletedBirthData() },
            { DatabaseHelperManiya(this).fetchDeletedMrgData() },
            { DatabaseHelperManiya(this).fetchDeletedSIMData() },
            { DatabaseHelperManiya(this).fetchDeletedPasswordData() },
         { DatabaseHelperManiya(this).fetchDeletedCustomData() },
            { DatabaseHelperManiya(this).fetchDeletedVehicleData()},
            { DatabaseHelperManiya(this).fetchDeletedAdharData()},
            { DatabaseHelperManiya(this).fetchDeletedVoterData()},
            { DatabaseHelperManiya(this).fetchDeletedPANData()})
    }

    private fun setArchivedWalletData(titleText: String) {
        setWalletData(
            titleText,
            0L,
            { DatabaseHelperManiya(this).fetchArchivedLicenceData() },
            { DatabaseHelperManiya(this).fetchArchivedPassportData() },
            { DatabaseHelperManiya(this).fetchArchivedIDCardData() },
            { DatabaseHelperManiya(this).fetchArchivedResidenceCardData() },
            { DatabaseHelperManiya(this).fetchArchivedPaymentData() },
            { DatabaseHelperManiya(this).fetchArchivedGiftData() },
            { DatabaseHelperManiya(this).fetchArchivedLoyaltyData() },
            { DatabaseHelperManiya(this).fetchArchivedMemberShipData() },
            { DatabaseHelperManiya(this).fetchArchivedMedicalData() },
            { DatabaseHelperManiya(this).fetchArchivedHealthData() },
            { DatabaseHelperManiya(this).fetchArchivedBirthData() },
            { DatabaseHelperManiya(this).fetchArchivedMrgData() },
            { DatabaseHelperManiya(this).fetchArchivedSIMData() },
            { DatabaseHelperManiya(this).fetchArchivedPasswordData() },
         { DatabaseHelperManiya(this).fetchArchivedCustomData() },
        { DatabaseHelperManiya(this).fetchArchivedVehicleData()},
        { DatabaseHelperManiya(this).fetchArchivedAdharData()},
        { DatabaseHelperManiya(this).fetchArchivedVoterData()},
        { DatabaseHelperManiya(this).fetchArchivedPANData()})
    }

    private fun setFavouritedWalletData(titleText: String) {
        setWalletData(
            titleText,
            0L,
            { DatabaseHelperManiya(this).fetchFavouriteLicenceData() },
            { DatabaseHelperManiya(this).fetchFavouritePassportData() },
            { DatabaseHelperManiya(this).fetchFavouriteIDCardData() },
            { DatabaseHelperManiya(this).fetchFavouriteResidenceCardData() },
            { DatabaseHelperManiya(this).fetchFavouritePaymentData() },
            { DatabaseHelperManiya(this).fetchFavouriteGiftData() },
            { DatabaseHelperManiya(this).fetchFavouriteLoyaltyData() },
            { DatabaseHelperManiya(this).fetchFavouriteMemberShipData() },
            { DatabaseHelperManiya(this).fetchFavouriteMedicalData() },
            { DatabaseHelperManiya(this).fetchFavouriteHealthData() },
            { DatabaseHelperManiya(this).fetchFavouriteBirthData() },
            { DatabaseHelperManiya(this).fetchFavouriteMrgData() },
            { DatabaseHelperManiya(this).fetchFavouriteSIMData() },
            { DatabaseHelperManiya(this).fetchFavouritePasswordData() },
         { DatabaseHelperManiya(this).fetchFavouriteCustomData() },
         { DatabaseHelperManiya(this).fetchFavouriteVehicleData()},
         { DatabaseHelperManiya(this).fetchFavouriteAdharData()},
         { DatabaseHelperManiya(this).fetchFavouriteVoterData()},
         { DatabaseHelperManiya(this).fetchFavouritePANData()}
        )
    }

    private fun setLockedWalletData(titleText: String) {
        setWalletData(
            titleText,
            0L,
            { DatabaseHelperManiya(this).fetchLockedLicenceData() },
            { DatabaseHelperManiya(this).fetchLockedPassportData() },
            { DatabaseHelperManiya(this).fetchLockedIDCardData() },
            { DatabaseHelperManiya(this).fetchLockedResidenceCardData() },
            { DatabaseHelperManiya(this).fetchLockedPaymentData() },
            { DatabaseHelperManiya(this).fetchLockedGiftData() },
            { DatabaseHelperManiya(this).fetchLockedLoyaltyData() },
            { DatabaseHelperManiya(this).fetchLockedMemberShipData() },
            { DatabaseHelperManiya(this).fetchLockedMedicalData() },
            { DatabaseHelperManiya(this).fetchLockedHealthData() },
            { DatabaseHelperManiya(this).fetchLockedBirthData() },
            { DatabaseHelperManiya(this).fetchLockedMrgData() },
            { DatabaseHelperManiya(this).fetchLockedSIMData() },
            { DatabaseHelperManiya(this).fetchLockedPasswordData() },
            { DatabaseHelperManiya(this).fetchLockedCustomData() },
            { DatabaseHelperManiya(this).fetchLockedVehicleData() },
            { DatabaseHelperManiya(this).fetchLockedAdharData() },
            { DatabaseHelperManiya(this).fetchLockedVoterData() },
            { DatabaseHelperManiya(this).fetchLockedPANData() }
        )
    }

    private fun setWalletData(
        titleText: String,
        labelID: Long,
        lLicenceData: () -> List<Any>,
        lPassportData: () -> List<Any>,
        lIDCardData: () -> List<Any>,
        lResidenceData: () -> List<Any>,
        lPaymentData: () -> List<Any>,
        lGiftData: () -> List<Any>,
        lLoyaltyData: () -> List<Any>,
        lMembershipData: () -> List<Any>,
        lMedicalData: () -> List<Any>,
        lHealthData: () -> List<Any>,
        lBirthData: () -> List<Any>,
        lMrgData: () -> List<Any>,
        lSIMData: () -> List<Any>,
        lPasswordData: () -> List<Any>,
        lCustomData: () -> List<Any>,
        lVehicleData: () -> List<Any>,
        lAdharData: () -> List<Any>,
        lVoterData: () -> List<Any>,
        lPANData: () -> List<Any>
    ) {
        combineList.clear()

        if (lLicenceData().isNotEmpty() ||
            lPassportData().isNotEmpty() ||
            lIDCardData().isNotEmpty() ||
            lResidenceData().isNotEmpty() ||
            lPaymentData().isNotEmpty() ||
            lGiftData().isNotEmpty() ||
            lLoyaltyData().isNotEmpty() ||
            lMembershipData().isNotEmpty() ||
            lMedicalData().isNotEmpty() ||
            lHealthData().isNotEmpty() ||
            lBirthData().isNotEmpty() ||
            lMrgData().isNotEmpty() ||
            lSIMData().isNotEmpty() ||
            lPasswordData().isNotEmpty() ||
            lCustomData().isNotEmpty() ||
            lVehicleData().isNotEmpty() ||
            lAdharData().isNotEmpty() ||
            lVoterData().isNotEmpty() ||
            lPANData().isNotEmpty()
        ) {
            isNoDataView = false
            if (lLicenceData().isNotEmpty()) {
                addLicenceRecyclerView(false, titleText, titleText, labelID)
            }

            if (lPassportData().isNotEmpty()) {
                addPassportRecyclerView(false, titleText, titleText, labelID)
            }

            if (lIDCardData().isNotEmpty()) {
                addIDCardRecyclerView(false, titleText, titleText, labelID)
            }

            if (lResidenceData().isNotEmpty()) {
                addResidencetRecyclerView(false, titleText, titleText, labelID)
            }

            if (lPaymentData().isNotEmpty()) {
                addPaymentRecyclerView(false, titleText, titleText, labelID)
            }

            if (lGiftData().isNotEmpty()) {
                addGiftRecyclerView(false, titleText, titleText, labelID)
            }

            if (lLoyaltyData().isNotEmpty()) {
                addLoyaltyRecyclerView(false, titleText, titleText, labelID)
            }

            if (lMembershipData().isNotEmpty()) {
                addMembershipRecyclerView(false, titleText, titleText, labelID)
            }

            if (lMedicalData().isNotEmpty()) {
                addMedicalRecyclerView(false, titleText, titleText, labelID)
            }

            if (lHealthData().isNotEmpty()) {
                addHealthRecyclerView(false, titleText, titleText, labelID)
            }

            if (lBirthData().isNotEmpty()) {
                addBirthRecyclerView(false, titleText, titleText, labelID)
            }

            if (lMrgData().isNotEmpty()) {
                addMrgRecyclerView(false, titleText, titleText, labelID)
            }

            if (lSIMData().isNotEmpty()) {
                addSIMRecyclerView(false, titleText, titleText, labelID)
            }

            if (lPasswordData().isNotEmpty()) {
                addPasswordRecyclerView(false, titleText, titleText, labelID)
            }
            if (lCustomData().isNotEmpty()) {
                addCustomRecyclerView(false, titleText, titleText, labelID)
            }
            if (lVehicleData().isNotEmpty()) {
                addVehicleRecyclerView(
                    false, titleText, titleText, labelID)
            }
            if (lAdharData().isNotEmpty()) {
                addAdharRecyclerView(
                    false, titleText, titleText, labelID)
            }
            if (lVoterData().isNotEmpty()) {
                addVoterRecyclerView(
                    false, titleText, titleText, labelID)
            }
            if (lPANData().isNotEmpty()) {
                addPANRecyclerView(
                    false, titleText, titleText, labelID)
            }

        } else {
            showNoDataView()
        }
    }


    private fun showNoDataView() {
        binding.scrollview.gone()
        binding.rvSearchRecyclerView.gone()
        isNoDataView = true
        binding.rlStartNoDataView.visible()
        handler.removeCallbacksAndMessages(null)
        startAutoSlide()
    }


    @SuppressLint("SetTextI18n")
    private fun addPaymentRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.pay_cat_maniya)
        val catID = 5L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedPaymentData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouritePaymentData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedPaymentData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedPaymentData
            titleText -> {
                { dbHelper.fetchPaymentByLabelID(labelID) }
            }

            else -> dbHelper::fetchPaymentData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchPaymentData()
        }

        paymentDataList = walletList


        Log.d("-----PAYMENT Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }
        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = context.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }


        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )

            paymentAdapter = PaymentAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->

                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.cardNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = paymentAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        paymentRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }

    @SuppressLint("SetTextI18n")
    private fun addGiftRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.gift_cat_maniya)
        val catID = 6L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.GiftCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedGiftData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteGiftData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedGiftData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedGiftData
            titleText -> {
                { dbHelper.fetchGiftByLabelID(labelID) }
            }

            else -> dbHelper::fetchGiftData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchGiftData()
        }


        giftDataList = walletList


        Log.d("-----GIFT Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = context.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }


        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            giftAdapter = GiftAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.cardNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = giftAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        giftRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }

    @SuppressLint("SetTextI18n")
    private fun addLoyaltyRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.loyal_cat_maniya)
        val catID = 7L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.LoyaltyCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedLoyaltyData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteLoyaltyData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedLoyaltyData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedLoyaltyData
            titleText -> {
                { dbHelper.fetchLoyaltyByLabelID(labelID) }
            }

            else -> dbHelper::fetchLoyaltyData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchLoyaltyData()
        }

        loyaltyDataList = walletList

        Log.d("-----Loyalty Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = context.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }


        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            loyaltyAdapter = LoyaltyAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.cardNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )

                    true
                })

            adapter = loyaltyAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        loyaltyRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addHealthRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.health_cat_maniya)
        val catID = 10L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedHealthData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteHealthData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedHealthData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedHealthData
            titleText -> {
                { dbHelper.fetchHealthByLabelID(labelID) }
            }

            else -> dbHelper::fetchHealthData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchHealthData()
        }

        healthDataList = walletList


        Log.d("-----Health Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = context.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }


        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            healthAdapter = HealthAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.documentNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = healthAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        healthRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addBirthRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.birth_cat_maniya)
        val catID = 11L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.BirthCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedBirthData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteBirthData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedBirthData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedBirthData
            titleText -> {
                { dbHelper.fetchBirthByLabelID(labelID) }
            }

            else -> dbHelper::fetchBirthData
        }

        walletList = dataFetchMethod()
        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchBirthData()
        }

        birthDataList = walletList


        Log.d("-----Birth Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = context.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }


        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            birthAdapter = BirthAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.documentNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = birthAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        birthRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addMrgRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.mrg_cat_maniya)
        val catID = 12L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MrgCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedMrgData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteMrgData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedMrgData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedMrgData
            titleText -> {
                { dbHelper.fetchMrgByLabelID(labelID) }
            }

            else -> dbHelper::fetchMrgData
        }

        walletList = dataFetchMethod()
        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchMrgData()
        }

        mrgDataList = walletList


        Log.d("-----MRG Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = context.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }


        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            mrgAdapter = MrgAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.notes,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )

                    true
                })

            adapter = mrgAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        mrgRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addSIMRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.sim_cat_maniya)
        val catID = 13L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.SIMCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedSIMData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteSIMData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedSIMData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedSIMData
            titleText -> {
                { dbHelper.fetchSIMByLabelID(labelID) }
            }

            else -> dbHelper::fetchSIMData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchSIMData()
        }

        simDataList = walletList


        Log.d("-----SIM Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = context.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }


        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            simAdapter = SIMAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.notes,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = simAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        simRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }

    @SuppressLint("SetTextI18n")
    private fun addPasswordRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.password_cat_maniya)
        val catID = 14L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PasswordCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedPasswordData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouritePasswordData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedPasswordData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedPasswordData
            titleText -> {
                { dbHelper.fetchPasswordByLabelID(labelID) }
            }

            else -> dbHelper::fetchPasswordData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchPasswordData()
        }

        passwordDataList = walletList


        Log.d("-----PASSWORD Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = context.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }


        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            passwordAdapter = PasswordAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.notes,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = passwordAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        passwordRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }

    @SuppressLint("SetTextI18n")
    private fun addCustomRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.custom_cat_maniya)
        val catID = 15L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.CustomScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedCustomData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteCustomData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedCustomData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedCustomData
            titleText -> {
                { dbHelper.fetchCustomByLabelID(labelID) }
            }

            else -> dbHelper::fetchCustomData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchCustomData()
        }

        customDataList = walletList


        Log.d("-----Custom Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = resources.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            customAdapter = CustomAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.text,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = customAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        customRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }

    @SuppressLint("SetTextI18n")
    private fun addVehicleRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.vehicle_cat_maniya)
        val catID = 16L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.VehicleScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedVehicleData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteVehicleData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedVehicleData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedVehicleData
            titleText -> {
                { dbHelper.fetchVehicleByLabelID(labelID) }
            }

            else -> dbHelper::fetchVehicleData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchVehicleData()
        }

        vehicleDataList = walletList


        Log.d("-----Vehicle Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = resources.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            vehicleAdapter = VehicleAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.text,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = vehicleAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        vehicleRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }

    @SuppressLint("SetTextI18n")
    private fun addAdharRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.adhar_cat_maniya)
        val catID = 17L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.AdharScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedAdharData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteAdharData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedAdharData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedAdharData
            titleText -> {
                { dbHelper.fetchAdharByLabelID(labelID) }
            }

            else -> dbHelper::fetchAdharData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchAdharData()
        }

        adharDataList = walletList


        Log.d("-----Adhar Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = resources.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            adharAdapter = AdharAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.text,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = adharAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        adharRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addVoterRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.voter_cat_maniya)
        val catID = 18L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.VoterScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedVoterData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteVoterData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedVoterData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedVoterData
            titleText -> {
                { dbHelper.fetchVoterByLabelID(labelID) }
            }

            else -> dbHelper::fetchVoterData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchVoterData()
        }

        voterDataList = walletList


        Log.d("-----Voter Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = resources.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            voterAdapter = VoterAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.text,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = voterAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        voterRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }

    @SuppressLint("SetTextI18n")
    private fun addPANRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.pan_cat_maniya)
        val catID = 19L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PANScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedPANData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouritePANData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedPANData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedPANData
            titleText -> {
                { dbHelper.fetchPANByLabelID(labelID) }
            }

            else -> dbHelper::fetchPANData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchPANData()
        }

        panDataList = walletList


        Log.d("-----PAN Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = resources.getString(R.string.view_all)
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            panAdapter = PANAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.text,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = panAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        panRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addMembershipRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.member_cat_maniya)
        val catID = 8L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MemberShipCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedMemberShipData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteMemberShipData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedMemberShipData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedMemberShipData
            titleText -> {
                { dbHelper.fetchMemberShipByLabelID(labelID) }
            }

            else -> dbHelper::fetchMemberShipData
        }

        walletList = dataFetchMethod()


        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchMemberShipData()
        }

        membershipDataList = walletList

        Log.d("-----MemberShip Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :"
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = "View All"
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            membershipAdapter = MembershipAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.cardHolderName,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = membershipAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        membershipRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addMedicalRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.medical_cat_maniya)
        val catID = 9L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.MedicalCardScanDataManiya>
        val dbHelper = DatabaseHelperManiya(this)
        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedMedicalData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteMedicalData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedMedicalData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedMedicalData
            titleText -> {
                { dbHelper.fetchMedicalByLabelID(labelID) }
            }

            else -> dbHelper::fetchMedicalData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchMedicalData()
        }


        medicalDataList = walletList


        Log.d("-----Medical Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = "View All"
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }
        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            medicalAdapter = MedicalAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.documentNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = medicalAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        medicalRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addLicenceRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()
        val categoryName = resources.getString(R.string.driver_cat_maniya)
        val catID = 1L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya> =
            mutableListOf()

        val dbHelper = DatabaseHelperManiya(this)

        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedLicenceData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteLicenceData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedLicenceData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedLicenceData
            titleText -> {
                { dbHelper.fetchLicensesByLabelID(labelID) }
            }

            else -> {
                dbHelper::fetchLicenceData
            }

        }
        walletList = dataFetchMethod()
        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchLicenceData()
        }
        licenceDataList = walletList


        Log.d("-----Licence Data----", "Size()----" + walletList.size)


        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
            binding.dynamicContainer.removeAllViews()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :"
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = "View All"
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            licenseAdapter = LicenseCardAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)
                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.documentNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )

                    true
                })


            adapter = licenseAdapter

            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }
        licenseRecyclerView = dynamicRecyclerView
        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)
    }


    @SuppressLint("SetTextI18n")
    private fun addIDCardRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()
        val categoryName = resources.getString(R.string.identity_cat_maniya)
        val catID = 3L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya> =
            mutableListOf()
        val dbHelper = DatabaseHelperManiya(this)

        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedIDCardData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteIDCardData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedIDCardData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedIDCardData
            titleText -> {
                { dbHelper.fetchIDCardByLabelID(labelID) }
            }

            else -> dbHelper::fetchIDCardData
        }

        walletList = dataFetchMethod()
        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchIDCardData()
        }
        identityDataList = walletList


        Log.d("-----Identity Data----", "Size()----" + walletList.size)


        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
            binding.dynamicContainer.removeAllViews()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = "View All"
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            identityAdapter = IDCardAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.documentNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = identityAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }
        identityRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)
    }

    @SuppressLint("SetTextI18n")
    private fun addResidencetRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()

        val categoryName = resources.getString(R.string.residence_cat_maniya)
        val catID = 4L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.ResidentScanDataManiya> =
            mutableListOf()
        val dbHelper = DatabaseHelperManiya(this)

        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedResidenceCardData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouriteResidenceCardData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedResidenceCardData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedResidenceCardData
            titleText -> {
                { dbHelper.fetchResidenceCardByLabelID(labelID) }
            }

            else -> dbHelper::fetchResidenceCardData
        }

        walletList = dataFetchMethod()
        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchResidenceCardData()
        }
        residenceDataList = walletList

        Log.d("-----ResidenceCard Data----", "Size()----" + walletList.size)
        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.dynamicContainer.removeAllViews()
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = "View All"
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            residenceAdapter = ResidenceCardAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.documentNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = residenceAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        residenceRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)

    }


    @SuppressLint("SetTextI18n")
    private fun addPassportRecyclerView(
        isFromNavMenuClick: Boolean,
        navTYPE: String,
        titleText: String,
        labelID: Long
    ) {
        closeDrawer()
        val categoryName = resources.getString(R.string.passport_cat_maniya)
        val catID = 2L

        var walletList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.PassportScanDataManiya> =
            mutableListOf()
        val dbHelper = DatabaseHelperManiya(this)

        val dataFetchMethod = when (navTYPE) {
            resources.getString(R.string.nav_recently_deleted_menu) -> dbHelper::fetchDeletedPassportData
            resources.getString(R.string.nav_favourite_menu) -> dbHelper::fetchFavouritePassportData
            resources.getString(R.string.nav_archived_menu) -> dbHelper::fetchArchivedPassportData
            resources.getString(R.string.nav_locked_menu) -> dbHelper::fetchLockedPassportData
            titleText -> {
                { dbHelper.fetchPassportByLabelID(labelID) }
            }

            else -> dbHelper::fetchPassportData
        }

        walletList = dataFetchMethod()

        if (navTYPE.equals("") && walletList.isEmpty()) {
            walletList = DatabaseHelperManiya(this).fetchPassportData()
        }

        passportDataList = walletList

        Log.d("-----Passport Data----", "Size()----" + walletList.size)

        binding.scrollview.visible()
        binding.rvSearchRecyclerView.gone()
        binding.rlStartNoDataView.gone()
        isNoDataView = false

        this.isFromNavMenu = isFromNavMenuClick
        this.title = titleText

        if (isFromNavMenuClick) {
            binding.tvType.visible()
            binding.tvType.text = titleText
            binding.llTitle.gone()
            binding.dynamicContainer.removeAllViews()
        }

        val containerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleBarLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTextView = TextView(this).apply {
            text = "$categoryName :" // Dynamic category name
            textSize = 19f
            setTypeface(Typeface.DEFAULT_BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setPadding(8, 8, 8, 8)
        }

        titleBarLayout.addView(titleTextView)

        if (walletList.size > 4) {
            val moreTextView = TextView(this).apply {
                text = "View All"
                textSize = 13f
                setTextColor(resources.getColor(R.color.colorPrimary))
                setTypeface(Typeface.DEFAULT_BOLD)
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                tag = catID
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setPadding(8, 8, 8, 8)
                }
                setOnClickListener {
                    openCategoryDataActivity(categoryName, tag as? Long, titleText)
                }
            }
            titleBarLayout.addView(moreTextView)
        }

        val dynamicRecyclerView = RecyclerView(this).apply {
            /* if(isFromNavMenuClick)
             layoutManager = GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
             else*/
            layoutManager = LinearLayoutManager(
                this@TESTMainActivityManiya,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            passportAdapter = PassportCardAdapter(
                this@TESTMainActivityManiya,
                walletList,
                useTwoColumns,
                onItemClick = { item, position ->
                    openRecordView(item.id, catID, position, item.isLock)

                },
                onItemLongClick = { item, position ->
                    openBottomDialogOnLongClick(
                        item.id,
                        catID,
                        categoryName,
                        item.frontCardImage,
                        item.backCardImage,
                        item.documentNumber,
                        item.isDelete,
                        item.isArchive,
                        item.isFav,
                        item.label?.id ?: -1,
                        position
                    )
                    true
                })

            adapter = passportAdapter
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 0)
            }
        }

        passportRecyclerView = dynamicRecyclerView

        containerLayout.addView(titleBarLayout)
        containerLayout.addView(dynamicRecyclerView)

        binding.dynamicContainer.addView(containerLayout)
    }

    private fun setNavLabelsRecyclerView() {
        navLabelAdapter = LabelsNavigationAdapter(
            this,
            DatabaseHelperManiya(this).fetchAllLabels()
        ) { label, position ->
            useTwoColumns = false
            currentType = "label" + "," + label.id + "," + label.name
            setLabelWalletDataRecyclerView(label.name, label.id)
        }
        navHeaderBinding.navRVLabels.adapter = navLabelAdapter


        if (currentType.contains("label,")) {

            val values = currentType.split(",")

            val label = values[0]
            val id = values[1]
            val name = values[2]

            when (id) {
                "1" ->
                    addLicenceRecyclerView(true, "", name, 0L)

                "2" ->
                    addPassportRecyclerView(true, "", name, 0L)

                "3" ->
                    addIDCardRecyclerView(true, "", name, 0L)

                "4" ->
                    addResidencetRecyclerView(true, "", name, 0L)

                "5" ->
                    addPaymentRecyclerView(true, "", name, 0L)

                "6" ->
                    addGiftRecyclerView(true, "", name, 0L)

                "7" ->
                    addLoyaltyRecyclerView(true, "", name, 0L)

                "8" ->
                    addMembershipRecyclerView(true, "", name, 0L)

                "9" ->
                    addMedicalRecyclerView(true, "", name, 0L)

                "10" ->
                    addHealthRecyclerView(true, "", name, 0L)

                "11" ->
                    addBirthRecyclerView(true, "", name, 0L)

                "12" ->
                    addMrgRecyclerView(true, "", name, 0L)

                "13" ->
                    addSIMRecyclerView(true, "", name, 0L)

                "14" ->
                    addPasswordRecyclerView(true, "", name, 0L)

                "15" ->
                    addCustomRecyclerView(true, "", name, 0L)

                "16" ->
                    addVehicleRecyclerView(true, "", name, 0L)
                "17" ->
                    addAdharRecyclerView(true, "", name, 0L)
                "18" ->
                    addVoterRecyclerView(true, "", name, 0L)
                "19" ->
                    addPANRecyclerView(true, "", name, 0L)

            }

        }

    }

    private fun setNavCategoriesRecyclerView() {
        if (dFilteredCategoriesData.size > 0) {
            navHeaderBinding.llCategories.visible()
            navCategoriesAdapter = CategoriesNavigationAdapter(
                this,
                dFilteredCategoriesData
            ) { category, position ->
                currentType = "category" + "," + category.id + "," + category.name
                useTwoColumns = false

                /*---GroupBY Category----*/
                when (category.id) {
                    1L ->
                        addLicenceRecyclerView(true, "", category.name, 0L)

                    2L ->
                        addPassportRecyclerView(true, "", category.name, 0L)

                    3L ->
                        addIDCardRecyclerView(true, "", category.name, 0L)

                    4L ->
                        addResidencetRecyclerView(true, "", category.name, 0L)

                    5L ->
                        addPaymentRecyclerView(true, "", category.name, 0L)

                    6L ->
                        addGiftRecyclerView(true, "", category.name, 0L)

                    7L ->
                        addLoyaltyRecyclerView(true, "", category.name, 0L)

                    8L ->
                        addMembershipRecyclerView(true, "", category.name, 0L)

                    9L ->
                        addMedicalRecyclerView(true, "", category.name, 0L)

                    10L ->
                        addHealthRecyclerView(true, "", category.name, 0L)

                    11L ->
                        addBirthRecyclerView(true, "", category.name, 0L)

                    12L ->
                        addMrgRecyclerView(true, "", category.name, 0L)

                    13L ->
                        addSIMRecyclerView(true, "", category.name, 0L)

                    14L ->
                        addPasswordRecyclerView(true, "", category.name, 0L)

                    15L ->
                        addCustomRecyclerView(true, "", category.name, 0L)

                    16L ->
                        addVehicleRecyclerView(true, "", category.name, 0L)
                    17L ->
                        addAdharRecyclerView(true, "", category.name, 0L)
                    18L ->
                        addVoterRecyclerView(true, "", category.name, 0L)
                    19L ->
                        addPANRecyclerView(true, "", category.name, 0L)

                }

            }
            navHeaderBinding.navRVCategories.adapter = navCategoriesAdapter

            if (currentType.contains("category,")) {
                Log.d("+++currentType++", "$currentType")
                val values = currentType.split(",")
                val id = values[1]
                val name = values[2]

                when (id) {
                    "1" ->
                        addLicenceRecyclerView(true, "", name, 0L)

                    "2" ->
                        addPassportRecyclerView(true, "", name, 0L)

                    "3" ->
                        addIDCardRecyclerView(true, "", name, 0L)

                    "4" ->
                        addResidencetRecyclerView(true, "", name, 0L)

                    "5" ->
                        addPaymentRecyclerView(true, "", name, 0L)

                    "6" ->
                        addGiftRecyclerView(true, "", name, 0L)

                    "7" ->
                        addLoyaltyRecyclerView(true, "", name, 0L)

                    "8" ->
                        addMembershipRecyclerView(true, "", name, 0L)

                    "9" ->
                        addMedicalRecyclerView(true, "", name, 0L)

                    "10" ->
                        addHealthRecyclerView(true, "", name, 0L)

                    "11" ->
                        addBirthRecyclerView(true, "", name, 0L)

                    "12" ->
                        addMrgRecyclerView(true, "", name, 0L)

                    "13" ->
                        addSIMRecyclerView(true, "", name, 0L)

                    "14" ->
                        addPasswordRecyclerView(true, "", name, 0L)

                    "15" ->
                        addCustomRecyclerView(true, "", name, 0L)
                    "16" ->
                        addVehicleRecyclerView(true, "", name, 0L)
                    "17" ->
                        addAdharRecyclerView(true, "", name, 0L)
                    "18" ->
                        addVoterRecyclerView(true, "", name, 0L)
                    "19" ->
                        addPANRecyclerView(true, "", name, 0L)

                }
            }

        } else {
            navHeaderBinding.llCategories.gone()
        }
    }

    private fun setCategoriesDBData() {
        if (DatabaseHelperManiya(this@TESTMainActivityManiya).fetchAllCategories().isEmpty()) {
            val categoryNames = resources.getStringArray(R.array.categories_maniya)
            val drawableNames = resources.getStringArray(R.array.categories_drawable_maniya)
            for (i in categoryNames.indices) {
                DatabaseHelperManiya(this).getCategoryDao().createOrUpdate(
                    com.deep.infotech.atm_card_wallet.maniya.dataModel.CategoryDataManiya(
                        name = categoryNames[i],
                        icon = drawableNames[i]
                    )
                )
            }

        }
    }

    fun onCancelSearchClick(view: View) {
        showToolbarBar()
    }

    private fun showSearchBar() {
        binding.llSearchView.visible()
        binding.llToolbar.gone()
        binding.llSelectionBar.gone()

    }

    private fun showSelectionBar() {
        binding.llSelectionBar.visible()
        binding.llSearchView.gone()
        binding.llToolbar.gone()
    }

    private fun showToolbarBar() {
        closeDrawer()
        binding.llToolbar.visible()
        binding.llSearchView.gone()
        binding.llSelectionBar.gone()

        binding.edtSearch.text.clear()
        binding.scrollview.visible()
        binding.scrollview.smoothScrollTo(0, 0)
        binding.rvSearchRecyclerView.gone()
    }

    fun onNavSettingsClick(view: View?) {
        closeDrawer()
        openSettingsActivity()
    }

    fun setSearchRecyclerView() {
        binding.rvSearchRecyclerView.apply {
            layoutManager =
                GridLayoutManager(this@TESTMainActivityManiya, if (useTwoColumns) 2 else 1)
            searchAdapter = SearchWalletAdapter(
                this@TESTMainActivityManiya,
                combineList,
                useTwoColumns
            ) { searchItem, position ->
                openRecordView(searchItem.id, searchItem.categoryID!!, -1, false)
            }
            adapter = searchAdapter
        }
    }

    fun onDrawerIconClick(view: View?) {
        binding.drawerLayout.openDrawer(GravityCompat.START)
    }

    private fun updateDrawerData() {
        setNavCategoriesRecyclerView()
        setNavLabelsRecyclerView()
        setADFLCount()
    }

    private fun setADFLCount() {
        val dbHelper = DatabaseHelperManiya(this)
        resetCount()
        fun getDataCount(fetchMethod: () -> List<Any>): Int {
            return fetchMethod().size
        }

        deletedCount += getDataCount { dbHelper.fetchDeletedPaymentData() }
        deletedCount += getDataCount { dbHelper.fetchDeletedLicenceData() }

        archivedCount += getDataCount { dbHelper.fetchArchivedLicenceData() }
        archivedCount += getDataCount { dbHelper.fetchArchivedPaymentData() }

        lockedCount += getDataCount { dbHelper.fetchLockedLicenceData() }
        lockedCount += getDataCount { dbHelper.fetchLockedPaymentData() }

        favouritedCount += getDataCount { dbHelper.fetchFavouriteLicenceData() }
        favouritedCount += getDataCount { dbHelper.fetchFavouritePaymentData() }

        Log.d("+++navFavCount++", "$favouritedCount")
        Log.d("+++navRDeleteCount++", "$deletedCount")
        Log.d("+++navLockCount++", "$lockedCount")
        Log.d("+++navArchiveCount++", "$archivedCount")

        runOnUiThread {
            updateCountUI(navHeaderBinding.navFavCount, favouritedCount)
            updateCountUI(navHeaderBinding.navRDeleteCount, deletedCount)
            updateCountUI(navHeaderBinding.navLockCount, lockedCount)
            updateCountUI(navHeaderBinding.navArchiveCount, archivedCount)
        }
    }

    private fun updateCountUI(view: TextView, count: Int) {
        if (count != 0) {
            view.visible()
            view.text = "$count"
        } else {
            view.gone()
        }
    }

    private fun resetCount() {
        runOnUiThread {
            deletedCount = 0
            archivedCount = 0
            lockedCount = 0
            favouritedCount = 0
        }
    }

    fun onFilterIconClick(view: View?) {
        useTwoColumns = !useTwoColumns
        binding.ivFilter.setImageResource(if (useTwoColumns) R.drawable.ic_grid_one else R.drawable.ic_two_grid)
        Log.d("+++++", "useTwoColumns: $useTwoColumns")
        updateDataView()
    }

    private fun updateDataView() {

        if (licenseRecyclerView != null) {

            if (!useTwoColumns) {
                licenseRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                licenseRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }

            licenseAdapter?.updateView(useTwoColumns)
        }

        if (passportRecyclerView != null) {

            if (!useTwoColumns) {
                passportRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                passportRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            passportAdapter?.updateView(useTwoColumns)
        }

        if (identityRecyclerView != null) {

            if (!useTwoColumns) {
                identityRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                identityRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }

            identityAdapter?.updateView(useTwoColumns)
        }


        if (residenceRecyclerView != null) {

            if (!useTwoColumns) {
                residenceRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                residenceRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }

            residenceAdapter?.updateView(useTwoColumns)
        }

        if (paymentRecyclerView != null) {

            if (!useTwoColumns) {
                paymentRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                paymentRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            paymentAdapter?.updateView(useTwoColumns)
        }

        if (giftRecyclerView != null) {

            if (!useTwoColumns) {
                giftRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                giftRecyclerView?.layoutManager = GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            giftAdapter?.updateView(useTwoColumns)
        }

        if (loyaltyRecyclerView != null) {

            if (!useTwoColumns) {
                loyaltyRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                loyaltyRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            loyaltyAdapter?.updateView(useTwoColumns)
        }

        if (membershipRecyclerView != null) {

            if (!useTwoColumns) {
                membershipRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                membershipRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            membershipAdapter?.updateView(useTwoColumns)
        }

        if (medicalRecyclerView != null) {

            if (!useTwoColumns) {
                medicalRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                medicalRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }

            medicalAdapter?.updateView(useTwoColumns)
        }

        if (healthRecyclerView != null) {

            if (!useTwoColumns) {
                healthRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                healthRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }

            healthAdapter?.updateView(useTwoColumns)
        }

        if (birthRecyclerView != null) {

            if (!useTwoColumns) {
                birthRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                birthRecyclerView?.layoutManager = GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            birthAdapter?.updateView(useTwoColumns)
        }

        if (mrgRecyclerView != null) {

            if (!useTwoColumns) {
                mrgRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                mrgRecyclerView?.layoutManager = GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            mrgAdapter?.updateView(useTwoColumns)
        }

        if (simRecyclerView != null) {

            if (!useTwoColumns) {
                simRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                simRecyclerView?.layoutManager = GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            simAdapter?.updateView(useTwoColumns)
        }

        if (passwordRecyclerView != null) {

            if (!useTwoColumns) {
                passwordRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                passwordRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            passwordAdapter?.updateView(useTwoColumns)
        }

        if (customRecyclerView != null) {

            if (!useTwoColumns) {
                customRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                customRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            customAdapter?.updateView(useTwoColumns)
        }
        if (vehicleRecyclerView != null) {

            if (!useTwoColumns) {
                vehicleRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                vehicleRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            vehicleAdapter?.updateView(useTwoColumns)
        }
        if (adharRecyclerView != null) {

            if (!useTwoColumns) {
                adharRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                adharRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            adharAdapter?.updateView(useTwoColumns)
        }
        if (voterRecyclerView != null) {

            if (!useTwoColumns) {
                voterRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                voterRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            voterAdapter?.updateView(useTwoColumns)
        }
        if (panRecyclerView != null) {

            if (!useTwoColumns) {
                panRecyclerView?.layoutManager = LinearLayoutManager(
                    this@TESTMainActivityManiya,
                    LinearLayoutManager.HORIZONTAL,
                    false
                )
            } else {
                panRecyclerView?.layoutManager =
                    GridLayoutManager(this@TESTMainActivityManiya, 2)
            }
            panAdapter?.updateView(useTwoColumns)
        }

    }

    @SuppressLint("InflateParams")
    private fun createMenuPopupWindow() {
        val layoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popupBinding = MainMenuBinding.inflate(layoutInflater)
        /* val popupView: View = layoutInflater.inflate(R.layout.main_menu, null).apply {*/
        popupWindow = PopupWindow(
            popupBinding.root,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        popupWindow!!.setBackgroundDrawable(BitmapDrawable())
        popupWindow!!.isFocusable = true
        popupWindow!!.isOutsideTouchable = true

        llMenuSelect = popupBinding.llMenuSelect
        llMenuSelectAll = popupBinding.llMenuSelectAll
        llMenuDeselectAll = popupBinding.llMenuDeselectAll
        llMenuDelete = popupBinding.llMenuDelete
        llMenuCategory = popupBinding.llMenuCategory
        menuCategory = popupBinding.menuCategory
        ivCategoryCheck = popupBinding.ivCategoryCheck
        menuType = popupBinding.menuType
        ivTypeCheck = popupBinding.ivTypeCheck
        menuLabel = popupBinding.menuLabel
        ivLabelCheck = popupBinding.ivLabelCheck
        menuNoGroup = popupBinding.menuNoGroup
        ivNoGroupCheck = popupBinding.ivNoGroupCheck

        val dismissListener = View.OnClickListener {
            popupWindow!!.dismiss()
        }
        /*SelectMenu*/
        llMenuSelect?.setOnClickListener {
            showSelectionBar()
            dismissListener.onClick(it)
        }
        /*SelectAllMenu*/
        llMenuSelectAll?.setOnClickListener {
            dismissListener.onClick(it)
        }
        /*DeSelectAllMenu*/
        llMenuDeselectAll?.setOnClickListener {
            dismissListener.onClick(it)
        }
        /*DeleteMenu*/
        llMenuDelete?.setOnClickListener {
            dismissListener.onClick(it)
        }
        /*CategoryMenu*/
        menuCategory?.setOnClickListener {
            dismissListener.onClick(it)
        }
        /*TypeMenu*/
        menuType?.setOnClickListener {
            dismissListener.onClick(it)
        }
        /*LabelMenu*/
        menuLabel?.setOnClickListener {
            dismissListener.onClick(it)
        }
        /*NoGroupMenu*/
        menuNoGroup?.setOnClickListener {
            dismissListener.onClick(it)
        }
    }

    private fun locateViewRect(v: View): Rect {
        val locInt = IntArray(2)
        v.getLocationOnScreen(locInt)
        val location = Rect()
        location.left = locInt[0]
        location.top = locInt[1]
        location.right = location.left + v.width
        return location
    }

    fun onMoreMenuIconClick(view: View?) {
        try {
            val anchorRect: Rect = locateViewRect(binding.ivMenu)
            val marginInDp = 30
            val scale = resources.displayMetrics.density
            val marginInPx = (marginInDp * scale + 0.5f).toInt()

            val x: Int = anchorRect.left - marginInPx
            val y: Int = anchorRect.top + marginInPx

            popupWindow!!.showAtLocation(binding.ivMenu, Gravity.TOP, x, y)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun onSearchIconClick(view: View?) {
        showSearchBar()
        // setSearchRecyclerView()
    }

    fun onFabCategoriesIconClick(view: View?) {
        openCategoryWalletActivity()
    }

    fun onNavAddLabelClick(view: View?) {
        closeDrawer()
        openLabelCreateActivity()
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        if (!isSpotlightActive) {
            if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                closeDrawer()
            } else {
                dialogExit()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        //  showNativeAdsSecond()
        if (isNoDataView) {
            startAutoSlide()
        }
    }

    fun closeDrawer() {
        binding.drawerLayout.closeDrawer(GravityCompat.START)
    }

    private fun openBottomDialogOnLongClick(
        itemID: Long,
        catID: Long,
        catName: String,
        frontCardImage: String?,
        backCardImage: String?,
        dataText: String,
        isSoftDeleted: Boolean,
        isArchived: Boolean,
        isFavourite: Boolean,
        labelID: Long,
        position: Int
    ) {

        val bottomSheetDialog = BottomSheetDialog(this@TESTMainActivityManiya)

        val binding = ItemLongclickBottomDialogBinding.inflate(bottomSheetDialog.layoutInflater)
        bottomSheetDialog.setContentView(binding.root)

        binding.root.setBackgroundResource(R.drawable.bottom_sheet_background)

        if (!frontCardImage.isNullOrEmpty())
            Glide.with(binding.ivData.context)
                .load(frontCardImage.toString())
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(binding.ivData)

        binding.tvType.text = catName
        binding.tvDataText.text = dataText


        /*---check Favourite Status-----*/
        if (isFavourite) {
            binding.tvFav.text = "UnFavourite"
            binding.ivFav.setImageResource(R.drawable.menu_unfav)
        } else {
            binding.tvFav.text = "Favourite"
            binding.ivFav.setImageResource(R.drawable.favourite)
        }

        /*---check Archive Status-----*/
        if (isArchived) {
            binding.tvArchive.text = "UnArchive"
            binding.ivArchive.setImageResource(R.drawable.menu_unarchive)
        } else {
            binding.tvArchive.text = "Archive"
            binding.ivArchive.setImageResource(R.drawable.archive)
        }

        /*---check Delete Status-----*/
        if (isSoftDeleted) {
            binding.llShare.alpha = 0.5f
            binding.llShare.isClickable = false

            binding.llFav.alpha = 0.5f
            binding.llFav.isClickable = false

            binding.llEdit.alpha = 0.5f
            binding.llEdit.isClickable = false

            binding.llArchive.alpha = 0.5f
            binding.llArchive.isClickable = false

            binding.llDetails.alpha = 0.5f
            binding.llDetails.isClickable = false

            binding.llLabels.alpha = 0.5f
            binding.llLabels.isClickable = false

            binding.tvDelete.text = getString(R.string.restore_delete)
            binding.ivDelete.setImageResource(R.drawable.meu_restore)
        } else {
            binding.llShare.alpha = 1f
            binding.llShare.isClickable = true

            binding.llFav.alpha = 1f
            binding.llFav.isClickable = true

            binding.llEdit.alpha = 1f
            binding.llEdit.isClickable = true

            binding.llArchive.alpha = 1f
            binding.llArchive.isClickable = true

            binding.llDetails.alpha = 1f
            binding.llDetails.isClickable = true

            binding.llLabels.alpha = 1f
            binding.llLabels.isClickable = true

            binding.tvDelete.text = getString(R.string.delete)
            binding.ivDelete.setImageResource(R.drawable.delete)
        }

        binding.llShare.setOnClickListener {
            if (binding.llShare.alpha == 1f) {
                showShareIntentAll(frontCardImage, backCardImage, "")
                bottomSheetDialog.dismiss()
            }
        }

        binding.llFav.setOnClickListener {
            if (binding.llFav.alpha == 1f) {
                performFADLOperation(catID, "favourite", itemID)
                bottomSheetDialog.dismiss()
            }
        }

        binding.llEdit.setOnClickListener {
            if (binding.llEdit.alpha == 1f) {
                openEditCardActivity(catID, itemID, false)
                bottomSheetDialog.dismiss()
            }
        }

        binding.llDelete.setOnClickListener {
            if (isSoftDeleted) {
                showRestoreDeleteDialog(catID, itemID)
            } else {
                performFADLOperation(catID, "delete", itemID)
            }
            bottomSheetDialog.dismiss()
        }

        binding.llArchive.setOnClickListener {
            if (binding.llArchive.alpha == 1f) {
                performFADLOperation(catID, "archive", itemID)
                bottomSheetDialog.dismiss()
            }
        }

        binding.llDetails.setOnClickListener {
            if (binding.llDetails.alpha == 1f) {
                bottomSheetDialog.dismiss()
            }
        }

        binding.llLabels.setOnClickListener {
            if (binding.llLabels.alpha == 1f) {
                openLabelViewActivity(labelID, catID, itemID)
                bottomSheetDialog.dismiss()
            }
        }
        bottomSheetDialog.show()
    }



    private fun showRestoreDeleteDialog(categoryID: Long, dataID: Long) {
        val dialog = Dialog(this@TESTMainActivityManiya).apply {
            window?.setBackgroundDrawable(ColorDrawable(0))
            setCancelable(true)
            setContentView(
                DialogRestoreBinding.inflate(LayoutInflater.from(context)).apply {
                    llDelete.setOnClickListener {
                        performFADLOperation(categoryID, "permanentDelete", dataID)
                        Toast.makeText(
                            this@TESTMainActivityManiya,
                            getString(R.string.deleted_successfully), Toast.LENGTH_SHORT
                        ).show()
                        dismiss()
                    }
                    llRestore.setOnClickListener {
                        performFADLOperation(categoryID, "delete", dataID)
                        Toast.makeText(
                            this@TESTMainActivityManiya,
                            getString(R.string.restore_completed), Toast.LENGTH_SHORT
                        ).show()
                        dismiss()
                    }
                }.root
            )
        }
        dialog.show()
    }

    private fun performFADLOperation(catID: Long, operationtype: String, itemID: Long) {
        Log.d("Delete+++", itemID.toString())
        when (catID) {
            1L -> {
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softLicenceDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).licenceDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleLicenceArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleLicenceFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleLicenceLock(itemID)
                }
                updateLicenceAdapterData()
            }

            2L -> {
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softPassportDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).passportDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).togglePassportArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).togglePassportFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).togglePassportLock(itemID)
                }
                updatePassportAdapterData()
            }

            3L -> {
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softIDCardDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).idCardDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleIDCardArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleIDCardFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleIDCardLock(itemID)
                }
                updateIDCardAdapterData()
            }

            4L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softResidenceDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).residenceDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleResidenceArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleResidenceFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleResidenceLock(itemID)
                }
                updateResidenceAdapterData()
            }

            5L -> {
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softPaymentDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).paymentDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).togglePaymentArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).togglePaymentFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).togglePaymentLock(itemID)
                }
                updatePaymentAdapterData()
            }

            6L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softGiftDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).giftDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleGiftArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleGiftFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleGiftLock(itemID)
                }

                updateGiftAdapterData()
            }

            7L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softLoyaltyDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).loyaltyDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleLoyaltyArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleLoyaltyFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleLoyaltyLock(itemID)
                }

                updateLoyaltyAdapterData()
            }

            8L -> {


                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softMembershipDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).membershipDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleMembershipArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleMembershipFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleMembershipLock(itemID)
                }

                updateMemberShipAdapterData()
            }

            9L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softMedicalDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).medicalDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleMedicalArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleMedicalFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleMedicalLock(itemID)
                }

                updateMedicalAdapterData()
            }

            10L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softHealthDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).healthDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleHealthArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleHealthFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleHealthLock(itemID)
                }

                updateHealthAdapterData()
            }

            11L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softBirthDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).birthDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleBirthArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleBirthFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleBirthLock(itemID)
                }

                updateBirthAdapterData()
            }

            12L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softMrgDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).mrgDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleMrgArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleMrgFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleMrgLock(itemID)
                }

                updateMrgAdapterData()
            }

            13L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softSIMDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).simDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleSIMArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleSIMFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleSIMLock(itemID)
                }

                updateSIMAdapterData()
            }

            14L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softPasswordDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).passwordDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).togglePasswordArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).togglePasswordFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).togglePasswordLock(itemID)
                }

                updatePasswordAdapterData()
            }

            15L -> {

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softCustomDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).customDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleCustomArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleCustomFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleCustomLock(itemID)
                }
                updateCustomAdapterData()
            }
            16L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).vehicleDelete(itemID)
                }
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softVehicleDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleVehicleArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleVehicleFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleVehicleLock(itemID)
                }
            }
            17L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).adharDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softAdharDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleAdharArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleAdharFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleAdharLock(itemID)
                }
            }
            18L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).voterDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softVoterDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleVoterArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleVoterFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleVoterLock(itemID)
                }
            }
            19L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).panDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softPANDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).togglePANArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).togglePANFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).togglePANLock(itemID)
                }
            }
        }
        updateDrawerData()
    }

    private fun updateLicenceAdapterData() {
        licenseAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchLicenceData())

    }

    private fun updatePaymentAdapterData() {
        paymentAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchPaymentData())
    }

    private fun updatePassportAdapterData() {
        passportAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchPassportData())
    }

    private fun updateIDCardAdapterData() {
        identityAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchIDCardData())
    }

    private fun updateResidenceAdapterData() {
        residenceAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchResidenceCardData())
    }

    private fun updateGiftAdapterData() {
        giftAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchGiftData())
    }

    private fun updateLoyaltyAdapterData() {
        loyaltyAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchLoyaltyData())
    }

    private fun updateMemberShipAdapterData() {
        membershipAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchMemberShipData())
    }

    private fun updateMedicalAdapterData() {
        medicalAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchMedicalData())
    }

    private fun updateHealthAdapterData() {
        healthAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchHealthData())
    }

    private fun updateBirthAdapterData() {
        licenseAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchLicenceData())
    }

    private fun updateMrgAdapterData() {
        mrgAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchMrgData())
    }

    private fun updateSIMAdapterData() {
        simAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchSIMData())
    }

    private fun updatePasswordAdapterData() {
        passwordAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchPasswordData())
    }

    private fun updateCustomAdapterData() {
        customAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchCustomData())
    }
    private fun updateVehicleAdapterData() {
        vehicleAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchVehicleData())
    }
    private fun updateAdharAdapterData() {
        adharAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchAdharData())
    }
    private fun updateVoterAdapterData() {
        voterAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchVoterData())
    }
    private fun updatePanAdapterData() {
        panAdapter?.updateData(DatabaseHelperManiya(this@TESTMainActivityManiya).fetchPANData())
    }

    private fun openCategoryWalletActivity() {
        activityResultLauncher.launch(
            Intent(
                this@TESTMainActivityManiya,
                CategoryWalletActivityManiya::class.java
            )
        )
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    private fun openEditCardActivity(categoryID: Long, itemID: Long, isFromScan: Boolean) {

        activityResultLauncher.launch(
            Intent(this@TESTMainActivityManiya, EditCardActivityManiya::class.java)
                .putExtra("categoryID", categoryID)
                .putExtra("ItemID", itemID)
                .putExtra("isFromScan", false)
        )

    }

    private fun openLabelViewActivity(labelID: Long, catID: Long, itemID: Long) {
        activityResultLauncher.launch(
            Intent(this@TESTMainActivityManiya, LabelViewActivityManiya::class.java)
                .putExtra("labelID", labelID)
                .putExtra("categoryID", catID)
                .putExtra("itemID", itemID)
        )
    }

    private fun openLabelCreateActivity() {
        activityResultLauncher.launch(
            Intent(
                this@TESTMainActivityManiya,
                LabelCreateActivityManiya::class.java
            )
        )
        /*   AdsInterstitial.instance?.open_activity(
               this@TESTMainActivityManiya,
               Intent(this@TESTMainActivityManiya, LabelCreateActivityManiya::class.java)
           )*/
    }

    private fun openCategoryDataActivity(categoryName: String, catID: Long?, titleText: String) {
        activityResultLauncher.launch(
            Intent(this@TESTMainActivityManiya, CategoryDataActivityManiya::class.java)
                /*  .putExtra("category_name", categoryName)*/
                .putExtra("category_id", catID)
                .putExtra("title", titleText)
        )
    }

    private fun openSettingsActivity() {
        activityResultLauncher.launch(
            Intent(
                this@TESTMainActivityManiya,
                SettingActivityManiya::class.java
            )
        )
    }

    private fun openRecordView(itemID: Long, catID: Long, position: Int, isLock: Boolean) {

        /* if(!isUnlockDone){

             if(isUnlockDone){
                 activityResultLauncher.launch( Intent(this@TESTMainActivityManiya, ViewActivityManiya::class.java)
                     .putExtra("categoryID", catID)
                     .putExtra("ItemID", itemID)
                     .putExtra("isFromScan", false))
             }else {

                 if (Build.VERSION.SDK_INT >= 23) {
                     intent = Intent(this@TESTMainActivityManiya, EnterPinActivity::class.java)
                 } else {
                     intent = Intent(this@TESTMainActivityManiya, ReEnterPinActivity::class.java)
                 }
                 intent!!.putExtra("pkgname", this@TESTMainActivityManiya.packageName)
                 intent!!.putExtra("fromLockData", false)
                 activityResultLauncher.launch(intent)
             }

         }else{

             activityResultLauncher.launch( Intent(this@TESTMainActivityManiya, ViewActivityManiya::class.java)
             .putExtra("categoryID", catID)
             .putExtra("ItemID", itemID)
             .putExtra("isFromScan", false))
         }*/

        activityResultLauncher.launch(
            Intent(this@TESTMainActivityManiya, ViewActivityManiya::class.java)
                .putExtra("categoryID", catID)
                .putExtra("ItemID", itemID)
                .putExtra("isFromScan", false)
        )
    }
}



