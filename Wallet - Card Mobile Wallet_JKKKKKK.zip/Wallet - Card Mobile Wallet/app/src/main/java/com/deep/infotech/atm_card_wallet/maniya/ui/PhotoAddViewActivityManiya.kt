package com.deep.infotech.atm_card_wallet.maniya.ui

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageContractOptions
import com.canhub.cropper.CropImageOptions
import com.canhub.cropper.CropImageView
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityPhotoAddViewManiyaBinding
import com.deep.infotech.atm_card_wallet.utils.LogD
import java.io.File
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PhotoAddViewActivityManiya : BaseActivity() {

    private val cropImage = registerForActivityResult(CropImageContract()) { result ->
        if (result.isSuccessful)
        {
            val croppedImageUri=   result.uriContent
            val croppedImageFilePath = result.getUriFilePath(this)
            if (isFrontSelected) {
                tmpFrontImage= moveFile(croppedImageFilePath.toString())
                   // renameFile(croppedImageFilePath.toString(), "wallet_mine_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())+".png")
                Log.e("++TmpFrontImage++", tmpFrontImage)
                if(tmpFrontImage!=""){ Glide.with(this@PhotoAddViewActivityManiya).load(tmpFrontImage).diskCacheStrategy(DiskCacheStrategy.ALL).into(binding.ivFrontPhoto)}
            } else {
                backImage = croppedImageFilePath.toString()
                Log.e("++TmpBbackImage++", backImage)
                tmpBackImage= moveFile(croppedImageFilePath.toString())
                  // renameFile(croppedImageFilePath.toString(), "wallet_mine_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())+".png")
                Log.e("++TmpBackImage++", tmpBackImage)
                if(tmpBackImage!=""){ Glide.with(this@PhotoAddViewActivityManiya).load(tmpBackImage).diskCacheStrategy(DiskCacheStrategy.ALL).into(binding.ivBackPhoto)}
            }
        } else {
            val exception = result.error
        }
    }

    private lateinit var binding: ActivityPhotoAddViewManiyaBinding

    private var frontImage = ""
    private var backImage = ""
    private var  tmpFrontImage = ""
    private var  tmpBackImage = ""
    private var title = ""
    private var sTAG = "PhotoAddViewActivity++++"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoAddViewManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        init()
    }

    fun moveFile(sourceFileUri:String):String {
        var sourceFile= File(sourceFileUri.toString())

        val fileName = "/wallet_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())+".png"
        val destinationFilePath = getFilesDir().absolutePath+fileName
        val destinationFile = File(destinationFilePath)
        if (sourceFile.exists()) {
            destinationFile.parentFile?.mkdirs()
            if (sourceFile.renameTo(destinationFile)) {
                LogD(sTAG, "File moved successfully!")
                if(sourceFile.exists()){
                    sourceFile.delete()
                }
                return destinationFile.absolutePath
            } else {
                LogD(sTAG, "Failed to move the file.")
                return sourceFile.absolutePath
            }
        } else {
            LogD(sTAG, "Source file does not exist.")
            return sourceFile.absolutePath
        }
    }

    private fun init() {
        getIntentData()
        if(frontImage!=""){ Glide.with(this@PhotoAddViewActivityManiya).load(frontImage).diskCacheStrategy(DiskCacheStrategy.ALL).into(binding.ivFrontPhoto)}
        if(backImage!=""){ Glide.with(this@PhotoAddViewActivityManiya).load(backImage).diskCacheStrategy(DiskCacheStrategy.ALL).into(binding.ivBackPhoto)}
    }

    private fun getIntentData() {
        frontImage = intent.getStringExtra("frontImage").toString()
        backImage = intent.getStringExtra("backIMage").toString()
        title = intent.getStringExtra("title").toString()
        binding.tvTitle.text = title
    }

    private fun returnResult() {
        if(tmpFrontImage.isNotEmpty()){
            frontImage = tmpFrontImage
        }
        if(tmpBackImage.isNotEmpty()){
            backImage = tmpBackImage
        }
        val resultIntent = Intent()
        resultIntent.putExtra("frontImage", frontImage)
        resultIntent.putExtra("backImage", backImage)
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    fun onBackClick(view: View) {
        onBackPressed()
    }

    fun onSaveClick(view: View) {
        AdsInterstitial.instance?.showInterstitialAd(
            this@PhotoAddViewActivityManiya,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    returnResult()
                }
            })

    }

    fun onResetPhotosClick(view: View) {
        reseatValue()
    }

    fun reseatValue()
    {
        frontImage = ""
        backImage = ""
        Glide.with(this@PhotoAddViewActivityManiya).load(R.drawable.plus).into(binding.ivFrontPhoto)
        Glide.with(this@PhotoAddViewActivityManiya).load(R.drawable.plus).into(binding.ivBackPhoto)
    }

    fun onClickFrontImage(view: View) {
        isFrontSelected = true
        requestPermission()
    }

    fun onClickBackImage(view: View) {
        isFrontSelected = false
        requestPermission()
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }

    fun requestPermission() {
        val i = Build.VERSION.SDK_INT
        if (i >= 33) {
            if (!hasPermissions(this, *PERMISSIONS33)) {
                requestPermissions(PERMISSIONS33, 100533)
            } else {
                chooseImage()
            }
        } else if (i >= 23) {
            if (!hasPermissions(this, *PERMISSIONS)) {
                requestPermissions(PERMISSIONS, 1005)
            } else {
                chooseImage()
            }
        } else {
            chooseImage()
        }
    }

    private fun chooseImage() {
        val pickPhoto =
            Intent("android.intent.action.PICK", MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        this@PhotoAddViewActivityManiya.startActivityForResult(pickPhoto, 11112222)
    }

    override fun onRequestPermissionsResult(i: Int, strArr: Array<String>, iArr: IntArray) {
        super.onRequestPermissionsResult(i, strArr, iArr)
        if (i == 1005) {
            val length = strArr.size
            var c = 0.toChar()
            for (i2 in 0 until length) {
                val str = strArr[i2]
                if (iArr[i2] == -1) {
                    if (Build.VERSION.SDK_INT < 23 || !shouldShowRequestPermissionRationale(str)) {
                        show_alert()
                        c = 2.toChar()
                        break
                    }
                    c = 1.toChar()
                }
            }
            if (c.code == 1) {
                ActivityCompat.requestPermissions(this, PERMISSIONS, 1005)
            } else if (c.code == 0) {
                chooseImage()
            }
        }
        if (i == 100533) {
            val length2 = strArr.size
            var c2 = 0.toChar()
            for (i22 in 0 until length2) {
                val str2 = strArr[i22]
                if (iArr[i22] == -1) {
                    if (Build.VERSION.SDK_INT < 23 || !shouldShowRequestPermissionRationale(str2)) {
                        show_alert()
                        c2 = 2.toChar()
                        break
                    }
                    c2 = 1.toChar()
                }
            }
            if (c2.code == 1) {
                ActivityCompat.requestPermissions(this, PERMISSIONS33, 100533)
            } else if (c2.code == 0) {
                chooseImage()
            }
        }
    }

    fun show_alert() {
        val builder = AlertDialog.Builder(this)
        builder.setMessage("This application requires permission. Please ensure that this is enabled in settings, then press the back button to continue ")
        builder.setCancelable(false)
        builder.setPositiveButton("OK", object : DialogInterface.OnClickListener {
            override fun onClick(dialogInterface: DialogInterface, i: Int) {
                val intent = Intent("android.settings.APPLICATION_DETAILS_SETTINGS")
                intent.data =
                    Uri.fromParts("package", this@PhotoAddViewActivityManiya.packageName, null)
                this@PhotoAddViewActivityManiya.startActivityForResult(intent, 1005)
                mMyDialog!!.dismiss()
            }
        })
        mMyDialog = builder.show()
    }

    public override fun onActivityResult(i: Int, i2: Int, intent: Intent?) {
        super.onActivityResult(i, i2, intent)
        if (i == 11112222) {
            if (i2 == -1) {
                Log.e("++++", "---resultCode == -1--")
                cropImage.launch(
                    CropImageContractOptions(
                        uri = intent!!.data,
                        cropImageOptions = CropImageOptions(
                            guidelines = CropImageView.Guidelines.ON,
                            outputCompressFormat = Bitmap.CompressFormat.PNG
                        )
                    )
                )

            }
        } else {
            if (i == CAMERA_REQUEST && i2 == -1) {
                cropImage.launch(
                    CropImageContractOptions(
                        uri = intent!!.data,
                        cropImageOptions = CropImageOptions(
                            guidelines = CropImageView.Guidelines.ON,
                            outputCompressFormat = Bitmap.CompressFormat.PNG
                        )
                    )
                )
            }
            if (i == 203) {
                Log.e("++++", "--203---")
            }
        }
    }

    companion object {
        private val CAMERA_REQUEST = 1888
        var cropPath: String? = null
        var destination_crop: File? = null
        var photo_click_activity: Activity? = null
        var PERMISSIONS = arrayOf("android.permission.CAMERA", "android.permission.WRITE_EXTERNAL_STORAGE")
        var PERMISSIONS33 = arrayOf("android.permission.CAMERA")
        var isFrontSelected = false
        var mMyDialog: AlertDialog? = null

        private fun hasPermissions(context: Context?, vararg strArr: String): Boolean {
            val i = Build.VERSION.SDK_INT
            if (i >= 33) {
                if ((i >= 23) && (context != null) && (strArr != null)) {
                    for (str: String in strArr) {
                        if (ContextCompat.checkSelfPermission(context, str) != 0) {
                            return false
                        }
                    }
                }
                return true
            }
            if ((i >= 23) && (context != null) && (strArr != null)) {
                for (str2: String in strArr) {
                    if (ContextCompat.checkSelfPermission(context, str2) != 0) {
                        return false
                    }
                }
            }
            return true
        }

        fun renameFile(currentPath: String, newName: String): String {
            val currentFile = File(currentPath)
            val newFile = File(currentFile.parent, newName)
            if (currentFile.renameTo(newFile)) {
                return newFile.absolutePath.toString()
            } else return newFile.absolutePath.toString()

        }

    }

}




