package com.deep.infotech.atm_card_wallet.maniya.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.model.CardData

class SearchWalletAdapter(
    private val context: Context,
    private val items: MutableList<CardData>,
    private var useTwoColumns: Boolean,
    private val onItemClick: (CardData, Int) -> Unit
) : RecyclerView.Adapter<SearchWalletAdapter.MyViewHolder>() {
    private var filteredItems: List<CardData> = items
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)
    {
        private val tvDataNM: TextView = itemView.findViewById(R.id.tvDataNM)
        private val tvDataText: TextView = itemView.findViewById(R.id.tvDataText)
        private val selectionIcon: ImageView = itemView.findViewById(R.id.ivSelection)
        private val ivData: ImageView = itemView.findViewById(R.id.ivData)
        fun bind(item: CardData, position: Int, context: Context)
        {
            Log.d("++++CardImage++++", "------${item.frontCardImage}---")
            selectionIcon.visibility = View.GONE
            tvDataNM.text = item.title
            tvDataText.text = item.text

            if (!item.frontCardImage.isNullOrEmpty()){
                Glide.with(context)
                    .load(item.frontCardImage)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(ivData)}

        }
    }

    override fun onCreateViewHolder( parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutId = if (useTwoColumns) R.layout.item_search_grid_two else R.layout.item_search_grid_one
        val view = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder( holder: MyViewHolder, position: Int) {
        val item = filteredItems[position]
        holder.bind(item,position,context)
        holder.itemView.setOnClickListener { v: View? ->
            onItemClick(item, position)
        }
    }

    override fun getItemCount(): Int {
        return filteredItems.size
    }

    @SuppressLint("NotifyDataSetChanged")
    fun filter(query: String) {
        filteredItems = if (query.isEmpty()) {
            items
        } else {
            items.filter { it.categoryName?.contains(query, ignoreCase = true)!!
                         || it.label?.contains(query, ignoreCase = true)!!
                         || it.title?.contains(query, ignoreCase = true)!!
                         || it.text?.contains(query, ignoreCase = true)!!
            }
        }
        notifyDataSetChanged()
    }
    @SuppressLint("NotifyDataSetChanged")
    fun updateView(isTwoColumns: Boolean) {
        useTwoColumns = isTwoColumns
        notifyDataSetChanged()
    }

}