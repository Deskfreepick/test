package com.deep.infotech.atm_card_wallet.Ads

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.OnLifecycleEvent
import androidx.lifecycle.ProcessLifecycleOwner
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.App_Open
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.App_Open_1
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.App_Open_id
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.when_click_ads
import com.deep.infotech.atm_card_wallet.maniya.ui.TESTMainActivityManiya
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.CreatePinActivity
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.EnterPinActivity
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.ReEnterPinActivity
import com.deep.infotech.atm_card_wallet.utils.LogD
import com.deep.infotech.atm_card_wallet.utils.LogE
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.ump.ConsentInformation
import java.util.Date

class AdsOpenApp(
    myApplication: Activity?, progressBar: LinearLayout, var sharedPreferences: SharedPreferences?
) : Application.ActivityLifecycleCallbacks, LifecycleObserver {

    private var appOpenAd: AppOpenAd? = null
    private var activity: Activity? = null
    private var boolean_showAd = false
    private var ad_loadTime: Long = 0
    private var fb_adShow = true
    var linearLayout: LinearLayout

    init {
        activity = myApplication
        this.linearLayout = progressBar
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    fun onStart() {
        activity?.let {
            LogD(LOG_TAG, "when_click_ads____" + when_click_ads)
            if (when_click_ads) {
                showAdIfAvailable(activity!!)
            } else {
                when_click_ads = true
            }
        }

        LogD(LOG_TAG, "onStart")
    }


    fun fetchAd() {
        LogD(LOG_TAG, "isAdAvailable_____fetchAd" + isAdAvailable())
        if (isAdAvailable()) {
            return
        }

        val builder = AdRequest.Builder()
        val request = GDPRChecker.status
        if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
            val extras = Bundle()
            extras.putString("npa", "1")
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        if (!verifyForTest(activity!!)) {
            App_Open_id = "/6499/example/app-open"
        }
        AppOpenAd.load(activity!!,
            App_Open_id!!,
            builder.build(),
            AppOpenAd.APP_OPEN_AD_ORIENTATION_PORTRAIT,
            object : AppOpenAd.AppOpenAdLoadCallback() {

                override fun onAdLoaded(ad: AppOpenAd) {
                    LogD(LOG_TAG, "Ad was loaded.")
                    appOpenAd = ad

                    ad_loadTime = Date().time
                    if (fb_adShow) {
                        showAdIfAvailable(activity!!)
                        linearLayout.visibility = View.GONE
                        fb_adShow = false
                    }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    if (App_Open_id == App_Open) {
                        App_Open_id = App_Open_1


                        AdsOpenApp(activity!!, linearLayout, sharedPreferences)
                    } else {
                        activity!!.getSharedPreferences("openApp", 0).edit()
                            .putBoolean("isFirstRun", false).apply()

                        if (AdsIDS.IDS_Activity_OPEN!!) {
                            AdsIDS.IDS_Activity_OPEN = false

                            if (sharedPreferences!!.getBoolean("appLockIsCheck", false)) {

                                if (sharedPreferences!!.getBoolean("first time", true)) {
                                    activity!!.startActivity(
                                        Intent(
                                            activity, CreatePinActivity::class.java
                                        )
                                    )
                                } else {
                                    val intent: Intent = if (Build.VERSION.SDK_INT >= 23) {
                                        Intent(
                                            activity, EnterPinActivity::class.java
                                        )
                                    } else {
                                        Intent(
                                            activity, ReEnterPinActivity::class.java
                                        )
                                    }

                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    intent.putExtra("pkgname", activity!!.packageName)
                                    activity!!.startActivity(intent)
                                    activity!!.finish()
                                }

                            } else {
                                /*if (activity!!.getSharedPreferences("language", 0).getBoolean(
                                        "isFirstRun", true
                                    )
                                ) {
                                    activity!!.startActivity(
                                        Intent(
                                            activity, LanguageActivity::class.java
                                        )
                                    )
                                    activity!!.finish()
                                } else*/ /*if (AdsIDS.start_screen_show) {
                                    activity!!.startActivity(
                                        Intent(
                                            activity, StartActivity::class.java
                                        )
                                    )
                                    activity!!.finish()
                                } else {*/
                                activity!!.startActivity(
                                    Intent(
                                        /* activity, MainActivity::class.java*/
                                        /*   activity, MainActivityManiya::class.java*/
                                        activity, TESTMainActivityManiya::class.java
                                    )
                                )
                                activity!!.finish()
                                /* }*/
                            }
                            activity!!.finish()
                        }
                    }

                    LogD(LOG_TAG, loadAdError.message)
                }
            })
    }

    fun showAdIfAvailable(activity: Activity) {
        if (boolean_showAd) {
            LogD(LOG_TAG, "The app open ad is already showing.")
            return
        }

        if (!isAdAvailable()) {
            LogD(LOG_TAG, "The app open ad is not ready yet.")

            fetchAd()
            return
        }

        appOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {

            override fun onAdDismissedFullScreenContent() {
                LogD(LOG_TAG, "Ad dismissed fullscreen content.")
                appOpenAd = null
                boolean_showAd = AdsIDS.app_open_repeat_show
                linearLayout.visibility = View.GONE

                LogD(LOG_TAG, "fetchAd________" + " " + AdsIDS.app_open_repeat_show)

                if (!AdsIDS.app_open_repeat_show) {
                    fetchAd()
                }

                activity.getSharedPreferences("openApp", 0).edit().putBoolean("isFirstRun", false)
                    .apply()


                if (AdsIDS.IDS_Activity_OPEN!!) {
                    AdsIDS.IDS_Activity_OPEN = false

                    if (sharedPreferences!!.getBoolean("appLockIsCheck", false)) {

                        if (sharedPreferences!!.getBoolean("first time", true)) {
                            activity.startActivity(
                                Intent(
                                    activity,
                                    CreatePinActivity::class.java
                                )
                            )
                        } else {
                            val intent: Intent = if (Build.VERSION.SDK_INT >= 23) {
                                Intent(
                                    activity,
                                    EnterPinActivity::class.java
                                )
                            } else {
                                Intent(
                                    activity,
                                    ReEnterPinActivity::class.java
                                )
                            }

                            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            intent.putExtra("pkgname", activity.packageName)
                            activity.startActivity(intent)
                            activity.finish()
                        }

                    } else {
                        /* if (activity.getSharedPreferences("language", 0).getBoolean(
                                 "isFirstRun",
                                 true
                             )
                         ) {
                             activity.startActivity(
                                 Intent(
                                     activity,
                                     LanguageActivity::class.java
                                 )
                             )
                             activity.finish()
                         } else*/ /*if (AdsIDS.start_screen_show) {
                            activity.startActivity(
                                Intent(
                                    activity,
                                    StartActivity::class.java
                                )
                            )
                            activity.finish()
                        } else {*/
                        activity.startActivity(
                            Intent(
                                activity,
                                /*MainActivity::class.java*/
                                /*  MainActivityManiya::class.java*/
                                TESTMainActivityManiya::class.java
                            )
                        )
                        activity.finish()
                        /*  }*/
                    }
                    activity.finish()
                }
            }

            override fun onAdFailedToShowFullScreenContent(adError: AdError) {

                LogD(LOG_TAG, adError.message)
                appOpenAd = null
                boolean_showAd = false
                fetchAd()
            }

            override fun onAdShowedFullScreenContent() {
                // Called when fullscreen content is shown.
                LogD(LOG_TAG, "Ad showed fullscreen content.")
            }
        }
        boolean_showAd = true
        appOpenAd?.show(activity)
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityStarted(activity: Activity) {
        this.activity = activity
    }

    override fun onActivityResumed(activity: Activity) {
        this.activity = activity

        LogD(LOG_TAG, "App_Resume____$activity")
    }

    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {
        this.activity = null
    }

    private fun wasLoadTimeLessThanNHoursAgo(numHours: Long): Boolean {
        val dateDifference = Date().time - ad_loadTime
        val numMilliSecondsPerHour: Long = 3600000
        return dateDifference < numMilliSecondsPerHour * numHours
    }

    private fun isAdAvailable(): Boolean {
        return appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
    }

    companion object {
        private const val LOG_TAG = "ADOpenApp++++"
        fun verifyForTest(context: Context): Boolean {
            try {
                val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                return pInfo.versionName!!.matches("[0-9][0-9.]*[0-9]".toRegex())
            } catch (e: Exception) {
                LogE("verifyForTest++++", "verifyForTest: Error" + e.message)
                return false
            }
        }
    }
}