package com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya
import jp.wasabeef.blurry.Blurry

class PaymentAdapter(
    private var context: Context,
    private var items: MutableList<PaymentCardScanDataManiya>,
    private var useTwoColumns: Boolean,
    private val onItemClick: (PaymentCardScanDataManiya, Int) -> Unit,
    private val onItemLongClick: (PaymentCardScanDataManiya, Int) -> Boolean

) : RecyclerView.Adapter<PaymentAdapter.MyViewHolder>() {


    private var filteredItems: List<PaymentCardScanDataManiya> = items
    private val selectedItems = mutableSetOf<PaymentCardScanDataManiya>()
    var isSelectionMode = false

    @SuppressLint("NotifyDataSetChanged")
    fun updateView(isTwoColumns: Boolean) {
        useTwoColumns = isTwoColumns
        notifyDataSetChanged()
    }
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvDataNM: TextView = itemView.findViewById(R.id.tvDataNM)
        private val tvDataText: TextView = itemView.findViewById(R.id.tvDataText)
        private val selectionIcon: ImageView = itemView.findViewById(R.id.ivSelection)
        private val ivData: ImageView = itemView.findViewById(R.id.ivData)
        private val ivFav: ImageView = itemView.findViewById(R.id.ivFav)



        fun bind(item: PaymentCardScanDataManiya, position:Int, isSelected: Boolean, isSelectionMode: Boolean) {

            if (!item.holderName.isNullOrEmpty())
            {
                tvDataNM.text = item.holderName
                tvDataNM.visibility =View.VISIBLE

            }else{
                tvDataNM.visibility =View.GONE
            }

            if (!item.cardNumber.isNullOrEmpty())
            {
                tvDataText.text = item.cardNumber
                tvDataText.visibility =View.VISIBLE

            }else{
                tvDataText.visibility =View.GONE
            }
            ivFav.visibility = if (item.isFav) View.VISIBLE else View.GONE

            selectionIcon.visibility = if (isSelectionMode) View.VISIBLE else View.GONE
            if (!item.frontCardImage.isNullOrEmpty())
            { if(item.isSensitive){
                Glide.with(ivData.context)
                    .asBitmap()
                    .load(item.frontCardImage)
                    .into(/* target = */ object : SimpleTarget<Bitmap>() {
                        override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                            Blurry.with(ivData.context)
                                .from(resource)
                                .into(ivData)
                        }
                    })
            }else{
                Glide.with(ivData.context).load(item.frontCardImage.toString()).into(ivData)
            }
            }

           /* selectionIcon.setImageResource(if (isSelectionMode) R.drawable.round_item_selected else R.drawable.round_item_deselected)*/
        }
    }

    override fun onCreateViewHolder( parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutId = if (useTwoColumns) R.layout.test_item_grid_two else R.layout.test_item_categories_maniya2

     //  val layoutId = if (useTwoColumns) R.layout.test_item_categories_maniya2 else R.layout.test_item_categories_maniya
        val view = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val item = filteredItems[position]
        val isSelected = selectedItems.contains(item)
        holder.bind(item,position,isSelected, isSelectionMode)

        holder.itemView.setOnClickListener { v: View? ->
            onItemClick(item, position)
        }

        holder.itemView.setOnLongClickListener {
            onItemLongClick(item, position)
        }

    }

    override fun getItemCount(): Int {
        if (filteredItems.size>4){
            return  4
        }else{
            return filteredItems.size}
    }

    fun filter(query: String) {
        filteredItems = if (query.isEmpty()) {
            items
        } else {
            items.filter { it.holderName.contains(query, ignoreCase = true) || it.cardNumber.contains(query, ignoreCase = true) }
        }
        updateData(filteredItems)
       // notifyDataSetChanged()
    }

    // Update data in real-time
    fun updateData(newItems: List<PaymentCardScanDataManiya>) {
        items = newItems.toMutableList()
        filteredItems = newItems
        notifyDataSetChanged()
    }




}