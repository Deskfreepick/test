package com.deep.infotech.atm_card_wallet.Ads

import android.app.Activity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RelativeLayout
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.fb_native_show_ads
import com.deep.infotech.atm_card_wallet.Ads.GDPRChecker.Companion.status
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.utils.LogD
import com.deep.infotech.atm_card_wallet.utils.LogE
import com.facebook.ads.Ad
import com.facebook.ads.AdError
import com.facebook.ads.AdOptionsView
import com.facebook.ads.NativeAdLayout
import com.facebook.ads.NativeAdListener
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.VideoOptions
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.ump.ConsentInformation

class NativeAds {
    private var loadNativeAd: NativeAd? = null
    var fbNative: com.facebook.ads.NativeAd? = null

    companion object {
        val nativeAds = NativeAds()
        private const val LOG_TAG = "AdNative++++"

    }

    fun nativeAdsLode(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        LogD(LOG_TAG,"---IS..fb_native_show_ads??--"+fb_native_show_ads)
            if (!fb_native_show_ads) {
                loadFBNativeAd(
                    activity,
                    fbNativeAdLayout,
                    frameLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )

            } else {
                loadADMOBNativeAd(
                    activity,
                    frameLayout,
                    fbNativeAdLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
            }

    }

    private fun loadADMOBNativeAd(
        activity: Activity?,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {

        val adIds = listOf(ad_native, re_ad_native, fb_ad_native)
      /*  val adIds: List<String>

        if(!verifyForTest(activity!!)){
            adIds = listOf("/6499/example/app-native", "/6499/example/app-nativeyu", fb_ad_native)
        } else {
            adIds = listOf(ad_native, re_ad_native, fb_ad_native)
        }*/

        val videoOptions = VideoOptions.Builder().setStartMuted(true).build()
        val adOptions = NativeAdOptions.Builder().setVideoOptions(videoOptions).build()

        var currentAdIndex = 0

        fun loadAd() {
            if (currentAdIndex >= adIds.size) {
                relativeLayout.visibility = View.GONE
                LogD(LOG_TAG, "All ads failed to load.")
                return
            }

            val adLoader = AdLoader.Builder(activity!!, adIds[currentAdIndex])
                .forNativeAd { ad: NativeAd ->
                    loadNativeAd = ad
                    showNativeAdView(
                        activity,
                        frameLayout,
                        fbNativeAdLayout,
                        shimmerFrameLayout,
                        relativeLayout,
                        ad_native,
                        re_ad_native,
                        fb_ad_native
                    )
                    LogD(LOG_TAG, "Ad loaded successfully for ID: ${adIds[currentAdIndex]}")
                }
                .withAdListener(object : AdListener() {
                    override fun onAdFailedToLoad(adError: LoadAdError) {
                        LogD(
                            LOG_TAG,
                            "Ad failed to load for ID: ${adIds[currentAdIndex]} - ${adError.message}"
                        )
                        currentAdIndex++

                        if (fb_native_show_ads) {

                            loadFBNativeAd(
                                activity,
                                fbNativeAdLayout,
                                frameLayout,
                                shimmerFrameLayout,
                                relativeLayout,
                                ad_native,
                                re_ad_native,
                                fb_ad_native
                            )

                        } else {
                            if (currentAdIndex < adIds.size - 1) {
                                relativeLayout.visibility = View.VISIBLE
                                /*   relativeLayout.visibility = View.VISIBLE*/
                                LogD(LOG_TAG, "----In loadAd()----")
                                loadAd()
                            } else {
                                relativeLayout.visibility = View.GONE
                            }
                        }
                    }
                })
                .withNativeAdOptions(adOptions)
                .build()

            val builder = AdRequest.Builder()
            val request = status
            if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
                val extras = Bundle()
                extras.putString("npa", "1")
                builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
            }
            adLoader.loadAd(builder.build())
        }

        loadAd()
    }

    private fun loadFBNativeAd(
        activity: Activity,
        fb_nativeAdLayout: NativeAdLayout,
        frameLayout: FrameLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {

        val nativeAd = activity.let { com.facebook.ads.NativeAd(it, fb_ad_native) }
        val nativeAdListener = object : NativeAdListener {
            override fun onMediaDownloaded(ad: Ad) {
                LogE(LOG_TAG, "Native ad finished downloading all assets.")
            }

            override fun onError(ad: Ad, adError: AdError) {
                LogE(LOG_TAG, "Error loading Facebook ad: ${adError.errorMessage}")

                if (fb_native_show_ads) {
                    loadADMOBNativeAd(
                        activity,
                        frameLayout,
                        fb_nativeAdLayout,
                        shimmerFrameLayout,
                        relativeLayout,
                        ad_native,
                        re_ad_native,
                        fb_ad_native
                    )
                } else {
                    relativeLayout.visibility = View.GONE
                }
            }

            override fun onAdLoaded(ad: Ad) {
                fbNative = nativeAd
                shimmerFrameLayout.stopShimmer()
                shimmerFrameLayout.visibility = View.GONE
                showNativeAdView(
                    activity,
                    frameLayout,
                    fb_nativeAdLayout,
                    shimmerFrameLayout,
                    relativeLayout,
                    ad_native,
                    re_ad_native,
                    fb_ad_native
                )
                LogD(LOG_TAG, "Native ad is loaded and ready to be displayed!")
            }

            override fun onAdClicked(ad: Ad) {
                LogD(LOG_TAG, "Native ad clicked!")
            }

            override fun onLoggingImpression(ad: Ad) {
                LogD(LOG_TAG, "Ad impression logged.")
            }
        }

        // Load the ad
        nativeAd.loadAd(nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build())
    }

    private fun showNativeAdView(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (fb_native_show_ads) {
            showFbNative(
                activity,
                fbNativeAdLayout,
                frameLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        } else {
            showAdmobNativeAd(
                activity,
                frameLayout,
                fbNativeAdLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }


    private fun showFbNative(
        activity: Activity,
        fbNativeAdLayout: NativeAdLayout,
        frameLayout: FrameLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (fbNative != null) {
            frameLayout.visibility = View.GONE
            shimmerFrameLayout.visibility = View.GONE
            fbNativeAdLayout.visibility = View.VISIBLE

            val inflater = LayoutInflater.from(activity)
            val adView = inflater.inflate(R.layout.ad_native_fb_layout, fbNativeAdLayout, false) as RelativeLayout
            fbNativeAdLayout.addView(adView)
            val adChoicesContainer = adView.findViewById<LinearLayout>(R.id.ad_choices_container)
            val adOptionsView = AdOptionsView(activity, fbNative!!, fbNativeAdLayout)
            adChoicesContainer.removeAllViews()
            adChoicesContainer.addView(adOptionsView, 0)
            FbNativeLayout().inflateAd(fbNative!!, adView)
        } else {
            showFBafterAdmobNative(
                activity,
                frameLayout,
                fbNativeAdLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }

    private fun showFBafterAdmobNative(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (loadNativeAd != null) {
            val adView = activity.layoutInflater.inflate(R.layout.ad_unified, null) as NativeAdView
            NativeInflateAds.instance?.Admob_Native_placement(
                activity, loadNativeAd!!, adView
            )
            frameLayout.visibility = View.VISIBLE
            shimmerFrameLayout.visibility = View.GONE
            fbNativeAdLayout.visibility = View.GONE
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
            loadFBNativeAd(
                activity,
                fbNativeAdLayout,
                frameLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }

    private fun showADMOBafterFBNative(
        activity: Activity,
        fbNativeAdLayout: NativeAdLayout,
        frameLayout: FrameLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (fbNative != null) {
            frameLayout.visibility = View.GONE
            shimmerFrameLayout.visibility = View.GONE
            fbNativeAdLayout.visibility = View.VISIBLE
            val inflater = LayoutInflater.from(activity)
            val adView = inflater.inflate(
                R.layout.ad_native_fb_layout, fbNativeAdLayout, false
            ) as RelativeLayout
            fbNativeAdLayout.addView(adView)
            val adChoicesContainer = adView.findViewById<LinearLayout>(R.id.ad_choices_container)
            val adOptionsView = AdOptionsView(activity, fbNative!!, fbNativeAdLayout)
            adChoicesContainer.removeAllViews()
            adChoicesContainer.addView(adOptionsView, 0)
            FbNativeLayout().inflateAd(fbNative!!, adView)
            loadADMOBNativeAd(
                activity,
                frameLayout,
                fbNativeAdLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }


    private fun showAdmobNativeAd(
        activity: Activity,
        frameLayout: FrameLayout,
        fbNativeAdLayout: NativeAdLayout,
        shimmerFrameLayout: ShimmerFrameLayout,
        relativeLayout: RelativeLayout,
        ad_native: String,
        re_ad_native: String,
        fb_ad_native: String
    ) {
        if (loadNativeAd != null) {
            val adView =
                activity.layoutInflater.inflate(R.layout.ad_unified, null) as NativeAdView
            NativeInflateAds.instance?.Admob_Native_placement(
                activity,
                loadNativeAd!!,
                adView
            )
            frameLayout.visibility = View.VISIBLE
            shimmerFrameLayout.visibility = View.GONE
            fbNativeAdLayout.visibility = View.GONE
            frameLayout.removeAllViews()
            frameLayout.addView(adView)
        } else {
            showADMOBafterFBNative(
                activity,
                fbNativeAdLayout,
                frameLayout,
                shimmerFrameLayout,
                relativeLayout,
                ad_native,
                re_ad_native,
                fb_ad_native
            )
        }
    }

}

