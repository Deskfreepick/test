package com.deep.infotech.atm_card_wallet.maniya.adapter.catAdapter

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya
import jp.wasabeef.blurry.Blurry

class IDCardAdapter(
    private var context: Context,
    private var items: MutableList<IdentityScanDataManiya>,
    private var useTwoColumns: Boolean,
    private val onItemClick: (IdentityScanDataManiya, Int) -> Unit,
    private val onItemLongClick: (IdentityScanDataManiya, Int) -> Boolean
) : RecyclerView.Adapter<IDCardAdapter.MyViewHolder>() {

    @SuppressLint("NotifyDataSetChanged")
    fun updateView(isTwoColumns: Boolean) {
        useTwoColumns = isTwoColumns
        notifyDataSetChanged()
    }

    private var filteredItems: List<IdentityScanDataManiya> = items
    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvDataNM: TextView = itemView.findViewById(R.id.tvDataNM)
        private val tvDataText: TextView = itemView.findViewById(R.id.tvDataText)
        private val ivData: ImageView = itemView.findViewById(R.id.ivData)
        private val ivFav: ImageView = itemView.findViewById(R.id.ivFav)


        fun bind(item: IdentityScanDataManiya, position:Int) {


            if (!item.fullName.isNullOrEmpty())
            {
                tvDataNM.text = item.fullName
                tvDataNM.visibility =View.VISIBLE

            }else{
                tvDataNM.visibility =View.GONE
            }

            if (!item.documentNumber.isNullOrEmpty())
            {
                tvDataText.text = item.documentNumber
                tvDataText.visibility =View.VISIBLE

            }else{
                tvDataText.visibility =View.GONE
            }
            ivFav.visibility = if (item.isFav) View.VISIBLE else View.GONE

            if (!item.frontCardImage.isNullOrEmpty())
            { if(item.isSensitive){
                Glide.with(ivData.context)
                    .asBitmap()
                    .load(item.frontCardImage)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(/* target = */ object : SimpleTarget<Bitmap>() {
                        override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                            Blurry.with(ivData.context)
                                .from(resource)
                                .into(ivData)
                        }
                    })
            }else{
                Glide.with(ivData.context)
                    .load(item.frontCardImage.toString())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(ivData)
            }

            }


           /* selectionIcon.setImageResource(if (isSelectionMode) R.drawable.round_item_selected else R.drawable.round_item_deselected)*/
        }
    }

    override fun onCreateViewHolder( parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutId = if (useTwoColumns) R.layout.test_item_grid_two else R.layout.test_item_categories_maniya2

       // val layoutId = if (useTwoColumns) R.layout.test_item_categories_maniya2 else R.layout.test_item_categories_maniya
        val view = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val item = filteredItems[position]
        holder.bind(item,position)

        holder.itemView.setOnClickListener {
            onItemClick(item, position)
        }

        holder.itemView.setOnLongClickListener {
            onItemLongClick(item, position)
        }

    }

    override fun getItemCount(): Int {
        if (filteredItems.size>4){
          return  4
        }else{
        return filteredItems.size}
    }

    fun filter(query: String) {
        filteredItems = if (query.isEmpty()) {
            items
        } else {
            items.filter { it.fullName.contains(query, ignoreCase = true) || it.documentNumber.contains(query, ignoreCase = true) }
        }
        notifyDataSetChanged()
    }

    fun updateData(fetchIDCardData: MutableList<IdentityScanDataManiya>) {
        items = fetchIDCardData.toMutableList()
        filteredItems = fetchIDCardData
        notifyDataSetChanged()

    }

}