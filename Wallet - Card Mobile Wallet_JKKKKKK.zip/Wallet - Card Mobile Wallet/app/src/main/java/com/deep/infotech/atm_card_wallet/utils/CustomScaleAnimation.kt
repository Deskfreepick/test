package com.deep.infotech.bank_info_locker.LockOption.Utils

import android.content.Context
import android.util.AttributeSet
import android.view.animation.ScaleAnimation
import android.view.animation.Transformation

class CustomScaleAnimation : ScaleAnimation {
    var isCanceled = false
        private set
    var lastInterpolatedTime = 0f
        private set

    constructor(context: Context?, attributeSet: AttributeSet?) : super(context, attributeSet) {

    }
    constructor(f: Float, f2: Float, f3: Float, f4: Float) : super(f, f2, f3, f4) {

    }

    constructor(f: Float, f2: Float, f3: Float, f4: Float, f5: Float, f6: Float) : super(
        f,
        f2,
        f3,
        f4,
        f5,
        f6
    )

    constructor(
        f: Float,
        f2: Float,
        f3: Float,
        f4: Float,
        i: Int,
        f5: Float,
        i2: Int,
        f6: Float
    ) : super(f, f2, f3, f4, i, f5, i2, f6) {
    }

    public override fun applyTransformation(f: Float, transformation: Transformation) {
        lastInterpolatedTime = f
        super.applyTransformation(f, transformation)
    }

    override fun cancel() {
        isCanceled = true
        super.cancel()
    }

    override fun setStartTime(j: Long) {
        isCanceled = false
        super.setStartTime(j)
    }
}