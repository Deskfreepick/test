package com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen

import android.annotation.SuppressLint
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.hardware.fingerprint.FingerprintManager
import android.os.Build
import android.os.Build.VERSION
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import androidx.annotation.RequiresApi
import androidx.core.app.ActivityCompat
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityOldPinBinding
import com.deep.infotech.atm_card_wallet.maniya.ui.BaseActivity
import java.io.IOException
import java.security.InvalidAlgorithmParameterException
import java.security.InvalidKeyException
import java.security.KeyStore
import java.security.KeyStoreException
import java.security.NoSuchAlgorithmException
import java.security.NoSuchProviderException
import java.security.UnrecoverableKeyException
import java.security.cert.CertificateException
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.NoSuchPaddingException
import javax.crypto.SecretKey

class OldPinLockActivity : BaseActivity() {

    var keyPadLockedFlag = false
    var pinBoxArray: Array<ImageView?>? = arrayOfNulls(4)
    var pk: String? = null
    var sharedPreferences: SharedPreferences? = null
    private var shake: Animation? = null
    var userEntered: String = ""

    private var cipher: Cipher? = null
    private var fingerprintManager: FingerprintManager? = null
    private var keyStore: KeyStore? = null
    private var keyguardManager: KeyguardManager? = null

    private lateinit var binding: ActivityOldPinBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOldPinBinding.inflate(layoutInflater)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE
        )
        setContentView(binding.root)
        updateWindow()
        initData()

    }
    fun initData() {
        pk = intent.getStringExtra("pkgname")
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        shake = AnimationUtils.loadAnimation(this, R.anim.shake)

        pinBoxArray?.let {
            it[0]= binding.pinBox0
            it[1] = binding.pinBox1
            it[2] = binding.pinBox2
            it[3]= binding.pinBox3
        }
    }
    fun onClickDeleteNumeric(view: View) {
        if (!keyPadLockedFlag && userEntered.isNotEmpty()) {
            val pin = this@OldPinLockActivity
            pin.userEntered = pin.userEntered.substring(0, userEntered.length - 1)
            pinBoxArray!![userEntered.length]!!.setImageResource(R.drawable.selected_border)
        }
    }
    fun onClickNumeric(view: View) {
        if (!keyPadLockedFlag) {
            if (userEntered.length < 4) {
                val pin = this@OldPinLockActivity
                pin.userEntered = userEntered + getViewNumericDigit(view)
                pinBoxArray!![userEntered.length - 1]!!.setImageResource(R.drawable.unselect_round)
                if (userEntered.length == sharedPreferences!!.getString(
                        "pin",
                        "0000"
                    )!!.length
                ) {
                    if (userEntered == sharedPreferences!!.getString("pin", "0000")) {
                        if (pk == this@OldPinLockActivity.packageName) {
                            this@OldPinLockActivity.startActivity(
                                Intent(
                                    this@OldPinLockActivity.applicationContext,
                                    com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.CreatePinActivity::class.java
                                )
                            )
                            finish()
                        }
                        val edit = sharedPreferences!!.edit()
                        edit.putBoolean(pk + "pattern", false)
                        edit.apply()
                        edit.apply()
                        finish()
                        this@OldPinLockActivity.overridePendingTransition(
                            R.anim.fade_in, R.anim.fade_out
                        )
                    } else {
                        binding.sk.startAnimation(shake)
                        keyPadLockedFlag = true
                        resetKeypadUI()
                    }
                }
            } else {

                pinBoxArray?.let {
                    it[0]?.setImageResource(R.drawable.selected_border)
                    it[1]?.setImageResource(R.drawable.selected_border)
                    it[2]?.setImageResource(R.drawable.selected_border)
                    it[3]?.setImageResource(R.drawable.selected_border)
                }


                userEntered = ""
                val pin2 = this@OldPinLockActivity
                pin2.userEntered = userEntered + getViewNumericDigit(view)
                Log.v("PinView", "User entered=$userEntered")
                pinBoxArray!![userEntered.length - 1]!!.setImageResource(R.drawable.unselect_round)
            }
        }
    }
    fun getViewNumericDigit(view: View): String? {
        if (view.id == R.id.button0) {
            return "0"
        }
        if (view.id == R.id.button1) {
            return "1"
        }
        if (view.id == R.id.button2) {
            return "2"
        }
        if (view.id == R.id.button3) {
            return "3"
        }
        if (view.id == R.id.button4) {
            return "4"
        }
        if (view.id == R.id.button5) {
            return "5"
        }
        if (view.id == R.id.button6) {
            return "6"
        }
        if (view.id == R.id.button7) {
            return "7"
        }
        if (view.id == R.id.button8) {
            return "8"
        }
        return if (view.id == R.id.button9) {
            "9"
        } else null
    }

    @SuppressLint("WrongConstant")
    public override fun onResume() {
        if (VERSION.SDK_INT >= 23) {
            keyguardManager = getSystemService("keyguard") as KeyguardManager
            val fingerprintManager2 = getSystemService("fingerprint") as FingerprintManager
            fingerprintManager = fingerprintManager2
            if (fingerprintManager2.isHardwareDetected && ActivityCompat.checkSelfPermission(this, "android.permission.USE_FINGERPRINT") == 0 && fingerprintManager!!.hasEnrolledFingerprints() && keyguardManager!!.isKeyguardSecure && sharedPreferences!!.getBoolean("fp", true)) {
                (findViewById<View>(R.id.fp) as ImageView).visible()
                generateKey()
                if (cipherInit()) {
                    FingerprintHandler(this).startAuth(fingerprintManager!!, FingerprintManager.CryptoObject(cipher!!))
                }
            }
        }
        super.onResume()
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    fun generateKey() {
        try {
            keyStore = KeyStore.getInstance("AndroidKeyStore")
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            val instance = KeyGenerator.getInstance("AES", "AndroidKeyStore")
            try {
                keyStore!!.load(null)
                instance.init(
                    KeyGenParameterSpec.Builder(com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.OldPinLockActivity.Companion.KEY_NAME, KeyProperties.PURPOSE_ENCRYPT)
                        .setBlockModes(*arrayOf("CBC")).setUserAuthenticationRequired(true)
                        .setEncryptionPaddings(*arrayOf("PKCS7Padding")).build()
                )
                instance.generateKey()
            } catch (e2: IOException) {
                throw RuntimeException(e2)
            } catch (e2: InvalidAlgorithmParameterException) {
                throw RuntimeException(e2)
            } catch (e2: NoSuchAlgorithmException) {
                throw RuntimeException(e2)
            } catch (e2: CertificateException) {
                throw RuntimeException(e2)
            }
        } catch (e3: NoSuchAlgorithmException) {
            throw RuntimeException("Failed to get KeyGenerator instance", e3)
        } catch (e3: NoSuchProviderException) {
            throw RuntimeException("Failed to get KeyGenerator instance", e3)
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    fun cipherInit(): Boolean {
        return try {
            cipher = Cipher.getInstance("AES/CBC/PKCS7Padding")
            try {
                keyStore!!.load(null)
                cipher!!.init(1, keyStore!!.getKey(com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.OldPinLockActivity.Companion.KEY_NAME, null) as SecretKey)
                true
            } catch (unused: KeyPermanentlyInvalidatedException) {
                false
            } catch (e: IOException) {
                throw RuntimeException("Failed to init Cipher", e)
            } catch (e: InvalidKeyException) {
                throw RuntimeException("Failed to init Cipher", e)
            } catch (e: KeyStoreException) {
                throw RuntimeException("Failed to init Cipher", e)
            } catch (e: NoSuchAlgorithmException) {
                throw RuntimeException("Failed to init Cipher", e)
            } catch (e: UnrecoverableKeyException) {
                throw RuntimeException("Failed to init Cipher", e)
            } catch (e: CertificateException) {
                throw RuntimeException("Failed to init Cipher", e)
            }
        } catch (e2: NoSuchAlgorithmException) {
            throw RuntimeException("Failed to get Cipher", e2)
        } catch (e2: NoSuchPaddingException) {
            throw RuntimeException("Failed to get Cipher", e2)
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    inner class FingerprintHandler(var context: Context) : FingerprintManager.AuthenticationCallback() {
        override fun onAuthenticationError(i: Int, charSequence: CharSequence) {

        }
        override fun onAuthenticationFailed() {

        }
        override fun onAuthenticationHelp(i: Int, charSequence: CharSequence) {

        }
        fun update(str: String?, bool: Boolean?) {

        }
        fun startAuth(
            fingerprintManager: FingerprintManager, cryptoObject: FingerprintManager.CryptoObject?
        ) {
            val cancellationSignal = CancellationSignal()
            if (ActivityCompat.checkSelfPermission(
                    context, "android.permission.USE_FINGERPRINT"
                ) == 0
            ) {
                fingerprintManager.authenticate(cryptoObject, cancellationSignal, 0, this, null)
            }
        }

        override fun onAuthenticationSucceeded(authenticationResult: FingerprintManager.AuthenticationResult) {
            if (sharedPreferences!!.getBoolean("fp", true)) {
                if (pk == this@OldPinLockActivity.packageName) {
                    this@OldPinLockActivity.startActivity(
                        Intent(
                            this@OldPinLockActivity.applicationContext,
                            com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.CreatePinActivity::class.java
                        )
                    )
                    finish()
                }
                val edit = sharedPreferences!!.edit()
                edit.putBoolean(pk + "pattern", false)
                edit.apply()
                edit.apply()
                finish()
                this@OldPinLockActivity.overridePendingTransition(
                    R.anim.fade_in,
                    R.anim.fade_out
                )
            }
        }
    }

    private fun resetKeypadUI() {
        Handler(Looper.getMainLooper()).postDelayed({
            pinBoxArray?.let {
                it[0]?.setImageResource(R.drawable.selected_border)
                it[1]?.setImageResource(R.drawable.selected_border)
                it[2]?.setImageResource(R.drawable.selected_border)
                it[3]?.setImageResource(R.drawable.selected_border)
            }
            userEntered = ""
            keyPadLockedFlag = false

        }, 500)

    }

    companion object {
        private const val KEY_NAME = "App lock"
    }

}