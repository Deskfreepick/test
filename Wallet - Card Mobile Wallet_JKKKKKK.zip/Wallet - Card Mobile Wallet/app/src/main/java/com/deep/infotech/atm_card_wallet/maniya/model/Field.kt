package com.deep.infotech.atm_card_wallet.maniya.model

import java.util.UUID

data class Field(
    val id: String = UUID.randomUUID().toString(), // Unique identifier for each field
    val type: FieldType,       // Type of field (Name, Email, Date, Password, etc.)
    var value: String = "",
    var isPinned: Boolean = false  // Pin status
) {
    fun togglePinned() {
        isPinned = !isPinned
    }
}

enum class FieldType {

    /*-------Text------*/
    ADDRESS,
    BARCODE,
    NAME,
    FULL_NAME,
    SPOUSE_NAME,
    PARENTS_NAME,
    TEXT,
    URL,
    NOTES,
    DOCUMENT_NUMBER,
    ISSUING_COUNTRY,
    ISSUING_AUTHORITY,
    RESTRICTIONS,
    REGISTRATION_ADDRESS,
    CLASS,
    TYPE,
    PLACE_OF_BIRTH,
    NATIONALITY,
    BLANK_PAGES_REMAINING,
    CARD_HOLDER_NAME,
    CARD_HOLDER_NUMBER,
    BRAND,
    BANK,
    PAY_SYSTEM,
    CURRENCY,
    BILLING_ADDRESS,
    LOGIN,
    PASSWORD,
    PIN,
    PUK,
    COUNTRY,
    MOBILE_OPERATOR,
    OWNER_NAME,

    /*-------Numeric-------*/
    CARD_NUMBER,
    NUMBER,
    PHONE_NUMBER,
    PERSONAL_NUMBER,
    AMOUNT,
    CVV,
    ACCOUNT_NUMBER,
    CUSTOMER_SERVICE_NO,

    /*-------DatePicker-------*/
    DATE,
    ISSUE_DATE,
    EXPIRY_DATE,
    DOB,
    MRG_DATE,
    MEMBER_SINCE,

    /*-------E-Mail-------*/
    EMAIL,
    PREDEFINED_LIST,
    CUSTOM

}
