package com.deep.infotech.atm_card_wallet.maniya.model

data class ModelLanguage(val title: String, val subtitle: String, val icon: Int)
