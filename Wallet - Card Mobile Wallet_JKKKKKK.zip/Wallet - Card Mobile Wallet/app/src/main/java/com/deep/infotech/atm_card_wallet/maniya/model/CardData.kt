package com.deep.infotech.atm_card_wallet.maniya.model

data class CardData (
    val id: Long,
    val title: String? = "",
    val text: String? = "",
    val frontCardImage: String? = "",
    val categoryName: String? = "",
    val categoryID: Long? = 0L,
    val label: String? = "",
    val labelID: Long? = 0L
)