package com.deep.infotech.atm_card_wallet.maniya.ui

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.preference.PreferenceManager
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivitySettingManiyaBinding
import com.deep.infotech.atm_card_wallet.databinding.DialogChangeThemeBinding
import com.deep.infotech.atm_card_wallet.databinding.DialogDateFormatBinding
import com.deep.infotech.atm_card_wallet.databinding.DialogDeleteDbBinding
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.utils.Utils
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


class SettingActivityManiya : BaseActivity() {
    private lateinit var binding: ActivitySettingManiyaBinding
    private lateinit var utils: Utils
    private var themeMode: String? = null
    private var dateFormate: String? = null
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        editor = sharedPreferences.edit()
        utils = Utils(this)
        init()
    }

    fun init() {
        updateCurrentTheme()
        updateCurrentLanguage()
        updateCurrentDateFormate()

    }

    fun updateCurrentLanguage() {
        val sharedPreferences = getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE)
        val selectedCountry = sharedPreferences.getString(SELECTED_LANGUAGE_NAME, "en")
        binding.tvLanguageCurrent.text = selectedCountry.toString()
    }

    fun onClickAppTheme(view: View) {
        showThemeDialog()
    }

    fun onClickAppSecurity(view: View) {
        startActivity(Intent(this, PrivacySecurityActivityManiya::class.java))
    }

    fun onClickAppLanguages(view: View) {
        startActivity(Intent(this, LanguageActivityManiya::class.java))
    }

    fun onBackClick(view: View) {
       // onBackPressed()

        AdsInterstitial.instance?.showInterstitialAd(
            this@SettingActivityManiya,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    returnResult()
                }
            })

    }

    fun onClickPrivacyPolicy(view: View) {

        AdsIDS.privacy_policy?.let { _ ->
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AdsIDS.privacy_policy!!)))

        } ?: run {
            Toast.makeText(this,
                getString(R.string.privacy_policy_url_is_not_available), Toast.LENGTH_SHORT).show()
        }

    }

    fun onClickStorage(view: View) {
        startActivity(Intent(this, StorageActivityManiya::class.java))
    }

    fun onClickRateApp(view: View) {
        rateUS()
    }
    fun onClickDateformate(view: View) {


        showDateFormatDialog()

    }
    fun onClickShareIdea(view: View) {
        AdsIDS.share_idea_mail?.let { _ ->
            shareIdea()
        } ?: run {
            Toast.makeText(this,
                getString(R.string.client_mail_is_not_available), Toast.LENGTH_SHORT).show()
        }


    }
    fun onClickContactSupport(view: View) {

        AdsIDS.contact_support_mail?.let { _ ->
            contactAppSupport()

        } ?: run {
            Toast.makeText(this, getString(R.string.client_mail_is_not_available), Toast.LENGTH_SHORT).show()
        }

    }
    fun onClickTellFriend(view: View) {
        shareAppToFrnd()

    }
    fun onClickDeleteAll(view: View) {
      dialogDeleteAll()

    }
    fun dialogDeleteAll() {
        val binding = DialogDeleteDbBinding.inflate(LayoutInflater.from(this))
        val dialog = Dialog(this@SettingActivityManiya)
        dialog.setContentView(binding.root)
        dialog.setCancelable(false)
        dialog.window!!.setBackgroundDrawable(ColorDrawable(0))

        binding.llNo.setOnClickListener {
            dialog.dismiss()
        }

        binding.llYes.setOnClickListener {
            DatabaseHelperManiya(this@SettingActivityManiya).deleteAll()
            dialog.dismiss()
            returnResult()
        }
        dialog.show()
    }

    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    fun showThemeDialog() {
        val dialogBinding = DialogChangeThemeBinding.inflate(layoutInflater)
        val dialog = Dialog(this).apply {
            setContentView(dialogBinding.root)
            window!!.setBackgroundDrawable(ColorDrawable(0))
        }

        when (utils.getThemeMode()) {
            "system" -> dialogBinding.radioGroup.check(R.id.radioButton_system_theme)
            "light" -> dialogBinding.radioGroup.check(R.id.radioButton_light_theme)
            "dark" -> dialogBinding.radioGroup.check(R.id.radioButton_dark_theme)
        }

        dialogBinding.radioGroup.setOnCheckedChangeListener { _, checkedId ->
            themeMode = when (checkedId) {
                R.id.radioButton_system_theme -> "system"
                R.id.radioButton_light_theme -> "light"
                R.id.radioButton_dark_theme -> "dark"
                else -> null
            }
        }

        dialogBinding.llDone.setOnClickListener {
            utils.setThemeMode(themeMode)
            applyTheme()
            dialog.dismiss()
        }

        dialog.show()
    }
    fun showDateFormatDialog() {

        val Format1="dd MMM yyyy" // 23 Feb 2025
        val Format2="dd/MM/yyyy"  // 23/02/2025 Default
        val Format3="MMM dd, yyyy"  // Feb 23, 2025
        val Format4="MM/dd/yyyy" // 02/23/2025

        val dialogBinding = DialogDateFormatBinding.inflate(layoutInflater)
        val dialog = Dialog(this).apply {
            setContentView(dialogBinding.root)
            window!!.setBackgroundDrawable(ColorDrawable(0))
        }

        dialogBinding.rbFormate1.text=SimpleDateFormat(Format1, Locale.getDefault()).format( Calendar.getInstance().time)
        dialogBinding.rbFormate2.text=SimpleDateFormat(Format2, Locale.getDefault()).format( Calendar.getInstance().time)
        dialogBinding.rbFormate3.text=SimpleDateFormat( Format3, Locale.getDefault()).format( Calendar.getInstance().time)
        dialogBinding.rbFormate4.text=SimpleDateFormat( Format4, Locale.getDefault()).format( Calendar.getInstance().time)

        when (utils.getDateFormate()) {
            Format1 -> dialogBinding.radioGroup.check(R.id.rbFormate1)
            Format2 -> dialogBinding.radioGroup.check(R.id.rbFormate2)
            Format3 -> dialogBinding.radioGroup.check(R.id.rbFormate3)
            Format4 -> dialogBinding.radioGroup.check(R.id.rbFormate4)
        }

        dialogBinding.radioGroup.setOnCheckedChangeListener { _, checkedId ->
            dateFormate = when (checkedId) {
                R.id.rbFormate1 -> Format1
                R.id.rbFormate2 -> Format2
                R.id.rbFormate3 ->Format3
                R.id.rbFormate4 -> Format4
                else -> Format1
            }
        }

        dialogBinding.tvDone.setOnClickListener {
            utils.setDateFormate(dateFormate)
            updateCurrentDateFormate()
            dialog.dismiss()
        }

        dialog.show()
    }


    fun applyTheme() {
        when (utils.getThemeMode()) {
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }
        updateCurrentTheme()
    }

    fun updateCurrentTheme() {

        binding.tvThemeCurrent.text = when (utils.getThemeMode()) {
            "system" -> getString(R.string.system_default)
            "light" -> getString(R.string.light_mode)
            "dark" -> getString(R.string.dark_mode)
            else -> ""
        }
    }
    fun updateCurrentDateFormate()
    {
        binding.tvDateFormate.text=SimpleDateFormat(utils.getDateFormate(), Locale.getDefault()).format(Calendar.getInstance().time)
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }

}
