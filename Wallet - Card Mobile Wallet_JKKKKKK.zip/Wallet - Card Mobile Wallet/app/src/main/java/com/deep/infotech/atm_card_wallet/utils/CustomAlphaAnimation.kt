package com.deep.infotech.bank_info_locker.LockOption.Utils

import android.content.Context
import android.util.AttributeSet
import android.view.animation.AlphaAnimation
import android.view.animation.Transformation

class CustomAlphaAnimation : AlphaAnimation {
    var lastInterpolatedTime = 0f
        private set

    constructor(context: Context?, attributeSet: AttributeSet?) : super(context, attributeSet) {

    }
    constructor(f: Float, f2: Float) : super(f, f2) {

    }

    public override fun applyTransformation(f: Float, transformation: Transformation) {
        lastInterpolatedTime = f
        super.applyTransformation(f, transformation)
    }
}