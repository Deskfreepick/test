package com.deep.infotech.atm_card_wallet.maniya.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityLabelManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.adapter.LabelColorAdapter
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import java.util.Arrays


class LabelCreateActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityLabelManiyaBinding
    private lateinit var labelColorAdapter: LabelColorAdapter
    private var selectedColor: Int = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLabelManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        setLabelsColorsList()
    }
    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    fun setLabelsColorsList() {
        val colorList = Arrays.asList(
            ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color1),
            ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color2),
            ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color3),
            ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color4),
            ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color5),
            ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color6),
            ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color7),
            ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color8)
        )
        labelColorAdapter = LabelColorAdapter(this, colorList,-1) { color, position ->
            selectedColor = color
        }
        binding.rvLabelColors.apply {
            layoutManager = LinearLayoutManager(this@LabelCreateActivityManiya, LinearLayoutManager.HORIZONTAL, false)
            adapter = labelColorAdapter
        }
        labelColorAdapter.setLastSelectedItem(1)
        selectedColor = ContextCompat.getColor(this@LabelCreateActivityManiya, R.color.label_color2)
    }

    fun onBackClick(view: View) {
       // onBackPressed()

        AdsInterstitial.instance?.showInterstitialAd(
            this@LabelCreateActivityManiya,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    returnResult()
                }
            })

    }
    fun onAddLabelClick(view: View) {
        if (binding.edtName.text.toString().trim().isEmpty()) {
            binding.edtName.error = getString(R.string.please_enter_a_label_name_error)
            binding.edtName.requestFocus()

        } else {
            saveLabelToDatabase(binding.edtName.text.toString().trim(),selectedColor)
           // finish()
            returnResult()
        }
    }

    private fun saveLabelToDatabase(labelName: String, selectedColor: Int) {
        DatabaseHelperManiya(this).getLabelDao().createOrUpdate(
            com.deep.infotech.atm_card_wallet.maniya.dataModel.LabelDataManiya(
                name = labelName,
                color = selectedColor
            )
        )

    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }
}




