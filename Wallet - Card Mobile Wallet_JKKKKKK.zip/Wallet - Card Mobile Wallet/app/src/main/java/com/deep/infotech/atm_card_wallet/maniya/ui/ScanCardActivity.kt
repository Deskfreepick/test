package com.deep.infotech.atm_card_wallet.maniya.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.os.Handler
import android.preference.PreferenceManager
import android.telephony.PhoneNumberUtils
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.Ads.NetworkConnectedCheck
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityScanCardBinding
import com.deep.infotech.atm_card_wallet.databinding.ScanDataBottomDialogBinding
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.AdharViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.BirthViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.CustomViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.EntityViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.GiftViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.HealthViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.LicenseViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.LoyaltyViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.MedicalViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.MemberShipViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.MrgViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.PanViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.PassportViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.PasswordViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.PaymentViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.SIMViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.VehicleViewModel
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.VoterViewModel
import com.deep.infotech.atm_card_wallet.utils.LogD
import com.deep.infotech.atm_card_wallet.utils.LogE
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.mlkit.nl.entityextraction.Entity
import com.google.mlkit.nl.entityextraction.EntityAnnotation
import com.google.mlkit.nl.entityextraction.EntityExtraction
import com.google.mlkit.nl.entityextraction.EntityExtractionParams
import com.google.mlkit.nl.entityextraction.EntityExtractor
import com.google.mlkit.nl.entityextraction.EntityExtractorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.documentscanner.GmsDocumentScanner
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_JPEG
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_PDF
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.SCANNER_MODE_FULL
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.net.URI
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class ScanCardActivity : BaseActivity() {

    private lateinit var options: GmsDocumentScannerOptions
    private lateinit var scannerLauncher: ActivityResultLauncher<IntentSenderRequest>
    private lateinit var scanner: GmsDocumentScanner
    private lateinit var binding: ActivityScanCardBinding

    val formattedText = StringBuilder()
    val entityText = StringBuilder()

    val entityValueList = ArrayList<Pair<String, String>>()

    private val bitmapList = mutableListOf<Bitmap>()

    private lateinit var progressDialog: ProgressDialog
    private var frontBitmap: Bitmap? = null
    private var backBitmap: Bitmap? = null

    private var frontUriString: String = ""
    private var backUriString: String = ""

    private var frontBuilder = StringBuilder()
    private var backBuilder = StringBuilder()

    var wordsFront: Array<String>? = null
    var wordsBack: Array<String>? = null
    var combineWords: Array<String>? = null

    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var editer: SharedPreferences.Editor

    private var categoryName: String = "Custom"
    private var categoryId: Long = 15

    private var entityViewModel: EntityViewModel = EntityViewModel()
    private var licenceViewModel: LicenseViewModel = LicenseViewModel()
    private var passportViewModel: PassportViewModel = PassportViewModel()
    private var paymentViewModel: PaymentViewModel = PaymentViewModel()
    private var giftViewModel: GiftViewModel = GiftViewModel()
    private var loyaltyViewModel: LoyaltyViewModel = LoyaltyViewModel()
    private var memberShipViewModel: MemberShipViewModel = MemberShipViewModel()
    private var medicalViewModel: MedicalViewModel = MedicalViewModel()
    private var healthViewModel: HealthViewModel = HealthViewModel()
    private var birthViewModel: BirthViewModel = BirthViewModel()
    private var mrgViewModel: MrgViewModel = MrgViewModel()
    private var simViewModel: SIMViewModel = SIMViewModel()
    private var passwordViewModel: PasswordViewModel = PasswordViewModel()
    private var customViewModel: CustomViewModel = CustomViewModel()
    private var vehicleViewModel: VehicleViewModel = VehicleViewModel()
    private var adharViewModel: AdharViewModel = AdharViewModel()
    private var voterViewModel: VoterViewModel = VoterViewModel()
    private var panViewModel: PanViewModel = PanViewModel()

    private lateinit var entityExtractor: EntityExtractor

    private var currentCategory = "Custom"
    private var categoryID = 15L
    private var dataID = 15L
    private var isFirstImage = true
    private var isCamera = true
    private var isSpoiler = false

    private var sTAG = "ScanCardActivity++++"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScanCardBinding.inflate(layoutInflater)
        Handler().postDelayed({
            setContentView(binding.root)
            updateWindow()
        }, 1500)

        entityExtractor = EntityExtraction.getClient(
            EntityExtractorOptions.Builder(EntityExtractorOptions.ENGLISH).build()
        )
        lifecycle.addObserver(entityExtractor)

        categoryName = intent.getStringExtra("category_name").toString()
        categoryId = intent.getLongExtra("category_id", 15)

        isCamera = intent.getBooleanExtra("isCamera", false)

        LogD(sTAG, "isCamera---> ${isCamera}")

        binding.tvType.text = categoryName

        initUI()
    }

    private fun getEntityExtractionParams(input: String): EntityExtractionParams {
        return EntityExtractionParams.Builder(input).build()
    }

    fun onClickFlip(view: View) {
        val flipAnimator = ObjectAnimator.ofFloat(binding.ivCard, "rotationY", 0f, 180f)
        flipAnimator.setDuration(300)
        flipAnimator.start()
        flipAnimator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                binding.ivCard.rotationY = 0f
                if (isFirstImage) {
                    if (backUriString.isNotEmpty()) {
                        Glide.with(this@ScanCardActivity)
                            .load(backUriString)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(binding.ivCard)
                    }
                } else {
                    if (frontUriString.isNotEmpty()) {
                        Glide.with(this@ScanCardActivity)
                            .load(frontUriString)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(binding.ivCard)
                    }
                }
                isFirstImage = !isFirstImage
            }
        })

    }

    private fun startScanning(
        scanner: GmsDocumentScanner,
        scannerLauncher: ActivityResultLauncher<IntentSenderRequest>
    ) {

        scanner.getStartScanIntent(this).addOnSuccessListener { intentSender ->
            scannerLauncher.launch(IntentSenderRequest.Builder(intentSender).build())

        }.addOnFailureListener { e ->
            LogE(sTAG, getString(R.string.failed_to_start_scanning_try_again) + e.message)
            Toast.makeText(
                this, getString(R.string.failed_to_start_scanning_try_again), Toast.LENGTH_SHORT
            ).show()
        }
    }

    fun moveFile(sourceFileUri: String): String {
        var sourceFile: File
        sourceFile = File(URI(sourceFileUri.toString()))
        val fileName = "/wallet_" + SimpleDateFormat(
            "yyyyMMdd_HHmmss",
            Locale.getDefault()
        ).format(Date()) + ".png"
        val destinationFilePath = getFilesDir().absolutePath + fileName
        val destinationFile = File(destinationFilePath)
        if (sourceFile.exists()) {
            destinationFile.parentFile?.mkdirs()
            if (sourceFile.renameTo(destinationFile)) {
                LogD(sTAG, "File moved successfully!")
                if (sourceFile.exists()) {
                    sourceFile.delete()
                }
                return destinationFile.absolutePath
            } else {
                LogD(sTAG, "Failed to move the file.")
                return sourceFile.absolutePath
            }
        } else {
            LogD(sTAG, "Source file does not exist.")
            return sourceFile.absolutePath
        }
    }

    private fun handleScanningResult(data: Intent?) {
        val gmsResult = GmsDocumentScanningResult.fromActivityResultIntent(data)
        gmsResult?.pages?.let { pages ->
            try {
                LogD(sTAG, "Number of pages: ${pages.size}")

                if (pages.isNotEmpty()) {

                    /*---FrontImage---*/ frontUriString = moveFile(pages[0].imageUri.toString())

                    val frontFile = File(frontUriString.toString())
                    LogD(sTAG, "frontFile: ${frontFile}")

                    if (frontFile.exists()) {
                        frontBitmap = BitmapFactory.decodeFile(frontFile.absolutePath)
                        // bitmapToStringFront = bitmapToByteArray(frontImage)
                        bitmapList.add(frontBitmap!!)
                    }

                    if (pages.size > 1) {
                        Handler().postDelayed({
                            /*---BackImage---*/ backUriString = moveFile(pages[1].imageUri.toString())

                            val backFile = File(backUriString.toString())
                            LogD(sTAG, "BackFile: ${backFile}")

                            if (backFile.exists()) {
                                backBitmap = BitmapFactory.decodeFile(backFile.absolutePath)
                                //bitmapToStringBack = bitmapToByteArray(backImage)
                                backBitmap?.let { bitmapList.add(it) }

                                if (NetworkConnectedCheck.isConnected(this)) {
                                    processImagesForTextAnkita()
                                } else {
                                    Toast.makeText(
                                        this@ScanCardActivity,
                                        resources.getString(R.string.please_check_your_internet_connection),
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        }, 1000)


                    } else {
                        LogD(sTAG, "No back image found.")
                        if (NetworkConnectedCheck.isConnected(this)) {
                            processImagesForTextAnkita()
                        } else {
                            Toast.makeText(
                                this@ScanCardActivity,
                                resources.getString(R.string.please_check_your_internet_connection),
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }


                } else {
                    LogD(sTAG, "No pages returned from scanning.")
                    Toast.makeText(
                        this@ScanCardActivity,
                        "something went wrong!!",
                        Toast.LENGTH_SHORT
                    ).show()
                }

            } catch (e: Exception) {
                LogE(sTAG, "Error processing images: ${e.message}")
                Toast.makeText(
                    this@ScanCardActivity,
                    "Error processing images: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun processImagesForTextAnkita() {
        lifecycleScope.launch(Dispatchers.Main) {

            if(frontUriString.isNotEmpty()){
                Glide.with(this@ScanCardActivity)
                    .load(frontUriString)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(binding.ivCard)
            }
            else{
                if(backUriString.isNotEmpty()){
                    Glide.with(this@ScanCardActivity)
                        .load(backUriString)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .into(binding.ivCard)
                }else{}
            }

            progressDialog.show()
            if (frontBitmap != null) {
                extractTextManiya(frontBitmap!!, isBackImage = false)
            } else {
                if (backBitmap != null) {
                    extractTextManiya(backBitmap!!, isBackImage = true)
                }
            }
        }
    }

    private fun getEntityInfo(isWordsBack: Boolean) {
        lifecycleScope.launch(Dispatchers.Main) {
            if (!isWordsBack) {
                if (frontBitmap != null) {
                    processEntity(this@ScanCardActivity, wordsFront, false, true)
                }
            } else {
                if (backBitmap != null) {
                    processEntity(this@ScanCardActivity, wordsBack, false, false)
                }
            }
        }
    }

    private fun getDriverLicenceInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            if (frontBitmap != null) {
                processDriverLicenceTextTESTGENIUS(this@ScanCardActivity, wordsFront, false)
            }
        }
    }

    private fun getPassportCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Password OCR--->${combineWords.contentToString()}")
            processPassportTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getIdentityCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Identity OCR--->${combineWords.contentToString()}")
            processIdentityTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getResidenceCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Residence OCR--->${combineWords.contentToString()}")

            processResidenceTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getPaymentCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            if (frontBitmap != null) {
                processPaymentCardTextTESTGENIUS(this@ScanCardActivity, wordsFront, false)
            } else {
                if (backBitmap != null) {
                    processPaymentCardTextTESTGENIUS(this@ScanCardActivity, wordsBack, true)
                }
            }
        }
    }

    private fun getGiftCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Gift OCR--->${combineWords.contentToString()}")

            processGiftTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getLoyaltyCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Loyalty OCR--->${combineWords.contentToString()}")

            processLoyaltyTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun processMemberShipTextTESTGENIUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()

            LogD(sTAG, "MemberShip OCR--->${combineWords.contentToString()}")
            processMemberShipTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun processMedicalTextTESTGENIUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Medical OCR--->${combineWords.contentToString()}")

            processMedicalCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun processHeathTextTESTGENIUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Health OCR--->${combineWords.contentToString()}")

            processHealthCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getBirthCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Birth OCR--->${combineWords.contentToString()}")

            processBirthCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getMrgCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()

            LogD(sTAG, "Mrg OCR--->${combineWords.contentToString()}")
            processMrgCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getSIMCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "SIM OCR--->${combineWords.contentToString()}")

            processSIMCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getPasswordCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Password OCR--->${combineWords.contentToString()}")
            processPasswordCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun getCustomCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Custom OCR--->${combineWords.contentToString()}")
            processCustomCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }
    private fun getVehicleCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Vehicle OCR--->${combineWords.contentToString()}")
            processVehicleCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }
    private fun getAdharCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Adhar OCR--->${combineWords.contentToString()}")
            processAdharCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }
    private fun getPanCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "PAN OCR--->${combineWords.contentToString()}")
            processPANCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }
    private fun getVoterCardInfoAnkitaGINUS() {
        lifecycleScope.launch(Dispatchers.Main) {
            val combineWordsdd = frontBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() } + backBuilder.split("\n".toRegex())
                .dropLastWhile { it.isEmpty() }
            combineWords = combineWordsdd.toTypedArray()
            LogD(sTAG, "Voter OCR--->${combineWords.contentToString()}")
            processVoterCardTextTESTGENIUS(this@ScanCardActivity, combineWords, false)
        }
    }

    private fun extractTextManiya(bitmap: Bitmap, isBackImage: Boolean) {

        val inputImage = InputImage.fromBitmap(bitmap, 0)
        var text: Text? = null

        val latinrecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        latinrecognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                if (visionText?.textBlocks!!.isNotEmpty()) {
                    LogD(sTAG, "Processing  image.......")
                    processTextTEST(this@ScanCardActivity, visionText, isBackImage)
                } else {
                    if (isBackImage && backBitmap != null) {
                        extractTextManiya(backBitmap!!, isBackImage = true)
                    }
                }
            }
            .addOnFailureListener {
                if (isBackImage && backBitmap != null) {
                    extractTextManiya(backBitmap!!, isBackImage = true)
                } else {
                    Toast.makeText(
                        this@ScanCardActivity,
                        getString(R.string.text_could_not_be_read),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }

    @SuppressLint("SetTextI18n")
    private fun processTextTEST(
        context: Context,
        visionText: Text,
        isBackImage: Boolean
    ) {
        val blocks = visionText.text
        LogD(sTAG, "processTextTEST----->${blocks.toString()}")


        if (blocks.isEmpty()) {
            Toast.makeText(context, getString(R.string.no_detected_ocr), Toast.LENGTH_SHORT).show()
            if (!isBackImage && backBitmap != null) {
                extractTextManiya(backBitmap!!, isBackImage = true)
            } else {
                progressDialog.dismiss()
                return
            }
        }

        val sortedBlocks =
            visionText.textBlocks.sortedBy { block -> block.boundingBox?.top ?: Int.MAX_VALUE }

        if (backBitmap != null || frontBitmap != null) {
            var blockBuilder = StringBuilder()
            var lineBuilder = StringBuilder()

            for (block in sortedBlocks) {
                for (line in block.lines) {
                    for (element in line.elements) {
                        lineBuilder.append(element.text + "\n")
                    }
                }
                blockBuilder.append(block.text.trim() + "\n")

                val blockLanguage = block.recognizedLanguage
                val blockBounds = block.boundingBox
            }
            LogD(sTAG, "BlockBuilder----->${blockBuilder.toString()}")
            LogD(sTAG, "lineBuilder----->${lineBuilder.toString()}")


            if (!isBackImage) {
                wordsFront =
                    blockBuilder.toString().split("\n".toRegex()).dropLastWhile { it.isEmpty() }
                        .toTypedArray()
            } else {
                wordsBack =
                    blockBuilder.toString().split("\n".toRegex()).dropLastWhile { it.isEmpty() }
                        .toTypedArray()
            }

            backBuilder.append(blockBuilder.toString())

        }
        if (!isBackImage && backBitmap != null) {
            extractTextManiya(backBitmap!!, isBackImage = true)
        } else {
            /*  progressDialog.dismiss()*/
            LogD(sTAG, "blockText++++wordsFront----->${wordsFront.contentToString()}")
            LogD(sTAG, "blockText++++wordsBack----->${wordsBack.contentToString()}")

            entityText.clear()
            getEntityInfo(false)
        }
    }

    suspend fun extractEntities(input: String) {
        LogD(sTAG, "extractEntities-----INPUT--->${input}")

        try {
            awaitDownloadModel()

            val result = awaitAnnotation(input)

            if (result.isEmpty()) {
                LogD(sTAG, "extractEntities-----result empty---")
                return
            }

            for (entityAnnotation in result) {
                val entities = entityAnnotation.entities
                val annotatedText = entityAnnotation.annotatedText
                for (entity in entities) {
                    displayEntityInfo(annotatedText, entity)
                    entityText.append("\n")
                }
            }

        } catch (e: Exception) {
            LogE(sTAG, "extractEntities-----failed---${e.message}")
        }
    }

    // Suspend function to download the model
    private suspend fun awaitDownloadModel(): Unit {
        suspendCancellableCoroutine { continuation ->
            entityExtractor.downloadModelIfNeeded()
                .addOnSuccessListener {
                    continuation.resume(Unit)
                }
                .addOnFailureListener { exception ->
                    continuation.resumeWithException(exception)
                    if (progressDialog.isShowing) progressDialog.dismiss()
                    Toast.makeText(
                        this@ScanCardActivity,
                        resources.getString(R.string.please_check_your_internet_connection),
                        Toast.LENGTH_SHORT
                    ).show()

                    LogE(sTAG, "awaitDownloadModel-----failed---${exception.message}")

                }
        }
    }

    private suspend fun awaitAnnotation(input: String): List<EntityAnnotation> {
        return suspendCancellableCoroutine { continuation ->
            entityExtractor.annotate(getEntityExtractionParams(input))
                .addOnSuccessListener { result ->
                    continuation.resume(result)

                }
                .addOnFailureListener { exception ->
                    continuation.resumeWithException(exception)
                    LogE(sTAG, "awaitAnnotation-----failed---${exception.message}")


                }
        }
    }

    private fun displayEntityInfo(annotatedText: String, entity: Entity) {
        when (entity.type) {
            Entity.TYPE_ADDRESS -> displayAddressInfo(annotatedText)
            Entity.TYPE_DATE_TIME -> displayDateTimeInfo(entity, annotatedText)
            Entity.TYPE_EMAIL -> displayEmailInfo(annotatedText)
            Entity.TYPE_FLIGHT_NUMBER -> displayFlightNoInfo(entity, annotatedText)
            Entity.TYPE_IBAN -> displayIbanInfo(entity, annotatedText)
            Entity.TYPE_ISBN -> displayIsbnInfo(entity, annotatedText)
            Entity.TYPE_MONEY -> displayMoneyEntityInfo(entity, annotatedText)
            Entity.TYPE_PAYMENT_CARD -> displayPaymentCardInfo(entity, annotatedText)
            Entity.TYPE_PHONE -> displayPhoneInfo(annotatedText)
            Entity.TYPE_TRACKING_NUMBER -> displayTrackingNoInfo(entity, annotatedText)
            Entity.TYPE_URL -> displayUrlInfo(annotatedText)
            else -> ""
        }
    }

    private fun displayAddressInfo(annotatedText: String) {
        entityValueList.add(Pair("Address", annotatedText))
        entityViewModel.address = annotatedText
        entityText.append("Address:-->" + annotatedText + "\n")
    }

    private fun displayEmailInfo(annotatedText: String) {
        entityValueList.add(Pair("Email", annotatedText))
        entityViewModel.email = annotatedText

        entityText.append("Email-->" + annotatedText + "\n")
    }

    private fun displayPhoneInfo(annotatedText: String) {
        if (PhoneNumberUtils.isGlobalPhoneNumber(annotatedText)) {
            entityValueList.add(Pair("Phone", annotatedText))
            entityViewModel.phoneNo = PhoneNumberUtils.formatNumber(annotatedText)
            entityText.append(
                "Phone-->" +
                        annotatedText + "----" +
                        PhoneNumberUtils.formatNumber(annotatedText) + "\n"
            )
        }
    }

    private fun displayUrlInfo(annotatedText: String) {
        entityValueList.add(Pair("URL", annotatedText))
        entityViewModel.url = annotatedText
        entityText.append("URL-->" + annotatedText).toString() + "\n"
    }

    private fun displayDateTimeInfo(entity: Entity, annotatedText: String) {
        entityValueList.add(Pair("Date", annotatedText))
        entityViewModel.checkDateFormat(annotatedText)

        entityText.append(
            "Date:-" +
                    annotatedText + "\n"
        )
    }


    private fun displayTrackingNoInfo(entity: Entity, annotatedText: String) {
        val trackingNumberEntity = entity.asTrackingNumberEntity()
        entityValueList.add(
            Pair(
                "TrakingNumber", annotatedText + "Carrier" + trackingNumberEntity!!.parcelCarrier
                        + "TrackingNumber" + trackingNumberEntity.parcelTrackingNumber
            )
        )

        entityViewModel.trackingNo = trackingNumberEntity.parcelTrackingNumber
        entityViewModel.trackingCarrier = trackingNumberEntity.parcelCarrier.toString()
        entityText.append(
            "TrakingNumber" +
                    annotatedText + "----" +
                    trackingNumberEntity!!.parcelCarrier + "----" +
                    trackingNumberEntity.parcelTrackingNumber + "\n"

        )
    }

    private fun displayPaymentCardInfo(entity: Entity, annotatedText: String) {
        val paymentCardEntity = entity.asPaymentCardEntity()
        entityValueList.add(Pair("PaymentCard", paymentCardEntity!!.paymentCardNumber))
        entityViewModel.paymentCardNo = paymentCardEntity.paymentCardNumber
        entityViewModel.paymentCardNetwork = paymentCardEntity.paymentCardNetwork.toString()
        entityText.append(
            "PaymentCard-->" +
                    annotatedText + "----" +
                    paymentCardEntity!!.paymentCardNetwork + "----" +
                    paymentCardEntity.paymentCardNumber + "\n"
        )
    }

    private fun displayIsbnInfo(entity: Entity, annotatedText: String) {
        entityValueList.add(Pair("ISBN", annotatedText + "ISBN" + entity.asIsbnEntity()!!.isbn))
        entityViewModel.isbn = entity.asIsbnEntity()!!.isbn

        entityText.append(
            "ISBN-->" + annotatedText + "----" + entity.asIsbnEntity()!!.isbn
        ).toString() + "\n"

    }

    private fun displayIbanInfo(entity: Entity, annotatedText: String) {

        val ibanEntity = entity.asIbanEntity()
        entityViewModel.iban = ibanEntity!!.iban
        entityViewModel.ibanCountryCode = ibanEntity!!.ibanCountryCode

        entityValueList.add(
            Pair(
                "IBAN", annotatedText
                        + "IBAN" + ibanEntity!!.iban.toString()
                        + "COUNTRY" + ibanEntity!!.ibanCountryCode
            )
        )

        entityText.append(
            "IBAN" +
                    annotatedText + "----" +
                    ibanEntity!!.iban + "----" +
                    ibanEntity.ibanCountryCode + "\n"

        )
    }

    private fun displayFlightNoInfo(entity: Entity, annotatedText: String) {
        val flightNumberEntity = entity.asFlightNumberEntity()
        entityValueList.add(
            Pair(
                "FlightNo",
                annotatedText + "Number" + flightNumberEntity!!.flightNumber + "Code" + flightNumberEntity!!.airlineCode
            )
        )
        entityViewModel.flightNO = flightNumberEntity.flightNumber
        entityViewModel.airlineCode = flightNumberEntity.airlineCode

        entityText.append(
            "FlightNo-->" +
                    annotatedText + "----" +
                    flightNumberEntity!!.airlineCode + "----" +
                    flightNumberEntity.flightNumber + "\n"

        )
    }

    private fun displayMoneyEntityInfo(entity: Entity, annotatedText: String) {
        val moneyEntity = entity.asMoneyEntity()
        entityValueList.add(
            Pair(
                "Money",
                annotatedText + "Number" + moneyEntity!!.unnormalizedCurrency
            )
        )
        entityViewModel.amount = moneyEntity.unnormalizedCurrency

        entityText.append(
            "Money-->" +
                    annotatedText + "----" +
                    moneyEntity.unnormalizedCurrency + "----" +
                    moneyEntity.integerPart + "----" +
                    moneyEntity.fractionalPart + "\n"

        )
    }


    @SuppressLint("SetTextI18n")
    private fun processEntity(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean,
        isWordsBack: Boolean
    ) {
        lifecycleScope.launch(Dispatchers.Main) {
            for (block in visionText!!) {
                extractEntities(block.trim().replace(" ", ""))
            }
            LogD(sTAG, "processEntity-----entityAnnotation---${entityText}")
            if (isWordsBack && backBitmap != null) {
                getEntityInfo(true)
            } else {
                when (categoryId) {
                    1L -> getDriverLicenceInfoAnkitaGINUS()
                    2L -> getPassportCardInfoAnkitaGINUS()
                    3L -> getIdentityCardInfoAnkitaGINUS()
                    4L -> getResidenceCardInfoAnkitaGINUS()
                    5L -> getPaymentCardInfoAnkitaGINUS()
                    6L -> getGiftCardInfoAnkitaGINUS()
                    7L -> getLoyaltyCardInfoAnkitaGINUS()
                    8L -> processMemberShipTextTESTGENIUS()
                    9L -> processMedicalTextTESTGENIUS()
                    10L -> processHeathTextTESTGENIUS()
                    11L -> getBirthCardInfoAnkitaGINUS()
                    12L -> getMrgCardInfoAnkitaGINUS()
                    13L -> getSIMCardInfoAnkitaGINUS()
                    14L -> getPasswordCardInfoAnkitaGINUS()
                    15L -> getCustomCardInfoAnkitaGINUS()
                    16L -> getVehicleCardInfoAnkitaGINUS()
                    17L -> getAdharCardInfoAnkitaGINUS()
                    18L -> getVoterCardInfoAnkitaGINUS()
                    19L -> getPanCardInfoAnkitaGINUS()
                    else -> getCustomCardInfoAnkitaGINUS()
                }
            }

        }

    }

    @SuppressLint("SetTextI18n")
    private fun processPaymentCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image), Toast.LENGTH_SHORT
            ).show()
            if (!isBackImage && backBitmap != null) {
                processPaymentCardTextTESTGENIUS(
                    this@ScanCardActivity,
                    wordsBack,
                    isBackImage = true
                )
            } else {
                progressDialog.dismiss()
                return
            }
        }
        if (!isBackImage)//isBackImage=FALSE
        {

            for (block in visionText!!) {
                val blockText = block.trim()
                Log.d("blockText++++", block)
                // Check if the block text contains a possible card number based on length (typically between 13 to 19 digits)
                if (blockText.length in 13..19) {
                    if (!paymentViewModel.isAlphabeticWithSpaces(blockText)) {
                        val cardNumber = paymentViewModel.fixOCRArtifacts(blockText)
                        val cleanCardNumber = cardNumber.replace(" ", "")
                        val regex = "^\\d+$".toRegex()
                        if (regex.matches(cleanCardNumber)) {
                            paymentViewModel.cardNO = cardNumber
                            Log.e("Cleaned Card Number++++", cardNumber)
                            paymentViewModel.cardType = paymentViewModel.getCardType(cardNumber)
                            Log.e("Card Type++++", paymentViewModel.getCardType(cardNumber))
                            val isvalid = paymentViewModel.checkValidCardNumber(cardNumber)
                            paymentViewModel.isValidCard = "${isvalid}"
                            Log.e("IsCardNumberValid?++++", "${isvalid}")
                        }
                    }

                } else {

                    if (paymentViewModel.isValidExpiryDateFormat("${blockText}")) {
                        var xDate = paymentViewModel.parseExpiryDate("${blockText}")
                        if (!paymentViewModel.isExpired(xDate)) {
                            paymentViewModel.detectedBlocks.add("${blockText}")
                            if (paymentViewModel.detectedBlocks.size > 1) {
                                paymentViewModel.findMaxDate()
                            } else {
                                paymentViewModel.cardExpiredDate = "${blockText}"
                                Log.e("DATES+++", "${blockText}")
                            }
                        }
                    }

                    val cardType1 = paymentViewModel.cardTypePattern.find("${blockText}")?.value
                    Log.e("cardType1+++", "cardType: ${cardType1}")

                    paymentViewModel.cardTier =
                        paymentViewModel.cardTierPattern.find("${blockText}")?.value
                    Log.e("cardTier+++", "cardTier: ${paymentViewModel.cardTier}")
                }

                paymentViewModel.getBankCardName("${blockText}")
                Log.e("bankName+++", "${paymentViewModel.cardBankNM}")

                if (paymentViewModel.isAlphabeticWithSpaces(blockText)) {
                    paymentViewModel.isValidCardholderName("${blockText}")
                }
            }

            if (!paymentViewModel.cardType.isNullOrEmpty()) {
                paymentViewModel.cardCVV =
                    paymentViewModel.getValidCVV(paymentViewModel.cardType, visionText)?.toString()
                        .toString()
            }

        } else {
            if (isBackImage && backBitmap != null) {
                if (!paymentViewModel.cardType.isNullOrEmpty()) {
                    paymentViewModel.cardCVV =
                        paymentViewModel.getValidCVV(paymentViewModel.cardType, visionText)
                            ?.toString().toString()
                }
            }
        }

        if (!isBackImage && backBitmap != null) {
            processPaymentCardTextTESTGENIUS(this@ScanCardActivity, wordsBack, isBackImage = true)
        } else {
            progressDialog.dismiss()
        }

        if (backBitmap == null) {
            /*paymentViewModel.*/showRecognizationBottomSheetDialog(
                this@ScanCardActivity,
                categoryId,
                paymentViewModel.cardHolder.toString() + "\n" +
                        paymentViewModel.cardNO.toString() + "\n"
                        + paymentViewModel.cardExpiredDate.toString()
                        + "  " + paymentViewModel.cardType.toString()
                        + "  " + paymentViewModel.cardCVV.toString(),
                frontUriString, backUriString
            )

            progressDialog.dismiss()
        } else {
            if (isBackImage) {
               /* paymentViewModel.*/showRecognizationBottomSheetDialog(
                    this@ScanCardActivity,
                    categoryId,
                    paymentViewModel.cardHolder.toString() + "\n" +
                            paymentViewModel.cardNO.toString() + "\n"
                            + paymentViewModel.cardExpiredDate.toString()
                            + "  " + paymentViewModel.cardType.toString()
                            + "  " + paymentViewModel.cardCVV.toString(),
                    frontUriString, backUriString
                )

                progressDialog.dismiss()
            }
        }

    }

    @SuppressLint("SetTextI18n")
    private fun processDriverLicenceTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            if (!isBackImage && backBitmap != null) {
                processDriverLicenceTextTESTGENIUS(
                    this@ScanCardActivity,
                    wordsBack,
                    isBackImage = true
                )
            } else {
                progressDialog.dismiss()
                return
            }
        }


/*        for (block in visionText!!) {*/
            for (i in visionText!!.indices) {
           /* val blockText = block.trim()*/
                val combinedText = visionText[i].replace(" ", "")
                val blockText = combinedText.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")


            if (blockText.contains("son/", ignoreCase = true) ||
                blockText.contains("wife/", ignoreCase = true) ||
                blockText.contains("Daughter/", ignoreCase = true) ||
                blockText.contains("DaughterOf", ignoreCase = true) ||
                blockText.contains("sonOf", ignoreCase = true) ||
                blockText.contains("wifeOf", ignoreCase = true)
            ) {
                if (i + 1 < visionText.size) {
                    licenceViewModel.checkParentsName(visionText[i + 1].trim())
                }
            }

           if (licenceViewModel.d_o_b.equals(""))
           {
               val blockTextLowerCase = blockText.toLowerCase()

               if (blockText.contains("DateOfIssue", ignoreCase = true)) {
                   licenceViewModel.checkDOBTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("BirthDate", ignoreCase = true)) {
                   licenceViewModel.checkDOBTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("BirthDete", ignoreCase = true)) {
                   licenceViewModel.  checkDOBTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("DeteofBirth", ignoreCase = true)) {
                   licenceViewModel. checkDOBTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("DOB", ignoreCase = true)) {
                   licenceViewModel.  checkDOBTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("D.O.B", ignoreCase = true)) {
                   licenceViewModel.   checkDOBTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("D-O-B", ignoreCase = true)) {
                   licenceViewModel.  checkDOBTrimDate(blockTextLowerCase)
               }

               if (blockText.contains("DateOfBirth", ignoreCase = true) ||
                   blockText.contains("BirthDate", ignoreCase = true) ||
                   blockText.contains("BirthDate", ignoreCase = true) ||
                   blockText.contains("DeteofBirth", ignoreCase = true) ||
                   blockText.contains("DOB", ignoreCase = true)
               ) {
                   if (i + 1 < visionText.size) {
                       licenceViewModel.checkBirthDateFormat(visionText[i + 1].trim())
                   }
               }
           }

           if (licenceViewModel.issueDate.equals("")) {

               val blockTextLowerCase = blockText.toLowerCase()

               if (blockText.contains("Dateofssue", ignoreCase = true)) {
                   licenceViewModel.  checkIssueTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("DateOfIssue", ignoreCase = true)) {
                   licenceViewModel.   checkIssueTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("Date of issue", ignoreCase = true)) {
                   licenceViewModel.   checkIssueTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("issue", ignoreCase = true)) {
                   licenceViewModel.   checkIssueTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("ssue", ignoreCase = true)) {
                   licenceViewModel.  checkIssueTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("IssueDate", ignoreCase = true)) {
                   licenceViewModel.  checkIssueTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("ISS", ignoreCase = true)) {
                   licenceViewModel.  checkIssueTrimDate(blockTextLowerCase)
               }

               if (licenceViewModel.issueDate.equals("")) {
                   if (blockText.contains("DateOfIssue", ignoreCase = true) ||
                       blockText.contains("Dateofssue", ignoreCase = true) ||
                       blockText.contains("Date of issue", ignoreCase = true) ||
                       blockText.contains("issue", ignoreCase = true) ||
                       blockText.contains("ssue", ignoreCase = true) ||
                       blockText.contains("IssueDate", ignoreCase = true) ||
                       blockText.contains("ISS", ignoreCase = true)
                   ) {
                       if (i + 1 < visionText.size) {
                           licenceViewModel.checkIssueDateFormat(visionText[i + 1].trim())
                       }
                   }}

           }

           if (licenceViewModel.expDate.equals("")) {

               val blockTextLowerCase = blockText.toLowerCase()

               if (blockText.contains("validity", ignoreCase = true)) {
                   licenceViewModel.  checkExpiryTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("ExpiryDate", ignoreCase = true)) {
                   licenceViewModel.   checkExpiryTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("ExpiryDete", ignoreCase = true)) {
                   licenceViewModel.   checkExpiryTrimDate(blockTextLowerCase)
               }
               if (blockText.contains("EXP", ignoreCase = true)) {
                   licenceViewModel. checkExpiryTrimDate(blockTextLowerCase)
               }

               if (blockText.contains("validity", ignoreCase = true) ||
                   blockText.contains("ExpiryDate", ignoreCase = true) ||
                   blockText.contains("ExpiryDete", ignoreCase = true) ||
                   blockText.contains("EXP", ignoreCase = true)
               ) {
                   if (i + 1 < visionText.size) {
                       licenceViewModel.checkExpiryDateFormat(visionText[i + 1].trim())
                   }
               }
           }

           if (blockText.contains("class", ignoreCase = true)) {
               if (i + 1 < visionText.size) {
                   licenceViewModel.checkClassFormate(visionText[i + 1].trim())
               }
           }

           if (blockText.contains("name", ignoreCase = true)) {
               if (i + 1 < visionText.size) {
                   licenceViewModel.checkFullName(visionText[i + 1].trim())
               }
           }

           if(licenceViewModel.parentsName.isNotEmpty()){
                   if(licenceViewModel.parentsName.replace(" ", "") != blockText){
                      licenceViewModel.checkFullName(blockText)
                   }
                }else{
           licenceViewModel.checkFullName(blockText)}

           licenceViewModel.checkDrivingLicenceNumber(blockText)
           licenceViewModel.checkGender(blockText)
           licenceViewModel.checkBloodGroup(blockText)
           licenceViewModel.checkDateFormat(blockText)
           licenceViewModel.checkCountry(blockText)
           licenceViewModel.checkAuthority(blockText)

        }

        licenceViewModel.regAddress = entityViewModel.address.toString()
        licenceViewModel.contactNumber = entityViewModel.phoneNo.toString()

        val licenceDetails = buildString {
            if (licenceViewModel.licenceNo.isNotEmpty()) append(licenceViewModel.licenceNo.toString())

            if (licenceViewModel.issueDate.isNotEmpty()
                || licenceViewModel.expDate.isNotEmpty()
                || licenceViewModel.d_o_b.isNotEmpty()
                ) append("\n${licenceViewModel.issueDate} ${licenceViewModel.expDate} ${licenceViewModel.d_o_b}")

            if (licenceViewModel.fullName.isNotEmpty()) append("\n${licenceViewModel.fullName.toString()}")
            if (licenceViewModel.parentsName.isNotEmpty()) append("\n${licenceViewModel.parentsName.toString()}")
            if (licenceViewModel.contactNumber.isNotEmpty()) append("\n${licenceViewModel.contactNumber.toString()}")

            if (licenceViewModel.issueCountry.isNotEmpty()
                || licenceViewModel.issueAuthority.isNotEmpty()
                ) append("\n${licenceViewModel.issueCountry} ${licenceViewModel.issueAuthority}")

            if (licenceViewModel.regAddress.isNotEmpty()) append("\n${licenceViewModel.regAddress}")
        }
        LogD(sTAG, "licenceDetails---> ${licenceDetails}")


        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            licenceDetails,
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }


    @SuppressLint("SetTextI18n")
    private fun processPassportTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }
        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            passportViewModel.checkFullName(blockText)
            passportViewModel.checkDocumentNumber(blockText)
            passportViewModel.checkDateFormat(blockText)
            passportViewModel.checkCountry(blockText)
            passportViewModel.checkAuthority(blockText)
            passportViewModel.nationality(blockText)
        }
        passportViewModel.findMinMaxDates()
        passportViewModel.regAddress = entityViewModel.address
        passportViewModel.personalNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            passportViewModel.documentNumber.toString() + "\n"
                    + passportViewModel.fullName.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    @SuppressLint("SetTextI18n")
    private fun processIdentityTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }
        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            passportViewModel.checkFullName(blockText)
            passportViewModel.checkDocumentNumber(blockText)
            passportViewModel.checkDateFormat(blockText)
            passportViewModel.checkCountry(blockText)
            passportViewModel.checkAuthority(blockText)
            passportViewModel.nationality(blockText)
        }
        passportViewModel.findMinMaxDates()
        passportViewModel.regAddress = entityViewModel.address
        passportViewModel.personalNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            passportViewModel.documentNumber.toString() + "\n"
                    + passportViewModel.fullName.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }


    private fun processResidenceTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }
        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            passportViewModel.checkFullName(blockText)
            passportViewModel.checkDocumentNumber(blockText)
            passportViewModel.checkDateFormat(blockText)
            passportViewModel.checkCountry(blockText)
            passportViewModel.checkAuthority(blockText)
            passportViewModel.nationality(blockText)
        }
        passportViewModel.findMinMaxDates()
        passportViewModel.regAddress = entityViewModel.address
        passportViewModel.personalNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            passportViewModel.documentNumber.toString() + "\n"
                    + passportViewModel.fullName.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processGiftTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            giftViewModel.checkCardNumber(blockText)
            giftViewModel.checkDateFormat(blockText)
        }

        giftViewModel.findMinMaxDates()
        giftViewModel.amount = entityViewModel.amount

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            giftViewModel.cardNumber.toString() + "\n"
                    + giftViewModel.amount.toString() + "\n"
                    + giftViewModel.expDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processLoyaltyTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {

            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            loyaltyViewModel.checkCardNumber(blockText)
            loyaltyViewModel.checkDateFormat(blockText)
        }

        loyaltyViewModel.findMinMaxDates()
        loyaltyViewModel.url = entityViewModel.url

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            loyaltyViewModel.cardNumber.toString() + "\n"
                    + loyaltyViewModel.url.toString() + "\n"
                    + loyaltyViewModel.expDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processMemberShipTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            memberShipViewModel.checkCardNumber(blockText)
            memberShipViewModel.checkDateFormat(blockText)
        }

        memberShipViewModel.findMinMaxDates()
        memberShipViewModel.url = entityViewModel.url

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            memberShipViewModel.cardHolderNumber.toString() + "\n"
                    + memberShipViewModel.url.toString() + "\n"
                    + memberShipViewModel.expDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processMedicalCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            medicalViewModel.checkDocumentNumber(blockText)
            medicalViewModel.checkDateFormat(blockText)
        }

        medicalViewModel.findMinMaxDates()
        medicalViewModel.email = entityViewModel.email
        medicalViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            medicalViewModel.documentNumber.toString() + "\n"
                    + medicalViewModel.email.toString() + "\n"
                    + medicalViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processHealthCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            healthViewModel.checkDocumentNumber(blockText)
            healthViewModel.checkDateFormat(blockText)
        }

        healthViewModel.findMinMaxDates()
        healthViewModel.email = entityViewModel.email
        healthViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            healthViewModel.documentNumber.toString() + "\n"
                    + healthViewModel.email.toString() + "\n"
                    + healthViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processCustomCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            customViewModel.checkDocumentNumber(blockText)
            customViewModel.checkDateFormat(blockText)
        }

        customViewModel.findMinMaxDates()
        customViewModel.email = entityViewModel.email
        customViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            customViewModel.documentNumber.toString() + "\n"
                    + customViewModel.email.toString() + "\n"
                    + customViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processVehicleCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            vehicleViewModel.checkDocumentNumber(blockText)
            vehicleViewModel.checkDateFormat(blockText)
        }

        vehicleViewModel.findMinMaxDates()
        vehicleViewModel.email = entityViewModel.email
        vehicleViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            vehicleViewModel.documentNumber.toString() + "\n"
                    + vehicleViewModel.email.toString() + "\n"
                    + vehicleViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processAdharCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            adharViewModel.isValidName(blockText)
          /*  adharViewModel.checkAdharNumber(blockText)*/
            adharViewModel.checkDateFormat(blockText)
            adharViewModel.checkGender(blockText)
        }

        adharViewModel.findDOBDate()
        adharViewModel.email = entityViewModel.email.toString()
        adharViewModel.website = entityViewModel.url.toString()
        adharViewModel.adharNo = entityViewModel.phoneNo.toString()
        adharViewModel.address = entityViewModel.address.toString()


        val AdharDetails = buildString {
            if (adharViewModel.adharNo.isNotEmpty()) append(adharViewModel.adharNo.toString())
            if (adharViewModel.fullName.isNotEmpty()) append("\n${adharViewModel.fullName.toString()}")
            if (adharViewModel.dob.isNotEmpty() || adharViewModel.gender.isNotEmpty()) append("\n${adharViewModel.dob} ${adharViewModel.gender} ")
            if (adharViewModel.email.isNotEmpty()) append("\n${adharViewModel.email.toString()}")
            if (adharViewModel.website.isNotEmpty()) append("\n${adharViewModel.website.toString()}")
            if (adharViewModel.website.isNotEmpty()) append("\n${adharViewModel.website}")
            if (adharViewModel.address.isNotEmpty()) append("\n${adharViewModel.address}")
        }
        LogD(sTAG, "AdharDetails---> ${AdharDetails}")


        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            AdharDetails,
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processPANCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            panViewModel.checkDocumentNumber(blockText)
            panViewModel.checkDateFormat(blockText)
        }

        panViewModel.findMinMaxDates()
        panViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            panViewModel.documentNumber.toString() + "\n"
                    + panViewModel.fullName.toString() + "\n"
                    + panViewModel.dob.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processVoterCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            voterViewModel.checkDocumentNumber(blockText)
            voterViewModel.checkDateFormat(blockText)
        }

        voterViewModel.findMinMaxDates()
        voterViewModel.email = entityViewModel.email
        voterViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            voterViewModel.documentNumber.toString() + "\n"
                    + voterViewModel.email.toString() + "\n"
                    + voterViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processPasswordCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            passwordViewModel.checkDocumentNumber(blockText)
            passwordViewModel.checkDateFormat(blockText)
        }

        passwordViewModel.findMinMaxDates()
        passwordViewModel.email = entityViewModel.email
        passwordViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            passwordViewModel.documentNumber.toString() + "\n"
                    + passwordViewModel.email.toString() + "\n"
                    + passwordViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processSIMCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            simViewModel.checkDocumentNumber(blockText)
            simViewModel.checkDateFormat(blockText)
        }

        simViewModel.findMinMaxDates()
        simViewModel.email = entityViewModel.email
        simViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            simViewModel.documentNumber.toString() + "\n"
                    + simViewModel.email.toString() + "\n"
                    + simViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processMrgCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            mrgViewModel.checkDocumentNumber(blockText)
            mrgViewModel.checkDateFormat(blockText)
        }

        mrgViewModel.findMinMaxDates()
        mrgViewModel.email = entityViewModel.email
        mrgViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            mrgViewModel.documentNumber.toString() + "\n"
                    + mrgViewModel.email.toString() + "\n"
                    + mrgViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    private fun processBirthCardTextTESTGENIUS(
        context: Context,
        visionText: Array<String>?,
        isBackImage: Boolean
    ) {
        if (visionText?.size == 0) {
            Toast.makeText(
                context,
                getString(R.string.no_text_detected_in_image),
                Toast.LENGTH_SHORT
            ).show()
            progressDialog.dismiss()
            return
        }

        for (block in visionText!!) {
            val blockText = block.trim()
            Log.d("blockText++++", blockText)
            blockText.replace(" ", "")
            birthViewModel.checkDocumentNumber(blockText)
            birthViewModel.checkDateFormat(blockText)
        }

        birthViewModel.findMinMaxDates()
        birthViewModel.email = entityViewModel.email
        birthViewModel.phoneNumber = entityViewModel.phoneNo

        showRecognizationBottomSheetDialog(
            this@ScanCardActivity,
            categoryId,
            birthViewModel.documentNumber.toString() + "\n"
                    + birthViewModel.email.toString() + "\n"
                    + birthViewModel.expiryDate.toString() + "\n",
            frontUriString,
            backUriString
        )
        progressDialog.dismiss()
    }

    fun showRecognizationBottomSheetDialog(
        context: Context,
        categoryId: Long,
        text: String,
        stringFront: String,
        stringBack: String
    ) {

        var ocrText:String= ""
        ocrText= text
        if (ocrText.contains("null", ignoreCase = true)) {
            ocrText = ocrText.replace(Regex("null", RegexOption.IGNORE_CASE), "").trim()
        }
        Glide.with(this@ScanCardActivity)
            .load(stringFront)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .into(binding.ivCard)

        if (stringBack.isNotEmpty()) binding.tvFlip.visible()

        val bottomSheetDialog = BottomSheetDialog(context)
        val binding = ScanDataBottomDialogBinding.inflate(bottomSheetDialog.layoutInflater)
        bottomSheetDialog.setContentView(binding.root)

        binding.root.setBackgroundResource(R.drawable.bottom_sheet_background)
        binding.tvOCRData.text = ocrText

        binding.tvContinue.setOnClickListener {

            when (categoryId) {
                1L -> {
                    licenceViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastLicenceRecord().id
                    openEditRecordView()
                }

                2L -> {
                    passportViewModel.insertInDB(context, stringFront, stringBack, categoryId)
                    dataID= DatabaseHelperManiya(this).fetchLastPassportRecord().id
                    openEditRecordView()
                }

                3L -> {
                    passportViewModel.insertInDB(context, stringFront, stringBack, categoryId)
                    dataID= DatabaseHelperManiya(this).fetchLastIDCardRecord().id
                    openEditRecordView()
                }

                4L -> {
                    passportViewModel.insertInDB(context, stringFront, stringBack, categoryId)
                    dataID= DatabaseHelperManiya(this).fetchLastResidenceCardRecord().id
                    openEditRecordView()
                }

                5L -> {
                    paymentViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastPaymentRecord().id
                    openEditRecordView()
                }

                6L -> {
                    giftViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastGiftCardRecord().id
                    openEditRecordView()
                }

                7L -> {
                    loyaltyViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastLicenceRecord().id
                    openEditRecordView()
                }

                8L -> {
                    memberShipViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastMembershipCardRecord().id
                    openEditRecordView()
                }

                9L -> {
                    medicalViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastMedicalCardRecord().id
                    openEditRecordView()
                }

                10L -> {
                    healthViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastHealthCardRecord().id
                    openEditRecordView()
                }

                11L -> {
                    birthViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastBirthCardRecord().id
                    openEditRecordView()
                }

                12L -> {
                    mrgViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastMrgCardRecord().id
                    openEditRecordView()
                }

                13L -> {
                    simViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastSIMCardRecord().id
                    openEditRecordView()
                }

                14L -> {
                    passwordViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastPasswordCardRecord().id
                    openEditRecordView()
                }
                15L -> {
                    passwordViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastPasswordCardRecord().id
                    openEditRecordView()
                }
                16L -> {
                    vehicleViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastVehicleCardRecord().id
                    openEditRecordView()
                }
                17L -> {
                    adharViewModel.insertInDB(context, stringFront, stringBack)
                    Handler().postDelayed({
                        dataID= DatabaseHelperManiya(this).fetchLastAdharCardRecord().id
                        openEditRecordView()
                    }, 500)
                }
                18L -> {
                    voterViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastVoterCardRecord().id
                    openEditRecordView()
                }
                19L -> {
                    panViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastPANCardRecord().id
                    openEditRecordView()
                }

                else -> {
                    customViewModel.insertInDB(context, stringFront, stringBack)
                    dataID= DatabaseHelperManiya(this).fetchLastCustomCardRecord().id
                    openEditRecordView()
                }
            }

            bottomSheetDialog.dismiss()
        }

        binding.tvRetake.setOnClickListener {
            startScanning(scanner, scannerLauncher)
            bottomSheetDialog.dismiss()
        }
        if (!isFinishing) bottomSheetDialog.show()
    }

    private fun initUI() {
        progressDialog = ProgressDialog(this).apply {
            setMessage(getString(R.string.processing))
            setCancelable(false)
        }

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        editer = sharedPreferences.edit()
        if (isCamera) {
            options =
                GmsDocumentScannerOptions.Builder().setGalleryImportAllowed(false)
                    .setPageLimit(2)
                    .setResultFormats(RESULT_FORMAT_JPEG, RESULT_FORMAT_PDF)
                    .setScannerMode(SCANNER_MODE_FULL).build()

        } else {
            options =
                GmsDocumentScannerOptions.Builder()
                    .setGalleryImportAllowed(true)
                    .setPageLimit(2)
                    .setResultFormats(RESULT_FORMAT_JPEG, RESULT_FORMAT_PDF)
                    .setScannerMode(SCANNER_MODE_FULL).build()

        }
        setScanner()

    }

    private fun setScanner() {

        scanner = GmsDocumentScanning.getClient(options)

        scannerLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
                if (result.resultCode == RESULT_OK) {
                    handleScanningResult(result.data)
                } else {
                    Log.e(
                        "ScanCardActivity++++++",
                        "Scanning failed with resultCode: ${result.resultCode}"
                    )
                    val intent = Intent(this@ScanCardActivity, TESTMainActivityManiya::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    finishAffinity()
                }
            }

        startScanning(scanner, scannerLauncher)

    }

    private fun openRecordView() {
        startActivity(
            Intent(this@ScanCardActivity, ViewActivityManiya::class.java)
                .putExtra("categoryID", categoryId)
                .putExtra("isFromScan", true)
        )

        finish()
    }

    private fun openEditRecordView() {
        startActivity(  Intent(this@ScanCardActivity, EditCardActivityManiya::class.java)
            .putExtra("categoryID", categoryId)
            .putExtra("ItemID", dataID)
            .putExtra("isFromScan", true))
        finish()
    }

    private fun extractCardNumber(lines: List<String>): String? {
        val cleanedLines =
            lines.joinToString(" ").replace("|", "").replace("\n", " ").replace("1800 1080", "")
                .replace(",", "").replace(".", "")

        val regex = Regex("\\b(\\d\\s*?){16}\\b")
        return regex.find(cleanedLines)?.value?.replace(" ", "")
    }

    private fun extractCvv(lines: List<String>): String? {

        val regex = Regex("\\b\\d{3}\\b")
        return lines.find { regex.matches(it) }?.trim()
    }

    private fun extractOwner(lines: List<String>): String? {
        val ignoredTerms =
            listOf("AUTHORIZED SIGNATURE", "Customer Care No.", "1800", "SBFINKAO14641123")

        return lines.asSequence().filter { it.trim().isNotEmpty() }
            .filter { line -> line.contains(" ") }.filter { line ->
                line.all { char -> char.isUpperCase() || char.isWhitespace() }
            }.filter { line ->
                ignoredTerms.none { term -> line.contains(term, ignoreCase = true) }
            }.filter { line ->
                val wordCount = line.split(" ").filter { it.isNotEmpty() }.size
                wordCount == 2 || wordCount == 3
            }.filter { line ->
                !line.any { it.isDigit() }
            }.maxByOrNull { it.length }?.trim()
    }

    private fun extractExpiration(lines: List<String>): Pair<String?, String?> {
        val expirationLine = extractExpirationLine(lines)
        val month = expirationLine?.substring(startIndex = 0, endIndex = 2)
        val year = expirationLine?.substring(startIndex = 3)
        return Pair(month, year)
    }

    private fun extractExpirationLine(lines: List<String>): String? {
        return lines.flatMap { it.split(" ") }
            .firstOrNull { (it.length == 5 || it.length == 7) && it[2] == '/' }
    }


    override fun onBackPressed() {
        super.onBackPressed()
        finish()
    }

    fun onBackClick(view: View) {

        AdsInterstitial.instance?.showInterstitialAd(
            this@ScanCardActivity,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    onBackPressed()
                }
            })
    }

    override fun onResume() {
        super.onResume()
//      showBannerAdsSecond()
    }
}
