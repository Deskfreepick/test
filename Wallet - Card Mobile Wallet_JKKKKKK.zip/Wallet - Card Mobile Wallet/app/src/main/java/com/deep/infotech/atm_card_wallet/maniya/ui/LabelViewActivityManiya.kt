package com.deep.infotech.atm_card_wallet.maniya.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.maniya.adapter.AdapterLabelView
import com.deep.infotech.atm_card_wallet.databinding.ActivityLabelViewManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya


class LabelViewActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityLabelViewManiyaBinding
    private lateinit var adapter: AdapterLabelView

    private var categoryID = 0L
    private var labelID = 0L
    private var itemID = 0L
    private var sTAG = "LabelViewActivityManiya++++++"

    private var labelList: MutableList<com.deep.infotech.atm_card_wallet.maniya.dataModel.LabelDataManiya> = mutableListOf()

    private lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    private var selectedLabel: com.deep.infotech.atm_card_wallet.maniya.dataModel.LabelDataManiya? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityLabelViewManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()

        labelID = intent.getLongExtra("labelID", 0L)
        categoryID = intent.getLongExtra("categoryID", 0L)
        itemID = intent.getLongExtra("itemID", 0L)

        Log.d(sTAG, "labelID---->" + labelID)
        Log.d(sTAG, "categoryID---->" + categoryID)
        Log.d(sTAG, "itemID---->" + itemID)

        activityResultLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                Log.d(sTAG, "----activityResultLauncher--")
                setAdapter()
            }
        }
        setAdapter()
    }

    fun onBackClick(view: View) {
        if(adapter.isSelectionMode){ adapter.enableSelectionMode(false)}else{
            if(labelList.size!= DatabaseHelperManiya(this).getLabelDao().queryForAll().size){
                AdsInterstitial.instance?.showInterstitialAd(
                    this@LabelViewActivityManiya,
                    false,
                    object : AdsInterstitial.adfinish {
                        override fun adfinished() {
                            returnResult()
                        }
                    })
            }else{
                onBackPressed()
            }
        }
    }

    fun onSaveLabelClick(view: View) {
        adapter.enableSelectionMode(false)
        saveCardLabels()
    }
    fun onClickCreateLabel(view: View) {
        activityResultLauncher.launch( Intent(this@LabelViewActivityManiya, LabelCreateActivityManiya::class.java)
        )
    }

    private fun setAdapter() {
        labelList = DatabaseHelperManiya(this).getLabelDao().queryForAll()


            binding.tvAvailabelLabel.visible()
            binding.rvLabel.visible()

            adapter = AdapterLabelView(
                this@LabelViewActivityManiya,
                labelList,
                labelID,
                onItemClick = { iteam, position ->
                    adapter.setLastSelectedItem(position)
                    selectedLabel = iteam
                },
                onItemLongClick = { item, position ->
                    adapter?.enableSelectionMode(true)
                    true
                })

            binding.rvLabel.adapter = adapter

            if (labelID > 0) {
                if (selectedLabel == null) {
                    selectedLabel = DatabaseHelperManiya(this).getLabelDao().queryForId(labelID)
                    labelList.forEachIndexed { index, labelModel ->
                        if (labelModel.equals(selectedLabel)) {
                            adapter.setLastSelectedItem(index)
                        }
                    }
                }
            }

        if (labelList.size > 0) {
        } else {
            binding.tvAvailabelLabel.gone()
            binding.rvLabel.gone()
        }
    }

    private fun saveCardLabels() {
        categoryID = intent.getLongExtra("categoryID", 15L)
        when (categoryID) {
            1L -> {
                DatabaseHelperManiya(this).updateLicenceLabel(itemID, selectedLabel)
            }

            2L -> {
                DatabaseHelperManiya(this).updatePassportabel(itemID, selectedLabel)
            }

            3L -> {
                DatabaseHelperManiya(this).updateIDCardLabel(itemID, selectedLabel)
            }

            4L -> {
                DatabaseHelperManiya(this).updateResidenceCardLabel(itemID, selectedLabel)
            }

            5L -> {
                DatabaseHelperManiya(this).updatePaymentCardLabel(itemID, selectedLabel)
            }

            6L -> {
                DatabaseHelperManiya(this).updateGiftCardLabel(itemID, selectedLabel)
            }

            7L -> {
                DatabaseHelperManiya(this).updateLoyaltyCardLabel(itemID, selectedLabel)
            }

            8L -> {
                DatabaseHelperManiya(this).updateMembershipCardLabel(itemID, selectedLabel)
            }

            9L -> {
                DatabaseHelperManiya(this).updateMedicalCardLabel(itemID, selectedLabel)
            }

            10L -> {
                DatabaseHelperManiya(this).updateHealthCardLabel(itemID, selectedLabel)
            }

            11L -> {
                DatabaseHelperManiya(this).updateBirthCardLabel(itemID, selectedLabel)
            }

            12L -> {
                DatabaseHelperManiya(this).updateMrgCardLabel(itemID, selectedLabel)
            }

            13L -> {
                DatabaseHelperManiya(this).updateSIMCardLabel(itemID, selectedLabel)
            }

            14L -> {
                DatabaseHelperManiya(this).updatePasswordCardLabel(itemID, selectedLabel)
            }

            15L -> {
                DatabaseHelperManiya(this).updateCustomCardLabel(itemID, selectedLabel)
            }
            16L -> {
                DatabaseHelperManiya(this).updateVehicleCardLabel(itemID, selectedLabel)
            }
            17L -> {
                DatabaseHelperManiya(this).updateAdharCardLabel(itemID, selectedLabel)
            }
            18L -> {
                DatabaseHelperManiya(this).updateVoterCardLabel(itemID, selectedLabel)
            }
            19L -> {
                DatabaseHelperManiya(this).updatePANCardLabel(itemID, selectedLabel)
            }
        }
        returnResult()
    }

    override fun onResume() {
        super.onResume()
          showNativeAdsSecond()
    }

    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }
}




