package com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData

import android.content.Context
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.dataModel.AdharScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AdharViewModel : ViewModel() {

    val detectedBlocks: MutableList<String> = ArrayList()

    var fullName: String = ""
    var parentsName: String = ""
    var adharNo: String = ""
    var dob: String = ""
    var gender: String = ""

    var phoneNumber: String = ""
    var address: String = ""
    var email: String = ""
    var url: String = ""

    val restrictedKeywords = listOf(
        "platinu",
        "platinum",
        "gold",
        "black",
        "classic",
        "silver",
        "titanium",
        "bank",
        "credit",
        "debit",
        "atm",
        "transaction",
        "international",
        "card",
        "paypal",
        "money",
        "e-commerce",
        "charge",
        "visa",
        "mastercard",
        "american express",
        "discover",
        "jcb",
        "diners club",
        "unionpay",
        "maestro",
        "rupay",
        "laser",
        "china unionpay,payment",
        "valid",
        "from",
        "thru",
        "validity",
        "birthdate",
        "dob",
        "authorized",
        "signature",
        "licence",
        "idcard",
        "vehical",
        "name",
        "son",
        "of",
        "wife",
        "daughter",
        "father",
        "mother",
        "blood",
        "group",
        "aadhaar",
        "licence",
        "card",
        "vehicales",
        "state",
        "drive",
        "no",
        "yes",
        "n/a",
        "ID",
        "health",
        "hospital",
        "principal",
        "www",
        "www.",
        "com",
        "customer",
        "customer care",
        "care",
        "tollfree",
        "scan",
        "qr",
        "code",
        "download",
        "change",
        "pin",
        "government",
        "unique",
        "identification",
        "s/o",
        "print",
        "help",
        "gov",
        "aadhaar",
        "/male",
        "/female",
        "/other",
        "issuedate",
        "date",
        "issuedate",
        "birthdate",
        "expiryDate",
        "birth",
        "election",
        "commission",
        "india",
        "photo",
        "identity",
        "elector",
        "sex",
        "age",
        "note",
        "vote",
        "ac no",
        "acno&name",
        "partno",
        "partno&name",
        "h no",
        "H.No.",
        "years"
    )
    val restrictedParentsKeywords = listOf(
        "platinu",
        "platinum",
        "gold",
        "black",
        "classic",
        "silver",
        "titanium",
        "bank",
        "credit",
        "debit",
        "atm",
        "transaction",
        "international",
        "card",
        "paypal",
        "money",
        "e-commerce",
        "charge",
        "visa",
        "mastercard",
        "american express",
        "discover",
        "jcb",
        "diners club",
        "unionpay",
        "maestro",
        "rupay",
        "laser",
        "china unionpay,payment",
        "valid",
        "from",
        "thru",
        "validity",
        "birthdate",
        "aadhaar",
        "dob",
        "authorized",
        "signature",
        "licence",
        "idcard",
        "vehical",
        "name",
        "blood",
        "group",
        "licence",
        "card",
        "vehicales",
        "state",
        "drive",
        "no",
        "yes",
        "n/a",
        "ID",
        "health",
        "hospital",
        "principal",
        "www",
        "www.",
        "com",
        "customer",
        "customer care",
        "care",
        "tollfree",
        "scan",
        "qr",
        "code",
        "download",
        "change",
        "pin",
        "government",
        "unique",
        "identification",
        "s/o",
        "print",
        "help",
        "gov",
        "aadhaar",
        "/male",
        "/female",
        "/other",
        "issuedate",
        "date",
        "issuedate",
        "birthdate",
        "expiryDate",
        "birth",
        "election",
        "commission",
        "india",
        "photo",
        "identity",
        "elector",
        "sex",
        "age",
        "years",
        "note",
        "vote",
        "ac no",
        "acno&name",
        "partno",
        "partno&name",
        "h no",
        "H.No."
    )


    fun parseDate(dateString: String): Pair<Date?, String>? {
        val dateFormats = arrayOf(
            "MM/dd/yyyy",
            "dd/MM/yyyy",
            "yyyy/MM/dd",
            "MM/dd/yy",
            "yyyy-MM-dd",
            "MM-dd-yyyy",
            "dd-MM-yyyy",
            "M-dd-yyyy",
            "yyyy.MM.dd",
            "dd.MM.yyyy",
            "MM.dd.yyyy",
            "MM-yy",
            "MM/yyyy",
            "MM/yy"
        )
        for (format in dateFormats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.getDefault())
                val date = sdf.parse(dateString)
                if (date != null) {
                    return Pair(date, format)
                }
            } catch (e: Exception) {

            }
        }
        return null
    }

    fun checkFullName(cardholderName: String) {
        if (restrictedKeywords.any { cardholderName.contains(it, ignoreCase = true) }) return
        val cleanHolderName = cardholderName.trim()
        if (cleanHolderName.isNotEmpty() && cleanHolderName.length > 3) {
            val fullNamePattern = Regex("\\b[A-Za-z][a-zA-Z]+(?: [A-Za-z][a-zA-Z]+)*\\b")
            if (fullNamePattern.matches(cleanHolderName)) {
                fullName = cardholderName
                Log.e("AadhaarCard+++FullName---+++", "cardholderName: $fullName")
            }
        }
    }

    fun checkParentsName(cardholderName: String) {
        val cleanHolderName = cardholderName.trim()
        if (restrictedParentsKeywords.any { cardholderName.contains(it, ignoreCase = true) }) return

        if (cleanHolderName.isNotEmpty() && cleanHolderName.length > 3) {
            val fullNamePattern = Regex("\\b[A-Za-z][a-zA-Z]+(?: [A-Za-z][a-zA-Z]+)*\\b")
            if (fullNamePattern.matches(cleanHolderName)) {
                parentsName = cardholderName
                Log.e("AadhaarCard++++++Parents---+++", parentsName)
            }
        }
    }


    fun formatDate(date: Date?, format: String?): String? {
        if (date == null || format == null) return null
        val sdf = SimpleDateFormat(format, Locale.getDefault())
        return sdf.format(date)
    }

    fun checkAdharNumber(str: String) {
        val adharPattern = Regex("^[2-9]{1}[0-9]{11}$")
        if (adharPattern.matches(str)) {
            adharNo = str
            Log.d("AadhaarCard++++++adharNo++++", str)
        }
    }

    fun isExpired(date: Date?): Boolean {
        val currentDate = Date()
        return date?.before(currentDate) ?: false
    }

    fun checkDateFormat(block: String) {
        if (Regex( """^(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$|^(0?[1-9]|[12][0-9]|3[01])([/-])(0?[1-9]|1[0-2])([/-])(\d{2}|\d{4})$""").matches(block)) {
            detectedBlocks.add(block)
        }
    }

    fun findDOBDate() {
        var minDate: Date? = null
        var maxDate: Date? = null

        var oldestExpiredDate: Date? = null
        var oldestExpiredDateFormat: String? = null

        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        dateFormat.isLenient = false

        fun isExpired(date: Date): Boolean {
            return date.before(Date())
        }

        fun parseDate(dateString: String): Pair<Date?, String>? {
            return try {
                val date = dateFormat.parse(dateString)
                if (date != null) {
                    Pair(date, "dd/MM/yyyy")
                } else {
                    null
                }
            } catch (e: Exception) {
                null
            }
        }

        for (dateString in detectedBlocks) {
            val result = parseDate(dateString)
            if (result != null) {
                val date = result.first
                val format = result.second

                if (date != null) {
                    // Check for the oldest expired date
                    if (isExpired(date)) {
                        if (oldestExpiredDate == null || date.before(oldestExpiredDate)) {
                            oldestExpiredDate = date
                            oldestExpiredDateFormat = format
                        }
                    }

                    // Find the minimum date
                    if (minDate == null || date.before(minDate)) {
                        minDate = date
                    }

                    // Find the maximum date
                    if (maxDate == null || date.after(maxDate)) {
                        maxDate = date
                    }
                }
            }
        }

        if (oldestExpiredDate != null) {
            dob = oldestExpiredDateFormat.toString()
            Log.e("AadhaarCard++++++DOB+++", "DOB: ${dob}")
        }
    }

    fun checkGender(text: String) {
        val genderPattern =
            Regex("^(?:m|M|male|Male|f|F|female|Female|FEMALE|MALE|Not prefer to say)$")
        if (genderPattern.matches(text)) {
            gender = text
            Log.d("AadhaarCard++++++Gender++++", gender)

        }
    }

    fun insertInDB(
        context: Context,
        stringFront: String,
        stringBack: String
    ) {

        val adharCard = AdharScanDataManiya(
            fullName = fullName.toString(),
            parentsName = parentsName.toString(),
            adharNo = adharNo,
            dob = dob.toString(),
            gender = gender.toString(),

            phoneNumber = phoneNumber.toString(),
            address = address.toString(),
            email = email.toString(),
            url = url.toString(),

            label = DatabaseHelperManiya(context).getLabelDao().queryForId(0),
            appearanceColor = ContextCompat.getColor(context, R.color.appreance),
            category = DatabaseHelperManiya(context).getCategoryDao().queryForId(17),
            frontCardImage = stringFront,
            backCardImage = stringBack,
            isLock = false,
            isFav = false,
            isDelete = true,
            isArchive = false
        )
        DatabaseHelperManiya(context).getAdharCardDao().createOrUpdate(adharCard)
    }

}


