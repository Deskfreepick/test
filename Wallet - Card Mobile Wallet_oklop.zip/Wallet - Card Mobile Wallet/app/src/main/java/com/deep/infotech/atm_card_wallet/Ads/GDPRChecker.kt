package com.deep.infotech.atm_card_wallet.Ads

import android.Manifest
import android.app.Activity
import android.util.Log
import androidx.annotation.RequiresPermission
import com.google.android.ump.ConsentForm
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.FormError
import com.google.android.ump.UserMessagingPlatform

class GDPRChecker {
    var consentInformation: ConsentInformation? = null
    var context: Activity? = null
    var privacyUrl: String? = null
    var publisherIds: Array<String>? = null
    var consentForm: ConsentForm? = null
    var withAdFreeOption = false

    protected constructor(context: Activity?) {
        this.context = context
        consentInformation = UserMessagingPlatform.getConsentInformation(context)
    }

    constructor() {}

    fun withContext(context: Activity?): GDPRChecker? {
        instance = GDPRChecker(context)
        return instance
    }

    fun withPrivacyUrl(privacyUrl: String?): GDPRChecker? {
        this.privacyUrl = privacyUrl
        if (instance == null) throw NullPointerException("Please call withContext first")
        return instance
    }

    @RequiresPermission(Manifest.permission.INTERNET)
    private fun initGDPR() {
        if (publisherIds == null) throw NullPointerException("publisherIds is null, please call withPublisherIds first")
        val params = ConsentRequestParameters.Builder().setTagForUnderAgeOfConsent(false).build()
        consentInformation!!.requestConsentInfoUpdate(context, params, {
            if (consentInformation!!.isConsentFormAvailable) {
                loadForm()
            }
        }
        ) { formError: FormError? -> loadForm() }
    }

    private fun loadForm() {
        UserMessagingPlatform.loadConsentForm(context, { consentForm1: ConsentForm? ->
            consentForm = consentForm1
            if (consentInformation!!.consentStatus == ConsentInformation.ConsentStatus.REQUIRED) {
                consentForm!!.show(context) { formError: FormError? ->
                    loadForm()
                }
            } else {
                Log.w("PTag", "Ram 5")
            }
            status = consentInformation!!.consentStatus
        }
        ) { formError: FormError? -> Log.w("PTag", "Ram 6") }
    }

    fun check() {
        initGDPR()
    }

    companion object {
        var instance: GDPRChecker? = null
        @JvmStatic
        var status = ConsentInformation.ConsentStatus.REQUIRED
    }
}