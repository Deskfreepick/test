package com.deep.infotech.atm_card_wallet.maniya.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.isVisible
import androidx.recyclerview.widget.GridLayoutManager
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityCategoriesdataManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.model.CardData
import com.deep.infotech.atm_card_wallet.maniya.adapter.SearchAdapter
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya


class CategoryDataActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityCategoriesdataManiyaBinding
    private lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    private var searchAdapter: SearchAdapter? = null
    private var  cardDataList: MutableList<CardData> = mutableListOf()
    private var  selectedDataList: List<CardData> = mutableListOf()

    private var useTwoColumns = true
    private var categoryName: String = "Custom"
    private var categoryId: Long = 15

    private var category: com.deep.infotech.atm_card_wallet.maniya.dataModel.CategoryDataManiya? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCategoriesdataManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        activityResultLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                init()
            }
        }
        init()
    }

    private fun init() {
        cardDataList.clear()
      /*  categoryName = intent.getStringExtra("category_name") ?: "Custom"
       */
        categoryId = intent.getLongExtra("category_id", 15)
        category = DatabaseHelperManiya(this@CategoryDataActivityManiya).getSingleCategoryByID(categoryId)?.get(0)
        categoryName = category?.name.toString()

        Log.d("+++++", "categoryName---: $categoryName" +
                " categoryName---:$categoryId"

        )
                DatabaseHelperManiya(this).fetchLicenceData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchPassportData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchIDCardData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchResidenceCardData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchPaymentData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchGiftData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchLoyaltyData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchMemberShipData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchMedicalData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchHealthData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchBirthData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchMrgData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchSIMData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchPasswordData().isNotEmpty() ||
                DatabaseHelperManiya(this).fetchCustomData().isNotEmpty()||
                DatabaseHelperManiya(this).fetchPANData().isNotEmpty()||
                DatabaseHelperManiya(this).fetchAdharData().isNotEmpty()||
                DatabaseHelperManiya(this).fetchVoterData().isNotEmpty()||
                DatabaseHelperManiya(this).fetchVehicleData().isNotEmpty()

        when (categoryId) {
            1L ->
                if (DatabaseHelperManiya(this).fetchLicenceData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchLicenceData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.fullName ?: "",
                            item.documentNumber ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }
                }

            2L ->
                if (DatabaseHelperManiya(this).fetchPassportData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchPassportData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.fullName ?: "",
                            item.documentNumber ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )

                    }
                }

            3L ->
                if (DatabaseHelperManiya(this).fetchIDCardData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchIDCardData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.fullName ?: "",
                            item.documentNumber ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            4L ->
                if (DatabaseHelperManiya(this).fetchResidenceCardData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchResidenceCardData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.fullName ?: "",
                            item.documentNumber ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            5L ->
                if (DatabaseHelperManiya(this).fetchPaymentData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchPaymentData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.cardNumber ?: "",
                            item.holderName ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            6L ->
                if (DatabaseHelperManiya(this).fetchGiftData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchGiftData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.cardNumber ?: "",
                            item.brand ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            7L ->
                if (DatabaseHelperManiya(this).fetchLoyaltyData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchLoyaltyData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.cardNumber ?: "",
                            item.cardHolderName ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            8L ->
                if (DatabaseHelperManiya(this).fetchMemberShipData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchMemberShipData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.cardHolderNumber ?: "",
                            item.cardHolderNumber ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            9L ->
                if (DatabaseHelperManiya(this).fetchMedicalData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchMedicalData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.documentNumber ?: "",
                            item.email ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            10L ->
                if (DatabaseHelperManiya(this).fetchHealthData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchHealthData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.documentNumber ?: "",
                            item.email ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            11L ->
                if (DatabaseHelperManiya(this).fetchBirthData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchBirthData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.documentNumber ?: "",
                            item.fullName ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            12L ->
                if (DatabaseHelperManiya(this).fetchMrgData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchMrgData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.custom ?: "",
                            item.notes ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            13L ->
                if (DatabaseHelperManiya(this).fetchSIMData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchSIMData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.phoneNumber ?: "",
                            item.ownerName ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            14L ->
                if (DatabaseHelperManiya(this).fetchPasswordData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchPasswordData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.password ?: "",
                            item.login ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

            15L ->

                if (DatabaseHelperManiya(this).fetchCustomData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchCustomData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.fullName ?: "",
                            item.note ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                categoryId,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }
            16L ->

                if (DatabaseHelperManiya(this).fetchVehicleData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchVehicleData()) {
                        cardDataList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                categoryId,
                                item.label?.name ?: "",
                                item.label?.id ?: -1)
                        )
                    }

                }
            17L ->

                if (DatabaseHelperManiya(this).fetchAdharData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchAdharData()) {
                        cardDataList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                categoryId,
                                item.label?.name ?: "",
                                item.label?.id ?: -1)
                        )
                    }

                }
            17L ->

                if (DatabaseHelperManiya(this).fetchVoterData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchVoterData()) {
                        cardDataList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                categoryId,
                                item.label?.name ?: "",
                                item.label?.id ?: -1)
                        )
                    }

                }
            17L ->

                if (DatabaseHelperManiya(this).fetchPANData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchPANData()) {
                        cardDataList.add(
                            CardData(
                                item.id,
                                item.fullName ?: "",
                                item.note ?: "",
                                item.frontCardImage ?: "",
                                item.category?.name ?: "",
                                categoryId,
                                item.label?.name ?: "",
                                item.label?.id ?: -1)
                        )
                    }

                }
            else ->
                if (DatabaseHelperManiya(this).fetchCustomData().isNotEmpty()) {
                    for (item in DatabaseHelperManiya(this).fetchCustomData()) {
                        cardDataList.add(
                            CardData(
                            item.id,
                            item.fullName ?: "",
                            item.note ?: "",
                            item.frontCardImage ?: "",
                            item.category?.name ?: "",
                                15L,
                            item.label?.name ?: "",
                            item.label?.id ?: -1)
                        )
                    }

                }

        }

        binding.tvTitle.text = categoryName
        setCategoriesRecyclerView()
        setSearchDataView()
        showToolbarBar()
    }

    private fun showSearchBar() {
        binding.llSearchView.visible()
        binding.rlToolbar.gone()
        binding.llSelectionBar.gone()
        binding.edtSearch.requestFocus()
    }

    private fun showToolbarBar() {
        binding.rlToolbar.visible()
        binding.llSearchView.gone()
        binding.llSelectionBar.gone()
        binding.edtSearch.text.clear()
        searchAdapter?.filter("")
        binding.rvDataRecyclerView.scrollToPosition(0)

    }

    private fun showSelectionBar() {
        binding.ivDelete.alpha =1f
        binding.ivSelectAll.alpha =1f
        binding.ivDeselectAll.alpha =1f
        binding.ivShare.alpha =1f
        binding.llSearchView.gone()
        binding.rlToolbar.gone()
        binding.llSelectionBar.visible()
    }

    fun onCancelSelectionIconClick(view: View) {
        searchAdapter?.enableSelectionMode(false)
        showToolbarBar()
    }

    fun onDeleteClick(view: View) {
        if(view.alpha==1f)
        {
        val selectedItems = searchAdapter?.getSelectedData()
            doSoftDelete(selectedItems,categoryId)
        searchAdapter?.enableSelectionMode(false)
        showToolbarBar()
        }

    }

    fun onSelectAllClick(view: View) {
        if(view.alpha==1f){
        searchAdapter?.selectAll()}
    }

    fun onDeselectClick(view: View) {
        if(view.alpha==1f){
        searchAdapter?.deSelectAll()}
    }

    @SuppressLint("SetTextI18n")
    private fun setCategoriesRecyclerView() {

        binding.rvDataRecyclerView.apply {
            layoutManager = GridLayoutManager(this@CategoryDataActivityManiya, if (useTwoColumns) 2 else 1)
            searchAdapter = SearchAdapter(
                this@CategoryDataActivityManiya,
                cardDataList,
                useTwoColumns,
                onItemClick = { cardData, position ->
                    openRecordView(cardData.id, cardData.categoryID!!, -1)
                },
                onItemLongClick = { item, position ->
                showSelectionBar()
                 searchAdapter?.enableSelectionMode(true)
                    true
                },
                onSelectionChange = { selectedItems ->
                    selectedDataList = selectedItems
                    Log.d("++++SelectedItems++++", "Selected Items Size: ${selectedItems.size}---\n$selectedItems.")
                    if (selectedItems.isNotEmpty()) {
                        binding.tvSelectionCount.text = selectedItems.size.toString()

                        binding.ivDelete.visible()
                        binding.ivDelete.alpha =1f

                        binding.ivSelectAll.visible()
                        binding.ivSelectAll.alpha =1f

                        binding.ivDeselectAll.visible()
                        binding.ivDeselectAll.alpha =1f

                        binding.ivShare.visible()
                        binding.ivShare.alpha =1f

                        if(selectedItems.size==cardDataList.size){
                            binding.ivSelectAll.alpha =0.5f
                        }
                    } else {
                        binding.tvSelectionCount.text = categoryName

                        binding.ivDelete.alpha =0.5f

                        binding.ivShare.alpha =0.5f

                        binding.ivDeselectAll.alpha =0.5f

                        binding.ivSelectAll.visible()
                        binding.ivSelectAll.alpha =1f

                    }
                }
            )
            adapter = searchAdapter
        }

    }

    private fun setSearchDataView() {
        binding.edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(query: CharSequence?, start: Int, before: Int, count: Int) {
                if (query.toString().trim().isNotEmpty()) {
                    searchAdapter?.filter(query.toString())
                }
            }
            override fun afterTextChanged(s: Editable?) {
            }
        })
    }
    private fun openRecordView(itemID: Long, catID: Long, position: Int) {
        activityResultLauncher.launch(Intent(this@CategoryDataActivityManiya, ViewActivityManiya::class.java)
            .putExtra("categoryID", catID)
            .putExtra("ItemID", itemID)
            .putExtra("isFromScan", false)

        )
    }
    fun onFilterClick(view: View?) {
        useTwoColumns = !useTwoColumns
        binding.ivFilter.setImageResource(if (useTwoColumns) R.drawable.ic_grid_one else R.drawable.ic_two_grid)
        Log.d("+++++", "useTwoColumns: $useTwoColumns")
       // updateDataView()
      setCategoriesRecyclerView()
    }
    private fun updateDataView() {
        if (!useTwoColumns) {
            binding.rvDataRecyclerView.layoutManager = GridLayoutManager(this@CategoryDataActivityManiya, 1)
        } else {
            binding.rvDataRecyclerView.layoutManager = GridLayoutManager(this@CategoryDataActivityManiya, 2)
        }
        searchAdapter?.updateView(useTwoColumns)
    }
    private fun doSoftDelete(selectedItems: List<CardData>?, catID: Long) {
        Log.d("Delete+++", catID.toString())
        when (catID) {
            1L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this@CategoryDataActivityManiya).softLicenceDelete(item.id)
                }
            }

            2L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softPassportDelete(item.id)
                }
            }

            3L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softIDCardDelete(item.id)
                }
            }
            4L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softResidenceDelete(item.id)
                }
            }
            5L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softPaymentDelete(item.id)
                }
            }
            6L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softGiftDelete(item.id)
                }
            }

            7L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softLoyaltyDelete(item.id)
                }
            }

            8L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softMembershipDelete(item.id)
                }
            }

            9L -> {
                    selectedItems?.forEach { item ->
                        DatabaseHelperManiya(this).softMedicalDelete(item.id)
                    }
            }

            10L -> {
                    selectedItems?.forEach { item ->
                        DatabaseHelperManiya(this).softHealthDelete(item.id)
                    }
            }

            11L -> {
                    selectedItems?.forEach { item ->
                        DatabaseHelperManiya(this).softBirthDelete(item.id)
                    }
            }

            12L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softMrgDelete(item.id)
                }
            }

            13L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softSIMDelete(item.id)
                }
            }

            14L -> {
                    selectedItems?.forEach { item ->
                        DatabaseHelperManiya(this).softPasswordDelete(item.id)
                    }
            }

            15L -> {
                selectedItems?.forEach { item ->
                        DatabaseHelperManiya(this).softCustomDelete(item.id)
                    }
            }
            16L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softVehicleDelete(item.id)
                }
            }
            17L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softAdharDelete(item.id)
                }
            }
            18L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softVoterDelete(item.id)
                }
            }
            19L -> {
                selectedItems?.forEach { item ->
                    DatabaseHelperManiya(this).softPANDelete(item.id)
                }
            }
        }
        init()
    }
    fun onBackClick(view: View) {
        if (binding.llSearchView.isVisible) {
            showToolbarBar()
        } else {
            AdsInterstitial.instance?.showInterstitialAd(
                this@CategoryDataActivityManiya,
                false,
                object : AdsInterstitial.adfinish {
                    override fun adfinished() {
                        returnResult()
                    }
                })
        }
    }
    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }
    fun onShareClick(view: View) {
        if(view.alpha==1f){
            val selectedCardsImages: MutableList<String> = mutableListOf()
            searchAdapter?.getSelectedData()?.forEach { item ->
                selectedCardsImages.add(item.frontCardImage.toString())
            }
            multiShare(selectedCardsImages)
            searchAdapter?.enableSelectionMode(false)
            showToolbarBar()

        Log.d("+++++", "onShareClick: ")}
    }

    fun onCancelSearchClick(view: View) {
        showToolbarBar()
    }

    fun onClickSearch(view: View) {
        showSearchBar()
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }
}




