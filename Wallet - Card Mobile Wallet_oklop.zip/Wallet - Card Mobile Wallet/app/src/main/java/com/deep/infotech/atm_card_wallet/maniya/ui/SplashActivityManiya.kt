package com.deep.infotech.atm_card_wallet.maniya.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.app_open_show_ads
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.is_splash_appOpen
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.is_splash_interstitial
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.Ads.AdsOpenApp
import com.deep.infotech.atm_card_wallet.Ads.ConfigManager
import com.deep.infotech.atm_card_wallet.Ads.NetworkConnectedCheck
import com.deep.infotech.atm_card_wallet.databinding.ActivitySplashManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.CreatePinActivity
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.EnterPinActivity
import com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen.ReEnterPinActivity
import com.deep.infotech.atm_card_wallet.utils.LogD
import com.deep.infotech.atm_card_wallet.utils.Utils
import com.facebook.FacebookSdk.setAutoLogAppEventsEnabled
import com.facebook.ads.AudienceNetworkAds


class SplashActivityManiya : BaseActivity() {

    private lateinit var binding: ActivitySplashManiyaBinding
    private var openManager: AdsOpenApp? = null
    private lateinit var sharedPreferences: SharedPreferences

    @JvmField
    var intent: Intent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
     /*       when (Utils(this).getThemeMode()) {
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }*/
        updateWindow()

        /*is_splash_interstitial
        is_splash_appOpen*/

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this@SplashActivityManiya)

        AudienceNetworkAds.initialize(this)
        setAutoLogAppEventsEnabled(true)

        val configManager = ConfigManager(this)
        if (NetworkConnectedCheck.isConnected(this))
        {
            configManager.loadDataIntoClass()
            if (getSharedPreferences("openApp", 0).getBoolean("isFirstRun", true))
            {
                Handler(Looper.getMainLooper()).postDelayed({
                    checkAds()
                }, 4000)
            }
            else
            {
                checkAds()
            }
        } else {
            goNext()
        }
    }

     fun checkAds() {
         if (is_splash_interstitial)
         {
             LogD("SplashManiya+++","--is_splash_interstitial----TRUE")

             AdsInterstitial.instance?.showInterstitialAd(
                 this@SplashActivityManiya,
                 false,
                 object : AdsInterstitial.adfinish {
                     override fun adfinished() {
                         goNext()
                     }
                 })

         }
         else if (is_splash_appOpen)
         {
             LogD("SplashManiya+++","--is_splash_appOpen---TRUE-")

             if (app_open_show_ads) {
                 openManager = AdsOpenApp(this, binding.llProgressBar, sharedPreferences)
             } else {
                 goNext()
             }
         }else{
             LogD("SplashManiya+++","----FirstRun----NO ADS-----")
             goNext()
         }
     }
     fun goNext() {
        if (sharedPreferences.getBoolean("appLockIsCheck", false)) {
            Log.w("SplashManiya+++","Lock---true----")
            if (sharedPreferences.getBoolean("first time", true)) {
                Log.w("SplashManiya+++","appLockIsCheck---First-")
                startActivity(Intent(this@SplashActivityManiya, CreatePinActivity::class.java))
            } else {
                Log.w("SplashManiya+++","Lock---Enter----")
                if (Build.VERSION.SDK_INT >= 23) {
                    intent = Intent(this@SplashActivityManiya, EnterPinActivity::class.java)
                } else {
                    intent = Intent(this@SplashActivityManiya, ReEnterPinActivity::class.java)
                }
                intent!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent!!.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                intent!!.putExtra("pkgname", this@SplashActivityManiya.packageName)
                intent!!.putExtra("fromLockData", false)
                startActivity(intent)
                finish()
            }
        } else {

            Log.w("SplashManiya+++","Lock---false----")
            if (getSharedPreferences("language", 0).getBoolean("isFirstRun", true)) {
            Log.w("SplashManiya+++","language---First-")

                 startActivity(Intent(this, LanguageActivityManiya::class.java))
                 finish()
             } /*else if (AdsIDS.start_screen_show) { Log.w("SplashManiya+++","start_screen_show----")

            startActivity(Intent(this, StartActivity::class.java))
            finish()
        }*/ else {
            Log.w("SplashManiya+++","TESTMainActivityManiya----")
            startActivity(Intent(this, TESTMainActivityManiya::class.java))
            finish()
        }
        }
        finish()
    }


    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        finishAffinity()
    }

    override fun onResume() {
        super.onResume()
    /*    when (Utils(this).getThemeMode()) {
            "system" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
            "light" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            "dark" -> AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        }*/
    }
}