package com.deep.infotech.atm_card_wallet.maniya.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.ShapeDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.PopupWindow
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityViewManiyaBinding
import com.deep.infotech.atm_card_wallet.databinding.DialogRestoreBinding
import com.deep.infotech.atm_card_wallet.databinding.ItemEditrecordFieldBinding
import com.deep.infotech.atm_card_wallet.databinding.ItemViewrecordFieldBinding
import com.deep.infotech.atm_card_wallet.maniya.dataModel.AdharScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PassportScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.ResidentScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.GiftCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LoyaltyCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MemberShipCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MedicalCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.BirthCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MrgCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.SIMCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PasswordCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.CustomScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PANScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.VehicleScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.VoterScanDataManiya
import com.ironsource.gr
import jp.wasabeef.blurry.Blurry


class ViewActivityManiya : BaseActivity() {

    private var sTAG = "ViewActivityManiya++++"

    private lateinit var binding: ActivityViewManiyaBinding
    private lateinit var view: ItemViewrecordFieldBinding
    var mainChild: RelativeLayout? = null

    private var licenceData: MutableList<LicenseScanDataManiya> = mutableListOf()
    private var passportData: MutableList<PassportScanDataManiya> = mutableListOf()
    private var idData: MutableList<IdentityScanDataManiya> = mutableListOf()
    private var residenceData: MutableList<ResidentScanDataManiya> = mutableListOf()
    private var paymentData: MutableList<PaymentCardScanDataManiya> = mutableListOf()
    private var giftData: MutableList<GiftCardScanDataManiya> = mutableListOf()
    private var loyaltyData: MutableList<LoyaltyCardScanDataManiya> = mutableListOf()
    private var memberShipData: MutableList<MemberShipCardScanDataManiya> = mutableListOf()
    private var medicalData: MutableList<MedicalCardScanDataManiya> = mutableListOf()
    private var healthData: MutableList<HealthCardScanDataManiya> = mutableListOf()
    private var birthData: MutableList<BirthCardScanDataManiya> = mutableListOf()
    private var mrgData: MutableList<MrgCardScanDataManiya> = mutableListOf()
    private var simData: MutableList<SIMCardScanDataManiya> = mutableListOf()
    private var passwordData: MutableList<PasswordCardScanDataManiya> = mutableListOf()
    private var customData: MutableList<CustomScanDataManiya> = mutableListOf()
    private var vehicleData: MutableList<VehicleScanDataManiya> = mutableListOf()
    private var adharData: MutableList<AdharScanDataManiya> = mutableListOf()
    private var voterData: MutableList<VoterScanDataManiya> = mutableListOf()
    private var panData: MutableList<PANScanDataManiya> = mutableListOf()

    private var popupWindow: PopupWindow? = null
    private var menuShare: View? = null
    private var menuFav: View? = null
    private var menuEdit: View? = null
    private var menuLabel: View? = null
    private var menuExpiry: View? = null
    private var menuArchive: View? = null
    private var menuExport: View? = null
    private var menuDetails: View? = null
    private var menuDelete: View? = null
    private var ivFav: ImageView? = null
    private var ivArchive: ImageView? = null
    private var ivDelete: ImageView? = null
    private var tvFav: TextView? = null
    private var tvArchive: TextView? = null
    private var tvDelete: TextView? = null

    private var title = ""
    private var frontImage = ""
    private var backImage = ""
    private var categoryID = 15L
    private var labelID = 0L
    private var appreanceColor = 0
    private var dataID = 15L
    private var isFirstImage = true
    private var isFromScan = false
    private var isSpoilerClick = false
    private var isSpoiler = false
    private var isFav = false
    private var isLock = false
    private var isArchive = false
    private var isSoftDelete = false

    private var isNumberVisible = false
    private var isPINVisible = false
    private var isPasswordVisible = false
    private var isCVVVisible = false

    private var currentCategory = "Custom"

    private lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityViewManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        getIntentData()
        appreanceColor = ContextCompat.getColor(this@ViewActivityManiya, R.color.appreance)
        // Register the ActivityResultLauncher
        activityResultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                Log.d("ActivityResultContracts+++++", "------")
                init()
            }
        }
        init()
    }

    fun getIntentData() {
        categoryID = intent.getLongExtra("categoryID", 15L)
        isFromScan = intent.getBooleanExtra("isFromScan", false)
        dataID = intent.getLongExtra("ItemID", 0L)
        currentCategory = getCategoryTitle(categoryID)
        Log.w(
            sTAG, "title--->$title\n" +
                    "DataID--->$dataID\n" +
                    "categoryID--->$categoryID\n" +
                    "currentCategory--->$currentCategory\n" +
                    "isFromScan--->$isFromScan"
        )
    }

    fun init() {
        getData()
        createMenuPopupWindow()
        setSpoiler()
    }

    private fun getData() {
        binding.dynamicContainer.removeAllViews()
        clearAllData()
         view = ItemViewrecordFieldBinding.inflate(LayoutInflater.from(this))
        if (isFromScan) {
            getScannedData()
        } else {
            getCategoryData()
        }
        if (backImage.isNotEmpty()) binding.tvFlip.visible()
        if (isSpoiler) binding.tvSpoiler.visible()
        if (title.isNotEmpty()) {
            binding.tvLabelTitle.visibility = visible()
            binding.tvLabelTitle.text = title
        }
        if (currentCategory.isNotEmpty()) {
            binding.tvType.text = currentCategory
        }
         binding.ivCard.setOnClickListener {
            startActivity(
                Intent(this@ViewActivityManiya, ImagePreviewActivity::class.java)
                    .putExtra("FrontImage", frontImage)
                    .putExtra("BackImage", backImage)
            )
        }

        binding.rlToolbar.backgroundTintList = ColorStateList.valueOf(appreanceColor)
        binding.rlImage.backgroundTintList = ColorStateList.valueOf(appreanceColor)

    }
    private fun clearAllData() {
        licenceData.clear()
        passportData.clear()
        idData.clear()
        residenceData.clear()
        paymentData.clear()
        giftData.clear()
        loyaltyData.clear()
        memberShipData.clear()
        medicalData.clear()
        healthData.clear()
        birthData.clear()
        mrgData.clear()
        simData.clear()
        passwordData.clear()
        customData.clear()
        vehicleData.clear()
        adharData.clear()
        voterData.clear()
        panData.clear()
    }
    private fun getCategoryData() {
        when (categoryID) {
            1L -> {
                licenceData = DatabaseHelperManiya(this).fetchLicensesCardByID(dataID)
                setLicenceResultData()
            }

            2L -> {
                passportData = DatabaseHelperManiya(this).fetchPassportCardByID(dataID)
                setPassportResultData()
            }

            3L -> {
                idData = DatabaseHelperManiya(this).fetchIDCardByID(dataID)
                setIDCardResultData()
            }

            4L -> {
                residenceData = DatabaseHelperManiya(this).fetchResidenceCardByID(dataID)
                setResidenceResultData()
            }

            5L -> {
                paymentData = DatabaseHelperManiya(this).fetchPaymentCardByID(dataID)
                setPaymentResultData()
            }

            6L -> {
                giftData = DatabaseHelperManiya(this).fetchGiftCardByID(dataID)
                setGiftResultData()
            }

            7L -> {
                loyaltyData = DatabaseHelperManiya(this).fetchLoyaltyCardByID(dataID)
                setLoyaltyResultData()
            }

            8L -> {
                memberShipData = DatabaseHelperManiya(this).fetchMemberShipCardByID(dataID)
                setMemberShipResultData()
            }

            9L -> {
                medicalData = DatabaseHelperManiya(this).fetchMedicalCardByID(dataID)
                setMedicalResultData()
            }

            10L -> {
                healthData = DatabaseHelperManiya(this).fetchHealthCardByID(dataID)
                setHealthResultData()
            }

            11L -> {
                birthData = DatabaseHelperManiya(this).fetchBirthCardByID(dataID)
                setBirthResultData()
            }

            12L -> {
                mrgData = DatabaseHelperManiya(this).fetchMrgCardByID(dataID)
                setMrgResultData()
            }

            13L -> {
                simData = DatabaseHelperManiya(this).fetchSIMCardByID(dataID)
                setSIMResultData()
            }

            14L -> {
                passwordData = DatabaseHelperManiya(this).fetchPasswordCardByID(dataID)
                setPasswordResultData()
            }

            15L -> {
                customData = DatabaseHelperManiya(this).fetchCustomCardByID(dataID)
                setCustomResultData()
            }
            16L -> {
                vehicleData = DatabaseHelperManiya(this).fetchVehicleCardByID(dataID)
                setVehicleResultData()
            }
            17L -> {
                adharData = DatabaseHelperManiya(this).fetchAdharCardByID(dataID)
                setAdharResultData()
            }
            18L -> {
                voterData = DatabaseHelperManiya(this).fetchVoterCardByID(dataID)
                setVoterResultData()
            }
            19L -> {
                panData = DatabaseHelperManiya(this).fetchPANCardByID(dataID)
                setPANResultData()
            }
        }
        updateDividerVisibility()
    }

    private fun getScannedData() {
        when (categoryID) {
            1L -> {
                licenceData.add(DatabaseHelperManiya(this).fetchLastLicenceRecord())
                setLicenceResultData()
            }

            2L -> {
                passportData.add(DatabaseHelperManiya(this).fetchLastPassportRecord())
                setPassportResultData()
            }

            3L -> {
                idData.add(DatabaseHelperManiya(this).fetchLastIDCardRecord())
                setIDCardResultData()
            }

            4L -> {
                residenceData.add(DatabaseHelperManiya(this).fetchLastResidenceCardRecord())
                setResidenceResultData()
            }

            5L -> {
                paymentData.add(DatabaseHelperManiya(this).fetchLastPaymentRecord())
                setPaymentResultData()
            }

            6L -> {
                giftData.add(DatabaseHelperManiya(this).fetchLastGiftCardRecord())
                setGiftResultData()
            }

            7L -> {
                loyaltyData.add(DatabaseHelperManiya(this).fetchLastLoyaltyCardRecord())
                setLoyaltyResultData()
            }

            8L -> {
                memberShipData.add(DatabaseHelperManiya(this).fetchLastMembershipCardRecord())
                setMemberShipResultData()
            }

            9L -> {
                medicalData.add(DatabaseHelperManiya(this).fetchLastMedicalCardRecord())
                setMedicalResultData()
            }

            10L -> {
                healthData.add(DatabaseHelperManiya(this).fetchLastHealthCardRecord())
                setHealthResultData()
            }

            11L -> {
                birthData.add(DatabaseHelperManiya(this).fetchLastBirthCardRecord())
                setBirthResultData()
            }

            12L -> {
                mrgData.add(DatabaseHelperManiya(this).fetchLastMrgCardRecord())
                setMrgResultData()
            }

            13L -> {
                simData.add(DatabaseHelperManiya(this).fetchLastSIMCardRecord())
                setSIMResultData()
            }

            14L -> {
                passwordData.add(DatabaseHelperManiya(this).fetchLastPasswordCardRecord())
                setPasswordResultData()
            }

            15L -> {
                customData.add(DatabaseHelperManiya(this).fetchLastCustomCardRecord())
                setCustomResultData()
            }

            16L -> {
                vehicleData = DatabaseHelperManiya(this).fetchVehicleCardByID(dataID)
                setVehicleResultData()
            }

            17L -> {
                adharData = DatabaseHelperManiya(this).fetchAdharCardByID(dataID)
                setAdharResultData()
            }

            18L -> {
                voterData = DatabaseHelperManiya(this).fetchVoterCardByID(dataID)
                setVoterResultData()
            }

            19L -> {
                panData = DatabaseHelperManiya(this).fetchPANCardByID(dataID)
                setPANResultData()
            }

        }
        updateDividerVisibility()
    }

    private fun maskCardNumber(cardNumber: String): String {
        /* -----   Show first 4 and last 3 digits, and mask the middle part-----*/
        val cleanedCardNumber = cardNumber.replace(" ", "").replace("-", "")
        return if (cleanedCardNumber.length > 7) {
            val first4 = cleanedCardNumber.take(4)
            val last3 = cleanedCardNumber.takeLast(3)
            val middleMasked = "*".repeat(cleanedCardNumber.length - 7)  // Mask the middle part
            "$first4 $middleMasked $last3"
        } else {
            cardNumber
        }
    }

    private fun setLicenceResultData() {
        if (licenceData.size > 0)
        {
            isNumberVisible = false

            isLock = licenceData[0].isLock
            isSpoiler = licenceData[0].isSensitive
            isSoftDelete = licenceData[0].isDelete
            isArchive = licenceData[0].isArchive
            isFav = licenceData[0].isFav
            frontImage = licenceData[0].frontCardImage
            backImage = licenceData[0].backCardImage
            binding.tvType.text = licenceData[0].category?.name
            title = licenceData[0].title
            appreanceColor = licenceData[0].appearanceColor
            labelID = licenceData[0].label?.id ?: 0

            mainChild = view.mainChild
            isSpoilerClick=isSpoiler


            /*----fullName-----*/if (licenceData[0].fullName.isNotEmpty())
            {
                view.rlNameView.visible()
                view.tvNameText.text = licenceData[0].fullName
                binding.rlPinned.visible()
            }

            /*----DocumentNumber-----*/if (licenceData[0].documentNumber.isNotEmpty())
            {
                view.rlLicenceNumber.visible()
                view.tvLiNumber.text = getString(R.string.licence_number)
                view.tvLiNumberText.text = maskCardNumber(licenceData[0].documentNumber)
                view.ivEyeLiNumber.visible()
                view.ivEyeLiNumber.setOnClickListener {
                    if (!isNumberVisible) {
                        view.tvLiNumberText.text = licenceData[0].documentNumber
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvLiNumberText.text = maskCardNumber(licenceData[0].documentNumber)
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_hide)
                    }
                    isNumberVisible = !isNumberVisible
                }
               binding.rlPinned.visible()
            }

            /*----expiryDate-----*/if (licenceData[0].expiryDate.isNotEmpty()) {
            if(licenceData[0].expiryDate.equals("null",ignoreCase = true)) { }else{

                view.rlExpDate.visible()
                view.tvExpDateText.text = licenceData[0].expiryDate
                binding.rlPinned.visible()}
            }

            /*----Gender-----*/if (licenceData[0].gender.isNotEmpty()) {
                view.rlGender.visible()
                view.tvGenderText.text = licenceData[0].gender
                binding.rlPinned.visible()
            }

            /*----bloodGroup-----*/if (licenceData[0].bloodGroup.isNotEmpty()) {
                view.rlBloodGroup.visible()
                view.tvBloodGroupText.text = licenceData[0].bloodGroup
               binding.rlPinned.visible()

            }

            /*----ParentsName-----*/if (licenceData[0].parentsName.isNotEmpty()) {
                view.rlParents.visible()
                view.tvParentsText.text = licenceData[0].parentsName
            binding.rlPinned.visible()

            }

            /*----issueDate-----*/if (licenceData[0].issueDate.isNotEmpty()) {
            if(licenceData[0].issueDate.equals("null",ignoreCase = true)) { }else{
                view.rlIssueDate.visible()
                view.tvIssueDateText.text = licenceData[0].parentsName
            binding.rlPinned.visible()}

            }

            /*----dob-----*/if (licenceData[0].dob.isNotEmpty()) {
            if(licenceData[0].dob.equals("null",ignoreCase = true))
            { }else{
                view.rlDOBDate.visible()
                view.tvDOBDateText.text = licenceData[0].dob
                binding.rlPinned.visible()}
            }

            /*----personalNumber-----*/ if (licenceData[0].personamNumber.isNotEmpty()) {
                view.rlPersonalNo.visible()
                view.tvPersonalNoText.text = licenceData[0].personamNumber
                binding.rlPinned.visible()

            }

            /*----issueCountry-----*/if (licenceData[0].issueCountry.isNotEmpty()) {
                view.rlIssueCountry.visible()
                view.tvIssueCountryText.text = licenceData[0].issueCountry
            binding.rlPinned.visible()

            }

            /*----issueAuthority-----*/if (licenceData[0].issueAuthority.isNotEmpty()) {
                view.rlIssueAuthority.visible()
                view.tvIssueAuthorityText.text = licenceData[0].issueAuthority
            binding.rlPinned.visible()

            }

            /*----regAddress-----*/if (licenceData[0].regAddress.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = licenceData[0].regAddress
            binding.rlPinned.visible()

            }

            /*----restrictions-----*/if (licenceData[0].restrictions.isNotEmpty()) {
                view.rlRestrictions.visible()
                view.tvRestrictionsText.text = licenceData[0].restrictions
                binding.rlPinned.visible()

            }

            /*----notes-----*/ if (licenceData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = licenceData[0].notes
                binding.rlPinned.visible()

            }

            /*----classs-----*/if (licenceData[0].classs.isNotEmpty()) {
                view.rlClass.visible()
                view.tvClassText.text = licenceData[0].classs
                binding.rlPinned.visible()
            }
            binding.dynamicContainer.addView(view.root)
        }

    }
    private fun setPassportResultData() {
        if (passportData.size > 0) {

            isNumberVisible= false

            isSpoiler = passportData[0].isSensitive
            isLock = passportData[0].isLock
            isSoftDelete = passportData[0].isDelete
            isArchive = passportData[0].isArchive
            isFav = passportData[0].isFav
            frontImage = passportData[0].frontCardImage
            backImage = passportData[0].backCardImage
            binding.tvType.text = passportData[0].category?.name
            title = passportData[0].title.toString()
            appreanceColor = passportData[0].appearanceColor
            labelID = passportData[0].label?.id ?: 0
            mainChild = view.mainChild

            isSpoilerClick=isSpoiler


            /*----fullName-----*/if (passportData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = passportData[0].fullName
                binding.rlPinned.visible()
            }
            /*----DocumentNumber-----*/if (passportData[0].documentNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = passportData[0].documentNumber
                view.tvLiNumber.text = getString(R.string.passport_number)
                binding.rlPinned.visible()

            }
            /*----issueDate-----*/if (passportData[0].issueDate.isNotEmpty()) {

                if(passportData[0].issueDate.equals("null",ignoreCase = true))
                { }else{

                view.rlIssueDate.visible()
                view.tvIssueDateText.text = passportData[0].issueDate
                binding.rlPinned.visible()}

            }
            /*----ExpDate-----*/if (passportData[0].expiryDate.isNotEmpty()) {

                if(passportData[0].expiryDate.equals("null",ignoreCase = true))
                { }else{

                view.rlExpDate.visible()
                view.tvExpDateText.text = passportData[0].expiryDate
                binding.rlPinned.visible()}

            }
            /*----dob-----*/if (passportData[0].dob.isNotEmpty()) {
                if(passportData[0].dob.equals("null",ignoreCase = true))
                { }else{
                view.rlDOBDate.visible()
                view.tvDOBDateText.text = passportData[0].dob
                binding.rlPinned.visible()}

            }
            /*----personalNumber-----*/if (passportData[0].personalNumber.isNotEmpty()) {
                view.rlPersonalNo.visible()
                view.tvPersonalNoText.text = passportData[0].personalNumber
                binding.rlPinned.visible()

            }
            /*----type-----*/if (passportData[0].type.isNotEmpty()) {
                view.rlType.visible()
                view.tvTypeText.text = passportData[0].type
                binding.rlPinned.visible()

            }
            /*----BirthPLace-----*/if (passportData[0].placeOfBirth.isNotEmpty()) {
                view.rlBirthPlace.visible()
                view.tvBirthPlaceText.text = passportData[0].placeOfBirth
                binding.rlPinned.visible()
            }
            /*----issueCountry-----*/if (passportData[0].issueCountry.isNotEmpty()) {
                view.rlCountry.visible()
                view.tvCountryText.text = passportData[0].issueCountry
                binding.rlPinned.visible()
            }
            /*----issueAuthority-----*/if (passportData[0].issueAuthority.isNotEmpty()) {
                view.rlIssueAuthority.visible()
                view.tvIssueAuthorityText.text = passportData[0].issueAuthority
                binding.rlPinned.visible()
            }
            /*----Nationality-----*/if (passportData[0].nationality.isNotEmpty()) {
                view.rlNationality.visible()
                view.tvNationalityText.text = passportData[0].nationality
                binding.rlPinned.visible()
            }
            /*----RegAddress-----*/if (passportData[0].regAddress.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = passportData[0].regAddress
                binding.rlPinned.visible()
            }
            /*----BlankPage-----*/if (passportData[0].blankpageRemain.isNotEmpty()) {
                view.rlBlankPage.visible()
                view.tvBlankPageText.text = passportData[0].blankpageRemain
                binding.rlPinned.visible()
            }
            /*----notes-----*/if (passportData[0].Notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = passportData[0].Notes
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setIDCardResultData() {
        if (idData.size > 0) {
            isSoftDelete = idData[0].isDelete
            isArchive = idData[0].isArchive
            isFav = idData[0].isFav
            isLock = idData[0].isLock
            isSpoiler = idData[0].isSensitive
            frontImage = idData[0].frontCardImage
            backImage = idData[0].backCardImage
            binding.tvType.text = idData[0].category?.name
            title = idData[0].title
            appreanceColor = idData[0].appearanceColor
            labelID = idData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler


            /*----fullName-----*/if (idData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = idData[0].fullName
                binding.rlPinned.visible()
            }
            /*----DocumentNumber-----*/if (idData[0].documentNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = idData[0].documentNumber
                view.tvLiNumber.text = getString(R.string.id_number)
                binding.rlPinned.visible()
            }
            /*----issueDate-----*/if (idData[0].issueDate.isNotEmpty()) {
                if(idData[0].dob.equals("null",ignoreCase = true))
                { }else{

                view.rlIssueDate.visible()
                view.tvIssueDateText.text = idData[0].issueDate
                binding.rlPinned.visible()}

            }
            /*----ExpDate-----*/if (idData[0].expiryDate.isNotEmpty()) {
                if(idData[0].expiryDate.equals("null",ignoreCase = true))
                { }else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = idData[0].expiryDate
                binding.rlPinned.visible()}

            }
            /*----dob-----*/if (idData[0].dob.isNotEmpty()) {
                if(idData[0].dob.equals("null",ignoreCase = true))
                { }else{
                view.rlDOBDate.visible()
                view.tvDOBDateText.text = idData[0].dob
                binding.rlPinned.visible()}

            }
            /*----personalNumber-----*/if (idData[0].personalNumber.isNotEmpty()) {
                view.rlPersonalNo.visible()
                view.tvPersonalNoText.text = idData[0].personalNumber
                binding.rlPinned.visible()

            }

            /*----BirthPLace-----*/if (idData[0].placeOfBirth.isNotEmpty()) {
                view.rlBirthPlace.visible()
                view.tvBirthPlaceText.text = idData[0].placeOfBirth
                binding.rlPinned.visible()
            }
            /*----issueCountry-----*/if (idData[0].issueCountry.isNotEmpty()) {
                view.rlCountry.visible()
                view.tvCountryText.text = idData[0].issueCountry
                binding.rlPinned.visible()
            }
            /*----issueAuthority-----*/if (idData[0].issueAuthority.isNotEmpty()) {
                view.rlIssueAuthority.visible()
                view.tvIssueAuthorityText.text = idData[0].issueAuthority
                binding.rlPinned.visible()
            }
            /*----Nationality-----*/if (idData[0].nationality.isNotEmpty()) {
                view.rlNationality.visible()
                view.tvNationalityText.text = idData[0].nationality
                binding.rlPinned.visible()
            }
            /*----RegAddress-----*/if (idData[0].regAddress.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = idData[0].regAddress
                binding.rlPinned.visible()
            }

            /*----notes-----*/if (idData[0].Notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = idData[0].Notes
                binding.rlPinned.visible()
            }


            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setResidenceResultData() {
        if (residenceData.size > 0) {
            isSoftDelete = residenceData[0].isDelete
            isArchive = residenceData[0].isArchive
            isFav = residenceData[0].isFav
            isLock = residenceData[0].isLock
            dataID = residenceData[0].id
            isSpoiler = residenceData[0].isSensitive
            frontImage = residenceData[0].frontCardImage
            backImage = residenceData[0].backCardImage
            binding.tvType.text = residenceData[0].category?.name.toString()
            title = residenceData[0].title
            appreanceColor = residenceData[0].appearanceColor
            labelID = residenceData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler


            /*----fullName-----*/if (residenceData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvName.text = getString(R.string.name)
                view.tvNameText.text = residenceData[0].fullName
                binding.rlPinned.visible()
            }

            /*----DocumentNumber-----*/if (residenceData[0].documentNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumber.text = getString(R.string.document_number)
                view.tvLiNumberText.text = residenceData[0].documentNumber
                binding.rlPinned.visible()

            }
            /*----issueDate-----*/if (residenceData[0].issueDate.isNotEmpty()) {
                if(residenceData[0].dob.equals("null",ignoreCase = true))
                { }else{
                view.rlIssueDate.visible()
                view.tvIssueDateText.text = residenceData[0].issueDate
                binding.rlPinned.visible()}

            }
            /*----ExpDate-----*/if (residenceData[0].expiryDate.isNotEmpty()) {
                if(residenceData[0].expiryDate.equals("null",ignoreCase = true))
                { }else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = residenceData[0].expiryDate
                binding.rlPinned.visible()}

            }
            /*----dob-----*/if (residenceData[0].dob.isNotEmpty()) {
                if(residenceData[0].dob.equals("null",ignoreCase = true))
                { }else{
                view.rlDOBDate.visible()
                view.tvDOBDateText.text = residenceData[0].dob
                binding.rlPinned.visible()}

            }
            /*----personalNumber-----*/if (residenceData[0].personalNumber.isNotEmpty()) {
                view.rlPersonalNo.visible()
                view.tvPersonalNoText.text = residenceData[0].personalNumber
                binding.rlPinned.visible()

            }

            /*----BirthPLace-----*/if (residenceData[0].placeOfBirth.isNotEmpty()) {
                view.rlBirthPlace.visible()
                view.tvBirthPlaceText.text = residenceData[0].placeOfBirth
                binding.rlPinned.visible()
            }
            /*----issueCountry-----*/if (residenceData[0].issueCountry.isNotEmpty()) {
                view.rlCountry.visible()
                view.tvCountryText.text = residenceData[0].issueCountry
                binding.rlPinned.visible()
            }
            /*----issueAuthority-----*/if (residenceData[0].issueAuthority.isNotEmpty()) {
                view.rlIssueAuthority.visible()
                view.tvIssueAuthorityText.text = residenceData[0].issueAuthority
                binding.rlPinned.visible()
            }
            /*----Nationality-----*/if (residenceData[0].nationality.isNotEmpty()) {
                view.rlNationality.visible()
                view.tvNationalityText.text = residenceData[0].nationality
                binding.rlPinned.visible()
            }
            /*----RegAddress-----*/if (residenceData[0].regAddress.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = residenceData[0].regAddress
                binding.rlPinned.visible()
            }

            /*----notes-----*/if (residenceData[0].Notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = residenceData[0].Notes
                binding.rlPinned.visible()

            }



            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setPaymentResultData() {
        if (paymentData.size > 0) {

            isSoftDelete = paymentData[0].isDelete
            isArchive = paymentData[0].isArchive
            isFav = paymentData[0].isFav
            isLock = paymentData[0].isLock
            dataID = paymentData[0].id
            isSpoiler = paymentData[0].isSensitive
            frontImage = paymentData[0].frontCardImage.toString()
            backImage = paymentData[0].backCardImage.toString()
            binding.tvType.text = paymentData[0].category?.name.toString()
            title = paymentData[0].title.toString()
            appreanceColor = paymentData[0].appearanceColor
            labelID = paymentData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----CardholderName-----*/
            if (paymentData[0].holderName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = paymentData[0].holderName
                view.tvName.text = getString(R.string.cardholder_name)
                binding.rlPinned.visible()
            }

            /*----CardNumber-----*/
            if (paymentData[0].cardNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = maskCardNumber(paymentData[0].cardNumber)
                view.tvLiNumber.text = getString(R.string.card_number)
                view.ivEyeLiNumber.visible()
                view.ivEyeLiNumber.setOnClickListener {
                    if (!isNumberVisible) {
                        view.tvLiNumberText.text = paymentData[0].cardNumber
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvLiNumberText.text = maskCardNumber(paymentData[0].cardNumber)
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_hide)
                    }
                    isNumberVisible = !isNumberVisible
                }
                binding.rlPinned.visible()
            }
            /*----CVV-----*/
            if (paymentData[0].cvv.isNotEmpty()) {
                view.rlCVV.visible()
                view.tvCVVText.text = paymentData[0].cvv.map { '*' }.joinToString("")
                view.ivEyeCVV.visible()
                view.ivEyeCVV.setOnClickListener {
                    if (!isCVVVisible) {
                        view.tvCVVText.text = paymentData[0].cvv
                        view.ivEyeCVV.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvCVVText.text = paymentData[0].cvv.map { '*' }.joinToString("")
                        view.ivEyeCVV.setImageResource(R.drawable.eye_hide)
                    }
                    isCVVVisible = !isCVVVisible
                }
                binding.rlPinned.visible()
            }

            /*----ExpDate-----*/
            if (paymentData[0].expDate.isNotEmpty()) {
                if(paymentData[0].expDate.equals("null",ignoreCase = true))
                { }else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = paymentData[0].expDate
                binding.rlPinned.visible()}

            }
            /*----CardType-----*/
            if (paymentData[0].cardType.isNotEmpty()) {
                view.rlType.visible()
                view.tvTypeText.text = paymentData[0].cardType
                binding.rlPinned.visible()

            }

            /*----Bank-----*/
            if (paymentData[0].bankName.isNotEmpty()) {
                view.rlBank.visible()
                view.tvBankText.text = paymentData[0].bankName
                binding.rlPinned.visible()
            }

            /*----CardPIN-----*/
            if (paymentData[0].cardPIN.isNotEmpty()) {
                view.rlPIN.visible()
                view.tvPINText.text = paymentData[0].cardPIN.map { '*' }.joinToString("")
                view.ivEyePIN.visible()
                view.ivEyePIN.setOnClickListener {
                    if (!isPINVisible) {
                        view.tvPINText.text = paymentData[0].cardPIN
                        view.ivEyePIN.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvPINText.text = paymentData[0].cardPIN.map { '*' }.joinToString("")
                        view.ivEyePIN.setImageResource(R.drawable.eye_hide)
                    }
                    isPINVisible = !isPINVisible
                }
                binding.rlPinned.visible()
            }
            /*----PhoneNumber-----*/
            if (paymentData[0].phoneNumber.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = paymentData[0].phoneNumber
                binding.rlPinned.visible()
            }
            /*----Email-----*/
            if (paymentData[0].email.isNotEmpty()) {
                view.rlEmail.visible()
                view.tvEmailText.text = paymentData[0].email
                binding.rlPinned.visible()
            }

            /*----Barcode-----*/
            if (paymentData[0].barcode.isNotEmpty()) {
                view.rlBarcode.visible()
                view.tvBarcodeText.text = paymentData[0].barcode
                binding.rlPinned.visible()
            }

            /*----OtherName-----*/
            if (paymentData[0].fullName.isNotEmpty()) {
                view.rlOtherNameView.visible()
                view.tvOtherNameText.text = paymentData[0].fullName
                view.tvOtherName.text = getString(R.string.full_name)
                binding.rlPinned.visible()
            }
            /*----URL-----*/
            if (paymentData[0].url.isNotEmpty()) {
                view.rlURL.visible()
                view.tvURLText.text = paymentData[0].url
                binding.rlPinned.visible()
            }

            /*----RegAddress-----*/
            if (paymentData[0].address.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = paymentData[0].address
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)
        }
    }
    private fun setBirthResultData() {
        if (birthData.size > 0) {
            isSoftDelete = birthData[0].isDelete
            isArchive = birthData[0].isArchive
            isFav = birthData[0].isFav
            isLock = birthData[0].isLock
            dataID = birthData[0].id
            isSpoiler = birthData[0].isSensitive
            frontImage = birthData[0].frontCardImage.toString()
            backImage = birthData[0].backCardImage.toString()
            binding.tvType.text = birthData[0].category?.name.toString()
            title = birthData[0].title.toString()
            appreanceColor = birthData[0].appearanceColor
            labelID = birthData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler


            /*----FullName-----*/if (birthData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = birthData[0].fullName
                binding.rlPinned.visible()
            }
            /*----DocumentNumber-----*/if (birthData[0].documentNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = birthData[0].documentNumber
                view.tvLiNumber.text = resources.getString(R.string.document_number)
                binding.rlPinned.visible()

            }
            /*----notes-----*/if (birthData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = birthData[0].notes
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setGiftResultData() { if (giftData.size > 0) {
            isSoftDelete = giftData[0].isDelete
            isArchive = giftData[0].isArchive
            isFav = giftData[0].isFav
            isLock = giftData[0].isLock
            dataID = giftData[0].id
            isSpoiler = giftData[0].isSensitive
            frontImage = giftData[0].frontCardImage.toString()
            backImage = giftData[0].backCardImage.toString()
            binding.tvType.text = giftData[0].category?.name.toString()
            title = giftData[0].title.toString()
            appreanceColor = giftData[0].appearanceColor
            labelID = giftData[0].label?.id ?: 0
            mainChild = view.mainChild
        isSpoilerClick=isSpoiler

            /*----CardNumber-----*/
        if (giftData[0].cardNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = giftData[0].cardNumber
                view.tvLiNumber.text = getString(R.string.card_number)
                binding.rlPinned.visible()

            }
            /*----PIN-----*/
        if (giftData[0].pin.isNotEmpty()) {
                view.rlPIN.visible()
                view.tvPINText.text = giftData[0].pin.map { '*' }.joinToString("")
                view.ivEyePIN.visible()
                view.ivEyePIN.setOnClickListener {
                    if (!isPINVisible) {
                        view.tvPINText.text = giftData[0].pin
                        view.ivEyePIN.setImageResource(R.drawable.eye_visible)
                    }
                    else {
                        view.tvPINText.text = giftData[0].pin.map { '*' }.joinToString("")
                        view.ivEyePIN.setImageResource(R.drawable.eye_hide)
                    }
                    isPINVisible = !isPINVisible
                }
                binding.rlPinned.visible()
            }
            /*----Amount-----*/if (giftData[0].amount.isNotEmpty()) {
                view.rlAmount.visible()
                view.tvAmountText.text = giftData[0].amount
                binding.rlPinned.visible()
            }
            /*----barcode-----*/if (giftData[0].barcode.isNotEmpty()) {
                view.rlBarcode.visible()
                view.tvBarcodeText.text = giftData[0].barcode
                binding.rlPinned.visible()
            }
            /*----brand-----*/if (giftData[0].brand.isNotEmpty()) {
                view.rlBrand.visible()
                view.tvBrandText.text = giftData[0].brand
                binding.rlPinned.visible()
            }
            /*----IssueDate-----*/if (giftData[0].issueDate.isNotEmpty()) {
            if (giftData[0].issueDate.equals("null",ignoreCase = true)) {}else{
                view.rlIssueDate.visible()
                view.tvIssueDateText.text = giftData[0].issueDate
                binding.rlPinned.visible()}
            }
            /*----ExpDate-----*/if (giftData[0].expDate.isNotEmpty()) {}else{
            if (giftData[0].expDate.equals("null",ignoreCase = true)) {
                view.rlExpDate.visible()
                view.tvExpDateText.text = giftData[0].expDate
                binding.rlPinned.visible()}
            }
            /*----notes-----*/if (giftData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = giftData[0].notes
                binding.rlPinned.visible()
            }


            binding.dynamicContainer.addView(view.root)

        } }
    private fun setHealthResultData() {

        if (healthData.size > 0) {
            isSoftDelete = healthData[0].isDelete
            isArchive = healthData[0].isArchive
            isFav = healthData[0].isFav
            isLock = healthData[0].isLock
            dataID = healthData[0].id
            isSpoiler = healthData[0].isSensitive
            frontImage = healthData[0].frontCardImage.toString()
            backImage = healthData[0].backCardImage.toString()
            binding.tvType.text = healthData[0].category?.name.toString()
            title = healthData[0].title.toString()
            appreanceColor = healthData[0].appearanceColor
            labelID = healthData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----FullName-----*/if (healthData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = healthData[0].fullName
                binding.rlPinned.visible()
            }
            /*----DocumentNumber-----*/if (healthData[0].documentNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumber.text = resources.getString(R.string.document_number)
                view.tvLiNumberText.text = healthData[0].documentNumber
                binding.rlPinned.visible()

            }
            /*----ExpDate-----*/if (healthData[0].expiryDate.isNotEmpty()) {

                if (healthData[0].expiryDate.equals("null",ignoreCase = true)) {}else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = healthData[0].expiryDate
                binding.rlPinned.visible()}
            }
            /*----Phone Number-----*/if (healthData[0].phoneNumber.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = healthData[0].phoneNumber
                binding.rlPinned.visible()
            }
            /*----Email-----*/if (healthData[0].email.isNotEmpty()) {
                view.rlEmail.visible()
                view.tvEmailText.text = healthData[0].email
                binding.rlPinned.visible()
            }
            /*----notes-----*/if (healthData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = healthData[0].notes
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setLoyaltyResultData() {
        if (loyaltyData.size > 0) {
            isSoftDelete = loyaltyData[0].isDelete
            isArchive = loyaltyData[0].isArchive
            isFav = loyaltyData[0].isFav
            dataID = loyaltyData[0].id
            isLock = loyaltyData[0].isLock
            isSpoiler = loyaltyData[0].isSensitive
            frontImage = loyaltyData[0].frontCardImage.toString()
            backImage = loyaltyData[0].backCardImage.toString()
            binding.tvType.text = loyaltyData[0].category?.name.toString()
            title = loyaltyData[0].title.toString()
            appreanceColor = loyaltyData[0].appearanceColor
            labelID = loyaltyData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----CardHolderName-----*/if (loyaltyData[0].cardHolderName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = loyaltyData[0].cardHolderName
                binding.rlPinned.visible()
            }
            /*----CardNumber-----*/if (loyaltyData[0].cardNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = loyaltyData[0].cardNumber
                view.tvLiNumber.text = resources.getString(R.string.card_number)
                binding.rlPinned.visible()

            }
            /*----CardHolderNumber-----*/if (loyaltyData[0].cardHolderNumber.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = loyaltyData[0].cardHolderNumber
                binding.rlPinned.visible()
            }
            /*----Barcode-----*/if (loyaltyData[0].barcode.isNotEmpty()) {
                view.rlBarcode.visible()
                view.tvBarcodeText.text = loyaltyData[0].barcode
                binding.rlPinned.visible()
            }
            /*----Brand-----*/if (loyaltyData[0].brand.isNotEmpty()) {
                view.rlBrand.visible()
                view.tvBrandText.text = loyaltyData[0].brand
                binding.rlPinned.visible()
            }
            /*----URL-----*/if (loyaltyData[0].url.isNotEmpty()) {
                view.rlURL.visible()
                view.tvURLText.text = loyaltyData[0].url
                binding.rlPinned.visible()
            }

            /*----Login-----*/if (loyaltyData[0].login.isNotEmpty()) {
                view.rlLogin.visible()
                view.tvLoginText.text = loyaltyData[0].login
                binding.rlPinned.visible()
            }
            /*----Password-----*/if (loyaltyData[0].password.isNotEmpty()) {
                view.rlPassword.visible()
                view.tvPasswordText.text = loyaltyData[0].password.map { '*' }.joinToString("")
                view.ivEyePassword.visible()
                binding.rlPinned.visible()

                if (!isPasswordVisible) {
                    view.tvPasswordText.text = loyaltyData[0].password
                    view.ivEyePassword.setImageResource(R.drawable.eye_visible)
                } else {
                    view.tvPasswordText.text = loyaltyData[0].password.map { '*' }.joinToString("")
                    view.ivEyePassword.setImageResource(R.drawable.eye_hide)
                }
                isPasswordVisible = !isPasswordVisible


            }

            /*----ExpDate-----*/if (loyaltyData[0].expDate.isNotEmpty()) {
                if (loyaltyData[0].expDate.isNotEmpty()) {}else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = loyaltyData[0].expDate
                binding.rlPinned.visible()}
            }

            /*----notes-----*/if (loyaltyData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = loyaltyData[0].notes
                binding.rlPinned.visible()
            }



            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setMedicalResultData() {
        if (medicalData.size > 0) {

            isSoftDelete = medicalData[0].isDelete
            isArchive = medicalData[0].isArchive
            isFav = medicalData[0].isFav
            isLock = medicalData[0].isLock
            dataID = medicalData[0].id
            isSpoiler = medicalData[0].isSensitive
            frontImage = medicalData[0].frontCardImage.toString()
            backImage = medicalData[0].backCardImage.toString()
            binding.tvType.text = medicalData[0].category?.name.toString()
            title = medicalData[0].title.toString()
            appreanceColor = medicalData[0].appearanceColor
            labelID = medicalData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler


            /*----DocumentNumber-----*/if (medicalData[0].documentNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = medicalData[0].documentNumber
                view.tvLiNumber.text = resources.getString(R.string.card_number)
                binding.rlPinned.visible()

            }
            /*----IssueDate-----*/
            if (medicalData[0].issueDate.isNotEmpty()) {
            if (medicalData[0].issueDate.equals("null",ignoreCase = true)) {}else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = medicalData[0].issueDate
                binding.rlPinned.visible()}
            }

            /*----ExpDate-----*/if (medicalData[0].expiryDate.isNotEmpty()) {
                if (medicalData[0].expiryDate.equals("null",ignoreCase = true)) {}else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = medicalData[0].expiryDate
                binding.rlPinned.visible()}
            }
            /*----DOB-----*/if (medicalData[0].dob.isNotEmpty()) {
                if (medicalData[0].dob.equals("null",ignoreCase = true)) {}else{

                view.rlDOBDate.visible()
                view.tvDOBDateText.text = medicalData[0].dob
                binding.rlPinned.visible()}
            }

            /*----Number-----*/if (medicalData[0].phoneNumber.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = medicalData[0].phoneNumber
                binding.rlPinned.visible()
            }
            /*----Email-----*/if (medicalData[0].email.isNotEmpty()) {
                view.rlEmail.visible()
                view.tvEmailText.text = medicalData[0].email
                binding.rlPinned.visible()
            }

            /*----notes-----*/if (medicalData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = medicalData[0].notes
                binding.rlPinned.visible()
            }


            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setMemberShipResultData() {
        if (memberShipData.size > 0) {
            isSoftDelete = memberShipData[0].isDelete
            isArchive = memberShipData[0].isArchive
            isFav = memberShipData[0].isFav
            isLock = memberShipData[0].isLock
            dataID = memberShipData[0].id
            isSpoiler = memberShipData[0].isSensitive
            frontImage = memberShipData[0].frontCardImage.toString()
            backImage = memberShipData[0].backCardImage.toString()
            binding.tvType.text = memberShipData[0].category?.name.toString()
            title = memberShipData[0].title.toString()
            appreanceColor = memberShipData[0].appearanceColor
            labelID = memberShipData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----CardHolderName-----*/if (memberShipData[0].cardHolderName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = memberShipData[0].cardHolderName
                binding.rlPinned.visible()
            }
            /*----CardHolderNumber-----*/if (memberShipData[0].cardHolderNumber.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = memberShipData[0].cardHolderNumber
                binding.rlPinned.visible()
            }
            /*----Barcode-----*/if (memberShipData[0].barcode.isNotEmpty()) {
                view.rlBarcode.visible()
                view.tvBarcodeText.text = memberShipData[0].barcode
                binding.rlPinned.visible()
            }
            /*----Login-----*/if (memberShipData[0].login.isNotEmpty()) {
                view.rlLogin.visible()
                view.tvLoginText.text = memberShipData[0].login
                binding.rlPinned.visible()
            }
            /*----Password-----*/if (memberShipData[0].password.isNotEmpty()) {
                view.rlPassword.visible()
                view.tvPasswordText.text = memberShipData[0].password.map { '*' }.joinToString("")
                view.ivEyePassword.setOnClickListener {
                    if (!isPasswordVisible) {
                        view.tvPasswordText.text = memberShipData[0].password
                        view.ivEyePassword.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvPasswordText.text =
                            memberShipData[0].password.map { '*' }.joinToString("")
                        view.ivEyePassword.setImageResource(R.drawable.eye_hide)
                    }
                    isPasswordVisible = !isPasswordVisible
                }
                binding.rlPinned.visible()
            }
            /*----URL-----*/if (memberShipData[0].url.isNotEmpty()) {
                view.rlURL.visible()
                view.tvURLText.text = memberShipData[0].url
                binding.rlPinned.visible()
            }
            /*----ExpDate-----*/if (memberShipData[0].expDate.isNotEmpty()) {
                if (memberShipData[0].expDate.equals("null",ignoreCase = true)) {}else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = memberShipData[0].expDate
                binding.rlPinned.visible()}
            }
            /*----Brand-----*/if (memberShipData[0].brand.isNotEmpty()) {
                view.rlBrand.visible()
                view.tvBrandText.text = memberShipData[0].brand
                binding.rlPinned.visible()
            }
            /*----MemberSince-----*/if (memberShipData[0].memberSince.isNotEmpty()) {
                view.rlMemberSince.visible()
                view.tvMemberSinceText.text = memberShipData[0].memberSince
                binding.rlPinned.visible()
            }
            /*----notes-----*/if (memberShipData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = memberShipData[0].notes
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setMrgResultData() {
        if (mrgData.size > 0) {

            isSoftDelete = mrgData[0].isDelete
            isArchive = mrgData[0].isArchive
            isFav = mrgData[0].isFav
            isLock = mrgData[0].isLock

            dataID = mrgData[0].id
            isSpoiler = mrgData[0].isSensitive
            frontImage = mrgData[0].frontCardImage.toString()
            backImage = mrgData[0].backCardImage.toString()
            binding.tvType.text = mrgData[0].category?.name.toString()
            title = mrgData[0].title.toString()
            appreanceColor = mrgData[0].appearanceColor
            labelID = mrgData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----name-----*/if (mrgData[0].spouseName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = mrgData[0].spouseName
                binding.rlPinned.visible()
            }
            /*----date-----*/if (mrgData[0].mrgDate.isNotEmpty()) {

                if (mrgData[0].mrgDate.equals("null",ignoreCase = true)) {}else{
                view.rlDOBDate.visible()
                view.tvDOBDate.text = "Marriage Date"
                view.tvDOBDateText.text = mrgData[0].mrgDate
                binding.rlPinned.visible()}
            }
            /*----notes-----*/if (mrgData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = mrgData[0].notes
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setPasswordResultData() {
        if (passwordData.size > 0) {

            isSoftDelete = passwordData[0].isDelete
            isArchive = passwordData[0].isArchive
            isFav = passwordData[0].isFav
            isLock = passwordData[0].isLock
            dataID = passwordData[0].id
            isSpoiler = passwordData[0].isSensitive
            frontImage = passwordData[0].frontCardImage.toString()
            backImage = passwordData[0].backCardImage.toString()
            binding.tvType.text = passwordData[0].category?.name.toString()
            title = passwordData[0].title.toString()
            appreanceColor = passwordData[0].appearanceColor
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            labelID = passwordData[0].label?.id ?: 0

            /*----Name-----*/if (passwordData[0].Name.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = passwordData[0].Name
                binding.rlPinned.visible()
            }
            /*----URL-----*/if (passwordData[0].url.isNotEmpty()) {
                view.rlURL.visible()
                view.tvURLText.text = passwordData[0].url
                binding.rlPinned.visible()
            }
            /*----Login-----*/if (passwordData[0].login.isNotEmpty()) {
                view.rlLogin.visible()
                view.tvLoginText.text = passwordData[0].login
                binding.rlPinned.visible()
            }
            /*----Password-----*/if (passwordData[0].password.isNotEmpty()) {
                view.rlPassword.visible()
                view.tvPasswordText.text = passwordData[0].password.map { '*' }.joinToString("")
                view.ivEyePassword.visible()
                view.ivEyePassword.setOnClickListener {
                    if (!isPasswordVisible) {
                        view.tvPasswordText.text = passwordData[0].password
                        view.ivEyePassword.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvPasswordText.text = passwordData[0].password.map { '*' }.joinToString("")
                        view.ivEyePassword.setImageResource(R.drawable.eye_hide)
                    }
                    isPasswordVisible = !isPasswordVisible

                }
                binding.rlPinned.visible()
            }
            /*----notes-----*/if (passwordData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = passwordData[0].notes
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)
        }

    }
    private fun setSIMResultData() {
        if (simData.size > 0) {
            isSoftDelete = simData[0].isDelete
            isArchive = simData[0].isArchive
            isFav = simData[0].isFav
            isLock = simData[0].isLock
            dataID = simData[0].id
            isSpoiler = simData[0].isSensitive
            frontImage = simData[0].frontCardImage.toString()
            backImage = simData[0].backCardImage.toString()
            binding.tvType.text = simData[0].category?.name.toString()
            title = simData[0].title.toString()
            appreanceColor = simData[0].appearanceColor
            labelID = simData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler


            /*----OwnerName-----*/if (simData[0].ownerName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = simData[0].ownerName
                view.tvName.text = getString(R.string.owner_name)
                binding.rlPinned.visible()
            }
            /*----PhoneNumber-----*/if (simData[0].phoneNumber.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = simData[0].phoneNumber
                binding.rlPinned.visible()
            }

            /*----PIN-----*/if (simData[0].pin.isNotEmpty()) {
                view.rlPIN.visible()
                view.tvPINText.text = simData[0].pin.map { '*' }.joinToString("")
                view.ivEyePIN.setOnClickListener {
                    if (!isPINVisible) {
                        view.tvPINText.text = simData[0].pin
                        view.ivEyePIN.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvPINText.text = simData[0].pin.map { '*' }.joinToString("")
                        view.ivEyePIN.setImageResource(R.drawable.eye_hide)
                    }
                    isPINVisible = !isPINVisible

                }
                binding.rlPinned.visible()

            }
            /*----PUK-----*/if (simData[0].puk.isNotEmpty()) {

                view.rlPUK.visible()
                view.tvPUKText.text = simData[0].puk
                binding.rlPinned.visible()

            }
            /*----Country-----*/if (simData[0].country.isNotEmpty()) {
                view.rlCountry.visible()
                view.tvCountryText.text = simData[0].country
                binding.rlPinned.visible()

            }
            /*----Operator-----*/if (simData[0].operator.isNotEmpty()) {
                view.rlMoOperator.visible()
                view.tvMoOperatorText.text = simData[0].operator
                binding.rlPinned.visible()

            }

            /*----notes-----*/if (simData[0].notes.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = simData[0].notes
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setCustomResultData() {
        if (customData.size > 0) {
            isSoftDelete = customData[0].isDelete
            isArchive = customData[0].isArchive
            isFav = customData[0].isFav
            dataID = customData[0].id
            isLock = customData[0].isLock
            isSpoiler = customData[0].isSensitive
            frontImage = customData[0].frontCardImage.toString()
            backImage = customData[0].backCardImage.toString()
            binding.tvType.text = customData[0].category?.name.toString()
            title = customData[0].title.toString()
            appreanceColor = customData[0].appearanceColor
            labelID = customData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----FullName-----*/if (customData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = customData[0].fullName
                binding.rlPinned.visible()
            }
            /*----PhoneNumber-----*/if (customData[0].phoneNumber.isNotEmpty()) {
                view.rlPersonalNo.visible()
                view.tvPersonalNoText.text = customData[0].phoneNumber
                binding.rlPinned.visible()
            }
            /*----Number-----*/if (customData[0].number.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = customData[0].number
                binding.rlPinned.visible()
            }
            /*----CardNumber-----*/if (customData[0].cardNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = customData[0].cardNumber.map { '*' }.joinToString("")
                view.tvLiNumber.text = "Card Number"
                view.ivEyeLiNumber.setOnClickListener {
                    if (!isNumberVisible) {
                        view.tvLiNumberText.text = customData[0].cardNumber
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvLiNumberText.text = customData[0].cardNumber.map { '*' }.joinToString("")
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_hide)
                    }
                    isNumberVisible = !isNumberVisible

                }
                binding.rlPinned.visible()
            }
            /*----ExpDate-----*/if (customData[0].expDate.isNotEmpty()) {
                if (customData[0].expDate.equals("null",ignoreCase = true)) {}else{
                view.rlExpDate.visible()
                view.tvExpDateText.text = customData[0].expDate
                binding.rlPinned.visible()}
            }

            /*----Address-----*/if (customData[0].address.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = customData[0].address
                binding.rlPinned.visible()

            }
            /*----Barcode-----*/if (customData[0].barcode.isNotEmpty()) {
                view.rlBarcode.visible()
                view.tvBarcodeText.text = customData[0].barcode
                binding.rlPinned.visible()

            }
            /*----Date-----*/if (customData[0].date.isNotEmpty()) {
                if (customData[0].date.equals("null",ignoreCase = true)) {}else{
                view.rlDOBDate.visible()
                view.tvDOBDateText.text = customData[0].date
                binding.rlPinned.visible()}

            }
            /*----Email-----*/if (customData[0].email.isNotEmpty()) {
                view.rlEmail.visible()
                view.tvEmailText.text = customData[0].email
                binding.rlPinned.visible()

            }
            /*----Text-----*/if (customData[0].text.isNotEmpty()) {
                view.rlText.visible()
                view.tvTextText.text = customData[0].text
                binding.rlPinned.visible()

            }
            /*----URI-----*/if (customData[0].url.isNotEmpty()) {
                view.rlURL.visible()
                view.tvURLText.text = customData[0].url
                binding.rlPinned.visible()

            }

            /*----notes-----*/if (customData[0].note.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = customData[0].note
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setVehicleResultData() {
        if (vehicleData.size > 0) {
            isSoftDelete = vehicleData[0].isDelete
            isArchive = vehicleData[0].isArchive
            isFav = vehicleData[0].isFav
            dataID = vehicleData[0].id
            isLock = vehicleData[0].isLock
            isSpoiler = vehicleData[0].isSensitive
            frontImage = vehicleData[0].frontCardImage.toString()
            backImage = vehicleData[0].backCardImage.toString()
            binding.tvType.text = vehicleData[0].category?.name.toString()
            title = vehicleData[0].title.toString()
            appreanceColor = vehicleData[0].appearanceColor
            labelID = vehicleData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----FullName-----*/if (vehicleData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = vehicleData[0].fullName
                binding.rlPinned.visible()
            }
            /*----PhoneNumber-----*/if (vehicleData[0].phoneNumber.isNotEmpty()) {
                view.rlPersonalNo.visible()
                view.tvPersonalNoText.text = vehicleData[0].phoneNumber
                binding.rlPinned.visible()
            }
            /*----Number-----*/if (vehicleData[0].number.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = vehicleData[0].number
                binding.rlPinned.visible()
            }
            /*----CardNumber-----*/if (vehicleData[0].cardNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = vehicleData[0].cardNumber.map { '*' }.joinToString("")
                view.tvLiNumber.text = "Card Number"
                view.ivEyeLiNumber.setOnClickListener {
                    if (!isNumberVisible) {
                        view.tvLiNumberText.text = vehicleData[0].cardNumber
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvLiNumberText.text = vehicleData[0].cardNumber.map { '*' }.joinToString("")
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_hide)
                    }
                    isNumberVisible = !isNumberVisible

                }
                binding.rlPinned.visible()
            }
            /*----ExpDate-----*/if (vehicleData[0].expDate.isNotEmpty()) {
                if (vehicleData[0].expDate.equals("null",ignoreCase = true)) {}else {

                    view.rlExpDate.visible()
                    view.tvExpDateText.text = vehicleData[0].expDate
                    binding.rlPinned.visible()
                }
            }

            /*----Address-----*/if (vehicleData[0].address.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = vehicleData[0].address
                binding.rlPinned.visible()

            }
            /*----Barcode-----*/if (vehicleData[0].barcode.isNotEmpty()) {
                view.rlBarcode.visible()
                view.tvBarcodeText.text = vehicleData[0].barcode
                binding.rlPinned.visible()

            }
            /*----Date-----*/if (vehicleData[0].date.isNotEmpty()) {
                if (vehicleData[0].date.equals("null",ignoreCase = true)) {}else {

                view.rlDOBDate.visible()
                view.tvDOBDateText.text = vehicleData[0].date
                binding.rlPinned.visible()}

            }
            /*----Email-----*/if (vehicleData[0].email.isNotEmpty()) {
                view.rlEmail.visible()
                view.tvEmailText.text = vehicleData[0].email
                binding.rlPinned.visible()

            }
            /*----Text-----*/if (vehicleData[0].text.isNotEmpty()) {
                view.rlText.visible()
                view.tvTextText.text = vehicleData[0].text
                binding.rlPinned.visible()

            }
            /*----URI-----*/if (vehicleData[0].url.isNotEmpty()) {
                view.rlURL.visible()
                view.tvURLText.text = vehicleData[0].url
                binding.rlPinned.visible()

            }

            /*----notes-----*/if (vehicleData[0].note.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = vehicleData[0].note
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setPANResultData() {
        if (panData.size > 0) {
            isSoftDelete = panData[0].isDelete
            isArchive = panData[0].isArchive
            isFav = panData[0].isFav
            dataID = panData[0].id
            isLock = panData[0].isLock
            isSpoiler = panData[0].isSensitive
            frontImage = panData[0].frontCardImage.toString()
            backImage = panData[0].backCardImage.toString()
            binding.tvType.text = panData[0].category?.name.toString()
            title = panData[0].title.toString()
            appreanceColor = panData[0].appearanceColor
            labelID = panData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----FullName-----*/
            if (panData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = panData[0].fullName
                binding.rlPinned.visible()
            }
            /*----paretnsName-----*/
            if (panData[0].parentsName.isNotEmpty()) {
                view.rlParents.visible()
                view.tvParentsText.text = panData[0].parentsName
                binding.rlPinned.visible()
            }
            /*----CardNumber-----*/
            if (panData[0].cardNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = panData[0].cardNumber.map { '*' }.joinToString("")
                view.tvLiNumber.text = getString(R.string.pan_number)
                view.ivEyeLiNumber.setOnClickListener {
                    if (!isNumberVisible) {
                        view.tvLiNumberText.text = panData[0].cardNumber
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvLiNumberText.text = panData[0].cardNumber.map { '*' }.joinToString("")
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_hide)
                    }
                    isNumberVisible = !isNumberVisible

                }
                binding.rlPinned.visible()
            }

            /*----Date-----*/if (panData[0].dob.isNotEmpty()) {
                if (panData[0].dob.equals("null",ignoreCase = true)) {}else {
                    view.rlDOBDate.visible()
                    view.tvDOBDateText.text = panData[0].dob
                    binding.rlPinned.visible()
                }
            }

            /*----notes-----*/if (panData[0].note.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = panData[0].note
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setAdharResultData() {
        if (adharData.size > 0) {
            isSoftDelete = adharData[0].isDelete
            isArchive = adharData[0].isArchive
            isFav = adharData[0].isFav
            dataID = adharData[0].id
            isLock = adharData[0].isLock
            isSpoiler = adharData[0].isSensitive
            frontImage = adharData[0].frontCardImage.toString()
            backImage = adharData[0].backCardImage.toString()
            binding.tvType.text = adharData[0].category?.name.toString()
            title = adharData[0].title.toString()
            appreanceColor = adharData[0].appearanceColor
            labelID = adharData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            /*----FullName-----*/  if (adharData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = adharData[0].fullName
                binding.rlPinned.visible() }

            /*----AadhaarNo-----*/if (adharData[0].adharNo.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = adharData[0].adharNo.map { '*' }.joinToString("")
                view.tvLiNumber.text = getString(R.string.aadhaar_no)
                view.ivEyeLiNumber.setOnClickListener {
                    if (!isNumberVisible) {
                        view.tvLiNumberText.text = adharData[0].adharNo
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvLiNumberText.text = adharData[0].adharNo.map { '*' }.joinToString("")
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_hide)
                    }
                    isNumberVisible = !isNumberVisible

                }
                binding.rlPinned.visible()
            }

            /*----PhoneNumber-----*/  if (adharData[0].phoneNumber.isNotEmpty()) {
                view.rlPersonalNo.visible()
                view.tvPersonalNoText.text = adharData[0].phoneNumber
                binding.rlPinned.visible()
            }

            /*----Address-----*/if (adharData[0].address.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = adharData[0].address
                binding.rlPinned.visible()

            }

            /*----DOB-----*/if (adharData[0].dob.isNotEmpty()) {
                if (adharData[0].dob.equals("null",ignoreCase = true)) {}else {

                view.rlDOBDate.visible()
                view.tvDOBDateText.text = adharData[0].dob
                binding.rlPinned.visible()}

            }

            /*----Email-----*/if (adharData[0].email.isNotEmpty()) {
                view.rlEmail.visible()
                view.tvEmailText.text = adharData[0].email
                binding.rlPinned.visible() }

            /*----Gender-----*/if (adharData[0].gender.isNotEmpty()) {
                view.rlText.visible()
                view.tvTextText.text = adharData[0].gender
                binding.rlPinned.visible() }

            /*----URI-----*/if (adharData[0].url.isNotEmpty()) {
                view.rlURL.visible()
                view.tvURLText.text = adharData[0].url
                binding.rlPinned.visible()

            }

            /*----notes-----*/if (adharData[0].note.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = adharData[0].note
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }
    private fun setVoterResultData() {
        if (voterData.size > 0) {
            isSoftDelete = voterData[0].isDelete
            isArchive = voterData[0].isArchive
            isFav = voterData[0].isFav
            dataID = voterData[0].id
            isLock = voterData[0].isLock
            isSpoiler = voterData[0].isSensitive
            frontImage = voterData[0].frontCardImage.toString()
            backImage = voterData[0].backCardImage.toString()
            binding.tvType.text = voterData[0].category?.name.toString()
            title = voterData[0].title.toString()
            appreanceColor = voterData[0].appearanceColor
            labelID = voterData[0].label?.id ?: 0
            mainChild = view.mainChild
            isSpoilerClick=isSpoiler

            val view = ItemViewrecordFieldBinding.inflate(LayoutInflater.from(this))

            /*----FullName-----*/if (voterData[0].fullName.isNotEmpty()) {
                view.rlNameView.visible()
                view.tvNameText.text = voterData[0].fullName
                binding.rlPinned.visible()
            }
            /*----PhoneNumber-----*/if (voterData[0].phoneNumber.isNotEmpty()) {
                view.rlPersonalNo.visible()
                view.tvPersonalNoText.text = voterData[0].phoneNumber
                binding.rlPinned.visible()
            }
            /*----Number-----*/if (voterData[0].phoneNumber.isNotEmpty()) {
                view.rlNumber.visible()
                view.tvNumberText.text = voterData[0].phoneNumber
                binding.rlPinned.visible()
            }
            /*----CardNumber-----*/if (voterData[0].cardNumber.isNotEmpty()) {
                view.rlLicenceNumber.visible()
                view.tvLiNumberText.text = voterData[0].cardNumber.map { '*' }.joinToString("")
                view.tvLiNumber.text = "Card Number"
                view.ivEyeLiNumber.setOnClickListener {
                    if (!isNumberVisible) {
                        view.tvLiNumberText.text = voterData[0].cardNumber
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_visible)
                    } else {
                        view.tvLiNumberText.text = voterData[0].cardNumber.map { '*' }.joinToString("")
                        view.ivEyeLiNumber.setImageResource(R.drawable.eye_hide)
                    }
                    isNumberVisible = !isNumberVisible

                }
                binding.rlPinned.visible()
            }
            /*----Address-----*/if (voterData[0].address.isNotEmpty()) {
                view.rlAddress.visible()
                view.tvAddressText.text = voterData[0].address
                binding.rlPinned.visible()

            }
            /*----Barcode-----*/if (voterData[0].barcode.isNotEmpty()) {
                view.rlBarcode.visible()
                view.tvBarcodeText.text = voterData[0].barcode
                binding.rlPinned.visible()

            }
            /*----Date-----*/if (voterData[0].dob.isNotEmpty()) {
                if (voterData[0].dob.equals("null",ignoreCase = true)) {}else {

                view.rlDOBDate.visible()
                view.tvDOBDateText.text = voterData[0].dob
                binding.rlPinned.visible()}
            }
            /*----Email-----*/if (voterData[0].email.isNotEmpty()) {
                view.rlEmail.visible()
                view.tvEmailText.text = voterData[0].email
                binding.rlPinned.visible()

            }
            /*----Text-----*/if (voterData[0].parentsName.isNotEmpty()) {
                view.rlText.visible()
                view.tvTextText.text = voterData[0].parentsName
                binding.rlPinned.visible()
            }
            /*----URI-----*/if (voterData[0].url.isNotEmpty()) {
                view.rlURL.visible()
                view.tvURLText.text = voterData[0].url
                binding.rlPinned.visible()

            }
            /*----notes-----*/if (voterData[0].note.isNotEmpty()) {
                view.rlNotes.visible()
                view.tvNotesText.text = voterData[0].note
                binding.rlPinned.visible()
            }

            binding.dynamicContainer.addView(view.root)

        }

    }

    private fun createMenuPopupWindow() {
        val layoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popupView: View = layoutInflater.inflate(R.layout.view_menu, null)

        popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        popupWindow!!.setBackgroundDrawable(BitmapDrawable())
        popupWindow!!.isFocusable = true
        popupWindow!!.isOutsideTouchable = true

        val selectedLanguage = getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE)
            .getString(SELECTED_COUNTRY_KEY, "en").toString()

        if (selectedLanguage == "ar" || selectedLanguage == "ur") {
            popupView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        } else {
            popupView.layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        menuShare = popupView.findViewById(R.id.menuShare)
        menuFav = popupView.findViewById(R.id.menuFav)
        menuEdit = popupView.findViewById(R.id.menuEdit)
        menuLabel = popupView.findViewById(R.id.menuLabel)
        menuExpiry = popupView.findViewById(R.id.menuExpiry)
        menuArchive = popupView.findViewById(R.id.menuArchive)
        menuExport = popupView.findViewById(R.id.menuExport)
        menuDetails = popupView.findViewById(R.id.menuDetails)
        menuDelete = popupView.findViewById(R.id.menuDelete)

        ivFav = popupView.findViewById(R.id.ivFav)
        tvFav = popupView.findViewById(R.id.tvFav)
        ivArchive = popupView.findViewById(R.id.ivArchive)
        tvArchive = popupView.findViewById(R.id.tvArchive)
        ivDelete = popupView.findViewById(R.id.ivDelete)
        tvDelete = popupView.findViewById(R.id.tvDelete)

        menuShare?.setOnClickListener {
            showShareIntentAll(frontImage,backImage,"")
            popupWindow!!.dismiss()
        }

        menuFav?.setOnClickListener {
            performFADLOperation(categoryID, "favourite", dataID)
            popupWindow!!.dismiss()
        }

        menuEdit?.setOnClickListener {
            activityResultLauncher.launch(
                Intent(this@ViewActivityManiya, EditCardActivityManiya::class.java)
                    .putExtra("categoryID", categoryID)
                    .putExtra("ItemID", dataID)
                    .putExtra("isFromScan", false)
            )
            popupWindow!!.dismiss()
        }

        menuLabel?.setOnClickListener {

            activityResultLauncher.launch(Intent(this@ViewActivityManiya, LabelViewActivityManiya::class.java)
                .putExtra("labelID", labelID)
                .putExtra("categoryID", categoryID)
                .putExtra("itemID", dataID))
            popupWindow!!.dismiss()
        }

        menuArchive?.setOnClickListener {
            performFADLOperation(categoryID, "archive", dataID)
            popupWindow!!.dismiss()
        }

        menuDelete?.setOnClickListener {
            if (isSoftDelete) {
                showRestoreDeleteDialog()
            } else {
                performFADLOperation(categoryID, "delete", dataID)
            }
            popupWindow!!.dismiss()
        }

    }
    private fun showRestoreDeleteDialog() {
        val dialog = Dialog(this@ViewActivityManiya).apply {
            window?.setBackgroundDrawable(ColorDrawable(0))
            setCancelable(true)
            setContentView(
                DialogRestoreBinding.inflate(LayoutInflater.from(context)).apply {
                    llDelete.setOnClickListener {
                        performFADLOperation(categoryID, "permanentDelete", dataID)
                        Toast.makeText(
                            this@ViewActivityManiya,
                            getString(R.string.deleted_successfully), Toast.LENGTH_SHORT
                        ).show()
                        dismiss()
                    }
                    llRestore.setOnClickListener {
                        performFADLOperation(categoryID, "delete", dataID)
                        Toast.makeText(
                            this@ViewActivityManiya,
                            getString(R.string.restore_completed), Toast.LENGTH_SHORT
                        ).show()
                        dismiss()
                    }
                }.root
            )
        }
        dialog.show()
    }

    private fun locateViewRect(v: View): Rect {
        val locInt = IntArray(2)
        v.getLocationOnScreen(locInt)
        val location = Rect()
        location.left = locInt[0]
        location.top = locInt[1]
        location.right = location.left + v.width
        return location
    }

    fun onMoreMenuIconClick(view: View?) {
        checkDeleteStatus()
        checkArchiveStatus()
        checkFavouriteStatus()

        var gravity = Gravity.END or Gravity.TOP
        if (getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE).getString(SELECTED_COUNTRY_KEY, "en").toString() == "ar"
            || getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE).getString(SELECTED_COUNTRY_KEY, "en").toString() == "ur"){

            gravity=  Gravity.START or Gravity.TOP
        }else{
            gravity=  Gravity.END or Gravity.TOP

        }
        popupWindow!!.showAtLocation(binding.ivMore, gravity, 0, 0)

        /*  try {
              val anchorRect: Rect = locateViewRect(binding.ivMore)
              val marginInDp = 30
              val scale = resources.displayMetrics.density
              val marginInPx = (marginInDp * scale + 0.5f).toInt()

              val x: Int = anchorRect.width() - marginInPx
              val y: Int = anchorRect.top + marginInPx

              popupWindow!!.showAtLocation(binding.ivMore, Gravity.TOP, x, y)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        */

    }

    private fun checkFavouriteStatus() {
        if (isFav) {
            tvFav?.text = "UnFavourite"
            ivFav?.setImageResource(R.drawable.menu_unfav)
        } else {
            tvFav?.text = "Favourite"
            ivFav?.setImageResource(R.drawable.favourite)
        }
    }

    private fun checkArchiveStatus() {
        if (isArchive) {
            tvArchive?.text = "UnArchive"
            ivArchive?.setImageResource(R.drawable.menu_unarchive)

        } else {
            tvArchive?.text = "Archive"
            ivArchive?.setImageResource(R.drawable.archive)

        }
    }

    private fun checkDeleteStatus() {
        if (isSoftDelete) {
            tvDelete?.text = "Restore/Delete"
            ivDelete?.setImageResource(R.drawable.meu_restore)

            menuShare?.gone()
            menuFav?.gone()
            menuEdit?.gone()
            menuLabel?.gone()
            menuArchive?.gone()
            menuDetails?.gone()

        } else {
            tvDelete?.text = "Delete"
            ivDelete?.setImageResource(R.drawable.delete)

            menuShare?.visible()
            menuFav?.visible()
            menuEdit?.visible()
            menuLabel?.visible()
            menuArchive?.visible()
          /*  menuDetails?.visible()*/
            menuDelete?.visible()
        }
    }

    fun onBackClick(view: View) {
        AdsInterstitial.instance?.showInterstitialAd(
            this@ViewActivityManiya,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    returnResult()
                }
            })

    }

    fun onClickFlip(view: View) {

        val flipAnimator = ObjectAnimator.ofFloat(binding.ivCard, "rotationY", 0f, 180f)
        flipAnimator.setDuration(300)
        flipAnimator.start()

        flipAnimator.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                binding.ivCard.rotationY = 0f
                if (isFirstImage) {
                    if (backImage.isNotEmpty()) {

                        if (isSpoilerClick) {
                            Glide.with(this@ViewActivityManiya)
                                .asBitmap()
                                .load(backImage)
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .into(object : SimpleTarget<Bitmap>() {
                                    override fun onResourceReady(
                                        resource: Bitmap,
                                        transition: Transition<in Bitmap>?
                                    ) {
                                        Blurry.with(this@ViewActivityManiya)
                                            .from(resource)
                                            .into(binding.ivCard)

                                    }
                                })
                        } else {
                            Glide.with(this@ViewActivityManiya)
                                .load(backImage)
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .into(binding.ivCard)

                        }

                    }
                } else {
                    if (frontImage.isNotEmpty()) {

                        if (isSpoilerClick) {
                            Glide.with(this@ViewActivityManiya)
                                .asBitmap()
                                .load(frontImage)
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .into(object : SimpleTarget<Bitmap>() {
                                    override fun onResourceReady(
                                        resource: Bitmap,
                                        transition: Transition<in Bitmap>?
                                    ) {
                                        Blurry.with(this@ViewActivityManiya)
                                            .from(resource)
                                            .into(binding.ivCard)

                                    }
                                })
                        } else {
                            Glide.with(this@ViewActivityManiya)
                                .load(frontImage)
                                .diskCacheStrategy(DiskCacheStrategy.ALL)
                                .into(binding.ivCard)

                        }

                    }
                }
                isFirstImage = !isFirstImage
            }
        })


    }
    private fun updateDividerVisibility() {
        var visibleViewPosition: MutableList<Int> = mutableListOf()
        if (mainChild != null) {
            for (i in 0 until mainChild!!.childCount) {
                val childView = mainChild!!.getChildAt(i)
                if (childView.visibility == View.VISIBLE) {
                    visibleViewPosition.add(i)
                }
            }
            if (visibleViewPosition.size == 1) {
                val sunChildView: RelativeLayout =
                    mainChild!!.getChildAt(visibleViewPosition[0]) as RelativeLayout
                sunChildView.getChildAt(sunChildView.childCount - 1).gone()
            } else {
                if (visibleViewPosition.size > 1)
                {
                    var lastViewPosition = visibleViewPosition.size - 1
                    val sunChildView: RelativeLayout =
                        mainChild!!.getChildAt(visibleViewPosition[lastViewPosition]) as RelativeLayout
                    sunChildView.getChildAt(sunChildView.childCount - 1).gone()
                }
            }
        }
    }

    fun setSpoiler() {
        if (frontImage.isNotEmpty()) {
            if (isSpoiler) {
                binding.tvSpoiler.text = "Reveal Photo"
                Glide.with(this@ViewActivityManiya)
                    .asBitmap()
                    .load(frontImage)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(object : SimpleTarget<Bitmap>() {
                        override fun onResourceReady(
                            resource: Bitmap,
                            transition: Transition<in Bitmap>?
                        ) {
                            Blurry.with(this@ViewActivityManiya)
                                .from(resource)
                                .into(binding.ivCard)
                        }
                    })
            } else {
                binding.tvSpoiler.text = "Hide with Spoiler"
                Glide.with(this@ViewActivityManiya)
                    .load(frontImage)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(binding.ivCard)
            }

        }
    }

    fun onClickSpoiler(view: View) {
        isSpoilerClick = !isSpoilerClick
        if (isSpoilerClick) {
            binding.tvSpoiler.text = "Reveal Photo"
            Glide.with(this@ViewActivityManiya)
                .asBitmap()
                .load(frontImage)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(object : SimpleTarget<Bitmap>() {
                    override fun onResourceReady(
                        resource: Bitmap,
                        transition: Transition<in Bitmap>?
                    ) {
                        Blurry.with(this@ViewActivityManiya)
                            .from(resource)
                            .into(binding.ivCard)

                    }
                })
        } else {
            binding.tvSpoiler.text = "Hide with Spoiler"
            Glide.with(this@ViewActivityManiya)
                .load(frontImage)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(binding.ivCard)
        }
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }

    private fun performFADLOperation(catID: Long, operationtype: String, itemID: Long) {
        Log.d("Delete+++", itemID.toString())
        when (catID) {
            1L -> {
                if (operationtype.equals("delete")) { DatabaseHelperManiya(this).softLicenceDelete(itemID) }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).licenceDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleLicenceArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleLicenceFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleLicenceLock(itemID)
                }

            }

            2L -> {
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softPassportDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).passportDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).togglePassportArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).togglePassportFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).togglePassportLock(itemID)
                }
            }

            3L -> {
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softIDCardDelete(itemID)
                }
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).idCardDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleIDCardArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleIDCardFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleIDCardLock(itemID)
                }
            }

            4L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).residenceDelete(itemID)
                }
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softResidenceDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleResidenceArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleResidenceFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleResidenceLock(itemID)
                }
            }

            5L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).paymentDelete(itemID)
                }
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softPaymentDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).togglePaymentArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).togglePaymentFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).togglePaymentLock(itemID)
                }
            }

            6L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).giftDelete(itemID)
                }
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softGiftDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleGiftArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleGiftFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleGiftLock(itemID)
                }
            }

            7L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).loyaltyDelete(itemID)
                }
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softLoyaltyDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleLoyaltyArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleLoyaltyFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleLoyaltyLock(itemID)
                }
            }

            8L -> {

                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).membershipDelete(itemID)
                }
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softMembershipDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleMembershipArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleMembershipFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleMembershipLock(itemID)
                }

            }

            9L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).medicalDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softMedicalDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleMedicalArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleMedicalFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleMedicalLock(itemID)
                }

            }

            10L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).healthDelete(itemID)
                }
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softHealthDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleHealthArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleHealthFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleHealthLock(itemID)
                }

            }

            11L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).birthDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softBirthDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleBirthArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleBirthFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleBirthLock(itemID)
                }

            }

            12L -> {

                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).mrgDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softMrgDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleMrgArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleMrgFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleMrgLock(itemID)
                }

            }

            13L -> {

                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).simDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softSIMDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleSIMArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleSIMFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleSIMLock(itemID)
                }

            }

            14L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).passwordDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softPasswordDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).togglePasswordArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).togglePasswordFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).togglePasswordLock(itemID)
                }

            }

            15L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).customDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softCustomDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleCustomArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleCustomFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleCustomLock(itemID)
                }
            }
            16L -> {
                if (operationtype.equals("permanentDelete")) { DatabaseHelperManiya(this).vehicleDelete(itemID) }
                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softVehicleDelete(itemID)
                }
                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleVehicleArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleVehicleFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleVehicleLock(itemID)
                }
            }
            17L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).adharDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softAdharDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleAdharArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleAdharFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleAdharLock(itemID)
                }
            }
            18L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).voterDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softVoterDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).toggleVoterArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).toggleVoterFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).toggleVoterLock(itemID)
                }
            }
            19L -> {
                if (operationtype.equals("permanentDelete")) {
                    DatabaseHelperManiya(this).panDelete(itemID)
                }

                if (operationtype.equals("delete")) {
                    DatabaseHelperManiya(this).softPANDelete(itemID)
                }

                if (operationtype.equals("archive")) {
                    DatabaseHelperManiya(this).togglePANArchive(itemID)
                }
                if (operationtype.equals("favourite")) {
                    DatabaseHelperManiya(this).togglePANFavorite(itemID)
                }
                if (operationtype.equals("lock")) {
                    DatabaseHelperManiya(this).togglePANLock(itemID)
                }
            }
        }

        if (operationtype.equals("delete") || operationtype.equals("archive") || operationtype.equals(
                "permanentDelete"
            )
        ) {
            if (!isSoftDelete || !isArchive) {
                //  finish()
                returnResult()
            }
        } else {
            getData()
        }
    }

    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }
}




