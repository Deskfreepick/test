package com.deep.infotech.atm_card_wallet.maniya.dataModel

import com.j256.ormlite.field.DatabaseField
import com.j256.ormlite.table.DatabaseTable

@DatabaseTable(tableName = "categories")
data class CategoryDataManiya(
    @DatabaseField(generatedId = true) // Auto-increment primary key
    val id: Long = 0,

    @DatabaseField(canBeNull = false, unique = true)
    var name: String = "",

    @DatabaseField(canBeNull = false)
    var icon: String = ""

)