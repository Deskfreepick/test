package com.deep.infotech.atm_card_wallet.maniya.ui

import android.annotation.SuppressLint

import android.os.Bundle
import android.util.Log
import android.view.View
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityDataStorageManiyaBinding
import java.io.File

class StorageActivityManiya : BaseActivity() {
    private lateinit var binding: ActivityDataStorageManiyaBinding
    @SuppressLint("UsableSpace")
    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        binding = ActivityDataStorageManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        init()

    }

    private fun getTotalStorageUsed(): Long {
        val appDataDir = filesDir
        val dataDir = dataDir
        val cacheDir = cacheDir
        val databasesDir = File(filesDir.parent, "databases")
        val sharedPrefsDir = File(filesDir.parent, "shared_prefs")

        Log.w("appDataDir Storage Used:+++",formatSize(getDirectorySize(appDataDir)))
        Log.w("cacheDir Storage Used:+++",formatSize(getDirectorySize(cacheDir)))
        Log.w("DataDir Storage Used:+++",formatSize(getDirectorySize(dataDir)))
        Log.w("DatabaseDir Storage Used:+++",formatSize(getDirectorySize(databasesDir)))
        Log.w("sharedPrefsDir Storage Used:+++",formatSize(getDirectorySize(sharedPrefsDir)))

        val totalStorageUsed = getDirectorySize(filesDir) +
                getDirectorySize(appDataDir) +
                getDirectorySize(dataDir) +
                getDirectorySize(cacheDir)+
                getDirectorySize(databasesDir) +
                getDirectorySize(sharedPrefsDir)
        return totalStorageUsed
    }

    private fun getDirectorySize(dir: File?): Long {
        if (dir == null || !dir.exists()) return 0L
        var size: Long = 0
        val files = dir.listFiles()
        if (files != null) {
            for (file in files) {
                size += if (file.isDirectory) {
                    getDirectorySize(file)
                } else {
                    file.length()
                }
            }
        }
        return size
    }

    @SuppressLint("DefaultLocale")
    private fun formatSize(sizeInBytes: Long): String {
        if (sizeInBytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(sizeInBytes.toDouble()) / Math.log10(1024.0)).toInt()
        return String.format("%.1f %s", sizeInBytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
    }


    @SuppressLint("SetTextI18n")
    private fun init() {
        val formattedSize = formatSize(getTotalStorageUsed())
        println("Total Storage Used:+++ $formattedSize")
        binding.tvStorageSize.text= formattedSize
        binding.tvDocumentSize.text=resources.getText(R.string._0_mb)
        binding.tvPhotoSize.text= resources.getText(R.string._0_mb)

    }

    fun onBackClick(view: View) {

        AdsInterstitial.instance?.showInterstitialAd(
            this@StorageActivityManiya,
            false,
            object : AdsInterstitial.adfinish {
                override fun adfinished() {
                    onBackPressed()
                }
            })
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }

}
