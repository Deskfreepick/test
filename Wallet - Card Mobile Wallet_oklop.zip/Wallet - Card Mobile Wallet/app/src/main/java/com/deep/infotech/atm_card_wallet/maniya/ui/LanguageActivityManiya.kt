package com.deep.infotech.atm_card_wallet.maniya.ui

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.maniya.adapter.AdapterLanguage
import com.deep.infotech.atm_card_wallet.databinding.ActivityLanguageManiyaBinding
import com.deep.infotech.atm_card_wallet.maniya.model.ModelLanguage
import com.deep.infotech.atm_card_wallet.utils.LocaleHelper

class LanguageActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityLanguageManiyaBinding

    private lateinit var adapter: AdapterLanguage
    private lateinit var languageList: List<ModelLanguage>

    private var currentLanguage: String = "en"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLanguageManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        init()
    }

    private fun changeLanguage() {

        val sharedPreferences = getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE)
        val selectedPosition = adapter.getLastSelectedItem()
        Log.d("TAG++++", "selectedPosition--->: " + selectedPosition)
        if (selectedPosition != -1) {
            val selectedLanguageCode = languageList[selectedPosition].subtitle
            Log.d("TAG++++", "selectedLanguageCode--->: " + selectedLanguageCode)

            val selectedLanguage = languageList[selectedPosition].title
            Log.d("TAG++++", "selectedLanguage--->: " + selectedLanguage)

            if (getSharedPreferences("language", 0).getBoolean("isFirstRun", true)) {
                setLocale(selectedLanguageCode, sharedPreferences, selectedLanguage)
            } else {
                if (selectedLanguageCode != currentLanguage) {
                    setLocale(selectedLanguageCode, sharedPreferences, selectedLanguage)
                }
            }

        }

    }

    private fun init() {
        val sharedPreferences = getSharedPreferences(SHARED_PREFS_NAME, MODE_PRIVATE)
        val selectedCountry = sharedPreferences.getString(SELECTED_COUNTRY_KEY, "en")
        currentLanguage = selectedCountry.toString()
        if (getSharedPreferences("language", 0).getBoolean("isFirstRun", true)) {
            binding.ivLanguageSet.visibility=View.VISIBLE

        }else{
            binding.ivLanguageSet.visibility=View.GONE
        }
        getAllLanguage()
        setAdapter(selectedCountry)
    }

    private fun setAdapter(selectedCountry: String?) {
        adapter = AdapterLanguage(this, languageList) { _, position ->
            adapter.setLastSelectedItem(position)
            if(binding.ivLanguageSet.visibility==View.GONE){
            changeLanguage()}
        }
        binding.rvLanguage.adapter = adapter

        languageList.forEachIndexed { index, languageModel ->
            if (languageModel.subtitle == selectedCountry) {
                adapter.setLastSelectedItem(index)
            }
        }
    }

    private fun getAllLanguage() {
        languageList = listOf(
            ModelLanguage("English", "en", R.drawable.australia_language),
            ModelLanguage("Bengali", "bn", R.drawable.bangladesh_language),
            ModelLanguage("Hindi", "hi", R.drawable.india_language),
            ModelLanguage("Japanese", "ja", R.drawable.japan_language),
            ModelLanguage("Urdu", "ur", R.drawable.pakistan_language),
            ModelLanguage("Russian", "ru", R.drawable.russia_language),
            ModelLanguage("Arabic", "ar", R.drawable.saudi_arabia_language),
            ModelLanguage("Afrikaans", "af", R.drawable.south_africa_language),
            ModelLanguage("Lao", "lo", R.drawable.laos_language),
            ModelLanguage("Mongolian", "mn", R.drawable.mongolia_language),
            ModelLanguage("Spanish", "es", R.drawable.ecuador_language),
            ModelLanguage("Khmer", "km", R.drawable.cambodia_language),
            ModelLanguage("Burmese", "my", R.drawable.myanmar_language),
            ModelLanguage("Amharic", "am", R.drawable.ethiopia_language),
            ModelLanguage("Nepali", "ne", R.drawable.nepal_language),
            ModelLanguage("Malay", "ms", R.drawable.malaysia_language),
            ModelLanguage("Swahili", "sw", R.drawable.kenya_language),
            ModelLanguage("Vietnamese", "vi", R.drawable.vietnam_language),
            ModelLanguage("Thai", "th", R.drawable.thailand_language),
            ModelLanguage("Uzbek", "uz", R.drawable.uzbekistan_language),
            ModelLanguage("Romanian", "ro", R.drawable.romania_language),
            ModelLanguage("German", "de", R.drawable.german_language),
            ModelLanguage("Indonesian", "in", R.drawable.indonesian_language),
            ModelLanguage("Italian", "it", R.drawable.italian_language),
            ModelLanguage("Korean", "ko", R.drawable.korean_language),
            ModelLanguage("Latvian", "lv", R.drawable.latvian_language),
            ModelLanguage("Lithuanian", "lt", R.drawable.klithuanian_language),
            ModelLanguage("Polish", "pl", R.drawable.polish_language),
            ModelLanguage("Portuguese", "pt", R.drawable.portuguese_language),
            ModelLanguage("Serbian", "sr", R.drawable.serbian_language),
            ModelLanguage("Slovak", "sk", R.drawable.slovak_language),
            ModelLanguage("Slovenian", "sl", R.drawable.slovenian_language),
            ModelLanguage("Swedish", "sv", R.drawable.swedish_language),
            ModelLanguage("Turkish", "tr", R.drawable.turkish_language),
            ModelLanguage("Ukrainian", "uk", R.drawable.ukrainian_language),
        )
    }

    private fun setLocale(
        localeCode: String,
        sharedPreferences: SharedPreferences,
        selectedLanguage: String
    ) {
        sharedPreferences.edit().apply {
            putString(SELECTED_COUNTRY_KEY, localeCode)
            putString(SELECTED_LANGUAGE_NAME, selectedLanguage)
            apply()
        }

        LocaleHelper.setLocale(this, localeCode)
        recreate()
        LocaleHelper.updateLocaleAndRefreshUI(this, localeCode)

        val intent = Intent(this, TESTMainActivityManiya::class.java)
        startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
        getSharedPreferences("language", 0).edit().putBoolean("isFirstRun", false).apply()

    }

    override fun onBackPressed() {
        finish()
    }

    override fun onResume() {
        super.onResume()
        showNativeBannerAdsSecond()
    }

    fun onClickLanguageSet(view: View) {
        changeLanguage()
    }
}