package com.deep.infotech.atm_card_wallet.maniya.model

import com.deep.infotech.atm_card_wallet.R

object CategoryFieldManager {

    data class CategoryFields(

        val pinned: MutableList<FieldType>,
        val unpinned: MutableList<FieldType>,
        val allFields: MutableList<FieldType>,
        val filteredListFields: MutableList<FieldType> = mutableListOf()
    )

    private val categories = mutableMapOf(
        R.string.custom_cat_maniya to CategoryFields(
            pinned = mutableListOf(FieldType.FULL_NAME, FieldType.NUMBER, FieldType.EXPIRY_DATE),
            unpinned = mutableListOf(FieldType.EMAIL, FieldType.URL, FieldType.ADDRESS),
            allFields = mutableListOf(
                FieldType.ADDRESS, FieldType.BARCODE, FieldType.CARD_NUMBER,
                FieldType.DATE, FieldType.EMAIL, FieldType.FULL_NAME,
                FieldType.NUMBER, FieldType.PHONE_NUMBER, FieldType.TEXT,
                FieldType.URL, FieldType.EXPIRY_DATE,
                FieldType.NOTES
            )
        ),
        R.string.driver_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.DOCUMENT_NUMBER,
                FieldType.ISSUE_DATE,
                FieldType.EXPIRY_DATE,
                FieldType.DOB,
                FieldType.FULL_NAME
            ),
            unpinned = mutableListOf(
                FieldType.PARENTS_NAME,
                FieldType.PERSONAL_NUMBER,
                FieldType.ISSUING_COUNTRY,
                FieldType.ISSUING_AUTHORITY,
                FieldType.REGISTRATION_ADDRESS,
                FieldType.CLASS,
            ),
            allFields = mutableListOf(
                FieldType.DOCUMENT_NUMBER,
                FieldType.ISSUE_DATE, FieldType.EXPIRY_DATE, FieldType.DOB,
                FieldType.FULL_NAME, FieldType.PARENTS_NAME, FieldType.PERSONAL_NUMBER,
                FieldType.ISSUING_COUNTRY, FieldType.ISSUING_AUTHORITY, FieldType.RESTRICTIONS,
                FieldType.REGISTRATION_ADDRESS, FieldType.CLASS,
                FieldType.NOTES

            )
        ),
        R.string.passport_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.DOCUMENT_NUMBER,
                FieldType.ISSUE_DATE,
                FieldType.EXPIRY_DATE,
                FieldType.DOB,
                FieldType.FULL_NAME
            ),
            unpinned = mutableListOf(
                FieldType.PERSONAL_NUMBER,
                FieldType.ISSUING_COUNTRY,
                FieldType.NATIONALITY
            ),
            allFields = mutableListOf(
                FieldType.DOCUMENT_NUMBER,
                FieldType.ISSUE_DATE,
                FieldType.EXPIRY_DATE,
                FieldType.DOB,
                FieldType.FULL_NAME,
                FieldType.PERSONAL_NUMBER,
                FieldType.TYPE,
                FieldType.PLACE_OF_BIRTH,
                FieldType.ISSUING_COUNTRY,
                FieldType.ISSUING_AUTHORITY,
                FieldType.NATIONALITY,
                FieldType.REGISTRATION_ADDRESS,
                FieldType.BLANK_PAGES_REMAINING,
                FieldType.NOTES
            )
        ),
        R.string.identity_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.PERSONAL_NUMBER,
                FieldType.ISSUE_DATE,
                FieldType.EXPIRY_DATE,
                FieldType.DOB,
                FieldType.FULL_NAME
            ),
            unpinned = mutableListOf(
                FieldType.DOCUMENT_NUMBER,
                FieldType.ISSUING_COUNTRY,
                FieldType.ISSUING_AUTHORITY,
                FieldType.NATIONALITY
            ),
            allFields = mutableListOf(
                FieldType.PERSONAL_NUMBER,
                FieldType.ISSUE_DATE,
                FieldType.EXPIRY_DATE,
                FieldType.DOB,
                FieldType.FULL_NAME,
                FieldType.DOCUMENT_NUMBER,
                FieldType.PLACE_OF_BIRTH,
                FieldType.ISSUING_COUNTRY,
                FieldType.ISSUING_AUTHORITY,
                FieldType.NATIONALITY,
                FieldType.REGISTRATION_ADDRESS,
                FieldType.NOTES
            )
        ),
        R.string.residence_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.PERSONAL_NUMBER,
                FieldType.ISSUE_DATE,
                FieldType.EXPIRY_DATE,
                FieldType.DOB,
                FieldType.FULL_NAME
            ),
            unpinned = mutableListOf(
                FieldType.DOCUMENT_NUMBER,
                FieldType.PLACE_OF_BIRTH,
                FieldType.ISSUING_COUNTRY,
                FieldType.ISSUING_AUTHORITY,
                FieldType.NATIONALITY
            ),
            allFields = mutableListOf(
                FieldType.PERSONAL_NUMBER, FieldType.ISSUE_DATE,
                FieldType.EXPIRY_DATE, FieldType.DOB,
                FieldType.FULL_NAME, FieldType.DOCUMENT_NUMBER, FieldType.PLACE_OF_BIRTH,
                FieldType.ISSUING_COUNTRY, FieldType.ISSUING_AUTHORITY,
                FieldType.NATIONALITY, FieldType.REGISTRATION_ADDRESS,
                FieldType.NOTES
            )
        ),

        R.string.pay_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.CARD_HOLDER_NAME,
                FieldType.CARD_NUMBER,
                FieldType.EXPIRY_DATE,
                FieldType.CVV
            ),
            unpinned = mutableListOf(
                FieldType.BANK,
                FieldType.PAY_SYSTEM,
                FieldType.PIN,
                FieldType.CURRENCY,
                FieldType.BILLING_ADDRESS
            ),
            allFields = mutableListOf(
                FieldType.CARD_HOLDER_NAME, FieldType.CARD_NUMBER, FieldType.EXPIRY_DATE,
                FieldType.CVV, FieldType.BANK,
                FieldType.PAY_SYSTEM, FieldType.PIN, FieldType.CURRENCY,
                FieldType.BILLING_ADDRESS, FieldType.ACCOUNT_NUMBER, FieldType.CUSTOMER_SERVICE_NO,
                FieldType.NOTES
            )
        ),
        R.string.gift_cat_maniya to CategoryFields(
            pinned = mutableListOf(FieldType.CARD_NUMBER, FieldType.PIN, FieldType.AMOUNT),
            unpinned = mutableListOf(FieldType.BRAND, FieldType.EXPIRY_DATE),
            allFields = mutableListOf(
                FieldType.CARD_NUMBER, FieldType.PIN, FieldType.AMOUNT,
                FieldType.BRAND, FieldType.BARCODE,
                FieldType.ISSUE_DATE, FieldType.EXPIRY_DATE,
                FieldType.NOTES
            )
        ),
        R.string.loyal_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.CARD_HOLDER_NAME,
                FieldType.CARD_HOLDER_NUMBER,
                FieldType.CARD_NUMBER
            ),
            unpinned = mutableListOf(
                FieldType.BRAND,
                FieldType.URL,
                FieldType.LOGIN,
                FieldType.PASSWORD,
            ),
            allFields = mutableListOf(
                FieldType.CARD_HOLDER_NAME, FieldType.CARD_HOLDER_NUMBER, FieldType.CARD_NUMBER,
                FieldType.BRAND, FieldType.URL, FieldType.LOGIN, FieldType.PASSWORD,
                FieldType.EXPIRY_DATE, FieldType.BARCODE,
                FieldType.NOTES
            )
        ),
        R.string.member_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.CARD_HOLDER_NAME,
                FieldType.CARD_HOLDER_NUMBER,
                FieldType.MEMBER_SINCE,
            ),
            unpinned = mutableListOf(
                FieldType.BRAND,
                FieldType.EXPIRY_DATE,
                FieldType.URL,
                FieldType.LOGIN,
                FieldType.PASSWORD,
            ),
            allFields = mutableListOf(
                FieldType.CARD_HOLDER_NAME, FieldType.CARD_HOLDER_NUMBER, FieldType.MEMBER_SINCE,
                FieldType.BRAND, FieldType.EXPIRY_DATE,
                FieldType.URL, FieldType.LOGIN,
                FieldType.PASSWORD, FieldType.BARCODE,
                FieldType.NOTES
            )
        ),

        R.string.medical_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.DOCUMENT_NUMBER,
                FieldType.FULL_NAME,
                FieldType.PHONE_NUMBER,
                FieldType.EXPIRY_DATE,
            ),
            unpinned = mutableListOf(FieldType.ISSUE_DATE, FieldType.DOB, FieldType.EMAIL),
            allFields = mutableListOf(
                FieldType.DOCUMENT_NUMBER, FieldType.FULL_NAME,
                FieldType.PHONE_NUMBER, FieldType.EXPIRY_DATE,
                FieldType.ISSUE_DATE, FieldType.DOB,
                FieldType.EMAIL,
                FieldType.NOTES
            )
        ),
        R.string.health_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.FULL_NAME,
                FieldType.DOCUMENT_NUMBER,
                FieldType.EXPIRY_DATE
            ),
            unpinned = mutableListOf(FieldType.PHONE_NUMBER, FieldType.EMAIL),
            allFields = mutableListOf(
                FieldType.FULL_NAME, FieldType.DOCUMENT_NUMBER, FieldType.EXPIRY_DATE,
                FieldType.PHONE_NUMBER, FieldType.EMAIL,
                FieldType.NOTES
            )
        ),
        R.string.birth_cat_maniya to CategoryFields(
            pinned = mutableListOf(FieldType.FULL_NAME, FieldType.DOB),
            unpinned = mutableListOf(FieldType.DOCUMENT_NUMBER),
            allFields = mutableListOf(
                FieldType.FULL_NAME,
                FieldType.DOB,
                FieldType.DOCUMENT_NUMBER,
                FieldType.NOTES
            )
        ),

        R.string.mrg_cat_maniya to CategoryFields(
            pinned = mutableListOf(FieldType.FULL_NAME, FieldType.SPOUSE_NAME),
            unpinned = mutableListOf(FieldType.MRG_DATE),
            allFields = mutableListOf(
                FieldType.FULL_NAME, FieldType.SPOUSE_NAME, FieldType.MRG_DATE,
                FieldType.NOTES
            )
        ),

        R.string.sim_cat_maniya to CategoryFields(
            pinned = mutableListOf(FieldType.PHONE_NUMBER, FieldType.PIN, FieldType.PUK),
            unpinned = mutableListOf(
                FieldType.COUNTRY,
                FieldType.MOBILE_OPERATOR,
                FieldType.OWNER_NAME,
                FieldType.NOTES
            ),
            allFields = mutableListOf(
                FieldType.PHONE_NUMBER,
                FieldType.PIN, FieldType.PUK,
                FieldType.COUNTRY,
                FieldType.MOBILE_OPERATOR, FieldType.OWNER_NAME,
                FieldType.NOTES
            )
        ),

        R.string.password_cat_maniya to CategoryFields(
            pinned = mutableListOf(
                FieldType.NAME,
                FieldType.LOGIN,
                FieldType.PASSWORD,
                FieldType.URL
            ),
            unpinned = mutableListOf(FieldType.NOTES),
            allFields = mutableListOf(
                FieldType.NAME,
                FieldType.LOGIN, FieldType.PASSWORD, FieldType.URL,
                FieldType.NOTES
            )
        ),
        R.string.voter_cat_maniya to CategoryFields(
                pinned = mutableListOf(FieldType.FULL_NAME, FieldType.NUMBER, FieldType.EXPIRY_DATE),
        unpinned = mutableListOf(FieldType.EMAIL, FieldType.URL, FieldType.ADDRESS),
        allFields = mutableListOf(
            FieldType.ADDRESS,  FieldType.CARD_NUMBER,
            FieldType.DATE, FieldType.EMAIL, FieldType.FULL_NAME,
            FieldType.NUMBER, FieldType.PHONE_NUMBER, FieldType.TEXT,
            FieldType.URL, FieldType.EXPIRY_DATE,
            FieldType.NOTES
        )
    ),
        R.string.adhar_cat_maniya to CategoryFields(
            pinned = mutableListOf(FieldType.FULL_NAME, FieldType.NUMBER, FieldType.EXPIRY_DATE),
            unpinned = mutableListOf(FieldType.EMAIL, FieldType.URL, FieldType.ADDRESS),
            allFields = mutableListOf(
                FieldType.ADDRESS,  FieldType.CARD_NUMBER,
                FieldType.DATE, FieldType.EMAIL, FieldType.FULL_NAME,
                FieldType.NUMBER, FieldType.PHONE_NUMBER, FieldType.TEXT,
                FieldType.URL, FieldType.EXPIRY_DATE,
                FieldType.NOTES
            )
        ),
        R.string.pan_cat_maniya to CategoryFields(
            pinned = mutableListOf(FieldType.FULL_NAME, FieldType.NUMBER, FieldType.EXPIRY_DATE),
            unpinned = mutableListOf(FieldType.EMAIL, FieldType.URL, FieldType.ADDRESS),
            allFields = mutableListOf(
                FieldType.ADDRESS,  FieldType.CARD_NUMBER,
                FieldType.DATE, FieldType.EMAIL, FieldType.FULL_NAME,
                FieldType.NUMBER, FieldType.PHONE_NUMBER, FieldType.TEXT,
                FieldType.URL, FieldType.EXPIRY_DATE,
                FieldType.NOTES
            )
        ),
        R.string.vehicle_cat_maniya to CategoryFields(
            pinned = mutableListOf(FieldType.FULL_NAME, FieldType.NUMBER, FieldType.EXPIRY_DATE),
            unpinned = mutableListOf(FieldType.EMAIL, FieldType.URL, FieldType.ADDRESS),
            allFields = mutableListOf(
                FieldType.ADDRESS,  FieldType.CARD_NUMBER,
                FieldType.DATE, FieldType.EMAIL, FieldType.FULL_NAME,
                FieldType.NUMBER, FieldType.PHONE_NUMBER, FieldType.TEXT,
                FieldType.URL, FieldType.EXPIRY_DATE,
                FieldType.NOTES
            )
        )


    )

    private fun updateFilteredList(category: Int) {
        val categoryFields = categories[category] ?: return
        categoryFields.filteredListFields.clear()
        categoryFields.filteredListFields.addAll(
            categoryFields.allFields.filter { field ->
                !categoryFields.pinned.contains(field) && !categoryFields.unpinned.contains(field)
            }
        )
    }

    fun refreshFilteredList(category: Int) {
        updateFilteredList(category)
    }

    fun getFilteredList(category: Int): MutableList<FieldType> {
        val categoryFields = categories[category] ?: return mutableListOf()
        categoryFields.filteredListFields.clear()
        categoryFields.filteredListFields.addAll(
            categoryFields.allFields.filter { field ->
                !categoryFields.pinned.contains(field) && !categoryFields.unpinned.contains(field)
            }
        )
        return categories[category]?.filteredListFields ?: mutableListOf()
    }

    fun getCategoryFields(category: Int): CategoryFields {
        return categories[category] ?: categories[R.string.custom_cat_maniya]!!
    }

    fun addToPinned(category: Int, field: FieldType) {
        val categoryFields = categories[category] ?: return
        if (!categoryFields.pinned.contains(field)) {
            categoryFields.pinned.add(field)
        }
        if (categoryFields.unpinned.contains(field)) {
            categoryFields.unpinned.remove(field)
        }
    }

    fun addToUnpinned(category: Int, field: FieldType) {
        val categoryFields = categories[category] ?: return
        if (!categoryFields.unpinned.contains(field)) {
            categoryFields.unpinned.add(field)
        }
        if (categoryFields.pinned.contains(field)) {
            categoryFields.pinned.remove(field)
        }
    }

    fun removeFromPinned(category: Int, field: FieldType) {
        val categoryFields = categories[category] ?: return
        if (categoryFields.pinned.contains(field)) {
            categoryFields.pinned.remove(field)
        }
        if (!categoryFields.filteredListFields.contains(field)) {
            categoryFields.filteredListFields.add(field)
        }

        updateFilteredList(category)
    }

    fun removeFromUnpinned(category: Int, field: FieldType) {
        val categoryFields = categories[category] ?: return
        if (categoryFields.unpinned.contains(field)) {
            categoryFields.unpinned.remove(field)
        }

        if (!categoryFields.filteredListFields.contains(field)) {
            categoryFields.filteredListFields.add(field)
        }

        updateFilteredList(category)
    }

}