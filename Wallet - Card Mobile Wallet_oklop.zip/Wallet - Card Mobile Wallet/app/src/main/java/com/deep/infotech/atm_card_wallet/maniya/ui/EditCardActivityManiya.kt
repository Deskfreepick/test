package com.deep.infotech.atm_card_wallet.maniya.ui

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.deep.infotech.atm_card_wallet.Ads.AdsInterstitial
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityEditManiyaBinding
import com.deep.infotech.atm_card_wallet.databinding.FieldMoreBottomDialogBinding
import com.deep.infotech.atm_card_wallet.databinding.ItemEditrecordFieldBinding
import com.deep.infotech.atm_card_wallet.maniya.dataModel.AdharScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.BirthCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.CustomScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.GiftCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LoyaltyCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MedicalCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MemberShipCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MrgCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PANScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PassportScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PasswordCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.ResidentScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.SIMCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.VehicleScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.VoterScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.deep.infotech.atm_card_wallet.utils.LogD
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.j256.ormlite.field.DatabaseField
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale


class EditCardActivityManiya : BaseActivity() {

    private lateinit var view: ItemEditrecordFieldBinding
    private lateinit var binding: ActivityEditManiyaBinding

    private var sTAG = "EditCardActivityManiya++++"

    private var licenceData: MutableList<LicenseScanDataManiya> = mutableListOf()
    private var passportData: MutableList<PassportScanDataManiya> = mutableListOf()
    private var idData: MutableList<IdentityScanDataManiya> = mutableListOf()
    private var residenceData: MutableList<ResidentScanDataManiya> = mutableListOf()
    private var paymentData: MutableList<PaymentCardScanDataManiya> = mutableListOf()
    private var giftData: MutableList<GiftCardScanDataManiya> = mutableListOf()
    private var loyaltyData: MutableList<LoyaltyCardScanDataManiya> = mutableListOf()
    private var memberShipData: MutableList<MemberShipCardScanDataManiya> = mutableListOf()
    private var medicalData: MutableList<MedicalCardScanDataManiya> = mutableListOf()
    private var healthData: MutableList<HealthCardScanDataManiya> = mutableListOf()
    private var birthData: MutableList<BirthCardScanDataManiya> = mutableListOf()
    private var mrgData: MutableList<MrgCardScanDataManiya> = mutableListOf()
    private var simData: MutableList<SIMCardScanDataManiya> = mutableListOf()
    private var passwordData: MutableList<PasswordCardScanDataManiya> = mutableListOf()
    private var customData: MutableList<CustomScanDataManiya> = mutableListOf()
    private var vehicalData: MutableList<VehicleScanDataManiya> = mutableListOf()
    private var adharData: MutableList<AdharScanDataManiya> = mutableListOf()
    private var voterData: MutableList<VoterScanDataManiya> = mutableListOf()
    private var panData: MutableList<PANScanDataManiya> = mutableListOf()

    var viewCount = 0
    private var appreanceColor: Int = 0

    private var title = ""
    private var frontImage = ""
    private var backImage = ""
    private var categoryID = 15L
    private var dataID = 15L
    private var isFromScan = false
    private var isLock = false
    private var isFav = false
    private var isArchive = false
    private var isSoftDelete = false
    private var isSensitive = false

    private var currentCategory = "Custom"
    var mainChild: RelativeLayout? = null

    private lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEditManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        activityResultLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                appreanceColor = result.data?.getIntExtra(
                    "appreanceColor",
                    ContextCompat.getColor(this@EditCardActivityManiya, R.color.appreance)
                ) ?: ContextCompat.getColor(this@EditCardActivityManiya, R.color.appreance)
                LogD(sTAG, "activityResultLauncher---AppreanceColor--->: $appreanceColor")
            }
        }
        init()
    }

    fun init() {
        appreanceColor = ContextCompat.getColor(this@EditCardActivityManiya, R.color.appreance)
        categoryID = intent.getLongExtra("categoryID", 15L)
        isFromScan = intent.getBooleanExtra("isFromScan", false)
        dataID = intent.getLongExtra("ItemID", 0L)
        currentCategory = getCategoryTitle(categoryID)
        LogD(
            sTAG, "title--->$title\n" +
                    "DataID--->$dataID\n" +
                    "categoryID--->$categoryID\n" +
                    "isFromScan--->$isFromScan"
        )

        view = ItemEditrecordFieldBinding.inflate(LayoutInflater.from(this))
        getData()
    }

    private fun getData() {
        binding.dynamicContainer.removeAllViews()
        clearAllData()
        getCategoryData()

        if (frontImage.isNotEmpty()) {
            Glide.with(this@EditCardActivityManiya).load(frontImage).into(binding.ivCard)
            viewCount = 1
        }
        if (backImage.isNotEmpty()) {
            viewCount++
        }
        binding.tvPhotoCount.text = viewCount.toString()

        binding.edtTitle.text = Editable.Factory.getInstance().newEditable(title)
        binding.switchSensitive.setOnCheckedChangeListener { _, isChecked ->
            isSensitive = isChecked
        }

        if(frontImage.isNotEmpty() || backImage.isNotEmpty()){
            binding.rlPhoto.visible()
            binding.llAddPhoto.gone()

        }else{
            binding.rlPhoto.gone()
            binding.llAddPhoto.visible()
        }

    }

    private fun updateDividerVisibility() {
        var visibleViewPosition: MutableList<Int> = mutableListOf()
        if (mainChild != null) {
            for (i in 0 until mainChild!!.childCount) {
                val childView = mainChild!!.getChildAt(i)
                if (childView.visibility == View.VISIBLE) {
                    visibleViewPosition.add(i)
                }
            }
            if (visibleViewPosition.size == 1) {
                val sunChildView: RelativeLayout =
                    mainChild!!.getChildAt(visibleViewPosition[0]) as RelativeLayout
                sunChildView.getChildAt(sunChildView.childCount - 1).gone()
            } else {
                if (visibleViewPosition.size > 1)
                {
                var lastViewPosition = visibleViewPosition.size - 1
                val sunChildView: RelativeLayout =
                    mainChild!!.getChildAt(visibleViewPosition[lastViewPosition]) as RelativeLayout
                sunChildView.getChildAt(sunChildView.childCount - 1).gone()
                }
            }
        }
    }
    private fun getCategoryData() {
        when (categoryID) {
            1L -> {
                licenceData = DatabaseHelperManiya(this).fetchLicensesCardByID(dataID)
                setLicenceResultData()
            }

            2L -> {
                passportData = DatabaseHelperManiya(this).fetchPassportCardByID(dataID)
                setPassportResultData()
            }

            3L -> {
                idData = DatabaseHelperManiya(this).fetchIDCardByID(dataID)
                setIDCardResultData()
            }

            4L -> {
                residenceData = DatabaseHelperManiya(this).fetchResidenceCardByID(dataID)
                setResidenceResultData()
            }

            5L -> {
                paymentData = DatabaseHelperManiya(this).fetchPaymentCardByID(dataID)
                setPaymentResultData()
            }

            6L -> {
                giftData = DatabaseHelperManiya(this).fetchGiftCardByID(dataID)
                setGiftResultData()
            }

            7L -> {
                loyaltyData = DatabaseHelperManiya(this).fetchLoyaltyCardByID(dataID)
                setLoyaltyResultData()
            }

            8L -> {
                memberShipData = DatabaseHelperManiya(this).fetchMemberShipCardByID(dataID)
                setMemberShipResultData()
            }

            9L -> {
                medicalData = DatabaseHelperManiya(this).fetchMedicalCardByID(dataID)
                setMedicalResultData()
            }

            10L -> {
                healthData = DatabaseHelperManiya(this).fetchHealthCardByID(dataID)
                setHealthResultData()
            }

            11L -> {
                birthData = DatabaseHelperManiya(this).fetchBirthCardByID(dataID)
                setBirthResultData()
            }
            12L -> {
                mrgData = DatabaseHelperManiya(this).fetchMrgCardByID(dataID)
                setMrgResultData()
            }
            13L -> {
                simData = DatabaseHelperManiya(this).fetchSIMCardByID(dataID)
                setSIMResultData()
            }
            14L -> {
                passwordData = DatabaseHelperManiya(this).fetchPasswordCardByID(dataID)
                setPasswordResultData()
            }
            15L -> {
                customData = DatabaseHelperManiya(this).fetchCustomCardByID(dataID)
                setCustomResultData()
            }
            16L -> {
                vehicalData = DatabaseHelperManiya(this).fetchVehicleCardByID(dataID)
                setVehicalResultData()
            }
            17L -> {
                adharData = DatabaseHelperManiya(this).fetchAdharCardByID(dataID)
                setAdharResultData()
            }
            18L -> {
                voterData = DatabaseHelperManiya(this).fetchVoterCardByID(dataID)
                setVoterResultData()
            }
            19L -> {
                panData = DatabaseHelperManiya(this).fetchPANCardByID(dataID)
                setPANResultData()
            }
        }
        updateDividerVisibility()
    }
    private fun saveEditedData() {
        if (isFromScan) isSoftDelete = false
        when (categoryID) {
            1L -> {

                val licenseCard =
                    LicenseScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        gender = view.edtGenderText.text.toString(),
                        bloodGroup = view.edtBloodGroupText.text.toString(),
                        documentNumber = view.edtLiNumberText.text.toString(),
                        issueDate = view.tvIssueDateText.text.toString(),
                        expiryDate = view.tvExpDateText.text.toString(),
                        dob = view.tvDOBDateText.text.toString(),
                        fullName = view.edtNameText.text.toString(),
                        parentsName = view.edtParentsText.text.toString(),
                        personamNumber = view.edtPersonalNoText.text.toString(),
                        issueCountry = view.edtIssueCountryText.text.toString(),
                        issueAuthority = view.edtIssueAuthorityText.text.toString(),
                        regAddress = view.edtAddressText.text.toString(),
                        restrictions = view.edtRestrictionsText.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        classs = view.edtClassText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateLicenceCard(licenseCard)
            }
            2L -> {

                val passportData =
                    PassportScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        documentNumber = view.edtLiNumberText.text.toString(),
                        issueDate = view.tvIssueDateText.text.toString(),
                        expiryDate = view.tvExpDateText.text.toString(),
                        dob = view.tvDOBDateText.text.toString(),
                        fullName = view.edtNameText.text.toString(),
                        personalNumber = view.edtPersonalNoText.text.toString(),
                        type = view.edtTypeText.text.toString(),
                        placeOfBirth = view.edtBirthPlaceText.text.toString(),
                        issueCountry = view.edtIssueCountryText.text.toString(),
                        issueAuthority = view.edtIssueAuthorityText.text.toString(),
                        nationality = view.edtNationalityText.text.toString(),
                        regAddress = view.edtAddressText.text.toString(),
                        blankpageRemain = view.edtBlankPageText.text.toString(),
                        Notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updatePassportCard(passportData)

            }
            3L -> {
                val identityData =
                    IdentityScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        documentNumber = view.edtLiNumberText.text.toString(),
                        issueDate = view.tvIssueDateText.text.toString(),
                        expiryDate = view.tvExpDateText.text.toString(),
                        dob = view.tvDOBDateText.text.toString(),
                        fullName = view.edtNameText.text.toString(),
                        personalNumber = view.edtPersonalNoText.text.toString(),
                        placeOfBirth = view.edtBirthPlaceText.text.toString(),
                        issueCountry = view.edtIssueCountryText.text.toString(),
                        issueAuthority = view.edtIssueAuthorityText.text.toString(),
                        nationality = view.edtNationalityText.text.toString(),
                        regAddress = view.edtAddressText.text.toString(),
                        Notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateIDCard(identityData)
            }
            4L -> {

                val residenceData =
                    ResidentScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        documentNumber = view.edtLiNumberText.text.toString(),
                        issueDate = view.tvIssueDateText.text.toString(),
                        expiryDate = view.tvExpDateText.text.toString(),
                        dob = view.tvDOBDateText.text.toString(),
                        fullName = view.edtNameText.text.toString(),
                        personalNumber = view.edtPersonalNoText.text.toString(),
                        placeOfBirth = view.edtBirthPlaceText.text.toString(),
                        issueCountry = view.edtIssueCountryText.text.toString(),
                        issueAuthority = view.edtIssueAuthorityText.text.toString(),
                        nationality = view.edtNationalityText.text.toString(),
                        regAddress = view.edtAddressText.text.toString(),
                        Notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateResidenceCard(residenceData)


            }
            5L -> {

                val paymentData =
                    PaymentCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        holderName = view.edtNameText.text.toString(),
                        cardNumber = view.edtLiNumberText.text.toString(),
                        cvv = view.edtCVVText.text.toString(),
                        expDate = view.tvExpDateText.text.toString(),
                        cardType = view.edtTypeText.text.toString(),
                        bankName = view.edtBankText.text.toString(),
                        cardPIN = view.edtPINText.text.toString(),
                        address = view.edtAddressText.text.toString(),
                        email = view.edtEmailText.text.toString(),
                        barcode = view.edtBarcodeText.text.toString(),
                        phoneNumber = view.edtPersonalNoText.text.toString(),
                        url = view.edtURLText.text.toString(),
                        /* predefinedList,*/
                        text = view.edtTextText.text.toString(),
                        number = view.edtNumberText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updatePaymentCard(paymentData)


            }
            6L -> {
                val giftData =
                    GiftCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        cardNumber = view.edtLiNumberText.text.toString(),
                        pin = view.edtPINText.text.toString(),
                        amount = view.edtAmountText.text.toString(),
                        barcode = view.edtBarcodeText.text.toString(),
                        brand = view.edtBrandText.text.toString(),
                        issueDate = view.tvIssueDate.text.toString(),
                        expDate = view.tvExpDateText.text.toString(),
                        /* predefinedList,*/
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateGiftCard(giftData)


            }
            7L -> {
                val loyaltyData =
                    LoyaltyCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        barcode = view.edtBarcodeText.text.toString(),
                        brand = view.edtBrandText.text.toString(),
                        cardNumber = view.edtLiNumberText.text.toString(),
                        url = view.edtURLText.text.toString(),
                        login = view.edtLoginText.text.toString(),
                        password = view.edtPasswordText.text.toString(),
                        cardHolderName = view.edtNameText.text.toString(),
                        cardHolderNumber = view.edtLiNumberText.text.toString(),
                        expDate = view.tvExpDateText.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateLoyaltyCard(loyaltyData)


            }
            8L -> {

                val memberShipData =
                    MemberShipCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        cardHolderName = view.edtNameText.text.toString(),
                        cardHolderNumber = view.edtLiNumberText.text.toString(),
                        url = view.edtURLText.text.toString(),
                        login = view.edtLoginText.text.toString(),
                        password = view.edtPasswordText.text.toString(),
                        barcode = view.edtBarcodeText.text.toString(),
                        brand = view.edtBrandText.text.toString(),
                        expDate = view.tvExpDateText.text.toString(),
                        memberSince = view.edtMemberSinceText.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateMembershipCard(memberShipData)


            }
            9L -> {

                val medicalData =
                    MedicalCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        documentNumber = view.edtLiNumberText.text.toString(),
                        expiryDate = view.tvExpDateText.text.toString(),
                        issueDate = view.tvIssueDateText.text.toString(),
                        dob = view.tvDOBDateText.text.toString(),
                        phoneNumber = view.edtPersonalNoText.text.toString(),
                        email = view.edtEmailText.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateMedicalCard(medicalData)


            }
            10L -> {
                val healthData =
                    HealthCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        fullName = view.edtNameText.text.toString(),
                        documentNumber = view.edtLiNumberText.text.toString(),
                        expiryDate = view.tvExpDateText.text.toString(),
                        phoneNumber = view.edtPersonalNoText.text.toString(),
                        email = view.edtEmailText.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateHealthCard(healthData)

            }
            11L -> {
                val birthData =
                    BirthCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        fullName = view.edtNameText.text.toString(),
                        documentNumber = view.edtLiNumberText.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateBirthCard(birthData)


            }
            12L -> {
                val mrgData =
                    MrgCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateMrgCard(mrgData)


            }
            13L -> {
                val simData =
                    SIMCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        phoneNumber = view.edtPersonalNoText.text.toString(),
                        pin = view.edtPINText.text.toString(),
                        puk = view.edtPUKText.text.toString(),
                        country = view.edtCountryText.text.toString(),
                        operator = view.edtMoOperatorText.text.toString(),
                        ownerName = view.edtOwnerText.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateSIMCard(simData)


            }
            14L -> {
                val passwordData =
                    PasswordCardScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        url = view.edtURLText.text.toString(),
                        password = view.edtPasswordText.text.toString(),
                        login = view.edtLoginText.text.toString(),
                        Name = view.edtNameText.text.toString(),
                        notes = view.edtNotesText.text.toString(),
                        custom = view.edtCustomText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updatePasswordCard(passwordData)


            }
            15L -> {
                val customData =
                    CustomScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        expDate = view.tvExpDateText.text.toString(),
                        note = view.edtNotesText.text.toString(),
                        address = view.edtAddressText.text.toString(),
                        barcode = view.edtBarcodeText.text.toString(),
                        cardNumber = view.edtLiNumberText.text.toString(),
                        date = view.tvIssueDate.text.toString(),
                        email = view.edtEmailText.text.toString(),
                        fullName = view.edtOtherNameText.text.toString(),
                        number = view.edtNumberText.text.toString(),
                        phoneNumber = view.edtPersonalNoText.text.toString(),
                        text = view.edtTextText.text.toString(),
                        /*     predefineList,*/
                        url = view.edtURLText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateCustomCard(customData)
            }
            16L -> {
                val vehicleData =
                    VehicleScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        expDate = view.tvExpDateText.text.toString(),
                        note = view.edtNotesText.text.toString(),
                        address = view.edtAddressText.text.toString(),
                        barcode = view.edtBarcodeText.text.toString(),
                        cardNumber = view.edtLiNumberText.text.toString(),
                        date = view.tvIssueDate.text.toString(),
                        email = view.edtEmailText.text.toString(),
                        fullName = view.edtOtherNameText.text.toString(),
                        number = view.edtNumberText.text.toString(),
                        phoneNumber = view.edtPersonalNoText.text.toString(),
                        text = view.edtTextText.text.toString(),
                        url = view.edtURLText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateVehicleCard(vehicleData)
            }
            17L -> {

                val adharData = AdharScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        fullName = view.edtNameText.text.toString(),
                        adharNo = view.edtLiNumberText.text.toString(),
                        phoneNumber = view.edtPersonalNoText.text.toString(),
                        dob = view.tvDOBDateText.text.toString(),
                        gender = view.edtGenderText.text.toString(),
                        email = view.edtEmailText.text.toString(),
                        url = view.edtURLText.text.toString(),
                        address = view.edtAddressText.text.toString(),
                        note = view.edtNotesText.text.toString(),

                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive)
                DatabaseHelperManiya(this).updateAdharCard(adharData)
            }
            18L -> {
                val voterData =
                    VoterScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        dob = view.tvExpDateText.text.toString(),
                        note = view.edtNotesText.text.toString(),
                        address = view.edtAddressText.text.toString(),
                        email = view.edtEmailText.text.toString(),
                        fullName = view.edtOtherNameText.text.toString(),
                        phoneNumber = view.edtPersonalNoText.text.toString(),
                        parentsName = view.edtTextText.text.toString(),
                        url = view.edtURLText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updateVoterCard(voterData)
            }
            19L -> {
                val panData =
                    PANScanDataManiya(
                        dataID,
                        title = binding.edtTitle.text.toString(),
                        fullName = view.edtOtherNameText.text.toString(),
                        parentsName = view.edtParentsText.text.toString(),
                        cardNumber = view.edtLiNumberText.text.toString(),
                        dob = view.tvDOBDateText.text.toString(),
                        note = view.edtNotesText.text.toString(),
                        frontCardImage = frontImage,
                        backCardImage = backImage,
                        appearanceColor = appreanceColor,
                        isSensitive = isSensitive,
                        isLock = isLock,
                        isFav = isFav,
                        isDelete = isSoftDelete,
                        isArchive = isArchive
                    )
                DatabaseHelperManiya(this).updatePANCard(panData)
            }
        }
        if (isFromScan) {
            openRecordView()
        }else{
        returnResult()}
    }
    private fun openRecordView() {


       startActivity(Intent(this@EditCardActivityManiya, ViewActivityManiya::class.java)
               .putExtra("categoryID", categoryID)
               .putExtra("ItemID", dataID)
               .putExtra("isFromScan", true))
       finish()
   }

    private fun setLicenceResultData() {
        if (licenceData.size > 0) {
            isLock = licenceData[0].isLock
            isSensitive = licenceData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive
            isSoftDelete = licenceData[0].isDelete
            isArchive = licenceData[0].isArchive
            isFav = licenceData[0].isFav
            frontImage = licenceData[0].frontCardImage
            backImage = licenceData[0].backCardImage
            title = licenceData[0].title



            mainChild = view.mainChild

            /*----fullName-----*/
            view.rlNameView.visible()
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(licenceData[0].fullName)
            view.ivNameMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null) }

            /* ----DocumentNumber-----*/
            view.rlLicenceNumber.visible()
            view.tvLiNumber.text = getString(R.string.licence_number)
            view.edtLiNumberText.text = Editable.Factory.getInstance().newEditable(licenceData[0].documentNumber)
            view.ivLiNumberMore.setOnClickListener { showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null) }

            /*----expiryDate-----*/
            view.rlExpDate.visible()
            if(licenceData[0].expiryDate.equals("null",ignoreCase = true)) { }else{
            view.tvExpDateText.text = licenceData[0].expiryDate}
            view.tvExpDateText.setOnClickListener { showDatePicker(licenceData[0].expiryDate, view.tvExpDateText) }
            view.ivExpMore.setOnClickListener { showMoreBottomSheetDialog(view.rlExpDate, null,view.tvExpDateText) }


            /*----Gender-----*/
            view.rlGender.visible()
            view.edtGenderText.text = Editable.Factory.getInstance().newEditable(licenceData[0].gender)
            view.ivGenderMore.setOnClickListener { showMoreBottomSheetDialog(view.rlGender, view.edtGenderText,null) }


            /*----bloodGroup-----*/
            view.rlBloodGroup.visible()
            view.edtBloodGroupText.text = Editable.Factory.getInstance().newEditable(licenceData[0].bloodGroup)
            view.ivBloodGroupMore.setOnClickListener { showMoreBottomSheetDialog(view.rlBloodGroup, view.edtBloodGroupText,null) }


            /*----ParentsName-----*/
            view.rlParents.visible()
            view.edtParentsText.text = Editable.Factory.getInstance().newEditable(licenceData[0].parentsName)
            view.ivParentsMore.setOnClickListener { showMoreBottomSheetDialog(view.rlParents, view.edtParentsText,null) }


            /*----issueDate-----*/
            view.rlIssueDate.visible()
            if(licenceData[0].issueDate.equals("null",ignoreCase = true)) { }else{
            view.tvIssueDateText.text = licenceData[0].issueDate}
            view.tvIssueDateText.setOnClickListener { showDatePicker(licenceData[0].issueDate, view.tvIssueDateText) }
            view.ivIssueDateMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueDate, null,view.tvIssueDateText) }


            /*----dob-----*/
            view.rlDOBDate.visible()
            if(licenceData[0].dob.equals("null",ignoreCase = true)) { }else{

            view.tvDOBDateText.text = licenceData[0].dob}
            view.tvDOBDateText.setOnClickListener { showDatePicker(licenceData[0].dob, view.tvDOBDateText) }
            view.ivDOBDateMore.setOnClickListener { showMoreBottomSheetDialog(view.rlDOBDate, null,view.tvDOBDateText) }


            /*----personalNumber-----*/
            view.rlPersonalNo.visible()
            view.edtPersonalNoText.text = Editable.Factory.getInstance().newEditable(licenceData[0].personamNumber)
            view.ivPersonalNoMore.setOnClickListener { showMoreBottomSheetDialog(view.rlPersonalNo, view.edtPersonalNoText,null) }


            /*----issueCountry-----*/
            view.rlIssueCountry.visible()
            view.edtIssueCountryText.text = Editable.Factory.getInstance().newEditable(licenceData[0].issueCountry)
            view.ivIssueCountryMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueCountry, view.edtIssueCountryText,null) }


            /*----issueAuthority-----*/
            view.rlIssueAuthority.visible()
            view.edtIssueAuthorityText.text = Editable.Factory.getInstance().newEditable(licenceData[0].issueAuthority)
            view.ivIssueAuthorityMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueAuthority, view.edtIssueAuthorityText,null) }


            /*----regAddress-----*/
            view.rlAddress.visible()
            view.edtAddressText.text = Editable.Factory.getInstance().newEditable(licenceData[0].regAddress)
            view.ivAddressMore.setOnClickListener { showMoreBottomSheetDialog(view.rlAddress, view.edtAddressText,null) }

            /*----restrictions-----*/
            view.rlRestrictions.visible()
            view.edtRestrictionsText.text = Editable.Factory.getInstance().newEditable(licenceData[0].restrictions)
            view.ivRestrictionsMore.setOnClickListener { showMoreBottomSheetDialog(view.rlRestrictions, view.edtRestrictionsText,null) }

            /*----notes-----*/
            view.rlNotes.visible()
            view.edtNotesText.text = Editable.Factory.getInstance().newEditable(licenceData[0].notes)
            view.ivNotesMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null) }

            /*----classs-----*/
            view.rlClass.visible()
            view.edtClassText.text = Editable.Factory.getInstance().newEditable(licenceData[0].classs)
            view.ivClassMore.setOnClickListener { showMoreBottomSheetDialog(view.rlClass, view.edtClassText,null) }

            binding.dynamicContainer.addView(view.root)
        }
    }
    private fun setPassportResultData() {
        if (passportData.size > 0) {
            isLock = passportData[0].isLock
            isSoftDelete = passportData[0].isDelete
            isArchive = passportData[0].isArchive
            isFav = passportData[0].isFav
            frontImage = passportData[0].frontCardImage
            backImage = passportData[0].backCardImage
            title = passportData[0].title.toString()

            isSensitive = passportData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild
            /*----fullName-----*/
            view.rlNameView.visible()
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(passportData[0].fullName)
            view.ivNameMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null) }

            /*----DocumentNumber-----*/
            view.rlLicenceNumber.visible()
            view.edtLiNumberText.text = Editable.Factory.getInstance().newEditable(passportData[0].documentNumber)
            view.edtLiNumberText.text = Editable.Factory.getInstance().newEditable(resources.getString(R.string.passport_number))
            view.ivLiNumberMore.setOnClickListener { showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null) }

            /*----issueDate-----*/
            view.rlIssueDate.visible()
            if(passportData[0].issueDate.equals("null",ignoreCase = true)) { }else{
            view.tvIssueDateText.text = passportData[0].issueDate}
            view.tvIssueDateText.setOnClickListener { showDatePicker(passportData[0].issueDate, view.tvIssueDateText) }
            view.ivIssueDateMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueDate, null,view.tvIssueDateText) }

            /*----ExpDate-----*/
            view.rlExpDate.visible()
            if(passportData[0].expiryDate.equals("null",ignoreCase = true)) { }else{
            view.tvExpDateText.text = passportData[0].expiryDate}
            view.tvExpDateText.setOnClickListener { showDatePicker(passportData[0].expiryDate, view.tvExpDateText) }
            view.ivExpMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueDate, null,view.tvIssueDateText) }


            /*----dob-----*/
                view.rlDOBDate.visible()
            if(passportData[0].dob.equals("null",ignoreCase = true)) { }else{
                view.tvDOBDateText.text = passportData[0].dob}
                view.tvDOBDateText.setOnClickListener {
                    showDatePicker(
                        passportData[0].dob,
                        view.tvDOBDateText
                    )
                }
            view.ivDOBDateMore.setOnClickListener { showMoreBottomSheetDialog(view.rlDOBDate, null,view.tvDOBDateText) }


            /*----personalNumber-----*/
                view.rlPersonalNo.visible()
                view.edtPersonalNoText.text = Editable.Factory.getInstance().newEditable(passportData[0].personalNumber)
                view.ivPersonalNoMore.setOnClickListener { showMoreBottomSheetDialog(view.rlPersonalNo, view.edtPersonalNoText,null) }

            /*----type-----*/
                view.rlType.visible()
                view.edtTypeText.text = Editable.Factory.getInstance().newEditable(passportData[0].type)
                view.ivTypeTextMore.setOnClickListener { showMoreBottomSheetDialog(view.rlType, view.edtTypeText,null) }

            /*----BirthPLace-----*/
                view.rlBirthPlace.visible()
                view.edtBirthPlaceText.text = Editable.Factory.getInstance().newEditable(passportData[0].placeOfBirth)
                view.ivBirthPlaceMore.setOnClickListener { showMoreBottomSheetDialog(view.rlBirthPlace, view.edtBirthPlaceText,null) }


            /*----issueCountry-----*/
                view.rlCountry.visible()
                view.edtCountryText.text = Editable.Factory.getInstance().newEditable(passportData[0].issueCountry)
            view.ivCountryMore.setOnClickListener { showMoreBottomSheetDialog(view.rlCountry, view.edtCountryText,null) }


            /*----issueAuthority-----*/
                view.rlIssueAuthority.visible()
                view.edtIssueAuthorityText.text = Editable.Factory.getInstance().newEditable(passportData[0].issueAuthority)
            view.ivIssueAuthorityMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueAuthority, view.edtIssueAuthorityText,null) }


            /*----Nationality-----*/
                view.rlNationality.visible()
                view.edtNationalityText.text = Editable.Factory.getInstance().newEditable(passportData[0].nationality)
            view.ivNationalityMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNationality, view.edtNationalityText,null) }


            /*----RegAddress-----*/
                view.rlAddress.visible()
                view.edtAddressText.text = Editable.Factory.getInstance().newEditable(passportData[0].regAddress)
               view.ivAddressMore.setOnClickListener { showMoreBottomSheetDialog(view.rlAddress, view.edtAddressText,null) }


            /*----BlankPage-----*/
                view.rlBlankPage.visible()
                view.edtBlankPageText.text = Editable.Factory.getInstance().newEditable(passportData[0].blankpageRemain)
            view.ivBlankPageMore.setOnClickListener { showMoreBottomSheetDialog(view.rlBlankPage, view.edtBlankPageText,null) }


            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text = Editable.Factory.getInstance().newEditable(passportData[0].Notes)
            view.ivNotesMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null) }

            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setIDCardResultData() {
        if (idData.size > 0) {
            isSoftDelete = idData[0].isDelete
            isArchive = idData[0].isArchive
            isFav = idData[0].isFav
            isLock = idData[0].isLock
            frontImage = idData[0].frontCardImage
            backImage = idData[0].backCardImage
            title = idData[0].title
            isSensitive = idData[0].isSensitive

            binding.switchSensitive.isChecked = isSensitive
            mainChild = view.mainChild

            /*----fullName-----*/
                view.rlNameView.visible()
                view.edtNameText.text = Editable.Factory.getInstance().newEditable(idData[0].fullName)
            view.ivNameMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null) }


            /*----DocumentNumber-----*/
                view.rlLicenceNumber.visible()
                view.edtLiNumberText.text = Editable.Factory.getInstance().newEditable(idData[0].documentNumber)
                view.tvLiNumber.text = getString(R.string.id_number)
            view.ivLiNumberMore.setOnClickListener { showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null) }


            /*----issueDate-----*/
                view.rlIssueDate.visible()
            if(idData[0].issueDate.equals("null",ignoreCase = true)) { }else{

                view.tvIssueDateText.text = idData[0].issueDate}
                view.tvIssueDateText.setOnClickListener {
                    showDatePicker(
                        idData[0].issueDate,
                        view.tvIssueDateText
                    )
                }
            view.ivIssueDateMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueDate, null,view.tvIssueDateText) }


            /*----ExpDate-----*/
                view.rlExpDate.visible()
            if(idData[0].expiryDate.equals("null",ignoreCase = true)) { }else{

                view.tvExpDateText.text = idData[0].expiryDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        idData[0].expiryDate,
                        view.tvExpDateText
                    )
                }
            view.ivExpMore.setOnClickListener { showMoreBottomSheetDialog(view.rlExpDate, null,view.tvExpDateText) }


            /*----dob-----*/
                view.rlDOBDate.visible()
            if(idData[0].dob.equals("null",ignoreCase = true)) { }else{
                view.tvDOBDateText.text = idData[0].dob}
                view.tvDOBDateText.setOnClickListener {
                    showDatePicker(
                        idData[0].dob,
                        view.tvDOBDateText
                    )
                }
            view.ivDOBDateMore.setOnClickListener { showMoreBottomSheetDialog(view.rlDOBDate, null,view.tvDOBDateText) }


            /*----personalNumber-----*/
                view.rlPersonalNo.visible()
                view.edtPersonalNoText.text =
                    Editable.Factory.getInstance().newEditable(idData[0].personalNumber)
            view.ivPersonalNoMore.setOnClickListener { showMoreBottomSheetDialog(view.rlPersonalNo, view.edtPersonalNoText,null) }


            /*----BirthPLace-----*/
                view.rlBirthPlace.visible()
                view.edtBirthPlaceText.text = Editable.Factory.getInstance().newEditable(idData[0].placeOfBirth)
            view.ivBirthPlaceMore.setOnClickListener { showMoreBottomSheetDialog(view.rlBirthPlace, view.edtBirthPlaceText,null) }


            /*----issueCountry-----*/
                view.rlCountry.visible()
                view.edtCountryText.text =
                    Editable.Factory.getInstance().newEditable(idData[0].issueCountry)
            view.ivCountryMore.setOnClickListener { showMoreBottomSheetDialog(view.rlCountry, view.edtCountryText,null) }


            /*----issueAuthority-----*/
                view.rlIssueAuthority.visible()
                view.edtIssueAuthorityText.text =
                    Editable.Factory.getInstance().newEditable(idData[0].issueAuthority)
            view.ivIssueAuthorityMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueAuthority, view.edtIssueAuthorityText,null) }


            /*----Nationality-----*/
                view.rlNationality.visible()
                view.edtNationalityText.text =
                    Editable.Factory.getInstance().newEditable(idData[0].nationality)
            view.ivNationalityMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNationality, view.edtNationalityText,null) }


            /*----RegAddress-----*/
                view.rlAddress.visible()
                view.edtAddressText.text =
                    Editable.Factory.getInstance().newEditable(idData[0].regAddress)
            view.ivAddressMore.setOnClickListener { showMoreBottomSheetDialog(view.rlAddress, view.edtAddressText,null) }



            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text = Editable.Factory.getInstance().newEditable(idData[0].Notes)
            view.ivNotesMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null) }



            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setResidenceResultData() {
        if (residenceData.size > 0) {
            isSoftDelete = residenceData[0].isDelete
            isArchive = residenceData[0].isArchive
            isFav = residenceData[0].isFav

            dataID = residenceData[0].id
            isLock = residenceData[0].isSensitive
            frontImage = residenceData[0].frontCardImage
            backImage = residenceData[0].backCardImage
            title = residenceData[0].title

            isSensitive = residenceData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild

            /*----fullName-----*/
                view.rlNameView.visible()
                view.edtNameText.text = Editable.Factory.getInstance().newEditable(getString(R.string.name))
                view.edtNameText.text = Editable.Factory.getInstance().newEditable(residenceData[0].fullName)

            view.ivNameMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null) }



            /*----DocumentNumber-----*/
                view.rlLicenceNumber.visible()
                view.tvLiNumber.text = getString(R.string.document_number)
                view.edtLiNumberText.text =
                    Editable.Factory.getInstance().newEditable(residenceData[0].documentNumber)
            view.ivLiNumberMore.setOnClickListener { showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null) }


            /*----issueDate-----*/
                view.rlIssueDate.visible()
            if(residenceData[0].issueDate.equals("null",ignoreCase = true)) { }else{
                view.tvIssueDateText.text = residenceData[0].issueDate}
                view.tvIssueDateText.setOnClickListener {
                    showDatePicker(
                        residenceData[0].issueDate,
                        view.tvIssueDateText
                    )
                }
            view.ivIssueDateMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueDate, null,view.tvIssueDateText) }


            /*----ExpDate-----*/
                view.rlExpDate.visible()
            if(residenceData[0].expiryDate.equals("null",ignoreCase = true)) { }else{

                view.tvExpDateText.text = residenceData[0].expiryDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        residenceData[0].expiryDate,
                        view.tvExpDateText
                    )
                }
            view.ivExpMore.setOnClickListener { showMoreBottomSheetDialog(view.rlExpDate, null,view.tvExpDateText) }


            /*----dob-----*/
                view.rlDOBDate.visible()
            if(residenceData[0].dob.equals("null",ignoreCase = true)) { }else{

                view.tvDOBDateText.text = residenceData[0].dob}
                view.tvDOBDateText.setOnClickListener {
                    showDatePicker(
                        residenceData[0].dob,
                        view.tvDOBDateText
                    )
                }
            view.ivDOBDateMore.setOnClickListener { showMoreBottomSheetDialog(view.rlDOBDate, null,view.tvDOBDateText) }

            /*----personalNumber-----*/
                view.rlPersonalNo.visible()
                view.edtPersonalNoText.text = Editable.Factory.getInstance().newEditable(residenceData[0].personalNumber)
            view.ivPersonalNoMore.setOnClickListener { showMoreBottomSheetDialog(view.rlPersonalNo, view.edtPersonalNoText,null) }



            /*----BirthPLace-----*/
                view.rlBirthPlace.visible()
                view.edtBirthPlaceText.text = Editable.Factory.getInstance().newEditable(residenceData[0].placeOfBirth)
            view.ivBirthPlaceMore.setOnClickListener { showMoreBottomSheetDialog(view.rlBirthPlace, view.edtBirthPlaceText,null) }


            /*----issueCountry-----*/
                view.rlIssueCountry.visible()
                view.edtIssueCountryText.text = Editable.Factory.getInstance().newEditable(residenceData[0].issueCountry)
            view.ivCountryMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueCountry, view.edtIssueCountryText,null) }


            /*----issueAuthority-----*/
                view.rlIssueAuthority.visible()
                view.edtIssueAuthorityText.text =
                    Editable.Factory.getInstance().newEditable(residenceData[0].issueAuthority)
            view.ivIssueAuthorityMore.setOnClickListener { showMoreBottomSheetDialog(view.rlIssueAuthority, view.edtIssueAuthorityText,null) }


            /*----Nationality-----*/
                view.rlNationality.visible()
                view.edtNationalityText.text =
                    Editable.Factory.getInstance().newEditable(residenceData[0].nationality)
            view.ivNationalityMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNationality, view.edtNationalityText,null) }


            /*----RegAddress-----*/
                view.rlAddress.visible()
                view.edtAddressText.text =
                    Editable.Factory.getInstance().newEditable(residenceData[0].regAddress)
            view.ivAddressMore.setOnClickListener { showMoreBottomSheetDialog(view.rlAddress, view.edtAddressText,null) }


            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text =
                    Editable.Factory.getInstance().newEditable(residenceData[0].Notes)
            view.ivNotesMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null) }

            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setPaymentResultData() {
        if (paymentData.size > 0) {

            isSoftDelete = paymentData[0].isDelete
            isArchive = paymentData[0].isArchive
            isFav = paymentData[0].isFav


            dataID = paymentData[0].id
            isLock = paymentData[0].isSensitive
            frontImage = paymentData[0].frontCardImage.toString()
            backImage = paymentData[0].backCardImage.toString()
            title = paymentData[0].title.toString()

            isSensitive = paymentData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive


            mainChild = view.mainChild

            /*----CardholderName-----*/
                view.rlNameView.visible()
                view.edtNameText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].holderName)
            view.ivNameMore.setOnClickListener { showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null) }


            /*----CardNumber-----*/
                view.rlLicenceNumber.visible()
                view.edtLiNumberText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].cardNumber)
                view.tvLiNumber.text = "Card Number"

            view.ivLiNumberMore.setOnClickListener { showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null) }


            /*----CVV-----*/
                view.rlCVV.visible()
                view.edtCVVText.text = Editable.Factory.getInstance()
                    .newEditable(paymentData[0].cvv.map { '*' }.joinToString(""))

            view.ivCVVMore.setOnClickListener { showMoreBottomSheetDialog(view.rlCVV, view.edtCVVText,null) }



            /*----ExpDate-----*/
                view.rlExpDate.visible()
            if(paymentData[0].expDate.equals("null",ignoreCase = true)) { }else{

                view.tvExpDateText.text = paymentData[0].expDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        paymentData[0].expDate,
                        view.tvExpDateText
                    )
                }
            view.ivExpMore.setOnClickListener { showMoreBottomSheetDialog(view.rlExpDate, null,view.tvExpDateText) }


            /*----CardType-----*/
                view.rlType.visible()
                view.edtTypeText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].cardType)
            view.ivTypeTextMore.setOnClickListener { showMoreBottomSheetDialog(view.rlType, view.edtTypeText,null) }


            /*----Bank-----*/
                view.rlBank.visible()
                view.edtBankText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].bankName)
            view.ivBankMore.setOnClickListener { showMoreBottomSheetDialog(view.rlBank, view.edtBankText,null) }


            /*----CardPIN-----*/
                view.rlPIN.visible()
                view.edtPINText.text = Editable.Factory.getInstance()
                    .newEditable(paymentData[0].cardPIN.map { '*' }.joinToString(""))
                view.ivPINMore.setOnClickListener {
                    showMoreBottomSheetDialog(view.rlPIN, view.edtPINText,null)
                }

            /*----PhoneNumber-----*/
                view.rlNumber.visible()
                view.edtNumberText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].phoneNumber)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber, view.edtNumberText,null)
            }

            /*----Email-----*/
                view.rlEmail.visible()
                view.edtEmailText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].email)
            view.ivEmailMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlEmail, view.edtEmailText,null)
            }

            /*----Barcode-----*/
                view.rlBarcode.visible()
                view.edtBarcodeText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].barcode)
            view.ivBarcodeMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBarcode, view.edtBarcodeText,null)
            }

            /*----OtherName-----*/
                view.rlOtherNameView.visible()
                view.edtOtherNameText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].fullName)
                view.tvOtherName.text = "Full Name"
            view.ivOtherMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlOtherNameView, view.edtOtherNameText,null)
            }

            /*----URL-----*/
                view.rlURL.visible()
                view.edtURLText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].url)
            view.ivURLMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlURL, view.edtURLText,null)
            }

            /*----RegAddress-----*/
                view.rlAddress.visible()
                view.edtAddressText.text =
                    Editable.Factory.getInstance().newEditable(paymentData[0].address)

            view.ivAddressMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlAddress, view.edtAddressText,null)
            }
            binding.dynamicContainer.addView(view.root)
        }

    }
    private fun setBirthResultData() {
        if (birthData.size > 0) {
            isSoftDelete = birthData[0].isDelete
            isArchive = birthData[0].isArchive
            isFav = birthData[0].isFav


            dataID = birthData[0].id
            isLock = birthData[0].isSensitive
            frontImage = birthData[0].frontCardImage.toString()
            backImage = birthData[0].backCardImage.toString()
            title = birthData[0].title.toString()

            isSensitive = birthData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild
            /*----FullName-----*/
                view.rlNameView.visible()
                view.edtNameText.text =
                    Editable.Factory.getInstance().newEditable(birthData[0].fullName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }

            /*----DocumentNumber-----*/
                view.rlLicenceNumber.visible()
                view.edtLiNumberText.text =
                    Editable.Factory.getInstance().newEditable(birthData[0].documentNumber)
                view.tvLiNumber.text = "Document Number"
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null)
            }

            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text =
                    Editable.Factory.getInstance().newEditable(birthData[0].notes)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }


            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setGiftResultData() {

        if (giftData.size > 0) {
            isSoftDelete = giftData[0].isDelete
            isArchive = giftData[0].isArchive
            isFav = giftData[0].isFav

            dataID = giftData[0].id
            isLock = giftData[0].isSensitive
            frontImage = giftData[0].frontCardImage.toString()
            backImage = giftData[0].backCardImage.toString()
            title = giftData[0].title.toString()

            isSensitive = giftData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive


            mainChild = view.mainChild
            /*----CardNumber-----*/
                view.rlLicenceNumber.visible()
                view.edtLiNumberText.text =
                    Editable.Factory.getInstance().newEditable(giftData[0].cardNumber)
                view.tvLiNumber.text = getString(R.string.card_number)
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null)
            }

            /*----PIN-----*/
                view.rlPIN.visible()
                view.edtPINText.text = Editable.Factory.getInstance().newEditable(giftData[0].pin)
            view.ivPINMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPIN, view.edtPINText,null)
            }

            /*----Amount-----*/
                view.rlAmount.visible()
                view.edtAmountText.text =
                    Editable.Factory.getInstance().newEditable(giftData[0].amount)
            view.ivAmountMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlAmount, view.edtAmountText,null)
            }

            /*----barcode-----*/
                view.rlBarcode.visible()
                view.edtBarcodeText.text =
                    Editable.Factory.getInstance().newEditable(giftData[0].barcode)
            view.ivBarcodeMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBarcode, view.edtBarcodeText,null)
            }

            /*----brand-----*/
                view.rlBrand.visible()
                view.edtBrandText.text =
                    Editable.Factory.getInstance().newEditable(giftData[0].brand)
            view.ivBrandMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBrand, view.edtBrandText,null)
            }

            /*----IssueDate-----*/
                view.rlIssueDate.visible()
            if(giftData[0].issueDate.equals("null",ignoreCase = true)) { }else{

                view.tvIssueDateText.text = giftData[0].issueDate}
                view.tvIssueDateText.setOnClickListener {
                    showDatePicker(
                        giftData[0].issueDate,
                        view.tvIssueDateText
                    )
                }
            view.ivIssueDateMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlIssueDate, null,view.tvIssueDateText)
            }

            /*----ExpDate-----*/
                view.rlExpDate.visible()
            if(giftData[0].expDate.equals("null",ignoreCase = true)) { }else{

                view.tvExpDateText.text = giftData[0].expDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        giftData[0].expDate,
                        view.tvExpDateText
                    )
                }
            view.ivExpMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlExpDate, null,view.tvExpDateText)
            }

            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text =
                    Editable.Factory.getInstance().newEditable(giftData[0].notes)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }

            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setHealthResultData() {

        if (healthData.size > 0) {
            isSoftDelete = healthData[0].isDelete
            isArchive = healthData[0].isArchive
            isFav = healthData[0].isFav

            dataID = healthData[0].id
            isLock = healthData[0].isSensitive
            frontImage = healthData[0].frontCardImage.toString()
            backImage = healthData[0].backCardImage.toString()
            title = healthData[0].title.toString()

            isSensitive = healthData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild
            /*----FullName-----*/
                view.rlNameView.visible()
                view.edtNameText.text = Editable.Factory.getInstance().newEditable(healthData[0].fullName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }
            /*----DocumentNumber-----*/
                view.rlLicenceNumber.visible()
                view.tvLiNumber.text = "Document Number"
                view.edtLiNumberText.text =
                    Editable.Factory.getInstance().newEditable(healthData[0].documentNumber)
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null)
            }

            /*----ExpDate-----*/
                view.rlExpDate.visible()
            if(healthData[0].expiryDate.equals("null",ignoreCase = true)) { }else{
                view.tvExpDateText.text = healthData[0].expiryDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        healthData[0].expiryDate,
                        view.tvExpDateText
                    )
                }
            view.ivExpMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlExpDate,null,view.tvExpDateText)
            }

            /*----Phone Number-----*/
                view.rlNumber.visible()
                view.edtNumberText.text =
                    Editable.Factory.getInstance().newEditable(healthData[0].phoneNumber)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber, view.edtNumberText,null)
            }

            /*----Email-----*/
                view.rlEmail.visible()
                view.edtEmailText.text =
                    Editable.Factory.getInstance().newEditable(healthData[0].email)
            view.ivEmailMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlEmail, view.edtEmailText,null)
            }

            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text =
                    Editable.Factory.getInstance().newEditable(healthData[0].notes)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }

            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setLoyaltyResultData() {
        if (loyaltyData.size > 0) {
            isSoftDelete = loyaltyData[0].isDelete
            isArchive = loyaltyData[0].isArchive
            isFav = loyaltyData[0].isFav
            dataID = loyaltyData[0].id
            isLock = loyaltyData[0].isSensitive
            frontImage = loyaltyData[0].frontCardImage.toString()
            backImage = loyaltyData[0].backCardImage.toString()
            title = loyaltyData[0].title.toString()

            isSensitive = loyaltyData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive


            mainChild = view.mainChild
            /*----CardHolderName-----*/
                view.rlNameView.visible()
                view.edtNameText.text =
                    Editable.Factory.getInstance().newEditable(loyaltyData[0].cardHolderName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }

            /*----CardNumber-----*/
                view.rlLicenceNumber.visible()
                view.edtLiNumberText.text =
                    Editable.Factory.getInstance().newEditable(loyaltyData[0].cardNumber)
                view.tvLiNumber.text = getString(R.string.card_number)
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null)
            }

            /*----CardHolderNumber-----*/
                view.rlNumber.visible()
                view.edtNumberText.text =
                    Editable.Factory.getInstance().newEditable(loyaltyData[0].cardHolderNumber)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber, view.edtNumberText,null)
            }

            /*----Barcode-----*/
                view.rlBarcode.visible()
                view.edtBarcodeText.text =
                    Editable.Factory.getInstance().newEditable(loyaltyData[0].barcode)
            view.ivBarcodeMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBarcode, view.edtBarcodeText,null)
            }

            /*----Brand-----*/
                view.rlBrand.visible()
                view.edtBrandText.text =
                    Editable.Factory.getInstance().newEditable(loyaltyData[0].brand)
            view.ivBrandMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBarcode, view.edtBarcodeText,null)
            }

            /*----URL-----*/
                view.rlURL.visible()
                view.edtURLText.text =
                    Editable.Factory.getInstance().newEditable(loyaltyData[0].url)
            view.ivURLMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlURL, view.edtURLText,null)
            }


            /*----Login-----*/
                view.rlLogin.visible()
                view.edtLoginText.text =
                    Editable.Factory.getInstance().newEditable(loyaltyData[0].login)
            view.ivLoginMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLogin, view.edtLoginText,null)
            }

            /*----Password-----*/
                view.rlPassword.visible()
                view.edtPasswordText.text = Editable.Factory.getInstance()
                    .newEditable(loyaltyData[0].password.map { '*' }.joinToString(""))
            view.ivPasswordMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPassword, view.edtPasswordText,null)
            }


            /*----ExpDate-----*/
                view.rlExpDate.visible()
            if(loyaltyData[0].expDate.equals("null",ignoreCase = true)) { }else{

                view.tvExpDateText.text = loyaltyData[0].expDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        loyaltyData[0].expDate,
                        view.tvExpDateText
                    )
                }
            view.ivExpMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlExpDate, null,view.tvExpDateText)
            }


            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text =
                    Editable.Factory.getInstance().newEditable(loyaltyData[0].notes)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }


            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setMedicalResultData() {
        if (medicalData.size > 0) {

            isSoftDelete = medicalData[0].isDelete
            isArchive = medicalData[0].isArchive
            isFav = medicalData[0].isFav

            dataID = medicalData[0].id
            isLock = medicalData[0].isSensitive
            frontImage = medicalData[0].frontCardImage.toString()
            backImage = medicalData[0].backCardImage.toString()
            title = medicalData[0].title.toString()

            isSensitive = medicalData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild
            /*----DocumentNumber-----*/
                view.rlLicenceNumber.visible()
                view.edtLiNumberText.text = Editable.Factory.getInstance().newEditable(medicalData[0].documentNumber)
                view.tvLiNumber.text = getString(R.string.document_number)
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null)
            }

            /*----IssueDate-----*/
                view.rlExpDate.visible()
            if(medicalData[0].issueDate.equals("null",ignoreCase = true)) { }else{
                view.tvExpDateText.text = medicalData[0].issueDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        medicalData[0].expiryDate,
                        view.tvExpDateText
                    )
                }
            view.ivIssueDateMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlIssueDate, null,view.tvIssueDateText)
            }

            /*----ExpDate-----*/
                view.rlExpDate.visible()
            if(medicalData[0].expiryDate.equals("null",ignoreCase = true)) { }else{

                view.tvExpDateText.text = medicalData[0].expiryDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(medicalData[0].expiryDate, view.tvExpDateText)
                }

                view.tvExpDateText.setOnClickListener {
                    showDatePicker(medicalData[0].dob, view.tvExpDateText)
                }
            view.ivExpMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlExpDate, null,view.tvExpDateText)
            }

            /*----DOB-----*/
                view.rlDOBDate.visible()
            if(medicalData[0].dob.equals("null",ignoreCase = true)) { }else{
                view.tvDOBDateText.text = medicalData[0].dob}
                view.tvDOBDateText.setOnClickListener { showDatePicker(medicalData[0].dob, view.tvDOBDateText) }
            view.ivDOBDateMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlDOBDate, null,view.tvDOBDateText)
            }


            /*----Number-----*/
                view.rlNumber.visible()
                view.edtNumberText.text = Editable.Factory.getInstance().newEditable(medicalData[0].phoneNumber)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber, view.edtNumberText,null)
            }

            /*----Email-----*/
                view.rlEmail.visible()
                view.edtEmailText.text = Editable.Factory.getInstance().newEditable(medicalData[0].email)
            view.ivExpMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlEmail, view.edtEmailText,null)
            }

            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text = Editable.Factory.getInstance().newEditable(medicalData[0].notes)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }


            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setMemberShipResultData() {
        if (memberShipData.size > 0) {
            isSoftDelete = memberShipData[0].isDelete
            isArchive = memberShipData[0].isArchive
            isFav = memberShipData[0].isFav
            dataID = memberShipData[0].id
            isLock = memberShipData[0].isSensitive
            frontImage = memberShipData[0].frontCardImage.toString()
            backImage = memberShipData[0].backCardImage.toString()
            title = memberShipData[0].title.toString()

            isSensitive = memberShipData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild

            /*----CardHolderName-----*/
                view.rlNameView.visible()
                view.edtNameText.text = Editable.Factory.getInstance().newEditable(memberShipData[0].cardHolderName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }

            /*----CardHolderNumber-----*/
                view.rlNumber.visible()
                view.edtNumberText.text = Editable.Factory.getInstance().newEditable(memberShipData[0].cardHolderNumber)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber, view.edtNumberText,null)
            }

            /*----Barcode-----*/
                view.rlBarcode.visible()
                view.edtBarcodeText.text = Editable.Factory.getInstance().newEditable(memberShipData[0].barcode)
            view.ivBarcodeMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBarcode, view.edtBarcodeText,null)
            }

            /*----Login-----*/
                view.rlLogin.visible()
                view.edtLoginText.text = Editable.Factory.getInstance().newEditable(memberShipData[0].login)
            view.ivLoginMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLogin, view.edtLoginText,null)
            }

            /*----Password-----*/
                view.rlPassword.visible()
                view.edtPasswordText.text = Editable.Factory.getInstance().newEditable(memberShipData[0].password.map { '*' }.joinToString(""))

            view.ivPasswordMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPassword, view.edtPasswordText,null)
            }

            /*----URL-----*/
                view.rlURL.visible()
                view.edtURLText.text = Editable.Factory.getInstance().newEditable(memberShipData[0].url)
            view.ivURLMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlURL, view.edtURLText,null)
            }


            /*----ExpDate-----*/
                view.rlExpDate.visible()
            if(memberShipData[0].expDate.equals("null",ignoreCase = true)) { }else{
                view.tvExpDateText.text = memberShipData[0].expDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        memberShipData[0].expDate,
                        view.tvExpDateText
                    )
                }
            view.ivExpMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlExpDate, null,view.tvExpDateText)
            }

            /*----Brand-----*/
                view.rlBrand.visible()
                view.edtBrandText.text =
                    Editable.Factory.getInstance().newEditable(memberShipData[0].brand)
            view.ivBrandMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBrand, view.edtBrandText,null)
            }

            /*----MemberSince-----*/
                view.rlMemberSince.visible()
                view.edtMemberSinceText.text =
                    Editable.Factory.getInstance().newEditable(memberShipData[0].memberSince)
            view.ivMemberSinceMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlMemberSince, view.edtMemberSinceText,null)
            }

            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text =
                    Editable.Factory.getInstance().newEditable(memberShipData[0].notes)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }

            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setMrgResultData() {
        if (mrgData.size > 0) {

            isSoftDelete = mrgData[0].isDelete
            isArchive = mrgData[0].isArchive
            isFav = mrgData[0].isFav

            dataID = mrgData[0].id
            isLock = mrgData[0].isSensitive
            frontImage = mrgData[0].frontCardImage.toString()
            backImage = mrgData[0].backCardImage.toString()
            title = mrgData[0].title.toString()

            isSensitive = mrgData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild

            /*----name-----*/
            view.rlNameView.visible()
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(mrgData[0].spouseName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }

            /*----date-----*/
            view.rlDOBDate.visible()
            view.tvDOBDate.text= getString(R.string.marriage_date)
            if(mrgData[0].mrgDate.equals("null",ignoreCase = true)) { }else{
            view.tvDOBDateText.text = Editable.Factory.getInstance().newEditable(mrgData[0].mrgDate)}
            view.ivDOBDateMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlDOBDate, null,view.tvDOBDateText)
            }

            /*----notes-----*/
            view.rlNotes.visible()
            view.edtNotesText.text = Editable.Factory.getInstance().newEditable(mrgData[0].notes)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }

            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setPasswordResultData() {
        if (passwordData.size > 0) {

            isSoftDelete = passwordData[0].isDelete
            isArchive = passwordData[0].isArchive
            isFav = passwordData[0].isFav

            dataID = passwordData[0].id
            isLock = passwordData[0].isSensitive
            frontImage = passwordData[0].frontCardImage.toString()
            backImage = passwordData[0].backCardImage.toString()
            title = passwordData[0].title.toString()

            isSensitive = passwordData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild
            /*----Name-----*/
                view.rlNameView.visible()
                view.edtNameText.text = Editable.Factory.getInstance().newEditable(passwordData[0].Name)
                view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
               }

            /*----URL-----*/
                view.rlURL.visible()
                view.edtURLText.text = Editable.Factory.getInstance().newEditable(passwordData[0].url)
            view.ivURLMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlURL, view.edtURLText,null)
            }

            /*----Login-----*/
                view.rlLogin.visible()
                view.edtLoginText.text = Editable.Factory.getInstance().newEditable(passwordData[0].login)
                view.ivLoginMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLogin, view.edtLoginText,null)
            }

            /*----Password-----*/
                view.rlPassword.visible()
                view.edtPasswordText.text = Editable.Factory.getInstance().newEditable(passwordData[0].password.map { '*' }.joinToString(""))
                view.ivPasswordMore.visible()
                view.ivPasswordMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPassword, view.edtPasswordText,null)
            }

            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text =  Editable.Factory.getInstance().newEditable(passwordData[0].notes)
                view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }

            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setSIMResultData() {
        if (simData.size > 0) {
            isSoftDelete = simData[0].isDelete
            isArchive = simData[0].isArchive
            isFav = simData[0].isFav
            dataID = simData[0].id
            isLock = simData[0].isSensitive
            frontImage = simData[0].frontCardImage.toString()
            backImage = simData[0].backCardImage.toString()
            title = simData[0].title.toString()
            isSensitive = simData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive


            mainChild = view.mainChild
            /*----OwnerName-----*/
            view.rlNameView.visible()
            view.tvName.text = Editable.Factory.getInstance().newEditable(getString(R.string.owner_name))
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(simData[0].ownerName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }

            /*----PhoneNumber-----*/
            view.rlNumber.visible()
            view.edtNumberText.text = Editable.Factory.getInstance().newEditable(simData[0].phoneNumber)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber, view.edtNumberText,null)
            }

            /*----PIN-----*/
                view.rlPIN.visible()
                view.edtPINText.text = Editable.Factory.getInstance().newEditable(simData[0].pin.map { '*' }.joinToString(""))
                 view.ivPINMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPIN, view.edtPINText,null)
              }

            /*----PUK-----*/
                view.rlPUK.visible()
                view.edtPUKText.text = Editable.Factory.getInstance().newEditable(simData[0].puk)
            view.ivPUKMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPUK, view.edtPUKText,null)
            }

            /*----Country-----*/
                view.rlCountry.visible()
                view.edtCountryText.text = Editable.Factory.getInstance().newEditable(simData[0].country)
            view.ivCountryMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlCountry, view.edtCustomText,null)
            }

            /*----Operator-----*/
                view.rlMoOperator.visible()
                view.edtMoOperatorText.text = Editable.Factory.getInstance().newEditable(simData[0].operator)
            view.ivMoOperatorMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlMoOperator, view.edtMoOperatorText,null)
            }


            /*----notes-----*/
                view.rlNotes.visible()
                view.edtNotesText.text = Editable.Factory.getInstance().newEditable(simData[0].notes)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }

            binding.dynamicContainer.addView(view.root)
        }
    }
    private fun setCustomResultData() {
        if (customData.size > 0) {
            isSoftDelete = customData[0].isDelete
            isArchive = customData[0].isArchive
            isFav = customData[0].isFav
            dataID = customData[0].id
            isLock = customData[0].isSensitive
            frontImage = customData[0].frontCardImage.toString()
            backImage = customData[0].backCardImage.toString()
            title = customData[0].title.toString()

            isSensitive = customData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild

            /*----FullName-----*/
            view.rlNameView.visible()
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(customData[0].fullName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }

            /*----PhoneNumber-----*/
            view.rlPersonalNo.visible()
            view.edtPersonalNoText.text = Editable.Factory.getInstance().newEditable(customData[0].phoneNumber)
            view.ivPersonalNoMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPersonalNo, view.edtPersonalNoText,null)
            }

            /*----Number-----*/
            view.rlNumber.visible()
            view.edtNumberText.text = Editable.Factory.getInstance().newEditable(customData[0].number)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber, view.edtNumberText,null)
            }

            /*----CardNumber-----*/
            view.rlLicenceNumber.visible()
                view.edtLiNumberText.text = Editable.Factory.getInstance().newEditable(customData[0].cardNumber.map { '*' }.joinToString(""))
                view.tvLiNumber.text = getString(R.string.card_number)
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber, null, view.tvLiNumber)
            }


            /*----ExpDate-----*/
            view.rlExpDate.visible()
            if(customData[0].expDate.equals("null",ignoreCase = true)) { }else{
                view.tvExpDateText.text = customData[0].expDate}
                view.tvExpDateText.setOnClickListener {
                    showDatePicker(
                        customData[0].expDate,
                        view.tvExpDateText
                    )
                }
            view.ivExpMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlExpDate, null, view.tvExpDateText)
            }

            /*----Address-----*/
            view.rlAddress.visible()
            view.edtAddressText.text = Editable.Factory.getInstance().newEditable(customData[0].address)
            view.ivAddressMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlAddress, view.edtAddressText, null)
            }

            /*----Barcode-----*/
            view.rlBarcode.visible()
            view.edtBarcodeText.text = Editable.Factory.getInstance().newEditable(customData[0].barcode)
            view.ivBarcodeMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBarcode, view.edtBarcodeText, null)
            }


            /*----Date-----*/
            view.rlDOBDate.visible()
            if(customData[0].date.equals("null",ignoreCase = true)) { }else{
                view.tvDOBDateText.text = customData[0].date}
                view.tvDOBDateText.setOnClickListener {
                    showDatePicker(
                        customData[0].date,
                        view.tvDOBDateText
                    )
                }
            view.ivDOBDateMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlDOBDate, null,view.tvDOBDateText)
            }

            /*----Email-----*/
            view.rlEmail.visible()
            view.edtEmailText.text = Editable.Factory.getInstance().newEditable(customData[0].email)
            view.ivEmailMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlEmail, null,view.edtEmailText)
            }

            /*----Text-----*/
            view.rlText.visible()
                view.edtTextText.text = Editable.Factory.getInstance().newEditable(customData[0].text)
            view.ivTextMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlText, null,view.edtTextText)
            }


            /*----URI-----*/
            view.rlURL.visible()
            view.edtURLText.text = Editable.Factory.getInstance().newEditable(customData[0].url)
            view.ivURLMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlURL, null,view.edtURLText)
            }

            /*----Notes-----*/
            view.rlNotes.visible()
            view.edtNotesText.text = Editable.Factory.getInstance().newEditable(customData[0].note)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, null,view.edtNotesText)
            }
            binding.dynamicContainer.addView(view.root)

        }
    }

    private fun setPANResultData() {
        if (panData.size > 0) {
            isSoftDelete = panData[0].isDelete
            isArchive = panData[0].isArchive
            isFav = panData[0].isFav
            dataID = panData[0].id
            isLock = panData[0].isSensitive
            frontImage = panData[0].frontCardImage.toString()
            backImage = panData[0].backCardImage.toString()
            title = panData[0].title.toString()

            isSensitive = panData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild

            /*----FullName-----*/
            view.rlNameView.visible()
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(panData[0].fullName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }

            /*----ParentsName-----*/
            view.rlParents.visible()
            view.edtParentsText.text = Editable.Factory.getInstance().newEditable(panData[0].parentsName)
            view.ivParentsMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlParents, view.edtParentsText,null)
            }

            /*----CardNumber-----*/
            view.rlLicenceNumber.visible()
                view.edtLiNumberText.text = Editable.Factory.getInstance()
                    .newEditable(panData[0].cardNumber.map { '*' }.joinToString(""))
                view.tvLiNumber.text = getString(R.string.card_number)
                view.ivLiNumberMore.setOnClickListener {
                    showMoreBottomSheetDialog(view.rlLicenceNumber,  view.edtLiNumberText,null)
                }

            /*----Date-----*/
            view.rlDOBDate.visible()
            if(panData[0].dob.equals("null",ignoreCase = true)) { }else{
                view.tvDOBDateText.text = panData[0].dob}
                view.tvDOBDateText.setOnClickListener {
                    showDatePicker(
                        panData[0].dob,
                        view.tvDOBDateText
                    )
                }
            view.ivDOBDateMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlDOBDate, null, view.tvDOBDateText)
            }

            /*----notes-----*/
            view.rlNotes.visible()
            view.edtNotesText.text = Editable.Factory.getInstance().newEditable(panData[0].note)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes, view.edtNotesText,null)
            }
            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setVoterResultData() {
        if (voterData.size > 0) {
            isSoftDelete = voterData[0].isDelete
            isArchive = voterData[0].isArchive
            isFav = voterData[0].isFav
            dataID = voterData[0].id
            isLock = voterData[0].isSensitive
            frontImage = voterData[0].frontCardImage.toString()
            backImage = voterData[0].backCardImage.toString()
            title = voterData[0].title.toString()
            isSensitive = voterData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive


            mainChild = view.mainChild

            /*----FullName-----*/
            view.rlNameView.visible()
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(voterData[0].fullName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView, view.edtNameText,null)
            }

            /*----PhoneNumber-----*/
            view.rlPersonalNo.visible()
            view.edtPersonalNoText.text = Editable.Factory.getInstance().newEditable(voterData[0].phoneNumber)
            view.ivPersonalNoMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPersonalNo, view.edtPersonalNoText,null)
            }

            /*----Number-----*/
            view.rlNumber.visible()
            view.edtNumberText.text = Editable.Factory.getInstance().newEditable(voterData[0].phoneNumber)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber, view.edtNumberText,null)
            }

            /*----CardNumber-----*/
            view.rlLicenceNumber.visible()
            view.edtLiNumberText.text = Editable.Factory.getInstance()
                .newEditable(voterData[0].cardNumber.map { '*' }.joinToString(""))
            view.tvLiNumber.text = getString(R.string.id_number)
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber, view.edtLiNumberText,null)
            }


            /*----Address-----*/
            view.rlAddress.visible()
            view.edtAddressText.text = Editable.Factory.getInstance().newEditable(voterData[0].address)
            view.ivAddressMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlAddress, view.edtAddressText,null)
            }


            /*----Barcode-----*/view.rlBarcode.visible()
            view.edtBarcodeText.text = Editable.Factory.getInstance().newEditable(voterData[0].barcode)
            view.ivBarcodeMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlBarcode,view.edtBarcodeText,null)
            }

            /*----Date-----*/view.rlDOBDate.visible()
            if(voterData[0].dob.equals("null",ignoreCase = true)) { }else{
            view.tvDOBDateText.text = voterData[0].dob}
            view.tvDOBDateText.setOnClickListener {
                showDatePicker(
                    voterData[0].dob,
                    view.tvDOBDateText
                )
            }
            view.ivDOBDateMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlDOBDate,null, view.tvDOBDateText)
            }

            /*----Email-----*/
            view.rlEmail.visible()
            view.edtEmailText.text = Editable.Factory.getInstance().newEditable(voterData[0].email)
            view.ivEmailMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlEmail,view.edtEmailText,null)
            }

            /*----Text-----*/
            view.rlParents.visible()
            view.edtParentsText.text = Editable.Factory.getInstance().newEditable(voterData[0].parentsName)
            view.ivParentsMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlParents,view.edtParentsText,null)
            }

            /*----URI-----*/
            view.rlURL.visible()
            view.edtURLText.text = Editable.Factory.getInstance().newEditable(voterData[0].url)
            view.ivURLMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlURL,view.edtURLText,null)
            }

            /*----notes-----*/
            view.rlNotes.visible()
            view.edtNotesText.text = Editable.Factory.getInstance().newEditable(voterData[0].note)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes,view.edtNotesText,null)
            }

            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setAdharResultData() {
        if (adharData.size > 0) {
            isSoftDelete = adharData[0].isDelete
            isArchive = adharData[0].isArchive
            isFav = adharData[0].isFav
            dataID = adharData[0].id
            isLock = adharData[0].isSensitive
            frontImage = adharData[0].frontCardImage.toString()
            backImage = adharData[0].backCardImage.toString()
            title = adharData[0].title.toString()

            isSensitive = adharData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild

            /*----FullName-----*/
            view.rlNameView.visible()
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(adharData[0].fullName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView,view.edtNameText,null)
            }

            /*----AadhaarNo-----*/
            view.rlLicenceNumber.visible()
            view.tvLiNumber.text = getString(R.string.aadhaar_no)
            view.edtLiNumberText.text = Editable.Factory.getInstance().newEditable(adharData[0].adharNo.map { '*' }.joinToString(""))
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber,view.edtLiNumberText,null)
            }

            /*----PhoneNumber-----*/
            view.rlPersonalNo.visible()
            view.edtPersonalNoText.text = Editable.Factory.getInstance().newEditable(adharData[0].phoneNumber)
            view.ivPersonalNoMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPersonalNo,view.edtPersonalNoText,null)
            }

            /*----DOB-----*/
            view.rlDOBDate.visible()
            if(adharData[0].dob.equals("null",ignoreCase = true)) { }else{
            view.tvDOBDateText.text = adharData[0].dob}
            view.tvDOBDateText.setOnClickListener {
                showDatePicker(
                    adharData[0].dob,
                    view.tvDOBDateText
                )
            }
            view.ivDOBDateMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPersonalNo,null,view.tvDOBDateText)
            }

            /*----Email-----*/
            view.rlEmail.visible()
            view.edtEmailText.text = Editable.Factory.getInstance().newEditable(adharData[0].email)
            view.ivEmailMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlEmail,view.edtEmailText,null)
            }

            /*----URI-----*/
            view.rlURL.visible()
            view.edtURLText.text = Editable.Factory.getInstance().newEditable(adharData[0].url)
            view.ivURLMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlURL,view.edtURLText,null)
            }

            /*----Address-----*/
            view.rlAddress.visible()
            view.edtAddressText.text = Editable.Factory.getInstance().newEditable(adharData[0].address)
            view.ivAddressMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlAddress,view.edtAddressText,null)
            }

            /*----Gender-----*/
            view.rlGender.visible()
            view.edtGenderText.text = Editable.Factory.getInstance().newEditable(adharData[0].gender)
            view.ivGenderMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlGender,view.edtGenderText,null)
            }

            /*----notes-----*/
            view.rlNotes.visible()
            view.edtNotesText.text = Editable.Factory.getInstance().newEditable(adharData[0].note)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes,view.edtNotesText,null)
            }
            binding.dynamicContainer.addView(view.root)

        }
    }
    private fun setVehicalResultData() {
        if (vehicalData.size > 0) {
            isSoftDelete = vehicalData[0].isDelete
            isArchive = vehicalData[0].isArchive
            isFav = vehicalData[0].isFav
            dataID = vehicalData[0].id
            isLock = vehicalData[0].isSensitive
            frontImage = vehicalData[0].frontCardImage.toString()
            backImage = vehicalData[0].backCardImage.toString()
            title = vehicalData[0].title.toString()

            isSensitive = vehicalData[0].isSensitive
            binding.switchSensitive.isChecked = isSensitive

            mainChild = view.mainChild

            /*----FullName-----*/
            view.rlNameView.visible()
            view.edtNameText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].fullName)
            view.ivNameMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNameView,view.edtNameText,null)
            }

            /*----PhoneNumber-----*/
            view.rlPersonalNo.visible()
            view.edtPersonalNoText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].phoneNumber)
            view.ivPersonalNoMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlPersonalNo,view.edtPasswordText,null)
            }

            /*----Number-----*/
            view.rlNumber.visible()
            view.edtNumberText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].cardNumber)
            view.ivNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNumber,view.edtNumberText,null)
            }

            /*----CardNumber-----*/
            view.rlLicenceNumber.visible()
            view.edtLiNumberText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].cardNumber.map { '*' }.joinToString(""))
            view.tvLiNumber.text = "Licence Number"
            view.ivLiNumberMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlLicenceNumber,view.edtLiNumberText,null)
            }

            /*----Address-----*/
            view.rlAddress.visible()
            view.edtAddressText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].address)
            view.ivAddressMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlAddress,view.edtAddressText,null)
            }

            /*----Date-----*/
            view.rlExpDate.visible()
            if(vehicalData[0].expDate.equals("null",ignoreCase = true)) { }else{
            view.tvExpDateText.text = vehicalData[0].expDate}
            view.tvExpDateText.setOnClickListener {
                showDatePicker(
                    vehicalData[0].date,
                    view.tvDOBDateText
                )
            }
            view.ivExpMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlExpDate,null,view.tvExpDateText)
            }

            /*----Email-----*/
            view.rlEmail.visible()
            view.edtEmailText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].email)
            view.ivEmailMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlEmail,view.edtEmailText,null)
            }

            /*----Text-----*/
            view.rlText.visible()
            view.edtTextText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].text)
            view.ivTextMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlText,view.edtTextText,null)
            }

            /*----URI-----*/
            view.rlURL.visible()
            view.edtURLText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].url)
            view.ivURLMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlURL,view.edtURLText,null)
            }

            /*----notes-----*/
            view.rlNotes.visible()
            view.edtNotesText.text = Editable.Factory.getInstance().newEditable(vehicalData[0].note)
            view.ivNotesMore.setOnClickListener {
                showMoreBottomSheetDialog(view.rlNotes,view.edtNotesText,null)
            }

            binding.dynamicContainer.addView(view.root)

        }
    }

    private fun clearAllData() {
        licenceData.clear()
        passportData.clear()
        idData.clear()
        residenceData.clear()
        paymentData.clear()
        giftData.clear()
        loyaltyData.clear()
        memberShipData.clear()
        medicalData.clear()
        healthData.clear()
        birthData.clear()
        mrgData.clear()
        simData.clear()
        passwordData.clear()
        customData.clear()
        vehicalData.clear()
        voterData.clear()
        adharData.clear()
        panData.clear()
    }

    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    fun onBackClick(view: View)
    {
        if (isFromScan) {
            eraseData(categoryID, dataID)
        } else {
            AdsInterstitial.instance?.showInterstitialAd(
                this@EditCardActivityManiya,
                false,
                object : AdsInterstitial.adfinish {
                    override fun adfinished() {
                        returnResult()
                    }
                })
        }
    }

    fun onClickAddField(view: View) {}

    private fun softDeleteData(catID: Long, itemID: Long) {
        LogD("Delete+++", itemID.toString())
        when (catID) {
            1L -> DatabaseHelperManiya(this).softLicenceDelete(itemID)
            2L -> DatabaseHelperManiya(this).softPassportDelete(itemID)
            3L ->  DatabaseHelperManiya(this).softIDCardDelete(itemID)
            4L -> DatabaseHelperManiya(this).softResidenceDelete(itemID)
            5L ->  DatabaseHelperManiya(this).softPaymentDelete(itemID)
            6L ->  DatabaseHelperManiya(this).softGiftDelete(itemID)
            7L -> DatabaseHelperManiya(this).softLoyaltyDelete(itemID)
            8L ->  DatabaseHelperManiya(this).softMembershipDelete(itemID)
            9L -> DatabaseHelperManiya(this).softMedicalDelete(itemID)
            10L ->  DatabaseHelperManiya(this).softHealthDelete(itemID)
            11L -> DatabaseHelperManiya(this).softBirthDelete(itemID)
            12L -> DatabaseHelperManiya(this).softMrgDelete(itemID)
            13L ->  DatabaseHelperManiya(this).softSIMDelete(itemID)
            14L -> DatabaseHelperManiya(this).softPasswordDelete(itemID)
            15L ->  DatabaseHelperManiya(this).softCustomDelete(itemID)
            16L -> DatabaseHelperManiya(this).softVehicleDelete(itemID)
            17L ->  DatabaseHelperManiya(this).softAdharDelete(itemID)
            18L ->  DatabaseHelperManiya(this).softVoterDelete(itemID)
            19L -> DatabaseHelperManiya(this).softPANDelete(itemID)

        }
        returnResult()

    }

    private fun eraseData(catID: Long, itemID: Long) {
        LogD("Delete+++", itemID.toString())
        when (catID) {
            1L -> DatabaseHelperManiya(this).licenceDelete(itemID)
            2L -> DatabaseHelperManiya(this).passportDelete(itemID)
            3L -> DatabaseHelperManiya(this).idCardDelete(itemID)
            4L -> DatabaseHelperManiya(this).residenceDelete(itemID)
            5L -> DatabaseHelperManiya(this).paymentDelete(itemID)
            6L -> DatabaseHelperManiya(this).giftDelete(itemID)
            7L -> DatabaseHelperManiya(this).loyaltyDelete(itemID)
            8L -> DatabaseHelperManiya(this).membershipDelete(itemID)
            9L -> DatabaseHelperManiya(this).medicalDelete(itemID)
            10L -> DatabaseHelperManiya(this).healthDelete(itemID)
            11L -> DatabaseHelperManiya(this).birthDelete(itemID)
            12L -> DatabaseHelperManiya(this).mrgDelete(itemID)
            13L -> DatabaseHelperManiya(this).simDelete(itemID)
            14L -> DatabaseHelperManiya(this).passwordDelete(itemID)
            15L -> DatabaseHelperManiya(this).customDelete(itemID)
            16L -> DatabaseHelperManiya(this).vehicleDelete(itemID)
            17L -> DatabaseHelperManiya(this).adharDelete(itemID)
            18L -> DatabaseHelperManiya(this).voterDelete(itemID)
            19L -> DatabaseHelperManiya(this).panDelete(itemID)
        }
        returnResult()
    }

    fun onClickDeleteField(view: View) {
        softDeleteData(categoryID, dataID)
    }

    fun onSaveClick(view: View) {
        saveEditedData()
    }

    fun onClickPhotos(view: View) {
        activityResultLauncher.launch(
            Intent(this@EditCardActivityManiya, PhotoAddViewActivityManiya::class.java)
                .putExtra("frontImage", frontImage)
                .putExtra("backIMage", backImage)
                .putExtra("title", currentCategory)

        )
    }

    fun onClickAppearance(view: View) {
        activityResultLauncher.launch(
            Intent(this@EditCardActivityManiya, AppreanceCardActivityManiya::class.java)
                .putExtra("appreanceColor", appreanceColor)
                .putExtra("categoryID", categoryID)
        )
    }


    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }

    fun parseDate(dateString: String): String {
        val dateFormats = arrayOf(
            "MM/dd/yyyy",
            "dd/MM/yyyy",
            "yyyy/MM/dd",
            "MM/dd/yy",
            "yyyy-MM-dd",
            "MM-dd-yyyy",
            "dd-MM-yyyy",
            "M-dd-yyyy",
            "yyyy.MM.dd",
            "dd.MM.yyyy",
            "MM.dd.yyyy",
            "MM-yy",
            "MM/yyyy",
            "MM/yy"
        )

        for (format in dateFormats) {
            try {
                val sdf = SimpleDateFormat(format, Locale.getDefault())
                val date = sdf.parse(dateString)
                if (date != null) {
                    if (format.contains("MM/yyyy") || format.contains("MM-yy") || format.contains("MM/yy")) {
                        return "Month-Year"
                    } else {
                        return "Day-Month-Year"
                    }
                }
            } catch (e: Exception) {

            }
        }

        return "Invalid"
    }

    fun showDatePicker(dateString: String, dateView: TextView) {
        val calendar = Calendar.getInstance()
        if (dateString.isNotEmpty()) {
            val dateFormatType = parseDate(dateString)
            when (dateFormatType) {
                "Month-Year" -> { /*---Show Month-Year Picker Dialog----*/
                    val datePickerDialog = DatePickerDialog(
                        this@EditCardActivityManiya,
                        { _, year, month, _ ->
                            dateView.text = "${month + 1}/$year"
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                    )

                    // Hide the day picker to make it a Month-Year picker
                    datePickerDialog.datePicker.findViewById<View>(
                        resources.getIdentifier("day", "id", "android")
                    )?.gone()

                    datePickerDialog.show()
                }

                "Day-Month-Year" -> {  /*-------Show Day-Month-Year Picker Dialog--------*/
                    val datePickerDialog = DatePickerDialog(
                        this@EditCardActivityManiya,
                        { _, year, month, dayOfMonth ->
                            dateView.text =
                                String.format("%02d-%02d-%d", dayOfMonth, month + 1, year)
                        },
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)
                    )

                    datePickerDialog.show()
                }

                else -> {
                    //  Toast.makeText(this, "Invalid date format", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            val datePickerDialog = DatePickerDialog(
                this@EditCardActivityManiya,
                { _, year, month, dayOfMonth ->
                    dateView.text = String.format("%02d-%02d-%d", dayOfMonth, month + 1, year)
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            )

            datePickerDialog.show()
        }
    }

    fun showMoreBottomSheetDialog(parentView: RelativeLayout, editView: EditText ?,textView: TextView ?) {
        var bottomSheetDialog = BottomSheetDialog(this@EditCardActivityManiya)
        val binding = FieldMoreBottomDialogBinding.inflate(bottomSheetDialog.layoutInflater)
        bottomSheetDialog.setContentView(binding.root)

        binding.root.setBackgroundResource(R.drawable.bottom_sheet_background)

        binding.tvTitle.text = editView?.text
        binding.tvTitle.text = textView?.text
        binding.llUnpin.gone()
        binding.llSettings.gone()
        binding.llDuplicate.gone()

        binding.llDelete.setOnClickListener {
            parentView.gone()
            if(editView!=null) editView?.text = Editable.Factory.getInstance().newEditable("")
            if(textView!=null) textView?.text = Editable.Factory.getInstance().newEditable("")
            bottomSheetDialog.dismiss()
        }

        bottomSheetDialog.show()
    }

}




