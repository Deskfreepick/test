package com.deep.infotech.atm_card_wallet.Ads

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.App_Open
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.app_open_show_ads
import com.google.android.gms.tasks.Task
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings
import com.google.firebase.remoteconfig.ktx.get

class ConfigManager(private val context: Context) {

    private val firebaseRemoteConfig = FirebaseRemoteConfig.getInstance()
    private val sharedPreferences: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun isDataDifferentFromFirebase(): Boolean {

        val conditions = listOf(
            (sharedPreferences.getBoolean(
                "first_interstitial_show", false
            ) != firebaseRemoteConfig.getBoolean("first_interstitial_show")),

            sharedPreferences.getBoolean(
                "fb_show_interstitial", false
            ) != firebaseRemoteConfig.getBoolean("fb_show_interstitial"),

            sharedPreferences.getBoolean(
                "interstitial_rotated_ad_network", false
            ) != firebaseRemoteConfig.getBoolean("interstitial_rotated_ad_network"),

            sharedPreferences.getBoolean(
                "show_dialog", false
            ) != firebaseRemoteConfig.getBoolean("show_dialog"),

            sharedPreferences.getBoolean(
                "start_screen_show", false
            ) != firebaseRemoteConfig.getBoolean("start_screen_show"),

            sharedPreferences.getBoolean(
                "show_second_interstitial", false
            ) != firebaseRemoteConfig.getBoolean("show_second_interstitial"),

            sharedPreferences.getBoolean(
                "show_third_interstitial", false
            ) != firebaseRemoteConfig.getBoolean("show_third_interstitial"),

            sharedPreferences.getBoolean(
                "app_open_repeat_show", false
            ) != firebaseRemoteConfig.getBoolean("app_open_repeat_show"),

            sharedPreferences.getString(
                "interstitial_first_choice_network", ""
            ) != firebaseRemoteConfig.getString("interstitial_first_choice_network"),

            sharedPreferences.getLong(
                "default_count", 0
            ) != firebaseRemoteConfig.getLong("default_count"),

            sharedPreferences.getLong("count", 0) != firebaseRemoteConfig.getLong("count"),

            sharedPreferences.getString(
                "app_open", ""
            ) != firebaseRemoteConfig.getString("app_open"),

            sharedPreferences.getString(
                "app_open_1", ""
            ) != firebaseRemoteConfig.getString("app_open_1"),

            sharedPreferences.getBoolean(
                "app_open_show_ads", false
            ) != firebaseRemoteConfig.getBoolean("app_open_show_ads"),

            sharedPreferences.getString(
                "interstitial", ""
            ) != firebaseRemoteConfig.getString("interstitial"),

            sharedPreferences.getString(
                "interstitial1", ""
            ) != firebaseRemoteConfig.getString("interstitial1"),

            sharedPreferences.getString(
                "interstitial2", ""
            ) != firebaseRemoteConfig.getString("interstitial2"),

            sharedPreferences.getString(
                "re_interstitial", ""
            ) != firebaseRemoteConfig.getString("re_interstitial"),

            sharedPreferences.getString(
                "fb_interstitial", ""
            ) != firebaseRemoteConfig.getString("fb_interstitial"),

            sharedPreferences.getString("re_interstitial1", "") != firebaseRemoteConfig.getString("re_interstitial1"),

            sharedPreferences.getString(
                "re_interstitial2", ""
            ) != firebaseRemoteConfig.getString("re_interstitial2"),

            sharedPreferences.getString(
                "fb_interstitial1", ""
            ) != firebaseRemoteConfig.getString("fb_interstitial1"),

            sharedPreferences.getString(
                "fb_interstitial2", ""
            ) != firebaseRemoteConfig.getString("fb_interstitial2"),

            sharedPreferences.getString(
                "native_ad_first_choice_network", ""
            ) != firebaseRemoteConfig.getString("native_ad_first_choice_network"),

            sharedPreferences.getBoolean(
                "native_rotated_ad_network", false
            ) != firebaseRemoteConfig.getBoolean("native_rotated_ad_network"),

            sharedPreferences.getBoolean(
                "start_show_native", false
            ) != firebaseRemoteConfig.getBoolean("start_show_native"),

            sharedPreferences.getBoolean(
                "second_ad_show_native", false
            ) != firebaseRemoteConfig.getBoolean("second_ad_show_native"),

            sharedPreferences.getBoolean(
                "third_ad_show_native", false
            ) != firebaseRemoteConfig.getBoolean("third_ad_show_native"),

            sharedPreferences.getBoolean(
                "fb_show_native", false
            ) != firebaseRemoteConfig.getBoolean("fb_show_native"),

            sharedPreferences.getString("native", "") != firebaseRemoteConfig.getString("native"),

            sharedPreferences.getString("native1", "") != firebaseRemoteConfig.getString("native1"),

            sharedPreferences.getString("native2", "") != firebaseRemoteConfig.getString("native2"),

            sharedPreferences.getString(
                "re_native", ""
            ) != firebaseRemoteConfig.getString("re_native"),

            sharedPreferences.getString(
                "re_native1", ""
            ) != firebaseRemoteConfig.getString("re_native1"),

            sharedPreferences.getString(
                "re_native2", ""
            ) != firebaseRemoteConfig.getString("re_native2"),

            sharedPreferences.getString(
                "fb_native", ""
            ) != firebaseRemoteConfig.getString("fb_native"),

            sharedPreferences.getString(
                "fb_native1", ""
            ) != firebaseRemoteConfig.getString("fb_native1"),

            sharedPreferences.getString(
                "fb_native2", ""
            ) != firebaseRemoteConfig.getString("fb_native2"),

            sharedPreferences.getBoolean(
                "banner_rotated_ad_network", false
            ) != firebaseRemoteConfig.getBoolean("banner_rotated_ad_network"),

            sharedPreferences.getBoolean(
                "start_show_banner", false
            ) != firebaseRemoteConfig.getBoolean("start_show_banner"),

            sharedPreferences.getBoolean(
                "second_ad_show_banner", false
            ) != firebaseRemoteConfig.getBoolean("second_ad_show_banner"),

            sharedPreferences.getBoolean(
                "third_ad_show_banner", false
            ) != firebaseRemoteConfig.getBoolean("third_ad_show_banner"),

            sharedPreferences.getString(
                "banner_ad_first_choice_network", ""
            ) != firebaseRemoteConfig.getString("banner_ad_first_choice_network"),

            sharedPreferences.getString("banner", "") != firebaseRemoteConfig.getString("banner"),

            sharedPreferences.getString("banner1", "") != firebaseRemoteConfig.getString("banner1"),

            sharedPreferences.getString("banner2", "") != firebaseRemoteConfig.getString("banner2"),

            sharedPreferences.getString(
                "re_banner", ""
            ) != firebaseRemoteConfig.getString("re_banner"),

            sharedPreferences.getString(
                "re_banner1", ""
            ) != firebaseRemoteConfig.getString("re_banner1"),

            sharedPreferences.getString(
                "re_banner2", ""
            ) != firebaseRemoteConfig.getString("re_banner2"),

            sharedPreferences.getString(
                "fb_banner", ""
            ) != firebaseRemoteConfig.getString("fb_banner"),

            sharedPreferences.getString(
                "fb_banner1", ""
            ) != firebaseRemoteConfig.getString("fb_banner1"),

            sharedPreferences.getString(
                "fb_banner2", ""
            ) != firebaseRemoteConfig.getString("fb_banner2"),



            sharedPreferences.getString(
                "privacy_policy", ""
            ) != firebaseRemoteConfig.getString("privacy_policy"),

            sharedPreferences.getBoolean(
                "fb_show_banner", false
            ) != firebaseRemoteConfig.getBoolean("fb_show_banner"),

            /*------------MANIYA-------------------*/
            sharedPreferences.getString(
                "share_idea_mail", ""
            ) != firebaseRemoteConfig.getString("share_idea_mail"),

            sharedPreferences.getString(
                "contact_support_mail", ""
            ) != firebaseRemoteConfig.getString("contact_support_mail"),

            sharedPreferences.getBoolean(
                "is_splash_appOpen", false
            ) != firebaseRemoteConfig.getBoolean("is_splash_appOpen"),

            sharedPreferences.getBoolean(
                "is_splash_interstitial", false
            ) != firebaseRemoteConfig.getBoolean("is_splash_interstitial"),

        )

        return conditions.any { it }
    }

    fun fetchAndStoreData() {

//        storeDataInSharedPreferences()

        val configSettings =
            FirebaseRemoteConfigSettings.Builder().setMinimumFetchIntervalInSeconds(0).build()
        firebaseRemoteConfig.setConfigSettingsAsync(configSettings)
        firebaseRemoteConfig.fetchAndActivate().addOnCompleteListener { task: Task<Boolean?> ->
            if (task.isSuccessful) {
                val isDifferent = isDataDifferentFromFirebase()
                if (isDifferent) {
                    Log.d("fatal", "Data is different from Firebase! Take action.")
                    storeDataInSharedPreferences()
                } else {
                    Log.d("fatal", "Data matches Firebase. No action needed.")
                    loadDataIntoClass()
                }
            } else {
                Log.d("fatal", "Remote Config fetch failed.")
            }
        }
    }

    private fun storeDataInSharedPreferences() {
        val editor = sharedPreferences.edit()

        editor.putBoolean(
            "first_interstitial_show", firebaseRemoteConfig.getBoolean("first_interstitial_show")
        )
        editor.putBoolean(
            "fb_show_interstitial", firebaseRemoteConfig.getBoolean("fb_show_interstitial")
        )
        editor.putBoolean(
            "interstitial_rotated_ad_network",
            firebaseRemoteConfig.getBoolean("interstitial_rotated_ad_network")
        )
        editor.putBoolean("show_dialog", firebaseRemoteConfig.getBoolean("show_dialog"))
        editor.putBoolean("start_screen_show", firebaseRemoteConfig.getBoolean("start_screen_show"))
        editor.putBoolean(
            "show_second_interstitial", firebaseRemoteConfig.getBoolean("show_second_interstitial")
        )
        editor.putBoolean(
            "show_third_interstitial", firebaseRemoteConfig.getBoolean("show_third_interstitial")
        )
        editor.putBoolean(
            "app_open_repeat_show", firebaseRemoteConfig.getBoolean("app_open_repeat_show")
        )
        editor.putString(
            "interstitial_first_choice_network",
            firebaseRemoteConfig.getString("interstitial_first_choice_network")
        )
        editor.putLong(
            "default_count", firebaseRemoteConfig.getLong("default_count").toInt().toLong()
        )

        editor.putLong("count", firebaseRemoteConfig.getLong("count").toInt().toLong())
        editor.putString("app_open", firebaseRemoteConfig.getString("app_open"))
        editor.putString("app_open_1", firebaseRemoteConfig.getString("app_open_1"))
        editor.putBoolean("app_open_show_ads", firebaseRemoteConfig.getBoolean("app_open_show_ads"))
        editor.putString("interstitial", firebaseRemoteConfig.getString("interstitial"))
        editor.putString("interstitial1", firebaseRemoteConfig.getString("interstitial1"))
        editor.putString("interstitial2", firebaseRemoteConfig.getString("interstitial2"))
        editor.putString("re_interstitial", firebaseRemoteConfig.getString("re_interstitial"))
        editor.putString("re_interstitial1", firebaseRemoteConfig.getString("re_interstitial1"))
        editor.putString("re_interstitial2", firebaseRemoteConfig.getString("re_interstitial2"))
        editor.putString("fb_interstitial", firebaseRemoteConfig.getString("fb_interstitial"))
        editor.putString("fb_interstitial1", firebaseRemoteConfig.getString("fb_interstitial1"))
        editor.putString("fb_interstitial2", firebaseRemoteConfig.getString("fb_interstitial2"))

        editor.putBoolean(
            "native_rotated_ad_network",
            firebaseRemoteConfig.getBoolean("native_rotated_ad_network")
        )
        editor.putBoolean("start_show_native", firebaseRemoteConfig.getBoolean("start_show_native"))
        editor.putBoolean(
            "second_ad_show_native", firebaseRemoteConfig.getBoolean("second_ad_show_native")
        )
        editor.putBoolean(
            "third_ad_show_native", firebaseRemoteConfig.getBoolean("third_ad_show_native")
        )
        editor.putString(
            "native_ad_first_choice_network",
            firebaseRemoteConfig.getString("native_ad_first_choice_network")
        )

        editor.putBoolean("fb_show_native", firebaseRemoteConfig.getBoolean("fb_show_native"))
        editor.putString("native", firebaseRemoteConfig.getString("native"))
        editor.putString("native1", firebaseRemoteConfig.getString("native1"))
        editor.putString("native2", firebaseRemoteConfig.getString("native2"))
        editor.putString("re_native", firebaseRemoteConfig.getString("re_native"))
        editor.putString("re_native1", firebaseRemoteConfig.getString("re_native1"))
        editor.putString("re_native2", firebaseRemoteConfig.getString("re_native2"))
        editor.putString("fb_native", firebaseRemoteConfig.getString("fb_native"))
        editor.putString("fb_native1", firebaseRemoteConfig.getString("fb_native1"))
        editor.putString("fb_native2", firebaseRemoteConfig.getString("fb_native2"))

        editor.putBoolean(
            "banner_rotated_ad_network",
            firebaseRemoteConfig.getBoolean("banner_rotated_ad_network")
        )
        editor.putBoolean("start_show_banner", firebaseRemoteConfig.getBoolean("start_show_banner"))
        editor.putBoolean(
            "second_ad_show_banner", firebaseRemoteConfig.getBoolean("second_ad_show_banner")
        )
        editor.putBoolean(
            "third_ad_show_banner", firebaseRemoteConfig.getBoolean("third_ad_show_banner")
        )
        editor.putString(
            "banner_ad_first_choice_network",
            firebaseRemoteConfig.getString("banner_ad_first_choice_network")
        )

        editor.putBoolean("fb_show_banner", firebaseRemoteConfig.getBoolean("fb_show_banner"))
        editor.putString("banner", firebaseRemoteConfig.getString("banner"))
        editor.putString("banner1", firebaseRemoteConfig.getString("banner1"))
        editor.putString("banner2", firebaseRemoteConfig.getString("banner2"))
        editor.putString("re_banner", firebaseRemoteConfig.getString("re_banner"))
        editor.putString("re_banner1", firebaseRemoteConfig.getString("re_banner1"))
        editor.putString("re_banner2", firebaseRemoteConfig.getString("re_banner2"))
        editor.putString("fb_banner", firebaseRemoteConfig.getString("fb_banner"))
        editor.putString("fb_banner1", firebaseRemoteConfig.getString("fb_banner1"))
        editor.putString("fb_banner2", firebaseRemoteConfig.getString("fb_banner2"))
        editor.putString("privacy_policy", firebaseRemoteConfig.getString("privacy_policy"))
        /*----------MANIYA----------*/
        editor.putString("share_idea_mail", firebaseRemoteConfig.getString("share_idea_mail"))
        editor.putString("contact_support_mail", firebaseRemoteConfig.getString("contact_support_mail"))
        editor.putBoolean("is_splash_appOpen", firebaseRemoteConfig.getBoolean("is_splash_appOpen"))
        editor.putBoolean("is_splash_interstitial", firebaseRemoteConfig.getBoolean("is_splash_appOpen"))

        editor.apply()

        loadDataIntoClass()
    }

      /* private fun storeDataInSharedPreferences() {

           val editor = sharedPreferences.edit()

           editor.putBoolean("first_interstitial_show", true)
           editor.putBoolean("fb_show_interstitial", true)
           editor.putBoolean("interstitial_rotated_ad_network",false)
           editor.putBoolean("show_dialog", true)
           editor.putBoolean("start_screen_show", true)
           editor.putBoolean("show_second_interstitial", true)
           editor.putBoolean("show_third_interstitial", true)
           editor.putBoolean("app_open_repeat_show", true)
           editor.putString("interstitial_first_choice_network", "F")
           editor.putLong("default_count", 2)

           editor.putLong("count", 3)
           editor.putString("app_open", "ca-app-pub-3940256099942544/9257395921")
           editor.putString("app_open_1", "ca-app-pub-3940256099942544/9257395921")
           editor.putBoolean("app_open_show_ads", true)

           editor.putString("interstitial", "ca-app-pub-3940256099942544/1033173712")
           editor.putString("interstitial1", "ca-app-pub-3940256099942544/1033173712")
           editor.putString("interstitial2", "ca-app-pub-3940256099942544/1033173712")
           editor.putString("re_interstitial", "ca-app-pub-3940256099942544/1033173712")
           editor.putString("re_interstitial1", "ca-app-pub-3940256099942544/1033173712")
           editor.putString("re_interstitial2", "ca-app-pub-3940256099942544/1033173712")
           editor.putString("fb_interstitial", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")
           editor.putString("fb_interstitial1", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")
           editor.putString("fb_interstitial2", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")

           editor.putBoolean("native_rotated_ad_network", false)
           editor.putBoolean("start_show_native", true)
           editor.putBoolean("second_ad_show_native", true)
           editor.putBoolean("third_ad_show_native", true)
           editor.putString("native_ad_first_choice_network", "F")

           editor.putBoolean("fb_show_native", true)

           editor.putString("native", "ca-app-pub-3940256099942544/2247696110")
           editor.putString("native1", "ca-app-pub-3940256099942544/2247696110")
           editor.putString("native2", "ca-app-pub-3940256099942544/2247696110")
           editor.putString("re_native", "ca-app-pub-3940256099942544/2247696110")
           editor.putString("re_native1", "ca-app-pub-3940256099942544/2247696110")
           editor.putString("re_native2", "ca-app-pub-3940256099942544/2247696110")
           editor.putString("fb_native", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")
           editor.putString("fb_native1", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")
           editor.putString("fb_native2", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")

           editor.putBoolean("banner_rotated_ad_network", false)
           editor.putBoolean("start_show_banner", true)
           editor.putBoolean("second_ad_show_banner", true)
           editor.putBoolean("third_ad_show_banner", true)
           editor.putString("banner_ad_first_choice_network", "F")

           editor.putBoolean("fb_show_banner", true)

           editor.putString("banner", "ca-app-pub-3940256099942544/6300978111")
           editor.putString("banner1", "ca-app-pub-3940256099942544/6300978111")
           editor.putString("banner2", "ca-app-pub-3940256099942544/6300978111")
           editor.putString("re_banner", "ca-app-pub-3940256099942544/6300978111")
           editor.putString("re_banner1", "ca-app-pub-3940256099942544/6300978111")
           editor.putString("re_banner2", "ca-app-pub-3940256099942544/6300978111")
           editor.putString("fb_banner", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")
           editor.putString("fb_banner1", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")
           editor.putString("fb_banner2", "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID")
           editor.putString("privacy_policy", "https://amazingappscollection.blogspot.com/2023/05/privacy-policy.html")

           editor.apply()

           loadDataIntoClass()
       }
*/


    fun loadDataIntoClass() {

        AdsIDS.first_activity_ad_show_interstitial =
            sharedPreferences.getBoolean("first_interstitial_show", false)
        AdsIDS.fb_interstitial_show_ads =
            sharedPreferences.getBoolean("fb_show_interstitial", false)
        AdsIDS.interstitial_rotated_ad_network =
            sharedPreferences.getBoolean("interstitial_rotated_ad_network", false)
        AdsIDS.show_dialog = sharedPreferences.getBoolean("show_dialog", false)
        AdsIDS.start_screen_show = sharedPreferences.getBoolean("start_screen_show", false)
        AdsIDS.show_second_interstitial =
            sharedPreferences.getBoolean("show_second_interstitial", false)
        AdsIDS.show_third_interstitial =
            sharedPreferences.getBoolean("show_third_interstitial", false)
        AdsIDS.app_open_repeat_show = sharedPreferences.getBoolean("app_open_repeat_show", false)
        AdsIDS.interstitial_ad_first_ad_network =
            sharedPreferences.getString("interstitial_first_choice_network", "")
        AdsIDS.Default_Count = sharedPreferences.getLong("default_count", 0).toInt()
        AdsIDGoogle.Count(context, sharedPreferences.getLong("count", 0).toInt())
        AdsIDGoogle.Default_Count(
            context, sharedPreferences.getLong("default_count", 0).toInt()
        )

        App_Open = sharedPreferences.getString("app_open", "")
        AdsIDS.App_Open_1 = sharedPreferences.getString("app_open_1", "")
        app_open_show_ads = sharedPreferences.getBoolean("app_open_show_ads", false)
        AdsIDS.interstitial = sharedPreferences.getString("interstitial", "")
        AdsIDS.interstitial_1 = sharedPreferences.getString("interstitial1", "")
        AdsIDS.interstitial_2 = sharedPreferences.getString("interstitial2", "")
        AdsIDS.re_interstitial = sharedPreferences.getString("re_interstitial", "")
        AdsIDS.re_interstitial_1 = sharedPreferences.getString("re_interstitial1", "")
        AdsIDS.re_interstitial_2 = sharedPreferences.getString("re_interstitial2", "")
        AdsIDS.fb_interstitial = sharedPreferences.getString("fb_interstitial", "")
        AdsIDS.fb_interstitial_1 = sharedPreferences.getString("fb_interstitial1", "")
        AdsIDS.fb_interstitial_2 = sharedPreferences.getString("fb_interstitial2", "")
        AdsIDS.Count = sharedPreferences.getLong("count", 0).toInt()

        AdsIDS.native_rotated_ad_network = sharedPreferences.getBoolean("native_rotated_ad_network", false)
        AdsIDS.first_activity_ad_show_native =
            sharedPreferences.getBoolean("start_show_native", false)
        AdsIDS.second_ad_show_native = sharedPreferences.getBoolean("second_ad_show_native", false)
        AdsIDS.third_ad_show_native = sharedPreferences.getBoolean("third_ad_show_native", false)
        AdsIDS.native_ad_first_ad_network =
            sharedPreferences.getString("native_ad_first_choice_network", "")

        AdsIDS.fb_native_show_ads = sharedPreferences.getBoolean("fb_show_native", false)
        AdsIDS.ad_native = sharedPreferences.getString("native", "")
        AdsIDS.ad_native_1 = sharedPreferences.getString("native1", "")
        AdsIDS.ad_native_2 = sharedPreferences.getString("native2", "")
        AdsIDS.re_ad_native = sharedPreferences.getString("re_native", "")
        AdsIDS.re_ad_native_1 = sharedPreferences.getString("re_native1", "")
        AdsIDS.re_ad_native_2 = sharedPreferences.getString("re_native2", "")
        AdsIDS.fb_ad_native = sharedPreferences.getString("fb_native", "")
        AdsIDS.fb_ad_native_1 = sharedPreferences.getString("fb_native1", "")
        AdsIDS.fb_ad_native_2 = sharedPreferences.getString("fb_native2", "")

        AdsIDS.banner_rotated_ad_network = sharedPreferences.getBoolean("banner_rotated_ad_network", false)
        AdsIDS.first_activity_ad_show_banner = sharedPreferences.getBoolean("start_show_banner", false)
        AdsIDS.second_ad_show_banner = sharedPreferences.getBoolean("second_ad_show_banner", false)
        AdsIDS.third_ad_show_banner = sharedPreferences.getBoolean("third_ad_show_banner", false)
        AdsIDS.banner_ad_first_ad_network = sharedPreferences.getString("banner_ad_first_choice_network", "")

        AdsIDS.fb_banner_show_ads = sharedPreferences.getBoolean("fb_show_banner", false)
        AdsIDS.ad_banner = sharedPreferences.getString("banner", "")
        AdsIDS.ad_banner_1 = sharedPreferences.getString("banner1", "")
        AdsIDS.ad_banner_2 = sharedPreferences.getString("banner2", "")
        AdsIDS.re_ad_banner = sharedPreferences.getString("re_banner", "")
        AdsIDS.re_ad_banner_1 = sharedPreferences.getString("re_banner1", "")
        AdsIDS.re_ad_banner_2 = sharedPreferences.getString("re_banner2", "")
        AdsIDS.fb_ad_banner = sharedPreferences.getString("fb_banner", "")
        AdsIDS.fb_ad_banner_1 = sharedPreferences.getString("fb_banner1", "")
        AdsIDS.fb_ad_banner_2 = sharedPreferences.getString("fb_banner2", "")
        AdsIDS.privacy_policy = sharedPreferences.getString("privacy_policy", "")



        AdsIDS.App_Open_id = App_Open
        AdsIDS.IDS_Activity_OPEN = true

        /*------------MANIYA----------*/
        AdsIDS.share_idea_mail = sharedPreferences.getString("share_idea_mail", "")
        AdsIDS.contact_support_mail = sharedPreferences.getString("contact_support_mail", "")
        AdsIDS.is_splash_appOpen = sharedPreferences.getBoolean("is_splash_appOpen", false)
        AdsIDS.is_splash_interstitial = sharedPreferences.getBoolean("is_splash_interstitial", false)



        AdsInterstitial.instance!!.pre_load_interstitial(context)


    }

    companion object {
        private const val PREFS_NAME = "FirebaseConfigPrefs"
    }
}
