package com.deep.infotech.atm_card_wallet.maniya.dataModel


import com.j256.ormlite.field.DatabaseField
import com.j256.ormlite.table.DatabaseTable

@DatabaseTable(tableName = "PasswordCards")
data class PasswordCardScanDataManiya(
    @DatabaseField(generatedId = true) // Auto-increment primary key
    var id: Long = 0,
    @DatabaseField(canBeNull = true)
    var title: String = "",

    @DatabaseField(canBeNull = true)
    var url: String = "",

    @DatabaseField(canBeNull = true)
    var password: String = "",


    @DatabaseField(canBeNull = true)
    var login: String = "",


    @DatabaseField(canBeNull = true)
    var Name: String = "",

    @DatabaseField(canBeNull = true)
    var notes: String = "",

    @DatabaseField(canBeNull = true)
    var custom: String = "",

    @DatabaseField(foreign = true, foreignAutoRefresh = true, canBeNull = true, foreignColumnName = "id")
    var label: com.deep.infotech.atm_card_wallet.maniya.dataModel.LabelDataManiya? = null,

    @DatabaseField(foreign = true, foreignAutoRefresh = true, canBeNull = true)
    var category: com.deep.infotech.atm_card_wallet.maniya.dataModel.CategoryDataManiya? = null,

    @DatabaseField(canBeNull = true)
    var frontCardImage: String= "",

    @DatabaseField(canBeNull = true)
    var backCardImage: String= "",


    @DatabaseField(canBeNull = true)
    var appearanceColor: Int = 0,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isSensitive: Boolean = false,


    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isLock: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isFav: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isDelete: Boolean = false,

    @DatabaseField(canBeNull = false, defaultValue = "false")
    var isArchive: Boolean = false
)
