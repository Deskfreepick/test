package com.deep.infotech.atm_card_wallet.Ads

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.preference.PreferenceManager
import android.util.Log
import com.facebook.ads.Ad
import com.facebook.ads.InterstitialAdListener
import com.google.ads.mediation.admob.AdMobAdapter
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.ump.ConsentInformation
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.fb_interstitial_show_ads
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.first_activity_ad_show_interstitial
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.interstitial_ad_first_ad_network
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.interstitial_first_time_show_ads
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.interstitial_rotated_ad_network
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.show_dialog
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.show_second_interstitial
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS.show_third_interstitial
import com.deep.infotech.atm_card_wallet.Ads.AdsIDGoogle.get_Count

import com.deep.infotech.atm_card_wallet.R

import com.deep.infotech.atm_card_wallet.utils.LogD


class AdsInterstitial {
    private var clickCount = 0
    var isInterstitialRequest = false
    var isInterstitialfbRequest = false
    private var dialog_ad: ProgressDialog? = null

    var myadfinish: adfinish? = null

    interface adfinish {
        fun adfinished()
    }

    fun pre_load_interstitial(activity: Context) {

        if (fb_interstitial_show_ads) {
                if (mInterstitialfb == null) {
                    Load_Fb_interstitial_Ad(activity)
                }
            } else {

                if (mInterstitialAdMob == null) {
                    instance!!.Load_Admob_Interstitial(activity)
                }
            }

    }


    fun admob_interstitial_get_id() {
        LogD(
            LOG_TAG,
            "onAdFailedToLoad_____$Admob_interstitial_Repeat_failed/ $admob_interstitial_id_rotation"
        )
        if (admob_interstitial_id_rotation == 0) {
            if (Admob_interstitial_Repeat_failed) {
                admob_interstitial_id = AdsIDS.interstitial
                Admob_interstitial_Repeat_failed = false
            } else {
                admob_interstitial_id = AdsIDS.re_interstitial
                Admob_interstitial_Repeat_failed = true
                admob_interstitial_fail_id_repeat()
            }
        } else if (admob_interstitial_id_rotation == 1) {
            if (Admob_interstitial_Repeat_failed) {
                admob_interstitial_id = AdsIDS.interstitial_1
                Admob_interstitial_Repeat_failed = false
            } else {
                admob_interstitial_id = AdsIDS.re_interstitial_1
                Admob_interstitial_Repeat_failed = true
                admob_interstitial_fail_id_repeat()
            }
        } else if (admob_interstitial_id_rotation == 2) {
            if (Admob_interstitial_Repeat_failed) {
                admob_interstitial_id = AdsIDS.interstitial_2
                Admob_interstitial_Repeat_failed = false
            } else {
                admob_interstitial_id = AdsIDS.re_interstitial_2
                Admob_interstitial_Repeat_failed = true
                admob_interstitial_fail_id_repeat()
            }
        }
    }

    fun Load_Admob_Interstitial(activity: Context?) {
        isInterstitialRequest = true
        val builder = AdRequest.Builder()
        val request = GDPRChecker.status
        if (request == ConsentInformation.ConsentStatus.NOT_REQUIRED) {
            // load non Personalized ads
            val extras = Bundle()
            extras.putString("npa", "1")
            builder.addNetworkExtrasBundle(AdMobAdapter::class.java, extras)
        }
        admob_interstitial_get_id()

      /*  if(!verifyForTest(activity!!)){
            admob_interstitial_id ="/6499/example/app-interstitial"
        }*/
        LogD(
            LOG_TAG,
            "admob_interstitial_id____$admob_interstitial_id--->rotation-->$admob_interstitial_id_rotation"
        )

        InterstitialAd.load(activity!!,
            admob_interstitial_id!!,
            builder.build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(interstitialAd: InterstitialAd) {
                    LogD(
                        LOG_TAG,
                        "admob_interstitial_id____onAdLoaded$admob_interstitial_id/$admob_interstitial_id_rotation/1"
                    )
                    isInterstitialRequest = false
                    mInterstitialAdMob = interstitialAd
             /*       interstitialAd.fullScreenContentCallback =
                        object : FullScreenContentCallback() {
                            override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                                super.onAdFailedToShowFullScreenContent(adError)
                            }

                            override fun onAdShowedFullScreenContent() {
                                super.onAdShowedFullScreenContent()
                            }

                            override fun onAdClicked() {
                                super.onAdClicked()
                                LogD("onAdClicked___", "onAdClicked___" + AdsIDS.when_click_ads)
                                AdsIDS.when_click_ads = false;
                            }

                            override fun onAdDismissedFullScreenContent() {
                                super.onAdDismissedFullScreenContent()
                                AdsIDS.when_click_ads = true
                                Admob_interstitial_Repeat_failed = true
                                admob_interstitial_onAdDismissed(activity)
                            }

                            override fun onAdImpression() {
                                super.onAdImpression()
                            }
                        }*/
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    LogD(LOG_TAG,
                        "+++admob_interstitial_id____onAdFailedToLoad---${loadAdError.responseInfo}"
                    )
                    mInterstitialAdMob = null
                    isInterstitialRequest = false
                    admob_interstitial_onAdFailedToLoad(activity)
                }
            })
    }

    fun showInterstitial(activity: Activity?) {
        if (mInterstitialAdMob != null) {
          //  mInterstitialAdMob!!.show(activity!!)
            showInterstitialAd(activity,false,myadfinish!!)
        }
    }

    fun isAdLoaded(): Boolean {
        return mInterstitialAdMob != null
    }

    fun showInterstitialAd(activity: Activity?, isLastAd: Boolean, myadfinish1: adfinish) {
        myadfinish = myadfinish1
        if (isAdLoaded())
        {
            mInterstitialAdMob?.setFullScreenContentCallback(object :
                FullScreenContentCallback() {
                override fun onAdClicked() {
                    super.onAdClicked()
                    LogD(LOG_TAG, "onAdClicked___" + AdsIDS.when_click_ads)
                    AdsIDS.when_click_ads = false
                }

                override fun onAdImpression() {
                    super.onAdImpression()
                }

                override fun onAdDismissedFullScreenContent() {
                    LogD(LOG_TAG,"+++onAdDismissedFullScreenContent--------------")
                    AdsIDS.when_click_ads = true
                    Admob_interstitial_Repeat_failed = true
                    mInterstitialAdMob = null
                    admob_interstitial_fail_id_repeat()
                    myadfinish?.adfinished()

                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    LogD(LOG_TAG,"+++onAdFailedToShowFullScreenContent-------------")
                    AdsIDS.when_click_ads = true
                    Admob_interstitial_Repeat_failed = true
                    mInterstitialAdMob = null
                    admob_interstitial_fail_id_repeat()

                    myadfinish?.adfinished()
                }

                override fun onAdShowedFullScreenContent() {
                }
            })
            if (mInterstitialAdMob != null) {
                mInterstitialAdMob!!.show(activity!!)
            }
        }
        else {
          /*  show_fb_interstitial(activity!!)*/
        /*    mInterstitialAdMob = null
            if (mInterstitialfb!!.isAdLoaded && mInterstitialfb != null) {
                mInterstitialfb!!.show()
            }else{
                myadfinish?.adfinished()
            }*/
            myadfinish?.adfinished()
            LogD(LOG_TAG,"+++isLoaded-----FALSE-------" )

        }
    }

    fun admob_interstitial_fail_id_repeat() {
        if (admob_interstitial_id_rotation == 0) {
            admob_interstitial_id_rotation = 1
        } else if (admob_interstitial_id_rotation == 1) {
            admob_interstitial_id_rotation = 2
        } else if (admob_interstitial_id_rotation == 2) {
            admob_interstitial_id_rotation = 0
        }
    }

    fun admob_interstitial_onAdFailedToLoad(activity: Context?) {
        LogD(
            LOG_TAG,
            "admob_interstitial_id____onAdFailedToLoad$admob_interstitial_id/$Admob_interstitial_Repeat_failed"
        )
        if (!Admob_interstitial_Repeat_failed) {
            Load_Admob_Interstitial(activity)
        }
    }

    fun admob_interstitial_onAdDismissed(activity: Context?)
    {
        mInterstitialAdMob = null
        admob_interstitial_fail_id_repeat()
            if (fb_interstitial_show_ads) {
                Load_Fb_interstitial_Ad(activity)
            } else {
                if (!isInterstitialRequest) {
                    Load_Admob_Interstitial(activity)
                }
            }

    }

    fun first_open_activity(activity: Activity, intent: Intent?) {
        clickCount = getClick(activity)
        if (first_activity_ad_show_interstitial) {
            activity(activity, intent)
        } else {
            activity.startActivity(intent)
        }
    }


    fun open_activity(activity: Activity, intent: Intent?) {
        clickCount = getClick(activity)
        if (show_second_interstitial) {
            activity(activity, intent)
        } else {
            activity.startActivity(intent)
        }
    }

    fun third_activity(activity: Activity, intent: Intent?) {
        clickCount = getClick(activity)
        if (show_third_interstitial) {
            activity(activity, intent)
        } else {
            activity.startActivity(intent)
        }
    }

    fun activity(activity: Activity, intent: Intent?) {
        if (interstitial_first_time_show_ads) {
            if (clickCount % get_Count(activity) == 0) {
                showDialog(activity)
                interstitial_first_time_show_ads = false
                Handler().postDelayed({
                    activity.startActivity(intent)
                    show_ad(activity)
                    hideDialog(activity)
                }, 1000)
                clickCount++
                Click(activity, clickCount)
            }
            else {
                if (show_dialog) {
                    showDialog(activity)
                    interstitial_first_time_show_ads = false
                    Handler().postDelayed({
                        activity.startActivity(intent)
                        show_ad(activity)
                        hideDialog(activity)
                    }, 1000)
                } else {
                    interstitial_first_time_show_ads = false
                    activity.startActivity(intent)
                    show_ad(activity)
                }
            }
        } else {
            if (clickCount % get_Count(activity) == 0) {
                if (show_dialog) {
                    showDialog(activity)
                    Handler().postDelayed({
                        activity.startActivity(intent)
                        show_ad(activity)
                        hideDialog(activity)
                    }, 1000)
                } else {
                    activity.startActivity(intent)
                    show_ad(activity)
                }
            } else {
                activity.startActivity(intent)
            }
            clickCount++
            Click(activity, clickCount)
        }

    }

    private fun showDialog(activity: Activity) {
        dialog_ad = ProgressDialog(activity, R.style.MyDialog)
        dialog_ad!!.setCancelable(false)
        dialog_ad!!.setCanceledOnTouchOutside(false)
        dialog_ad!!.setTitle(activity.getString(R.string.please_wait))
        dialog_ad!!.setMessage(activity.getString(R.string.load_ad))
        dialog_ad!!.show()
    }

    private fun hideDialog(activity: Activity?) {
        if (activity != null && !activity.isFinishing && dialog_ad != null && dialog_ad!!.isShowing) {
            dialog_ad!!.dismiss()
        }
    }

    private fun show_ad(activity: Activity) {
        if (interstitial_rotated_ad_network) {
            if (interstitial_ad_first_ad_network.equals("G")) {
                interstitial_ad_first_ad_network = "F"
                showInterstitial(activity)
            } else {
                interstitial_ad_first_ad_network = "G"
                show_fb_interstitial(activity)
            }
        } else {
            if (!fb_interstitial_show_ads) {
                show_fb_interstitial(activity)
            } else {
                showInterstitial(activity)

            }
        }
    }

    fun fb_interstitial_get_id() {
        if (fb_interstitial_id_rotation == 0) {
            fb_interstitial_id = AdsIDS.fb_interstitial
        } else if (fb_interstitial_id_rotation == 1) {
            fb_interstitial_id = AdsIDS.fb_interstitial_1
        } else if (fb_interstitial_id_rotation == 2) {
            fb_interstitial_id = AdsIDS.fb_interstitial_2
        }
    }

    fun fb_interstitial_id_repeat() {
        if (fb_interstitial_id_rotation == 0) {
            fb_interstitial_id_rotation = 1
        } else if (fb_interstitial_id_rotation == 1) {
            fb_interstitial_id_rotation = 2
        } else {
            fb_interstitial_id_rotation = 0
        }
    }

    fun Load_Fb_interstitial_Ad(activity: Context?) {
        isInterstitialfbRequest = true
        fb_interstitial_get_id()
        LogD(LOG_TAG, "Load_Network_____$fb_interstitial_id")
        mInterstitialfb = com.facebook.ads.InterstitialAd(activity, fb_interstitial_id)


        val interstitialAdListener: InterstitialAdListener = object : InterstitialAdListener {
            override fun onInterstitialDisplayed(ad: Ad) {
                LogD(
                    LOG_TAG, "FB_____OnDisplayed----"
                )
            }
            override fun onInterstitialDismissed(ad: Ad) {
                LogD(
                    LOG_TAG, "FB_____OnDismissed()----"
                )
                AdsIDS.when_click_ads = true
                fb_onInterstitialDismissed(activity)
            }

            override fun onError(ad: Ad, adError: com.facebook.ads.AdError) {
                LogD(
                    LOG_TAG, "FB_____onError$fb_interstitial_show_ads"
                )
                isInterstitialfbRequest = false
                fb_interstitial_id_repeat()
                Load_Admob_Interstitial(activity)
            }

            override fun onAdLoaded(ad: Ad) {
                LogD(LOG_TAG, "FB_____onLoaded()---" )
                isInterstitialfbRequest = true
            }

            override fun onAdClicked(ad: Ad) {
                LogD(LOG_TAG, "FB_____onAdClicked___" + AdsIDS.when_click_ads)
                AdsIDS.when_click_ads = false
            }

            override fun onLoggingImpression(ad: Ad) {}
        }
        mInterstitialfb!!.loadAd(mInterstitialfb!!.buildLoadAdConfig().withAdListener(interstitialAdListener).build()
        )
    }


    private fun show_fb_interstitial(activity: Activity) {
        if (mInterstitialfb!!.isAdLoaded && mInterstitialfb != null) {
            mInterstitialfb!!.show()
        } else {
            showInterstitial(activity)
        }
    }

    private fun fb_onInterstitialDismissed(activity: Context?) {
        LogD(LOG_TAG, "Load_Network_____Dismissed$fb_interstitial_show_ads")
        isInterstitialfbRequest = false
        fb_interstitial_id_repeat()
        pre_load_interstitial(activity!!)
        myadfinish?.adfinished()

    }

    companion object {
        private const val Count_No = "click"
        private const val LOG_TAG = "AdInterstitial++++"
        private var admob_interstitial_id: String? = null
        private var fb_interstitial_id: String? = null
        private var admob_interstitial_id_rotation = 0
        private var fb_interstitial_id_rotation = 0
        private var mInterstitialfb: com.facebook.ads.InterstitialAd? = null
        var mInstance: AdsInterstitial? = null
        var Admob_interstitial_Repeat_failed = true

        //    public static boolean interstitial_admob_ad_failed = false;
        var mInterstitialAdMob: InterstitialAd? = null
        val instance: AdsInterstitial?
            get() {
                if (mInstance == null) {
                    mInstance = AdsInterstitial()
                }
                return mInstance
            }

        fun Click(context: Activity, str2: Int) {
            val edit = context.getSharedPreferences(Count_No, 0).edit()
            edit.putInt(Count_No, str2)
            edit.apply()
        }

        fun getClick(context: Context): Int {
            return context.getSharedPreferences(Count_No, 0).getInt(Count_No, AdsIDS.Default_Count)
        }
    }
}