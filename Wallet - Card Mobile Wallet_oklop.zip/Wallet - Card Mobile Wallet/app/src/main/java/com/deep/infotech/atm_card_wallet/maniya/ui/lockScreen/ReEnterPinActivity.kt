package com.deep.infotech.atm_card_wallet.maniya.ui.lockScreen

import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.AsyncTask
import android.os.Bundle
import android.preference.PreferenceManager
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import com.deep.infotech.atm_card_wallet.Ads.AdsIDS
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ActivityEnterPinBinding
import com.deep.infotech.atm_card_wallet.maniya.ui.TESTMainActivityManiya
import com.deep.infotech.atm_card_wallet.maniya.ui.BaseActivity
import com.deep.infotech.atm_card_wallet.utils.CircleRippleLayout
import java.lang.Boolean
import kotlin.Array
import kotlin.Exception
import kotlin.String
import kotlin.arrayOf
import kotlin.arrayOfNulls
import kotlin.plus
import kotlin.toString

class ReEnterPinActivity : BaseActivity() {

    private lateinit var binding: ActivityEnterPinBinding

    private var loutCancel: LinearLayout? = null
    private var save: LinearLayout? = null
    private var a2: EditText? = null

    var keyPadLockedFlag = false
    var pinBoxArray: Array<ImageView?>? = null
    private var pk: String? = null
    var sharedPreferences: SharedPreferences? = null
    private var animation: Animation? = null
    var userEntered: String? = null
    private var isFromLockData = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEnterPinBinding.inflate(layoutInflater)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE
        )
        setContentView(binding.root)
        updateWindow()

        pk = intent.getStringExtra("pkgname")
        /* isFromLockData=  intent.getBooleanExtra("fromLockData", false)
 */
        val valueOf = Boolean.valueOf(intent.getBooleanExtra("forgetpass", false))
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        userEntered = ""

        findViewById<View>(R.id.tl)
        binding.fp.gone()

        val drawable: Drawable? = try {
            packageManager.getApplicationIcon(pk!!)
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
            null
        }
        try {
            binding.imageView1.setImageDrawable(drawable)
        } catch (e2: Exception) {
            e2.printStackTrace()
        }
        animation = AnimationUtils.loadAnimation(this, R.anim.shake)
        binding.tvForgot.setOnClickListener {
            val builder = Dialog(
                this@ReEnterPinActivity,
                androidx.appcompat.R.style.Base_Theme_AppCompat_Dialog_MinWidth
            )
            builder.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            builder.setContentView(R.layout.activity_forgot_password)
            a2 = builder.findViewById(R.id.editText2)!!
            save = builder.findViewById(R.id.button1)
            save!!.setOnClickListener {
                val obj = a2!!.text.toString()
                if (obj.isEmpty()) {
                    a2!!.startAnimation(
                        AnimationUtils.loadAnimation(
                            this@ReEnterPinActivity.applicationContext, R.anim.shake
                        )
                    )
                } else if (sharedPreferences!!.getString("Q", "").toString() == obj) {
                    this@ReEnterPinActivity.startActivity(
                        Intent(
                            this@ReEnterPinActivity.applicationContext,
                            CreatePinActivity::class.java
                        )
                    )
                    builder.dismiss()
                    finish()
                } else {
                    a2!!.startAnimation(
                        AnimationUtils.loadAnimation(
                            this@ReEnterPinActivity.applicationContext, R.anim.shake
                        )
                    )
                }
            }
            loutCancel!!.setOnClickListener { builder.dismiss() }
            builder.show()
        }
        (findViewById<View>(R.id.buttonDeleteBack) as CircleRippleLayout).setOnClickListener {
            if (!keyPadLockedFlag && userEntered!!.isNotEmpty()) {
                val pin2 = this@ReEnterPinActivity
                pin2.userEntered = pin2.userEntered!!.substring(0, userEntered!!.length - 1)
                pinBoxArray!![userEntered!!.length]!!.setImageResource(R.drawable.selected_border)
            }
        }
        pinBoxArray = arrayOfNulls(4)
        pinBoxArray!![0] = binding.pinBox0
        pinBoxArray!![1] = binding.pinBox1
        pinBoxArray!![2] = binding.pinBox2
        pinBoxArray!![3] = binding.pinBox3

        val r1 = View.OnClickListener { view ->
            if (!keyPadLockedFlag) {
                if (userEntered!!.length < 4) {
                    val pin2 = this@ReEnterPinActivity
                    pin2.userEntered = userEntered + click(view)
                    pinBoxArray!![userEntered!!.length - 1]!!.setImageResource(R.drawable.unselect_round)
                    if (userEntered!!.length == sharedPreferences!!.getString(
                            "pin", "0000"
                        )!!.length
                    ) {
                        if (userEntered == sharedPreferences!!.getString("pin", "0000")) {
                            if (pk == this@ReEnterPinActivity.packageName) {
                                if (intent.getIntExtra("intent", 0) != 9999) {
                                    /* if (getSharedPreferences("language", 0).getBoolean(
                                             "isFirstRun",
                                             true
                                         )
                                     ) {
                                         startActivity(Intent(this, LanguageActivity::class.java))
                                         finish()
                                     } else*/
                                /*    if (AdsIDS.start_screen_show) {
                                        startActivity(Intent(this, StartActivity::class.java))
                                        finish()
                                    } else {*/

                                        /* if(!isFromLockData) {startActivity(Intent(this, TESTMainActivityManiya::class.java))
                                         finish()}else{
                                             returnWithResult()
                                         }*/

                                        startActivity(
                                            Intent(
                                                this,
                                                TESTMainActivityManiya::class.java
                                            )
                                        )
                                        finish()
                                   /* }*/
                                }
                            } else {
                                sharedPreferences!!.edit().putBoolean("setResultApp", true).apply()
                                finish()
                            }
                            val edit = sharedPreferences!!.edit()
                            edit.putBoolean(pk + "pattern", false)
                            edit.apply()
                            edit.apply()
                            finish()
                            this@ReEnterPinActivity.overridePendingTransition(
                                R.anim.fade_in, R.anim.fade_out
                            )
                        } else {
                            binding.sk.startAnimation(animation)
                            keyPadLockedFlag = true
                            LockKeyPadOperation().execute(*arrayOf(""))
                        }
                    }
                } else {
                    pinBoxArray!![0]!!.setImageResource(R.drawable.selected_border)
                    pinBoxArray!![1]!!.setImageResource(R.drawable.selected_border)
                    pinBoxArray!![2]!!.setImageResource(R.drawable.selected_border)
                    pinBoxArray!![3]!!.setImageResource(R.drawable.selected_border)
                    userEntered = ""
                    val pin22 = this@ReEnterPinActivity
                    pin22.userEntered = userEntered + click(view)
                    Log.v("PinView", "User entered=$userEntered")
                    pinBoxArray!![userEntered!!.length - 1]!!.setImageResource(R.drawable.unselect_round)
                }
            }
        }

        binding.keyBord.button0.setOnClickListener(r1)
        binding.keyBord.button1.setOnClickListener(r1)
        binding.keyBord.button2.setOnClickListener(r1)
        binding.keyBord.button3.setOnClickListener(r1)
        binding.keyBord.button4.setOnClickListener(r1)
        binding.keyBord.button5.setOnClickListener(r1)
        binding.keyBord.button6.setOnClickListener(r1)
        binding.keyBord.button7.setOnClickListener(r1)
        binding.keyBord.button8.setOnClickListener(r1)
        binding.keyBord.button9.setOnClickListener(r1)

        if (valueOf) {
            val builder =
                Dialog(this, androidx.appcompat.R.style.Base_Theme_AppCompat_Dialog_MinWidth)
            builder.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            builder.setContentView(R.layout.activity_forgot_password)
            a2 = builder.findViewById(R.id.editText2)!!
            save = builder.findViewById(R.id.button1)
            save!!.setOnClickListener {
                val obj = a2!!.text.toString()
                if (obj.isEmpty()) {
                    a2!!.startAnimation(
                        AnimationUtils.loadAnimation(
                            this@ReEnterPinActivity.applicationContext, R.anim.shake
                        )
                    )
                } else if (sharedPreferences!!.getString("Q", "").toString() == obj) {
                    this@ReEnterPinActivity.startActivity(
                        Intent(
                            this@ReEnterPinActivity.applicationContext,
                            CreatePinActivity::class.java
                        )
                    )
                    builder.dismiss()
                    finish()
                } else {
                    a2!!.startAnimation(
                        AnimationUtils.loadAnimation(
                            this@ReEnterPinActivity.applicationContext, R.anim.shake
                        )
                    )
                }
            }
            loutCancel!!.setOnClickListener { builder.dismiss() }
            builder.show()
        }

    }

    private fun returnWithResult() {
        val resultIntent = Intent()
        resultIntent.putExtra("isUnlockDone", true)
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    private fun click(view: View): String? {
        if (view.id == R.id.button0) {
            return "0"
        }
        if (view.id == R.id.button1) {
            return "1"
        }
        if (view.id == R.id.button2) {
            return "2"
        }
        if (view.id == R.id.button3) {
            return "3"
        }
        if (view.id == R.id.button4) {
            return "4"
        }
        if (view.id == R.id.button5) {
            return "5"
        }
        if (view.id == R.id.button6) {
            return "6"
        }
        if (view.id == R.id.button7) {
            return "7"
        }
        if (view.id == R.id.button8) {
            return "8"
        }
        return if (view.id == R.id.button9) {
            "9"
        } else null
    }

    private inner class LockKeyPadOperation : AsyncTask<String?, Void?, String>() {

        override fun onPreExecute() {}

        override fun doInBackground(vararg strArr: String?): String {
            for (i in 0..1) {
                try {
                    Thread.sleep(500)
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
            }
            return "Executed"
        }

        override fun onProgressUpdate(vararg voidArr: Void?) {}

        public override fun onPostExecute(str: String) {
            pinBoxArray!![0]!!.setImageResource(R.drawable.selected_border)
            pinBoxArray!![1]!!.setImageResource(R.drawable.selected_border)
            pinBoxArray!![2]!!.setImageResource(R.drawable.selected_border)
            pinBoxArray!![3]!!.setImageResource(R.drawable.selected_border)
            userEntered = ""
            keyPadLockedFlag = false
        }
    }
}