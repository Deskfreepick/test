package com.deep.infotech.atm_card_wallet.maniya.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.deep.infotech.atm_card_wallet.databinding.ActivityCategoriesManiyaBinding
import com.deep.infotech.atm_card_wallet.R
import com.deep.infotech.atm_card_wallet.databinding.ScanDataBottomDialogBinding
import com.deep.infotech.atm_card_wallet.databinding.ScanDialogBinding
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.model.DatabaseHelperManiya
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch


class CategoryWalletActivityManiya : BaseActivity() {

    private lateinit var binding: ActivityCategoriesManiyaBinding
    private lateinit var views: List<Pair<View, TextView>>

    private lateinit var activityResultLauncher: ActivityResultLauncher<Intent>

    var originalBottomPadding = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCategoriesManiyaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        updateWindow()
        originalBottomPadding = binding.scrollView.paddingBottom

        // Register the ActivityResultLauncher
        activityResultLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                Log.d("ActivityResultContracts+++++", "------")
                returnResult()
            }
        }
        init()
    }
    private fun returnResult() {
        val resultIntent = Intent()
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }

    private fun init() {
        setSearchDataView()
        showToolbarBar()
    }
    private fun showSearchBar() {
        binding.llSearchView.visible()
        binding.rlToolbar.gone()
        setDimViews()
    }
    private fun showToolbarBar() {
        binding.rlToolbar.visible()
        binding.llSearchView.gone()
        binding.edtSearch.text.clear()
        binding.scrollView.requestChildFocus(binding.tvIDs, binding.tvIDs)
        resetDimViews()
    }
    private fun setSearchDataView() {
        views = listOf(
            Pair(binding.llLicence, binding.tvLicence),
            Pair(binding.llPassport,binding.tvPassport),
            Pair(binding.llIdentity,binding.tvIdentity),
            Pair(binding.llVoterID,binding.tvVoter),
            Pair(binding.llAdhar,binding.tvAdhar),
            Pair(binding.llResidence,binding.tvResidence),
            Pair(binding.llPaymentCard,binding.tvPaymentCard),
            Pair(binding.llDebitCard,binding.tvDebitCard),
            Pair(binding.llPanCard,binding.tvPanCard),
            Pair(binding.llGiftCard,binding.tvGiftCard),
            Pair(binding.llLoyaltyCard,binding.tvLoyaltyCard),
            Pair(binding.llMembershipCard,binding.tvMembershipCard),
            Pair(binding.llMedicalCard,binding.tvMedicalCard),
            Pair(binding.llHealthInsuranceCard,binding.tvHealthInsuranceCard),
            Pair(binding.llBirthCard,binding.tvBirthCard),
            Pair(binding.llMrgCard,binding.tvMrgCard),
            Pair(binding.llVehicleCard,binding.tvVehicleCard),
            Pair(binding.llSIMCard,binding.tvSIMCard),
            Pair(binding.llPasswordCard,binding.tvPasswordCard),
            Pair(binding.llCustom,binding.tvCustomt)
        )

        binding.edtSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(query: CharSequence?, start: Int, before: Int, count: Int) {
                searchByText( query.toString())
            }

            override fun afterTextChanged(s: Editable?) {
            }
        })

    }

    private fun searchByText(searchQuery: String)
    {
        var matchedView: View? = null
        if(searchQuery.trim().isNotEmpty())
        {
        for (view in views)
        {
            if (view.second.text.toString().contains(searchQuery, ignoreCase = true))
            {
                matchedView = view.first
                break
            }
        }
        if (matchedView != null)
        {
            binding.scrollView.post {
                binding. scrollView.requestChildFocus(matchedView, matchedView)
                binding.edtSearch.requestFocus()
            }

            for (view in views) {
                if (view.first == matchedView) {
                    view.first.alpha = 1f // Highlight the matched view
                } else {
                    view.first.alpha = 0.5f // Dim others
                }
            }
        }
        else
        {
            for (view in views)
            {
                view.first.alpha = 0.5f
            }
            binding.scrollView.post {
                binding.scrollView.requestChildFocus(binding.tvCustomt, binding.ivCustom)
                binding.edtSearch.requestFocus()
                binding.llCustom.alpha = 1f
            }
        }
        }
        else{
            for (view in views)
            {
                view.first.alpha = 0.5f

            }
            binding.scrollView.post {
                binding.scrollView.requestChildFocus(binding.tvIDs, binding.tvIDs)
                binding.edtSearch.requestFocus()
            }
        }
    }
    private fun setDimViews()
    {
        for (view in views)
        {
            view.first.alpha = 0.5f

        }
        binding.tvIDs.alpha = 0.5f
        binding.tvPaymentGift.alpha = 0.5f
        binding.tvLoyaltyMembership.alpha = 0.5f
        binding.tvHealthDocument.alpha = 0.5f
        binding.tvCertificates.alpha = 0.5f
        binding.tvSIMPass.alpha = 0.5f
        binding.tvCustom.alpha = 0.5f
    }
    private fun resetDimViews()
    {
        for (view in views)
        {
            view.first.alpha = 1f

        }
        binding.tvIDs.alpha = 1f
        binding.tvPaymentGift.alpha = 1f
        binding.tvLoyaltyMembership.alpha = 1f
        binding.tvHealthDocument.alpha = 1f
        binding.tvCertificates.alpha = 1f
        binding.tvSIMPass.alpha = 1f
        binding.tvCustom.alpha = 1f
    }

    fun onClickLicence(view: View) {
        showRecognizationBottomSheetDialog(this,1,resources.getString(R.string.driver_cat_maniya))
      //  scanByCategoryType(view,resources.getString(R.string.driver_cat_maniya),1,"")
    }

    fun onClickPassportCard(view: View) {
      //  scanByCategoryType(view,resources.getString(R.string.passport_cat_maniya),2,"")
        showRecognizationBottomSheetDialog(this,2,resources.getString(R.string.passport_cat_maniya))

    }

    fun onClickIdentityCard(view: View) {
       // scanByCategoryType(view,resources.getString(R.string.identity_cat_maniya),3,"")
        showRecognizationBottomSheetDialog(this,3,resources.getString(R.string.identity_cat_maniya))

    }
    fun onClickResidenceCard(view: View) {
       // scanByCategoryType(view,resources.getString(R.string.residence_cat_maniya),4,"")
        showRecognizationBottomSheetDialog(this,4,resources.getString(R.string.residence_cat_maniya))

    }
    fun onClickDebitCard(view: View) {
      //  scanByCategoryType(view,resources.getString(R.string.debit_cat_maniya),5,"debit")
        showRecognizationBottomSheetDialog(this,5,resources.getString(R.string.debit_cat_maniya))

    }
    fun onClickCredit(view: View) {
      //  scanByCategoryType(view,resources.getString(R.string.credit_cat_wallet),5,"credit")
        showRecognizationBottomSheetDialog(this,5,resources.getString(R.string.credit_cat_maniya))

    }


    fun onClickGiftCard(view: View) {
      //  scanByCategoryType(view,resources.getString(R.string.gift_cat_maniya),6,"")
        showRecognizationBottomSheetDialog(this,6,resources.getString(R.string.gift_cat_maniya))

    }
    fun onClickLoyaltyCard(view: View) {
       // scanByCategoryType(view,resources.getString(R.string.loyal_cat_maniya),7,"")
        showRecognizationBottomSheetDialog(this,7,resources.getString(R.string.loyal_cat_maniya))

    }
    fun onClickLLMembershipCard(view: View) {
       // scanByCategoryType(view,resources.getString(R.string.member_cat_maniya),8,"")
        showRecognizationBottomSheetDialog(this,8,resources.getString(R.string.member_cat_maniya))

    }
    fun onClickMedicalCard(view: View) {
      //  scanByCategoryType(view,resources.getString(R.string.medical_cat_maniya),9,"")
        showRecognizationBottomSheetDialog(this,9,resources.getString(R.string.medical_cat_maniya))

    }

    fun onClickHealthInsuranceCard(view: View) {
      //  scanByCategoryType(view,resources.getString(R.string.health_cat_maniya),10,"")
        showRecognizationBottomSheetDialog(this,10,resources.getString(R.string.health_cat_maniya))

    }
    fun onClickBirthCard(view: View) {
       // scanByCategoryType(view,resources.getString(R.string.birth_cat_maniya),11,"")
        showRecognizationBottomSheetDialog(this,11,resources.getString(R.string.birth_cat_maniya))

    }

    fun onClickMrgCard(view: View) {
       // scanByCategoryType(view,resources.getString(R.string.mrg_cat_maniya),12,"")
        showRecognizationBottomSheetDialog(this,12,resources.getString(R.string.mrg_cat_maniya))

    }
    fun onClickSIMCard(view: View) {
      //  scanByCategoryType(view,resources.getString(R.string.sim_cat_maniya),13,"")
        showRecognizationBottomSheetDialog(this,13,resources.getString(R.string.sim_cat_maniya))

    }

    fun onClickPasswordCard(view: View) {
      //  scanByCategoryType(view,resources.getString(R.string.password_cat_maniya),14,"")
        showRecognizationBottomSheetDialog(this,14,resources.getString(R.string.password_cat_maniya))

    }

    fun onClickCustom(view: View) {
       // scanByCategoryType(view,resources.getString(R.string.custom_cat_maniya),15,"")
        showRecognizationBottomSheetDialog(this,15,resources.getString(R.string.custom_cat_maniya))

    }

    fun onClickVehicleCard(view: View) {
       // scanByCategoryType(view,resources.getString(R.string.custom_cat_maniya),15,"")
        showRecognizationBottomSheetDialog(this,16,resources.getString(R.string.vehicle_cat_maniya))

    }
    fun onClickAdharCard(view: View) {
        // scanByCategoryType(view,resources.getString(R.string.custom_cat_maniya),15,"")
        showRecognizationBottomSheetDialog(this,17,resources.getString(R.string.adhar_cat_maniya))

    }    fun onClickVoterIDCard(view: View) {
        // scanByCategoryType(view,resources.getString(R.string.custom_cat_maniya),15,"")
        showRecognizationBottomSheetDialog(this,18,resources.getString(R.string.voter_cat_maniya))

    }    fun onClickPanCard(view: View) {
        // scanByCategoryType(view,resources.getString(R.string.custom_cat_maniya),15,"")
        showRecognizationBottomSheetDialog(this,19,resources.getString(R.string.pan_cat_maniya))
    }

    fun onBackClick(view: View) {
        if(binding.llSearchView.isVisible){
            showToolbarBar()
        }else{
      //  onBackPressed()
         returnResult()
        }
    }
    fun onCancelSearchClick(view: View) {
        showToolbarBar()
    }

    fun onClickSearch(view: View) {
        showSearchBar()
    }

    fun scanByCategoryType(view:View,categoryName: String, categoryID: Long,paymentType:String) {
        if(view.alpha==1f){
        val intent = Intent(this@CategoryWalletActivityManiya, ScanTypeActivityManiya::class.java)
        intent.putExtra("category_name", categoryName)
        intent.putExtra("category_id", categoryID)
        startActivity(intent)}
    }

    override fun onResume() {
        super.onResume()
        showNativeAdsSecond()
    }
    fun onCameraScanClick(categoryName: String, categoryID: Long) {
        startActivity(Intent(this@CategoryWalletActivityManiya, ScanCardActivity::class.java)
            .putExtra("category_name", categoryName)
            .putExtra("category_id", categoryID)
            .putExtra("isCamera", true))
    }

    fun onPhotoScanClick(categoryName: String, categoryID: Long) {
        startActivity(Intent(this@CategoryWalletActivityManiya, ScanCardActivity::class.java)
        .putExtra("category_name", categoryName)
        .putExtra("category_id", categoryID)
        .putExtra("isCamera", false))
    }
    fun onSkipScanClick(categoryName: String, categoryID: Long) {
        startActivity(Intent(this@CategoryWalletActivityManiya, CustomActivityManiya::class.java)
            .putExtra("categoryName",categoryName)
            .putExtra("categoryID",categoryID)
        )
    }

    @SuppressLint("SetTextI18n")
    fun showRecognizationBottomSheetDialog(context: Context, categoryID:Long, categoryName:String) {

        val  bottomSheetDialog = BottomSheetDialog(context)
        val dialogBinding = ScanDialogBinding.inflate(bottomSheetDialog.layoutInflater)
        bottomSheetDialog.setContentView(dialogBinding.root)
        bottomSheetDialog.setCancelable(true)
        bottomSheetDialog.setCanceledOnTouchOutside(true)

        dialogBinding.root.setBackgroundResource(R.drawable.bottom_scan_sheet_background)

        dialogBinding.tvScanText.text = dialogBinding.tvScanText.text.toString()+" "+categoryName

        val databaseHelper = DatabaseHelperManiya(this@CategoryWalletActivityManiya)
        val categoriesData = databaseHelper.getSingleCategoryByID(categoryID)

        if (!categoriesData.isNullOrEmpty()) {
            val iconName = categoriesData[0].icon
            val resourceId = resources.getIdentifier(iconName, "drawable", packageName)

            if (resourceId != 0) {
                dialogBinding.ivScanType.setImageResource(resourceId)
            }
        }

        dialogBinding.tvScan.setOnClickListener {
            startActivity(Intent(this@CategoryWalletActivityManiya, ScanCardActivity::class.java)
                .putExtra("category_name", categoryName)
                .putExtra("category_id", categoryID)
                .putExtra("isCamera", true))
            bottomSheetDialog.dismiss()
        }

        dialogBinding.tvPhoto.setOnClickListener {
            startActivity(Intent(this@CategoryWalletActivityManiya, ScanCardActivity::class.java)
                .putExtra("category_name", categoryName)
                .putExtra("category_id", categoryID)
                .putExtra("isCamera", false))
            bottomSheetDialog.dismiss()
        }

            dialogBinding.tvSkip.setOnClickListener {
           /*     GlobalScope.launch(Dispatchers.Main) {*/
                    startActivity(Intent(this@CategoryWalletActivityManiya, CustomActivityManiya::class.java)
                        .putExtra("categoryName", categoryName)
                        .putExtra("categoryID", categoryID))
                    bottomSheetDialog.dismiss()
 /*               }*/
            }

        bottomSheetDialog.show()
    }

}




