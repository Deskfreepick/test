package com.deep.infotech.atm_card_wallet.maniya.model

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import androidx.lifecycle.MutableLiveData
import com.deep.infotech.atm_card_wallet.maniya.dataModel.AdharScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.BirthCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.CategoryDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.CustomScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.GiftCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.HealthCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.IdentityScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LabelDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LicenseScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.LoyaltyCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MedicalCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MemberShipCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.MrgCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PANScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PassportScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PasswordCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.PaymentCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.ResidentScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.SIMCardScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.VehicleScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.dataModel.VoterScanDataManiya
import com.deep.infotech.atm_card_wallet.maniya.ui.ocrScanData.PanViewModel
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper
import com.j256.ormlite.dao.Dao
import com.j256.ormlite.support.ConnectionSource
import com.j256.ormlite.table.TableUtils

class DatabaseHelperManiya(context: Context) : OrmLiteSqliteOpenHelper(
    context,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    companion object {

        private const val DATABASE_NAME = "app_database.db"
        private const val DATABASE_VERSION = 1

    }

    private var labelDataDaoManiya: Dao<LabelDataManiya, Long>? = null
    private var categoryDaoManiya: Dao<CategoryDataManiya, Long>? = null

    private var licenseDaoManiya: Dao<LicenseScanDataManiya, Long>? = null
    private var passportDaoManiya: Dao<PassportScanDataManiya, Long>? = null
    private var idCardDaoManiya: Dao<IdentityScanDataManiya, Long>? = null
    private var residenceDaoManiya: Dao<ResidentScanDataManiya, Long>? = null
    private var paymentDaoManiya: Dao<PaymentCardScanDataManiya, Long>? = null
    private var giftDaoManiya: Dao<GiftCardScanDataManiya, Long>? = null
    private var loyaltyDaoManiya: Dao<LoyaltyCardScanDataManiya, Long>? = null
    private var membershipDaoManiya: Dao<MemberShipCardScanDataManiya, Long>? = null
    private var medicalDaoManiya: Dao<MedicalCardScanDataManiya, Long>? = null
    private var healthDaoManiya: Dao<HealthCardScanDataManiya, Long>? = null
    private var birthDaoManiya: Dao<BirthCardScanDataManiya, Long>? = null
    private var dMrgDaoManiya: Dao<MrgCardScanDataManiya, Long>? = null
    private var dSimDaoManiya: Dao<SIMCardScanDataManiya, Long>? = null
    private var passwordDaoManiya: Dao<PasswordCardScanDataManiya, Long>? = null
    private var customDaoManiya: Dao<CustomScanDataManiya, Long>? = null
    private var vehicleDaoManiya: Dao<VehicleScanDataManiya, Long>? = null
    private var panDaoManiya: Dao<PANScanDataManiya, Long>? = null
    private var adharDaoManiya: Dao<AdharScanDataManiya, Long>? = null
    private var voterDaoManiya: Dao<VoterScanDataManiya, Long>? = null

    /*-------------------------------------    Create   -------------------------*/

    override fun onCreate(database: SQLiteDatabase, connectionSource: ConnectionSource) {
        // Create tables
        TableUtils.createTableIfNotExists(connectionSource, LabelDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, CategoryDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, LicenseScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, PassportScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, IdentityScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, ResidentScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, PaymentCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, GiftCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, LoyaltyCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(
            connectionSource,
            MemberShipCardScanDataManiya::class.java
        )
        TableUtils.createTableIfNotExists(connectionSource, MedicalCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, HealthCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, BirthCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, MrgCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, SIMCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, PasswordCardScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, CustomScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, VehicleScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, PANScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, AdharScanDataManiya::class.java)
        TableUtils.createTableIfNotExists(connectionSource, VoterScanDataManiya::class.java)

    }
    /*-------------------------------------    DROP/UPGRADE   -------------------------*/

    override fun onUpgrade(
        database: SQLiteDatabase,
        connectionSource: ConnectionSource,
        oldVersion: Int,
        newVersion: Int
    ) {
        /*  Drop and recreate tables if database version changes*/

        TableUtils.dropTable<LabelDataManiya, Any>(
            connectionSource,
            LabelDataManiya::class.java,
            true
        )
        TableUtils.dropTable<CategoryDataManiya, Any>(
            connectionSource,
            CategoryDataManiya::class.java,
            true
        )

        TableUtils.dropTable<LicenseScanDataManiya, Any>(
            connectionSource,
            LicenseScanDataManiya::class.java,
            true
        )
        TableUtils.dropTable<PassportScanDataManiya, Any>(
            connectionSource,
            PassportScanDataManiya::class.java,
            true
        )
        TableUtils.dropTable<IdentityScanDataManiya, Any>(
            connectionSource,
            IdentityScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<ResidentScanDataManiya, Any>(
            connectionSource,
            ResidentScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<PaymentCardScanDataManiya, Any>(
            connectionSource,
            PaymentCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<GiftCardScanDataManiya, Any>(
            connectionSource,
            GiftCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<LoyaltyCardScanDataManiya, Any>(
            connectionSource,
            LoyaltyCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<MemberShipCardScanDataManiya, Any>(
            connectionSource,
            MemberShipCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<MedicalCardScanDataManiya, Any>(
            connectionSource,
            MedicalCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<HealthCardScanDataManiya, Any>(
            connectionSource,
            HealthCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<BirthCardScanDataManiya, Any>(
            connectionSource,
            BirthCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<MrgCardScanDataManiya, Any>(
            connectionSource,
            MrgCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<SIMCardScanDataManiya, Any>(
            connectionSource,
            SIMCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<PasswordCardScanDataManiya, Any>(
            connectionSource,
            PasswordCardScanDataManiya::class.java,
            true
        )

        TableUtils.dropTable<CustomScanDataManiya, Any>(
            connectionSource,
            CustomScanDataManiya::class.java,
            true
        )
        TableUtils.dropTable<VehicleScanDataManiya, Any>(
            connectionSource,
            VehicleScanDataManiya::class.java,
            true
        )
        TableUtils.dropTable<AdharScanDataManiya, Any>(
            connectionSource,
            AdharScanDataManiya::class.java,
            true
        )
        TableUtils.dropTable<PANScanDataManiya, Any>(
            connectionSource,
            PANScanDataManiya::class.java,
            true
        )
        TableUtils.dropTable<VoterScanDataManiya, Any>(
            connectionSource,
            VoterScanDataManiya::class.java,
            true
        )


        onCreate(database, connectionSource)
    }
    /*-------------------------------------- DAO ------------------------------------*/

    fun getLabelDao(): Dao<LabelDataManiya, Long> {
        if (labelDataDaoManiya == null) {
            labelDataDaoManiya = getDao(LabelDataManiya::class.java)
        }
        return labelDataDaoManiya!!
    }

    fun getCategoryDao(): Dao<CategoryDataManiya, Long> {
        if (categoryDaoManiya == null) {
            categoryDaoManiya = getDao(CategoryDataManiya::class.java)
        }
        return categoryDaoManiya!!
    }

    fun getLicenceCardDao(): Dao<LicenseScanDataManiya, Long> {
        if (licenseDaoManiya == null) {
            licenseDaoManiya = getDao(LicenseScanDataManiya::class.java)
        }
        return licenseDaoManiya!!
    }

    fun getPassportDao(): Dao<PassportScanDataManiya, Long> {
        if (passportDaoManiya == null) {
            passportDaoManiya = getDao(PassportScanDataManiya::class.java)
        }
        return passportDaoManiya!!

    }

    fun getIDCardDao(): Dao<IdentityScanDataManiya, Long> {
        if (idCardDaoManiya == null) {
            idCardDaoManiya = getDao(IdentityScanDataManiya::class.java)
        }
        return idCardDaoManiya!!
    }

    fun getResidenceCardDao(): Dao<ResidentScanDataManiya, Long> {
        if (residenceDaoManiya == null) {
            residenceDaoManiya = getDao(ResidentScanDataManiya::class.java)
        }
        return residenceDaoManiya!!
    }

    fun getPaymentDao(): Dao<PaymentCardScanDataManiya, Long> {
        if (paymentDaoManiya == null) {
            paymentDaoManiya = getDao(PaymentCardScanDataManiya::class.java)
        }
        return paymentDaoManiya!!
    }

    fun getGiftCardDao(): Dao<GiftCardScanDataManiya, Long> {
        if (giftDaoManiya == null) {
            giftDaoManiya = getDao(GiftCardScanDataManiya::class.java)
        }
        return giftDaoManiya!!
    }

    fun getLoyaltyCardDao(): Dao<LoyaltyCardScanDataManiya, Long> {
        if (loyaltyDaoManiya == null) {
            loyaltyDaoManiya = getDao(LoyaltyCardScanDataManiya::class.java)
        }
        return loyaltyDaoManiya!!
    }

    fun getMemberShipCardDao(): Dao<MemberShipCardScanDataManiya, Long> {
        if (membershipDaoManiya == null) {
            membershipDaoManiya = getDao(MemberShipCardScanDataManiya::class.java)
        }
        return membershipDaoManiya!!
    }

    fun getMedicalCardDao(): Dao<MedicalCardScanDataManiya, Long> {
        if (medicalDaoManiya == null) {
            medicalDaoManiya = getDao(MedicalCardScanDataManiya::class.java)
        }
        return medicalDaoManiya!!
    }

    fun getHealthCardDao(): Dao<HealthCardScanDataManiya, Long> {
        if (healthDaoManiya == null) {
            healthDaoManiya = getDao(HealthCardScanDataManiya::class.java)
        }
        return healthDaoManiya!!
    }

    fun getBirthCardDao(): Dao<BirthCardScanDataManiya, Long> {
        if (birthDaoManiya == null) {
            birthDaoManiya = getDao(BirthCardScanDataManiya::class.java)
        }
        return birthDaoManiya!!
    }

    fun getMrgCardDao(): Dao<MrgCardScanDataManiya, Long> {
        if (dMrgDaoManiya == null) {
            dMrgDaoManiya = getDao(MrgCardScanDataManiya::class.java)
        }
        return dMrgDaoManiya!!
    }

    fun getSIMCardDao(): Dao<SIMCardScanDataManiya, Long> {
        if (dSimDaoManiya == null) {
            dSimDaoManiya = getDao(SIMCardScanDataManiya::class.java)
        }
        return dSimDaoManiya!!
    }

    fun getPasswordCardDao(): Dao<PasswordCardScanDataManiya, Long> {
        if (passwordDaoManiya == null) {
            passwordDaoManiya = getDao(PasswordCardScanDataManiya::class.java)
        }
        return passwordDaoManiya!!
    }

    fun getCustomCardDao(): Dao<CustomScanDataManiya, Long> {
        if (customDaoManiya == null) {
            customDaoManiya = getDao(CustomScanDataManiya::class.java)
        }
        return customDaoManiya!!
    }

    fun getVehicleCardDao(): Dao<VehicleScanDataManiya, Long> {
        if (vehicleDaoManiya == null) {
            vehicleDaoManiya = getDao(VehicleScanDataManiya::class.java)
        }
        return vehicleDaoManiya!!
    }

    fun getAdharCardDao(): Dao<AdharScanDataManiya, Long> {
        if (adharDaoManiya == null) {
            adharDaoManiya = getDao(AdharScanDataManiya::class.java)
        }
        return adharDaoManiya!!
    }

    fun getPANCardDao(): Dao<PANScanDataManiya, Long> {
        if (panDaoManiya == null) {
            panDaoManiya = getDao(PANScanDataManiya::class.java)
        }
        return panDaoManiya!!
    }

    fun getVoterCardDao(): Dao<VoterScanDataManiya, Long> {
        if (voterDaoManiya == null) {
            voterDaoManiya = getDao(VoterScanDataManiya::class.java)
        }
        return voterDaoManiya!!
    }

    /*-------------------------------------------------- Add a new label --------------------------------------------*/
    fun addLabel(label: LabelDataManiya) {
        val labelDao = getLabelDao()
        labelDao.create(label)
    }

    /*------------------------------------------------- -Add a new Category--------------------------------------------*/
    fun addCategory(category: CategoryDataManiya) {
        val categoryDao = getCategoryDao()
        categoryDao.create(category)
    }

    /*--------------------------------------------------    INSERT   --------------------------------------------*/

    fun insertLicenceCard(scanCard: LicenseScanDataManiya) {
        getLicenceCardDao().createOrUpdate(scanCard)
    }

    fun insertPassportCard(scanCard: PassportScanDataManiya) {
        getPassportDao().create(scanCard)
    }

    fun insertIDCard(scanCard: IdentityScanDataManiya) {
        getIDCardDao().create(scanCard)
    }

    fun insertResidenceCard(scanCard: ResidentScanDataManiya) {
        getResidenceCardDao().create(scanCard)
    }

    fun insertPaymentCard(scanCard: PaymentCardScanDataManiya) {
        getPaymentDao().create(scanCard)
    }

    fun insertGiftCard(scanCard: GiftCardScanDataManiya) {
        getGiftCardDao().create(scanCard)
    }

    fun insertLoyaltyCard(scanCard: LoyaltyCardScanDataManiya) {
        getLoyaltyCardDao().create(scanCard)
    }

    fun insertMembershipCard(scanCard: MemberShipCardScanDataManiya) {
        getMemberShipCardDao().create(scanCard)
    }

    fun insertMedicalCard(scanCard: MedicalCardScanDataManiya) {
        getMedicalCardDao().create(scanCard)
    }

    fun insertHealthCard(scanCard: HealthCardScanDataManiya) {
        getHealthCardDao().create(scanCard)
    }

    fun insertBirthCard(scanCard: BirthCardScanDataManiya) {
        getBirthCardDao().create(scanCard)
    }

    fun insertMrgCard(scanCard: MrgCardScanDataManiya) {
        getMrgCardDao().create(scanCard)
    }

    fun insertSIMCard(scanCard: SIMCardScanDataManiya) {
        getSIMCardDao().create(scanCard)
    }

    fun insertPasswordCard(scanCard: PasswordCardScanDataManiya) {
        getPasswordCardDao().create(scanCard)
    }

    fun insertCustomCard(scanCard: CustomScanDataManiya) {
        getCustomCardDao().create(scanCard)
    }

    fun insertVoterCard(scanCard: VoterScanDataManiya) {
        getVoterCardDao().create(scanCard)
    }

    fun insertAdharCard(scanCard: AdharScanDataManiya) {
        getAdharCardDao().create(scanCard)
    }

    fun insertVehicleCard(scanCard: VehicleScanDataManiya) {
        getVehicleCardDao().create(scanCard)
    }

    fun insertPANCard(scanCard: PANScanDataManiya) {
        getPANCardDao().create(scanCard)
    }

    /*--------------------------------------------------  UPDATE  --------------------------------------------*/

    fun updateLicenceCard(scanCard: LicenseScanDataManiya) {
        getLicenceCardDao().update(scanCard)
    }

    fun updatePassportCard(scanCard: PassportScanDataManiya) {
        getPassportDao().update(scanCard)
    }

    fun updateIDCard(scanCard: IdentityScanDataManiya) {
        getIDCardDao().update(scanCard)
    }

    fun updateResidenceCard(scanCard: ResidentScanDataManiya) {
        getResidenceCardDao().update(scanCard)
    }

    fun updatePaymentCard(scanCard: PaymentCardScanDataManiya) {
        getPaymentDao().update(scanCard)
    }

    fun updateGiftCard(scanCard: GiftCardScanDataManiya) {
        getGiftCardDao().update(scanCard)
    }

    fun updateLoyaltyCard(scanCard: LoyaltyCardScanDataManiya) {
        getLoyaltyCardDao().update(scanCard)
    }

    fun updateMembershipCard(scanCard: MemberShipCardScanDataManiya) {
        getMemberShipCardDao().update(scanCard)
    }

    fun updateMedicalCard(scanCard: MedicalCardScanDataManiya) {
        getMedicalCardDao().update(scanCard)
    }

    fun updateHealthCard(scanCard: HealthCardScanDataManiya) {
        getHealthCardDao().update(scanCard)
    }

    fun updateBirthCard(scanCard: BirthCardScanDataManiya) {
        getBirthCardDao().update(scanCard)
    }

    fun updateMrgCard(scanCard: MrgCardScanDataManiya) {
        getMrgCardDao().update(scanCard)
    }

    fun updateSIMCard(scanCard: SIMCardScanDataManiya) {
        getSIMCardDao().update(scanCard)
    }

    fun updatePasswordCard(scanCard: PasswordCardScanDataManiya) {
        getPasswordCardDao().update(scanCard)
    }

    fun updateCustomCard(scanCard: CustomScanDataManiya) {
        getCustomCardDao().update(scanCard)
    }

    fun updateVoterCard(scanCard: VoterScanDataManiya) {
        getVoterCardDao().update(scanCard)
    }

    fun updateAdharCard(scanCard: AdharScanDataManiya) {
        getAdharCardDao().update(scanCard)
    }

    fun updateVehicleCard(scanCard: VehicleScanDataManiya) {
        getVehicleCardDao().update(scanCard)
    }

    fun updatePANCard(scanCard: PANScanDataManiya) {
        getPANCardDao().update(scanCard)
    }

    /*------------------------------------------------- PERCENT-DELETE --------------------------------------------*/
    fun labelDelete(id: Long) {
        val scanCardDao = getLabelDao()
        scanCardDao.deleteById(id)
    }

    fun licenceDelete(id: Long) {
        val scanCardDao = getLicenceCardDao()
        scanCardDao.deleteById(id)
    }

    fun paymentDelete(id: Long) {
        val scanCardDao = getPaymentDao()
        scanCardDao.deleteById(id)
    }

    fun passportDelete(id: Long) {
        val scanCardDao = getPasswordCardDao()
        scanCardDao.deleteById(id)
    }

    fun idCardDelete(id: Long) {
        val scanCardDao = getIDCardDao()
        scanCardDao.deleteById(id)
    }

    fun residenceDelete(id: Long) {
        val scanCardDao = getResidenceCardDao()
        scanCardDao.deleteById(id)
    }

    fun giftDelete(id: Long) {
        val scanCardDao = getGiftCardDao()
        scanCardDao.deleteById(id)
    }

    fun loyaltyDelete(id: Long) {
        val scanCardDao = getLoyaltyCardDao()
        scanCardDao.deleteById(id)
    }

    fun membershipDelete(id: Long) {
        val scanCardDao = getMemberShipCardDao()
        scanCardDao.deleteById(id)
    }

    fun medicalDelete(id: Long) {
        val scanCardDao = getMedicalCardDao()
        scanCardDao.deleteById(id)
    }

    fun healthDelete(id: Long) {
        val scanCardDao = getHealthCardDao()
        scanCardDao.deleteById(id)
    }

    fun birthDelete(id: Long) {
        val scanCardDao = getBirthCardDao()
        scanCardDao.deleteById(id)
    }

    fun mrgDelete(id: Long) {
        val scanCardDao = getMrgCardDao()
        scanCardDao.deleteById(id)
    }

    fun simDelete(id: Long) {
        val scanCardDao = getSIMCardDao()
        scanCardDao.deleteById(id)
    }
    fun passwordDelete(id: Long) {
        val scanCardDao = getPasswordCardDao()
        scanCardDao.deleteById(id)
    }
    fun customDelete(id: Long) {
        val scanCardDao = getCustomCardDao()
        scanCardDao.deleteById(id)
    }
    fun panDelete(id: Long) {
        val scanCardDao = getPANCardDao()
        scanCardDao.deleteById(id)
    }
    fun adharDelete(id: Long) {
        val scanCardDao = getAdharCardDao()
        scanCardDao.deleteById(id)
    }
    fun voterDelete(id: Long) {
        val scanCardDao = getVoterCardDao()
        scanCardDao.deleteById(id)
    }
    fun vehicleDelete(id: Long) {
        val scanCardDao = getVehicleCardDao()
        scanCardDao.deleteById(id)
    }

    /*--------------------------------------------------  DELETE ALL  --------------------------------------------*/
    fun deleteAll() {
        getLabelDao().deleteBuilder().delete()
        getCategoryDao().deleteBuilder().delete()
        getLicenceCardDao().deleteBuilder().delete()
        getPassportDao().deleteBuilder().delete()
        getIDCardDao().deleteBuilder().delete()
        getResidenceCardDao().deleteBuilder().delete()
        getPaymentDao().deleteBuilder().delete()
        getGiftCardDao().deleteBuilder().delete()
        getLoyaltyCardDao().deleteBuilder().delete()
        getMemberShipCardDao().deleteBuilder().delete()
        getMedicalCardDao().deleteBuilder().delete()
        getHealthCardDao().deleteBuilder().delete()
        getBirthCardDao().deleteBuilder().delete()
        getMrgCardDao().deleteBuilder().delete()
        getSIMCardDao().deleteBuilder().delete()
        getPasswordCardDao().deleteBuilder().delete()
        getSIMCardDao().deleteBuilder().delete()
        getPANCardDao().deleteBuilder().delete()
        getVoterCardDao().deleteBuilder().delete()
        getVehicleCardDao().deleteBuilder().delete()
        getAdharCardDao().deleteBuilder().delete()

    }

    /*-------------------------------------------------- SOFT DELETE --------------------------------------------*/
    fun softLicenceDelete(cardId: Long) {

        val licenceCard = getLicenceCardDao().queryForId(cardId)
        licenceCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getLicenceCardDao().update(it)
        }
    }

    fun softPassportDelete(cardId: Long) {
        val passportCard = getPassportDao().queryForId(cardId)
        passportCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getPassportDao().update(it)
        }
    }

    fun softIDCardDelete(cardId: Long) {
        val idCard = getIDCardDao().queryForId(cardId)
        idCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getIDCardDao().update(it)
        }
    }

    fun softResidenceDelete(cardId: Long) {
        val residenceCard = getResidenceCardDao().queryForId(cardId)
        residenceCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getResidenceCardDao().update(it)
        }
    }

    fun softPaymentDelete(cardId: Long) {
        val pamentCard = getPaymentDao().queryForId(cardId)
        pamentCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getPaymentDao().update(it)
        }
    }

    fun softGiftDelete(cardId: Long) {
        val giftCrad = getGiftCardDao().queryForId(cardId)
        giftCrad?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getGiftCardDao().update(it)
        }
    }

    fun softLoyaltyDelete(cardId: Long) {
        val loyaltyCard = getLoyaltyCardDao().queryForId(cardId)
        loyaltyCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getLoyaltyCardDao().update(it)
        }
    }

    fun softMembershipDelete(cardId: Long) {
        val membershipCard = getMemberShipCardDao().queryForId(cardId)
        membershipCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getMemberShipCardDao().update(it)
        }
    }

    fun softMedicalDelete(cardId: Long) {
        val medicalCard = getMedicalCardDao().queryForId(cardId)
        medicalCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getMedicalCardDao().update(it)
        }
    }

    fun softHealthDelete(cardId: Long) {
        val healthCard = getHealthCardDao().queryForId(cardId)
        healthCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getHealthCardDao().update(it)
        }
    }

    fun softBirthDelete(cardId: Long) {
        val birthCard = getBirthCardDao().queryForId(cardId)
        birthCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getBirthCardDao().update(it)
        }
    }

    fun softMrgDelete(cardId: Long) {
        val mrgCard = getMrgCardDao().queryForId(cardId)
        mrgCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getMrgCardDao().update(it)
        }
    }

    fun softSIMDelete(cardId: Long) {
        val simCard = getSIMCardDao().queryForId(cardId)
        simCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getSIMCardDao().update(it)
        }
    }

    fun softPasswordDelete(cardId: Long) {
        val passwordCard = getPasswordCardDao().queryForId(cardId)
        passwordCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getPasswordCardDao().update(it)
        }
    }

    fun softCustomDelete(cardId: Long) {
        val customCard = getCustomCardDao().queryForId(cardId)
        customCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getCustomCardDao().update(it)
        }
    }
    fun softPANDelete(cardId: Long) {
        val customCard = getPANCardDao().queryForId(cardId)
        customCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getPANCardDao().update(it)
        }
    }
    fun softAdharDelete(cardId: Long) {
        val customCard = getAdharCardDao().queryForId(cardId)
        customCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getAdharCardDao().update(it)
        }
    }
    fun softVoterDelete(cardId: Long) {
        val customCard = getVoterCardDao().queryForId(cardId)
        customCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getVoterCardDao().update(it)
        }
    }
    fun softVehicleDelete(cardId: Long) {
        val customCard = getVehicleCardDao().queryForId(cardId)
        customCard?.let {
            it.isDelete = !it.isDelete
            it.isFav = false
            it.isArchive = false
            it.isLock = false
            getVehicleCardDao().update(it)
        }
    }

    /*-------------------------------------------------- FetchByID --------------------------------------------*/


    fun fetchLicensesCardByID(itemID: Long): MutableList<LicenseScanDataManiya> {
        return getLicenceCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()
    }

    fun fetchPassportCardByID(itemID: Long): MutableList<PassportScanDataManiya> {
        return getPassportDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()
    }

    fun fetchIDCardByID(itemID: Long): MutableList<IdentityScanDataManiya> {
        return getIDCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchResidenceCardByID(itemID: Long): MutableList<ResidentScanDataManiya> {
        return getResidenceCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchPaymentCardByID(itemID: Long): MutableList<PaymentCardScanDataManiya> {
        return getPaymentDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchGiftCardByID(itemID: Long): MutableList<GiftCardScanDataManiya> {
        return getGiftCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchLoyaltyCardByID(itemID: Long): MutableList<LoyaltyCardScanDataManiya> {
        return getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchMemberShipCardByID(itemID: Long): MutableList<MemberShipCardScanDataManiya> {
        return getMemberShipCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchMedicalCardByID(itemID: Long): MutableList<MedicalCardScanDataManiya> {
        return getMedicalCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchHealthCardByID(itemID: Long): MutableList<HealthCardScanDataManiya> {
        return getHealthCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchBirthCardByID(itemID: Long): MutableList<BirthCardScanDataManiya> {
        return getBirthCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchMrgCardByID(itemID: Long): MutableList<MrgCardScanDataManiya> {
        return getMrgCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }

    fun fetchSIMCardByID(itemID: Long): MutableList<SIMCardScanDataManiya> {
        return getSIMCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }
    fun fetchPasswordCardByID(itemID: Long): MutableList<PasswordCardScanDataManiya> {
        return getPasswordCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }
    fun fetchCustomCardByID(itemID: Long): MutableList<CustomScanDataManiya> {
        return getCustomCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }
    fun fetchPANCardByID(itemID: Long): MutableList<PANScanDataManiya> {
        return getPANCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }
    fun fetchAdharCardByID(itemID: Long): MutableList<AdharScanDataManiya> {
        return getAdharCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }
    fun fetchVehicleCardByID(itemID: Long): MutableList<VehicleScanDataManiya> {
        return getVehicleCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }
    fun fetchVoterCardByID(itemID: Long): MutableList<VoterScanDataManiya> {
        return getVoterCardDao().queryBuilder()
            .where()
            .eq("id", itemID)
            .query()

    }


    /*-------------------------------------------------- FetchByLabel --------------------------------------------*/
    fun fetchLicensesByLabelID(labelID: Long): MutableList<LicenseScanDataManiya> {
        return getLicenceCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()
    }

    fun fetchPassportByLabelID(labelID: Long): MutableList<PassportScanDataManiya> {
        return getPassportDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()
    }

    fun fetchIDCardByLabelID(labelID: Long): MutableList<IdentityScanDataManiya> {
        return getIDCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchResidenceCardByLabelID(labelID: Long): MutableList<ResidentScanDataManiya> {
        return getResidenceCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchPaymentByLabelID(labelID: Long): MutableList<PaymentCardScanDataManiya> {
        return getPaymentDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchGiftByLabelID(labelID: Long): MutableList<GiftCardScanDataManiya> {
        return getGiftCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchLoyaltyByLabelID(labelID: Long): MutableList<LoyaltyCardScanDataManiya> {
        return getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchMemberShipByLabelID(labelID: Long): MutableList<MemberShipCardScanDataManiya> {
        return getMemberShipCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchMedicalByLabelID(labelID: Long): MutableList<MedicalCardScanDataManiya> {
        return getMedicalCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchHealthByLabelID(labelID: Long): MutableList<HealthCardScanDataManiya> {
        return getHealthCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchBirthByLabelID(labelID: Long): MutableList<BirthCardScanDataManiya> {
        return getBirthCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchMrgByLabelID(labelID: Long): MutableList<MrgCardScanDataManiya> {
        return getMrgCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchSIMByLabelID(labelID: Long): MutableList<SIMCardScanDataManiya> {
        return getSIMCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchPasswordByLabelID(labelID: Long): MutableList<PasswordCardScanDataManiya> {
        return getPasswordCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }

    fun fetchCustomByLabelID(labelID: Long): MutableList<CustomScanDataManiya> {
        return getCustomCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }
    fun fetchPANByLabelID(labelID: Long): MutableList<PANScanDataManiya> {
        return getPANCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }
    fun fetchAdharByLabelID(labelID: Long): MutableList<AdharScanDataManiya> {
        return getAdharCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }
    fun fetchVoterByLabelID(labelID: Long): MutableList<VoterScanDataManiya> {
        return getVoterCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }
    fun fetchVehicleByLabelID(labelID: Long): MutableList<VehicleScanDataManiya> {
        return getVehicleCardDao().queryBuilder()
            .where()
            .eq("label_id", labelID)
            .query()

    }


    /*-------------------------------------------------- FetchAllData --------------------------------------------*/

    fun fetchAllLabels(): List<LabelDataManiya> {
        return getLabelDao().queryForAll()
    }

    fun fetchAllCategories(): List<CategoryDataManiya> {
        return getCategoryDao().queryForAll()
    }

    fun fetchLicenceData(): MutableList<LicenseScanDataManiya> {
        return getLicenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchLicenceDataLIVE(): MutableLiveData<MutableList<LicenseScanDataManiya>> {
        val liveData = MutableLiveData<MutableList<LicenseScanDataManiya>>()

        val licenceData = getLicenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

        liveData.postValue(licenceData)

        return liveData
    }

    fun fetchPassportData(): MutableList<PassportScanDataManiya> {
        return getPassportDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchIDCardData(): MutableList<IdentityScanDataManiya> {
        return getIDCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchResidenceCardData(): MutableList<ResidentScanDataManiya> {
        return getResidenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchPaymentData(): MutableList<PaymentCardScanDataManiya> {
        return getPaymentDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchGiftData(): MutableList<GiftCardScanDataManiya> {
        return getGiftCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchLoyaltyData(): MutableList<LoyaltyCardScanDataManiya> {
        return getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchMemberShipData(): MutableList<MemberShipCardScanDataManiya> {
        return getMemberShipCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchMedicalData(): MutableList<MedicalCardScanDataManiya> {
        return getMedicalCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchHealthData(): MutableList<HealthCardScanDataManiya> {
        return getHealthCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchBirthData(): MutableList<BirthCardScanDataManiya> {
        return getBirthCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchMrgData(): MutableList<MrgCardScanDataManiya> {
        return getMrgCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchSIMData(): MutableList<SIMCardScanDataManiya> {
        return getSIMCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchPasswordData(): MutableList<PasswordCardScanDataManiya> {
        return getPasswordCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    fun fetchCustomData(): MutableList<CustomScanDataManiya> {
        return getCustomCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }
    fun fetchPANData(): MutableList<PANScanDataManiya> {
        return getPANCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }
    fun fetchAdharData(): MutableList<AdharScanDataManiya> {
        return getAdharCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }
    fun fetchVoterData(): MutableList<VoterScanDataManiya> {
        return getVoterCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }
    fun fetchVehicleData(): MutableList<VehicleScanDataManiya> {
        return getVehicleCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .query()

    }

    /*-------------------------------------------------- LOCKED Data --------------------------------------------*/
    fun fetchLockedLicenceData(): MutableList<LicenseScanDataManiya> {
        return getLicenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedPassportData(): MutableList<PassportScanDataManiya> {
        return getPassportDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedIDCardData(): MutableList<IdentityScanDataManiya> {
        return getIDCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedResidenceCardData(): MutableList<ResidentScanDataManiya> {
        return getResidenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedPaymentData(): MutableList<PaymentCardScanDataManiya> {
        return getPaymentDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedGiftData(): MutableList<GiftCardScanDataManiya> {
        return getGiftCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedLoyaltyData(): MutableList<LoyaltyCardScanDataManiya> {
        return getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedMemberShipData(): MutableList<MemberShipCardScanDataManiya> {
        return getMemberShipCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedMedicalData(): MutableList<MedicalCardScanDataManiya> {
        return getMedicalCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedHealthData(): MutableList<HealthCardScanDataManiya> {
        return getHealthCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedBirthData(): MutableList<BirthCardScanDataManiya> {
        return getBirthCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedMrgData(): MutableList<MrgCardScanDataManiya> {
        return getMrgCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedSIMData(): MutableList<SIMCardScanDataManiya> {
        return getSIMCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedPasswordData(): MutableList<PasswordCardScanDataManiya> {
        return getPasswordCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedCustomData(): MutableList<CustomScanDataManiya> {
        return getCustomCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }

    fun fetchLockedPANData(): MutableList<PANScanDataManiya> {
        return getPANCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }
    fun fetchLockedAdharData(): MutableList<AdharScanDataManiya> {
        return getAdharCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }
    fun fetchLockedVoterData(): MutableList<VoterScanDataManiya> {
        return getVoterCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }
    fun fetchLockedVehicleData(): MutableList<VehicleScanDataManiya> {
        return getVehicleCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isLock", true)
            .query()

    }


    /*-------------------------------------------------- FAVOURITE Data --------------------------------------------*/

    fun fetchFavouriteLicenceData(): MutableList<LicenseScanDataManiya> {
        return getLicenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouritePassportData(): MutableList<PassportScanDataManiya> {
        return getPassportDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteIDCardData(): MutableList<IdentityScanDataManiya> {
        return getIDCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteResidenceCardData(): MutableList<ResidentScanDataManiya> {
        return getResidenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouritePaymentData(): MutableList<PaymentCardScanDataManiya> {
        return getPaymentDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteGiftData(): MutableList<GiftCardScanDataManiya> {
        return getGiftCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteLoyaltyData(): MutableList<LoyaltyCardScanDataManiya> {
        return getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteMemberShipData(): MutableList<MemberShipCardScanDataManiya> {
        return getMemberShipCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteMedicalData(): MutableList<MedicalCardScanDataManiya> {
        return getMedicalCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteHealthData(): MutableList<HealthCardScanDataManiya> {
        return getHealthCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteBirthData(): MutableList<BirthCardScanDataManiya> {
        return getBirthCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteMrgData(): MutableList<MrgCardScanDataManiya> {
        return getMrgCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteSIMData(): MutableList<SIMCardScanDataManiya> {
        return getSIMCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouritePasswordData(): MutableList<PasswordCardScanDataManiya> {
        return getPasswordCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }

    fun fetchFavouriteCustomData(): MutableList<CustomScanDataManiya> {
        return getCustomCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }
    fun fetchFavouritePANData(): MutableList<PANScanDataManiya> {
        return getPANCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }
    fun fetchFavouriteAdharData(): MutableList<AdharScanDataManiya> {
        return getAdharCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }
    fun fetchFavouriteVoterData(): MutableList<VoterScanDataManiya> {
        return getVoterCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }
    fun fetchFavouriteVehicleData(): MutableList<VehicleScanDataManiya> {
        return getVehicleCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", false)
            .and()
            .eq("isFav", true)
            .query()

    }


    /*-------------------------------------------------- Archive Data --------------------------------------------*/

    fun fetchArchivedLicenceData(): MutableList<LicenseScanDataManiya> {
        return getLicenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedPassportData(): MutableList<PassportScanDataManiya> {
        return getPassportDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedIDCardData(): MutableList<IdentityScanDataManiya> {
        return getIDCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedResidenceCardData(): MutableList<ResidentScanDataManiya> {
        return getResidenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedPaymentData(): MutableList<PaymentCardScanDataManiya> {
        return getPaymentDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedGiftData(): MutableList<GiftCardScanDataManiya> {
        return getGiftCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedLoyaltyData(): MutableList<LoyaltyCardScanDataManiya> {
        return getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedMemberShipData(): MutableList<MemberShipCardScanDataManiya> {
        return getMemberShipCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedMedicalData(): MutableList<MedicalCardScanDataManiya> {
        return getMedicalCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedHealthData(): MutableList<HealthCardScanDataManiya> {
        return getHealthCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedBirthData(): MutableList<BirthCardScanDataManiya> {
        return getBirthCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedMrgData(): MutableList<MrgCardScanDataManiya> {
        return getMrgCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedSIMData(): MutableList<SIMCardScanDataManiya> {
        return getSIMCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedPasswordData(): MutableList<PasswordCardScanDataManiya> {
        return getPasswordCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }

    fun fetchArchivedCustomData(): MutableList<CustomScanDataManiya> {
        return getCustomCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }
    fun fetchArchivedPANData(): MutableList<PANScanDataManiya> {
        return getPANCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }
    fun fetchArchivedAdharData(): MutableList<AdharScanDataManiya> {
        return getAdharCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }
    fun fetchArchivedVoterData(): MutableList<VoterScanDataManiya> {
        return getVoterCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }
    fun fetchArchivedVehicleData(): MutableList<VehicleScanDataManiya> {
        return getVehicleCardDao().queryBuilder()
            .where()
            .eq("isDelete", false)
            .and()
            .eq("isArchive", true)
            .query()

    }


    /*-------------------------------------------------- Delete Data --------------------------------------------*/

    fun fetchDeletedLicenceData(): MutableList<LicenseScanDataManiya> {
        return getLicenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedPassportData(): MutableList<PassportScanDataManiya> {
        return getPassportDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedIDCardData(): MutableList<IdentityScanDataManiya> {
        return getIDCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedResidenceCardData(): MutableList<ResidentScanDataManiya> {
        return getResidenceCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedPaymentData(): MutableList<PaymentCardScanDataManiya> {
        return getPaymentDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedGiftData(): MutableList<GiftCardScanDataManiya> {
        return getGiftCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedLoyaltyData(): MutableList<LoyaltyCardScanDataManiya> {
        return getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedMemberShipData(): MutableList<MemberShipCardScanDataManiya> {
        return getMemberShipCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedMedicalData(): MutableList<MedicalCardScanDataManiya> {
        return getMedicalCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedHealthData(): MutableList<HealthCardScanDataManiya> {
        return getHealthCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedBirthData(): MutableList<BirthCardScanDataManiya> {
        return getBirthCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedMrgData(): MutableList<MrgCardScanDataManiya> {
        return getMrgCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedSIMData(): MutableList<SIMCardScanDataManiya> {
        return getSIMCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedPasswordData(): MutableList<PasswordCardScanDataManiya> {
        return getPasswordCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }

    fun fetchDeletedCustomData(): MutableList<CustomScanDataManiya> {
        return getCustomCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }
    fun fetchDeletedPANData(): MutableList<PANScanDataManiya> {
        return getPANCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }
    fun fetchDeletedAdharData(): MutableList<AdharScanDataManiya> {
        return getAdharCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }
    fun fetchDeletedVoterData(): MutableList<VoterScanDataManiya> {
        return getVoterCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }
    fun fetchDeletedVehicleData(): MutableList<VehicleScanDataManiya> {
        return getVehicleCardDao().queryBuilder()
            .where()
            .eq("isDelete", true)
            .query()
    }


    /*------------------------------------------------- Toggle Favourited Data------------------------------------------*/

    fun toggleLicenceFavorite(cardId: Long) {
        val scanCard = getLicenceCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getLicenceCardDao().update(it)
        }
    }

    fun togglePassportFavorite(cardId: Long) {
        val scanCard = getPassportDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getPassportDao().update(it)
        }
    }

    fun toggleIDCardFavorite(cardId: Long) {
        val scanCard = getIDCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getIDCardDao().update(it)
        }
    }

    fun toggleResidenceFavorite(cardId: Long) {
        val scanCard = getResidenceCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getResidenceCardDao().update(it)
        }
    }

    fun togglePaymentFavorite(cardId: Long) {
        val scanCard = getPaymentDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getPaymentDao().update(it)
        }
    }

    fun toggleGiftFavorite(cardId: Long) {
        val scanCard = getGiftCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getGiftCardDao().update(it)
        }
    }

    fun toggleLoyaltyFavorite(cardId: Long) {
        val scanCard = getLoyaltyCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getLoyaltyCardDao().update(it)
        }
    }

    fun toggleMembershipFavorite(cardId: Long) {
        val scanCard = getMemberShipCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getMemberShipCardDao().update(it)
        }
    }

    fun toggleMedicalFavorite(cardId: Long) {
        val scanCard = getMedicalCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getMedicalCardDao().update(it)
        }
    }

    fun toggleHealthFavorite(cardId: Long) {
        val scanCard = getHealthCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getHealthCardDao().update(it)
        }
    }

    fun toggleBirthFavorite(cardId: Long) {
        val scanCard = getBirthCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getBirthCardDao().update(it)
        }
    }

    fun toggleMrgFavorite(cardId: Long) {
        val scanCard = getMrgCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getMrgCardDao().update(it)
        }
    }

    fun toggleSIMFavorite(cardId: Long) {
        val scanCard = getSIMCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getSIMCardDao().update(it)
        }
    }

    fun togglePasswordFavorite(cardId: Long) {
        val scanCard = getPasswordCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getPasswordCardDao().update(it)
        }
    }

    fun toggleCustomFavorite(cardId: Long) {
        val scanCard = getCustomCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getCustomCardDao().update(it)
        }
    }

    fun togglePANFavorite(cardId: Long) {
        val scanCard = getPANCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getPANCardDao().update(it)
        }
    }
    fun toggleAdharFavorite(cardId: Long) {
        val scanCard = getAdharCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getAdharCardDao().update(it)
        }
    }
    fun toggleVoterFavorite(cardId: Long) {
        val scanCard = getVoterCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getVoterCardDao().update(it)
        }
    }
    fun toggleVehicleFavorite(cardId: Long) {
        val scanCard = getVehicleCardDao().queryForId(cardId)
        scanCard?.let {
            it.isFav = !it.isFav
            getVehicleCardDao().update(it)
        }
    }


    /*------------------------------------------------- Toggle Archived Data ------------------------------------------*/

    fun toggleLicenceArchive(cardId: Long) {
        val scanCard = getLicenceCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getLicenceCardDao().update(it)
        }
    }

    fun togglePassportArchive(cardId: Long) {
        val scanCard = getPassportDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getPassportDao().update(it)
        }
    }

    fun toggleIDCardArchive(cardId: Long) {
        val scanCard = getIDCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getIDCardDao().update(it)
        }
    }

    fun toggleResidenceArchive(cardId: Long) {
        val scanCard = getResidenceCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getResidenceCardDao().update(it)
        }
    }

    fun togglePaymentArchive(cardId: Long) {
        val scanCard = getPaymentDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getPaymentDao().update(it)
        }
    }

    fun toggleGiftArchive(cardId: Long) {
        val scanCard = getGiftCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getGiftCardDao().update(it)
        }
    }

    fun toggleLoyaltyArchive(cardId: Long) {
        val scanCard = getLoyaltyCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getLoyaltyCardDao().update(it)
        }
    }

    fun toggleMembershipArchive(cardId: Long) {
        val scanCard = getMemberShipCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getMemberShipCardDao().update(it)
        }
    }

    fun toggleMedicalArchive(cardId: Long) {
        val scanCard = getMedicalCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getMedicalCardDao().update(it)
        }
    }

    fun toggleHealthArchive(cardId: Long) {
        val scanCard = getHealthCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getHealthCardDao().update(it)
        }
    }

    fun toggleBirthArchive(cardId: Long) {
        val scanCard = getBirthCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getBirthCardDao().update(it)
        }
    }

    fun toggleMrgArchive(cardId: Long) {
        val scanCard = getMrgCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getMrgCardDao().update(it)
        }
    }

    fun toggleSIMArchive(cardId: Long) {
        val scanCard = getSIMCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getSIMCardDao().update(it)
        }
    }

    fun togglePasswordArchive(cardId: Long) {
        val scanCard = getPasswordCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getPasswordCardDao().update(it)
        }
    }

    fun toggleCustomArchive(cardId: Long) {
        val scanCard = getCustomCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getCustomCardDao().update(it)
        }
    }
    fun togglePANArchive(cardId: Long) {
        val scanCard = getPANCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getPANCardDao().update(it)
        }
    }
    fun toggleAdharArchive(cardId: Long) {
        val scanCard = getAdharCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getAdharCardDao().update(it)
        }
    }
    fun toggleVehicleArchive(cardId: Long) {
        val scanCard = getVehicleCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getVehicleCardDao().update(it)
        }
    }
    fun toggleVoterArchive(cardId: Long) {
        val scanCard = getVoterCardDao().queryForId(cardId)
        scanCard?.let {
            it.isArchive = !it.isArchive
            getVoterCardDao().update(it)
        }
    }

    /*------------------------------------------------- Toggle Locked Data ------------------------------------------*/

    fun toggleLicenceLock(cardId: Long) {
        val scanCard = getLicenceCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getLicenceCardDao().update(it)
        }
    }

    fun togglePassportLock(cardId: Long) {
        val scanCard = getPassportDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getPassportDao().update(it)
        }
    }

    fun toggleIDCardLock(cardId: Long) {
        val scanCard = getIDCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getIDCardDao().update(it)
        }
    }

    fun toggleResidenceLock(cardId: Long) {
        val scanCard = getResidenceCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getResidenceCardDao().update(it)
        }
    }

    fun togglePaymentLock(cardId: Long) {
        val scanCard = getPaymentDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getPaymentDao().update(it)
        }
    }

    fun togglePaymentSensitive(cardId: Long) {
        val scanCard = getPaymentDao().queryForId(cardId)
        scanCard?.let {
            it.isSensitive = !it.isSensitive
            getPaymentDao().update(it)
        }
    }

    fun toggleLicenceSensitive(cardId: Long) {
        val scanCard = getLicenceCardDao().queryForId(cardId)
        scanCard?.let {
            it.isSensitive = !it.isSensitive
            getLicenceCardDao().update(it)
        }
    }

    fun toggleGiftLock(cardId: Long) {
        val scanCard = getGiftCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getGiftCardDao().update(it)
        }
    }

    fun toggleLoyaltyLock(cardId: Long) {
        val scanCard = getLoyaltyCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getLoyaltyCardDao().update(it)
        }
    }

    fun toggleMembershipLock(cardId: Long) {
        val scanCard = getMemberShipCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getMemberShipCardDao().update(it)
        }
    }

    fun toggleMedicalLock(cardId: Long) {
        val scanCard = getMedicalCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getMedicalCardDao().update(it)
        }
    }

    fun toggleHealthLock(cardId: Long) {
        val scanCard = getHealthCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getHealthCardDao().update(it)
        }
    }

    fun toggleBirthLock(cardId: Long) {
        val scanCard = getBirthCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getBirthCardDao().update(it)
        }
    }

    fun toggleMrgLock(cardId: Long) {
        val scanCard = getMrgCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getMrgCardDao().update(it)
        }
    }

    fun toggleSIMLock(cardId: Long) {
        val scanCard = getSIMCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getSIMCardDao().update(it)
        }
    }

    fun togglePasswordLock(cardId: Long) {
        val scanCard = getPasswordCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getPasswordCardDao().update(it)
        }
    }

    fun toggleCustomLock(cardId: Long) {
        val scanCard = getCustomCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getCustomCardDao().update(it)
        }
    }
    fun togglePANLock(cardId: Long) {
        val scanCard = getPANCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getPANCardDao().update(it)
        }
    }

    fun toggleAdharLock(cardId: Long) {
        val scanCard = getAdharCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getAdharCardDao().update(it)
        }
    }
    fun toggleVoterLock(cardId: Long) {
        val scanCard = getVoterCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getVoterCardDao().update(it)
        }
    }
    fun toggleVehicleLock(cardId: Long) {
        val scanCard = getVehicleCardDao().queryForId(cardId)
        scanCard?.let {
            it.isLock = !it.isLock
            getVehicleCardDao().update(it)
        }
    }

    /*------------------------------------------------- Fetch Unique Labels ------------------------------------------*/

    fun fetchUniqueLabels(): List<LabelDataManiya> {
        val labelList = mutableListOf<LabelDataManiya>()
        for (license in getLicenceCardDao().queryForAll()) {
            license.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (passport in getPassportDao().queryForAll()) {
            passport.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (idCard in getIDCardDao().queryForAll()) {
            idCard.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (residence in getResidenceCardDao().queryForAll()) {
            residence.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (payment in getPaymentDao().queryForAll()) {
            payment.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (gift in getGiftCardDao().queryForAll()) {
            gift.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }

        for (loyalty in getLoyaltyCardDao().queryForAll()) {
            loyalty.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }


        for (membership in getMemberShipCardDao().queryForAll()) {
            membership.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }

        for (medical in getMedicalCardDao().queryForAll()) {
            medical.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }

        for (health in getHealthCardDao().queryForAll()) {
            health.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (birth in getBirthCardDao().queryForAll()) {
            birth.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (mrg in getMrgCardDao().queryForAll()) {
            mrg.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (sim in getSIMCardDao().queryForAll()) {
            sim.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (password in getPasswordCardDao().queryForAll()) {
            password.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (custom in getCustomCardDao().queryForAll()) {
            custom.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (pan in getPANCardDao().queryForAll()) {
            pan.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (adhar in getAdharCardDao().queryForAll()) {
            adhar.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (voter in getVoterCardDao().queryForAll()) {
            voter.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        for (vehicle in getVehicleCardDao().queryForAll()) {
            vehicle.label?.let { label ->
                if (!labelList.contains(label)) {
                    labelList.add(label)
                }
            }
        }
        return labelList
    }

    /*------------------------------------------------- OTHERS Operations ------------------------------------------*/

    fun getSingleCategoryByID(cardId: Long): MutableList<CategoryDataManiya>? {
        return getCategoryDao().queryBuilder()
            .where()
            .eq("id", cardId)
            .query()
    }

    fun getLabelByID(labelId: Long): MutableList<LabelDataManiya> {
        return getLabelDao().queryBuilder()
            .where()
            .eq("id", labelId)
            .query()
    }

    /*------------------------------------------------- Fetch LastRecord ------------------------------------------*/

    fun fetchLastLabelRecord(): LabelDataManiya {
        return getLabelDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastLicenceRecord(): LicenseScanDataManiya {
        return getLicenceCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastPassportRecord(): PassportScanDataManiya {
        return getPassportDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastIDCardRecord(): IdentityScanDataManiya {
        return getIDCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastResidenceCardRecord(): ResidentScanDataManiya {
        return getResidenceCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastPaymentRecord(): PaymentCardScanDataManiya {
        return getPaymentDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastGiftCardRecord(): GiftCardScanDataManiya {
        return getGiftCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastLoyaltyCardRecord(): LoyaltyCardScanDataManiya {
        return getLoyaltyCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastMembershipCardRecord(): MemberShipCardScanDataManiya {
        return getMemberShipCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastMedicalCardRecord(): MedicalCardScanDataManiya {
        return getMedicalCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastHealthCardRecord(): HealthCardScanDataManiya {
        return getHealthCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastBirthCardRecord(): BirthCardScanDataManiya {
        return getBirthCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastMrgCardRecord(): MrgCardScanDataManiya {
        return getMrgCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastSIMCardRecord(): SIMCardScanDataManiya {
        return getSIMCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastPasswordCardRecord(): PasswordCardScanDataManiya {
        return getPasswordCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    fun fetchLastCustomCardRecord(): CustomScanDataManiya {
        return getCustomCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }
    fun fetchLastPANCardRecord(): PANScanDataManiya {
        return getPANCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }
    fun fetchLastAdharCardRecord(): AdharScanDataManiya {
        return getAdharCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }
    fun fetchLastVoterCardRecord(): VoterScanDataManiya {
        return getVoterCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }
    fun fetchLastVehicleCardRecord(): VehicleScanDataManiya {
        return getVehicleCardDao().queryBuilder()
            .orderBy("id", false)
            .queryForFirst()

    }

    /*-------------------------------------------------update label by ID ------------------------------------------*/


    fun updateLicenceLabel(licenceID: Long, newLabel: LabelDataManiya?) {
        getLicenceCardDao().queryBuilder()
            .where()
            .eq("id", licenceID)
            .query()
        val licence = getLicenceCardDao().queryBuilder()
            .where()
            .eq("id", licenceID)
            .queryForFirst()

        if (licence != null) {
            licence.label = newLabel
            getLicenceCardDao().update(licence)
        }
    }

    fun updatePassportabel(passportID: Long, newLabel: LabelDataManiya?) {
        getPassportDao().queryBuilder()
            .where()
            .eq("id", passportID)
            .query()
        val passport = getPassportDao().queryBuilder()
            .where()
            .eq("id", passportID)
            .queryForFirst()

        if (passport != null) {
            passport.label = newLabel
            getPassportDao().update(passport)
        }
    }

    fun updateIDCardLabel(idCard: Long, newLabel: LabelDataManiya?) {
        getIDCardDao().queryBuilder()
            .where()
            .eq("id", idCard)
            .query()
        val idCardd = getIDCardDao().queryBuilder()
            .where()
            .eq("id", idCard)
            .queryForFirst()

        if (idCardd != null) {
            idCardd.label = newLabel
            getIDCardDao().update(idCardd)
        }
    }

    fun updateResidenceCardLabel(residenceID: Long, newLabel: LabelDataManiya?) {
        getResidenceCardDao().queryBuilder()
            .where()
            .eq("id", residenceID)
            .query()
        val residence = getResidenceCardDao().queryBuilder()
            .where()
            .eq("id", residenceID)
            .queryForFirst()

        if (residence != null) {
            residence.label = newLabel
            getResidenceCardDao().update(residence)
        }
    }

    fun updatePaymentCardLabel(paymentID: Long, newLabel: LabelDataManiya?) {
        getPaymentDao().queryBuilder()
            .where()
            .eq("id", paymentID)
            .query()
        val payment = getPaymentDao().queryBuilder()
            .where()
            .eq("id", paymentID)
            .queryForFirst()

        if (payment != null) {
            payment.label = newLabel
            getPaymentDao().update(payment)
        }
    }

    fun updateGiftCardLabel(giftID: Long, newLabel: LabelDataManiya?) {
        getGiftCardDao().queryBuilder()
            .where()
            .eq("id", giftID)
            .query()
        val giftCard = getGiftCardDao().queryBuilder()
            .where()
            .eq("id", giftID)
            .queryForFirst()

        if (giftCard != null) {
            giftCard.label = newLabel
            getGiftCardDao().update(giftCard)
        }
    }

    fun updateLoyaltyCardLabel(loyaltyID: Long, newLabel: LabelDataManiya?) {
        getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("id", loyaltyID)
            .query()
        val loyalty = getLoyaltyCardDao().queryBuilder()
            .where()
            .eq("id", loyaltyID)
            .queryForFirst()

        if (loyalty != null) {
            loyalty.label = newLabel
            getLoyaltyCardDao().update(loyalty)
        }
    }

    fun updateMembershipCardLabel(membershipID: Long, newLabel: LabelDataManiya?) {
        getMemberShipCardDao().queryBuilder()
            .where()
            .eq("id", membershipID)
            .query()
        val memberShip = getMemberShipCardDao().queryBuilder()
            .where()
            .eq("id", membershipID)
            .queryForFirst()

        if (memberShip != null) {
            memberShip.label = newLabel
            getMemberShipCardDao().update(memberShip)
        }
    }

    fun updateMedicalCardLabel(medicalID: Long, newLabel: LabelDataManiya?) {
        getMedicalCardDao().queryBuilder()
            .where()
            .eq("id", medicalID)
            .query()
        val medicalCard = getMedicalCardDao().queryBuilder()
            .where()
            .eq("id", medicalID)
            .queryForFirst()

        if (medicalCard != null) {
            medicalCard.label = newLabel
            getMedicalCardDao().update(medicalCard)
        }
    }

    fun updateHealthCardLabel(healthID: Long, newLabel: LabelDataManiya?) {
        getHealthCardDao().queryBuilder()
            .where()
            .eq("id", healthID)
            .query()
        val healthCard = getHealthCardDao().queryBuilder()
            .where()
            .eq("id", healthID)
            .queryForFirst()

        if (healthCard != null) {
            healthCard.label = newLabel
            getHealthCardDao().update(healthCard)
        }
    }

    fun updateBirthCardLabel(birthID: Long, newLabel: LabelDataManiya?) {
        getBirthCardDao().queryBuilder()
            .where()
            .eq("id", birthID)
            .query()
        val birthCard = getBirthCardDao().queryBuilder()
            .where()
            .eq("id", birthID)
            .queryForFirst()

        if (birthCard != null) {
            birthCard.label = newLabel
            getBirthCardDao().update(birthCard)
        }
    }

    fun updateMrgCardLabel(mrgID: Long, newLabel: LabelDataManiya?) {
        getMrgCardDao().queryBuilder()
            .where()
            .eq("id", mrgID)
            .query()
        val mrgCard = getMrgCardDao().queryBuilder()
            .where()
            .eq("id", mrgID)
            .queryForFirst()

        if (mrgCard != null) {
            mrgCard.label = newLabel
            getMrgCardDao().update(mrgCard)
        }
    }

    fun updateSIMCardLabel(simID: Long, newLabel: LabelDataManiya?) {
        getSIMCardDao().queryBuilder()
            .where()
            .eq("id", simID)
            .query()
        val simCard = getSIMCardDao().queryBuilder()
            .where()
            .eq("id", simID)
            .queryForFirst()

        if (simCard != null) {
            simCard.label = newLabel
            getSIMCardDao().update(simCard)
        }
    }

    fun updatePasswordCardLabel(passwordID: Long, newLabel: LabelDataManiya?) {
        getPasswordCardDao().queryBuilder()
            .where()
            .eq("id", passwordID)
            .query()
        val passwordCard = getPasswordCardDao().queryBuilder()
            .where()
            .eq("id", passwordID)
            .queryForFirst()

        if (passwordCard != null) {
            passwordCard.label = newLabel
            getPasswordCardDao().update(passwordCard)
        }
    }

    fun updateCustomCardLabel(customID: Long, newLabel: LabelDataManiya?) {
        getCustomCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .query()
        val customCard = getCustomCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .queryForFirst()

        if (customCard != null) {
            customCard.label = newLabel
            getCustomCardDao().update(customCard)
        }
    }
    fun updatePANCardLabel(customID: Long, newLabel: LabelDataManiya?) {
        getPANCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .query()
        val panCard = getPANCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .queryForFirst()

        if (panCard != null) {
            panCard.label = newLabel
            getPANCardDao().update(panCard)
        }
    }
    fun updateAdharCardLabel(customID: Long, newLabel: LabelDataManiya?) {
        getAdharCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .query()
        val adharCard = getAdharCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .queryForFirst()

        if (adharCard != null) {
            adharCard.label = newLabel
            getAdharCardDao().update(adharCard)
        }
    }
    fun updateVoterCardLabel(customID: Long, newLabel: LabelDataManiya?) {
        getVoterCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .query()
        val voterCard = getVoterCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .queryForFirst()

        if (voterCard != null) {
            voterCard.label = newLabel
            getVoterCardDao().update(voterCard)
        }
    }
    fun updateVehicleCardLabel(customID: Long, newLabel: LabelDataManiya?) {
        getVehicleCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .query()
        val vehicleCard = getVehicleCardDao().queryBuilder()
            .where()
            .eq("id", customID)
            .queryForFirst()

        if (vehicleCard != null) {
            vehicleCard.label = newLabel
            getVehicleCardDao().update(vehicleCard)
        }
    }
}